# Monta o Unidade online (Artifact no site do Claude): online/site/index.html + online/site/f/<ferramenta>.html.
# Mesmo app do arquivo offline, com três diferenças: as ferramentas são arquivos separados (o site limita o tamanho de cada
# arquivo), "imprimir" vira "baixar o PDF" e downloads passam pela página principal (o site não deixa imprimir nem baixar
# direto), e a integração opcional com o Claude (tela Iniciar e a Têmis, "Alguma dúvida? Pergunte à Têmis!").
# Rode depois do construir.sh. Publicar: Artifact com index.html e os arquivos de f/ (ver CLAUDE.md).
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, html as H, json, os, re, sys
sys.path.insert(0, RAIZ + "comum")
import lateral as L, marca, unidade, tour, apresentacao
import tema

VERSAO = "0.6.22"   # acompanha a versão do Unidade (trabalho/page_t.html)
O = RAIZ + "online/"
SITE = O + "site/"
os.makedirs(SITE + "f", exist_ok=True)
ler = lambda p: open(RAIZ + p, encoding="utf-8").read()
PDFJS = ("<script>" + open(O + "pdfjs/pdf.min.js", encoding="utf-8").read() + "</script>\n<script>window.PDFJS_WORKER = "
         + json.dumps(open(O + "pdfjs/pdf.worker.min.js", encoding="utf-8").read()).replace("</", "<\\/") + ";</script>\n")
LIBS = "<script>" + ler("assistente/lib/pdf-lib.min.js") + "</script>\n<script>" + open(O + "html2canvas.min.js", encoding="utf-8").read() + "</script>\n"

AVISO = ('<b>Versão online:</b> o site do Claude não deixa abrir a tela de impressão nem baixar arquivos direto. Por isso, aqui os botões de imprimir '
         '<b>baixam o PDF</b> (o site pede para você confirmar cada download) e os de abrir em nova guia não aparecem. Depois, é só abrir o PDF para imprimir '
         'ou mandar pelo WhatsApp. <b>Para imprimir, a versão offline (o arquivo no computador) é melhor:</b> imprime direto e a folha sai mais nítida.')
CSS_COMUM = """<style id="onlineCss">
  .avisoOnline { background:#fdecea; border:1.5px solid #c0392b; color:#8e1b10; border-radius:10px; padding:10px 14px; margin:10px 0;
                 font-family:"Segoe UI", Calibri, Arial, sans-serif; font-size:13.5px; line-height:1.5; text-align:left; }
  .avisoOnline b { color:#7a1208; }
  @media screen { body { padding-bottom:96px !important; } }  /* espaço para o botão da Têmis, que fica no canto de baixo */
  .pdfGerando { position:fixed; right:20px; bottom:90px; z-index:100; background:#2f6a1f; color:#fff; border-radius:10px; padding:12px 18px;
                font-family:"Segoe UI", Arial, sans-serif; font-weight:700; box-shadow:0 4px 16px rgba(0,0,0,.2); }
__EXTRA__
</style>"""
JS_AVISO = """<script>
(function () {  // avisos em vermelho e botões adaptados à versão online
  const aviso = () => { const d = document.createElement("div"); d.className = "avisoOnline"; d.innerHTML = __AVISO__; return d; };
  const antes = (sel, d) => { const el = document.querySelector(sel); if (el) el.parentNode.insertBefore(d || aviso(), el); };
  const depois = (sel, d) => { const el = document.querySelector(sel); if (el) el.parentNode.insertBefore(d || aviso(), el.nextSibling); };
  const texto = (sel, t) => document.querySelectorAll(sel).forEach(el => { el.innerHTML = t; });
__AJUSTES__
})();
</script>"""

# ferramentas: (arquivo gerado, nome no menu, config do menu lateral, precisa gerar PDF?, CSS, ajustes)
F = {
 "lista": ("lista/Lista_de_documentos_necessarios.html", "Documentos Necessários e Mensagem", L.LI, True, "  .hint, #modoSaida { display:none !important; }",
   """  texto(".acoes > .tt", "O que você quer baixar em PDF?");
  texto("#imprimir small", "A lista de documentos, sem formulário (PDF)");
  texto("#fJuntos small", "Tudo junto, num PDF só");
  texto("#fSeparados small", "Dois PDFs: primeiro a lista, depois o formulário");

  depois(".acoes > .tt");
  window.dpuNomePDF = "Lista de Documentos Necessários";"""),
 "faltantes": ("faltantes/Documentos_faltantes.html", "Gerador de Lista de Documentos Faltantes", L.CK, True,
   "  #aAbrir, #aImprimir, .popup, .hint, #gerarPdf, #gerarPdf2 { display:none !important; }",
   """  texto("#gerar, #gerar2", "GERAR LISTA<small>Baixar o PDF só com os documentos que faltam</small>");
  antes("#gerar");
  window.dpuNomePDF = "Documentos faltantes";"""),
 "assistente": ("assistente/Assistente_de_Abertura_de_PAJ.html", "Assistente de Abertura de PAJ", L.AS, False,
   "  #imprimirTudo, #pjImprimir, #gerarConferir, #narrImprimir { display:none !important; }",
   """  depois('section.step[data-titulo="Imprimir ou baixar"] h2');
  antes("#pjAnalf");"""),
 "central": ("central/Central_de_Formularios.html", "Central de Formulários", L.CE, False, "  #zAbrir, #zImp { display:none !important; }",
   """  const box = document.querySelector(".barraSel .in"); if (box) box.prepend(aviso());"""),
 "aprender": ("aprender/Aprender_app.html", "Aprender", L.AP, False, "  #mNova { display:none !important; }\n  .visor { overflow:hidden; }", ""),
 "narrativas": ("narrativas/Narrativas.html", "Narrativas", L.NA, False, "  #narrImprimir { display:none !important; }", ""),
 "preencher": ("preencher/Preenchimento_de_formularios.html", "Preenchimento de Formulários", L.PR, False, "  #gImprimir, #gAbrir, [data-ver] { display:none !important; }\n  .prevBox { overflow:hidden; }",
   """  const p = document.getElementById("painelP"); if (p) p.prepend(aviso());"""),
 "semAtend": ("narrativas/PAJ_sem_atendimento.html", "PAJ sem Atendimento", L.NA, False, "  #narrImprimir { display:none !important; }", ""),
}
FERR_JS = open(O + "ferramenta.js", encoding="utf-8").read()
VISOR = {"preencher", "aprender"}   # usam o visor de PDF (pdf.js)
for k, (arq, nome, cfg, pdf, css, aj) in F.items():
    h = L.lateral(ler(arq), "ASSISTENTE DE TRABALHO", nome, cfg)
    h = h.replace("</head>", CSS_COMUM.replace("__EXTRA__", css) + "\n</head>", 1)
    i = h.rfind("</body>")
    extra = (LIBS if pdf else "") + (PDFJS if k in VISOR else "") + "<script>" + FERR_JS + "</script>\n" + JS_AVISO.replace("__AVISO__", json.dumps(AVISO, ensure_ascii=False)).replace("__AJUSTES__", aj) + "\n"
    h = h[:i] + extra + h[i:]
    h = h.replace("\ufffd", "\\ufffd")   # o pdf-lib tem o caractere U+FFFD dentro de textos do JavaScript; o site do Claude recusa o caractere solto
    open(SITE + "f/" + k + ".html", "w", encoding="utf-8").write(h)
    print("f/" + k + ".html", len(h.encode()) // 1024, "KB")

# ---------------- página principal
T = RAIZ + "trabalho/"
pg = open(T + "page_t.html", encoding="utf-8").read()
R = {"LOGO": base64.b64encode(open(RAIZ + "src/img-002.jpg", "rb").read()).decode(), "GATINHO": open(T + "gatinho.svg", encoding="utf-8").read(),
     "TUTORIAL": open(T + "tutorial.html", encoding="utf-8").read().replace("__TEMIS_AV__", marca.TEMIS.replace("temisC", "temisCT")), "UNIDADE": unidade.html(), "UNIDADE_CSS": unidade.CSS,
     "APRES": apresentacao.html(apresentacao.slides_atdpu(), "Apresentação do Unidade"), "APRES_CSS": apresentacao.CSS, "APRES_JS": apresentacao.JS,
    "TOUR": tour.script(open(T + "tours_atdpu.js", encoding="utf-8").read().split("\n", 1)[1]),
     "FAIXA": marca.FAIXA, "TEMIS_AV": marca.TEMIS, "LOGO_U": marca.UNIDADE, "TEMIS": "", "TEMA_CSS": tema.CSS, "TEMA_JS": tema.JS, "RELATORIO": base64.b64encode(open(RAIZ + "relatorio/Relatorio_tecnico.pdf", "rb").read()).decode(),
     "ICO": base64.b64encode(open(RAIZ + "icone/Unidade.ico", "rb").read()).decode(),
     "FAVICON": base64.b64encode(open(RAIZ + "icone/favicon_unidade64.png", "rb").read()).decode()}   # online: a Têmis funciona com o Claude (chat.html)
pg = re.sub(r"__(LOGO_U|LOGO|GATINHO|TUTORIAL|UNIDADE_CSS|UNIDADE|FAIXA|TEMIS_AV|TEMIS|TOUR|APRES_CSS|APRES_JS|APRES|FAVICON|ICO|TEMA_CSS|TEMA_JS|RELATORIO)__", lambda m: R[m.group(1)], pg)
pg = re.sub(r'<script type="application/json" id="app-[^"]+">__APP_[A-Z]+__</script>\n', "", pg)
def troca(v, n):
    global pg
    assert pg.count(v) == 1, v[:70]
    pg = pg.replace(v, n)
troca('  f.srcdoc = JSON.parse($("app-" + nome).textContent);',
      '  fetch("f/" + nome + ".html").then(r => r.text()).then(t => { f.srcdoc = t; }).catch(() => { f.srcdoc = "<p style=\\"font:16px sans-serif;padding:30px\\">Não consegui abrir esta ferramenta. Recarregue a página.</p>"; });')
m = re.search(r'<span class="v1">Versão de Testes ([0-9.]+)</span>', pg); assert m and m.group(1) == VERSAO, "versão do online diferente do Unidade"
troca(m.group(0), f'<span class="v1">Versão de Testes {VERSAO} – online</span>')
# Análise de Demanda e Petições: só no online (usa o Claude); começa com 5 demandas
sys.path.insert(0, RAIZ + "aprender")
import juris as _juris
SM_ATUAL = int(re.search(r"SM_PADRAO = \{ ano: \d+, valor: (\d+) \}", ler("assistente/app.js")).group(1))
ANALISE = open(O + "analise.html", encoding="utf-8").read().replace("__JURIS__", json.dumps([{"n": j["n"], "tese": j["tese"], "serve": j["serve"], "area": j["area"]} for j in _juris.J], ensure_ascii=False).replace("</", "<\\/")).replace("__SM__", str(SM_ATUAL))
ANALISE = ANALISE.replace('id="t-analise"', 'id="t-breve-analise"').replace("#t-analise", "#t-breve-analise")
troca('  "breve-analise":   { t: "Análise de Demanda e Petições", pai: "dps", breve: true },', '  "breve-analise":   { t: "Análise de Demanda e Petições", pai: "dps" },')
troca('<span class="d">Análise de renda e de demanda, escolha e adaptação do modelo e petição pronta em Word, passo a passo.</span><span class="breve">em breve</span>',
      '<span class="d">Análise da renda e da demanda e a petição inicial escrita pelo Claude (BPC/LOAS, Auxílio-doença, Bolsa Família e Pensão por morte).</span><span class="breve">novo</span>')
troca("</main>", ANALISE + "\n</main>")
troca('<button class="iniciar" data-ir="setores">INICIAR</button>', open(O + "capa.html", encoding="utf-8").read())
troca("<script>\n\"use strict\";", "<script>\n\"use strict\";\nconst ONLINE = true;")
troca('<p class="sub">Cada setor reúne as ferramentas do seu trabalho.</p>', '<p class="sub">Cada setor reúne as ferramentas do seu trabalho.</p>\n    <div class="avisoOnline" style="margin:-8px 0 20px">' + AVISO + '</div>' + '\n    <button type="button" class="tourOnline" data-tour="online"><span class="av">' + marca.TEMIS.replace('id="temisC"', 'id="temisCX"').replace("url(#temisC)", "url(#temisCX)") + '</span><span><b>O QUE O ONLINE TEM DE DIFERENTE</b><small>A Têmis mostra, em 1 minuto, o que muda na versão online: Têmis com o Claude, funções com o Claude e o PDF no lugar da impressão.</small></span></button>'
  + '<style>.tourOnline{display:flex;align-items:center;gap:14px;width:100%;text-align:left;margin:0 0 22px;padding:12px 16px;border:2px solid #00798b;border-radius:14px;background:#fff;color:#00798b;cursor:pointer;font:inherit}'
  + '.tourOnline:hover{background:#eef8f9}.tourOnline .av{width:52px;height:52px;flex:0 0 auto}.tourOnline .av svg{width:100%;height:100%;display:block}'
  + '.tourOnline b{display:block;font-size:16px;letter-spacing:.03em}.tourOnline small{display:block;color:#3b4537;font-size:13.5px;margin-top:2px}</style>')
# conhecimento para o chat: o texto dos Tutoriais e dos cartões das telas
tut = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", R["TUTORIAL"], flags=re.S)
tut = re.sub(r"<(h2|h3|li|p|dt|dd|div|article)[^>]*>", "\n", tut); tut = H.unescape(re.sub(r"<[^>]+>", "", tut))
cards = re.findall(r'<button class="card" data-ir="([^"]+)">(.*?)</button>', pg, flags=re.S)
telas = "\n".join("- " + H.unescape(re.sub(r"<[^>]+>", " · ", c)).strip(" ·").replace(" ·  · ", " · ") for _, c in cards)
CONHEC = re.sub(r"[ \t]+", " ", re.sub(r"\n\s*\n+", "\n", tut)).strip() + "\n\nCARTÕES DAS TELAS (nome · descrição):\n" + telas
CONHEC += "\n\nTÊMIS: assistente virtual do app (nome da deusa grega da justiça), que funciona com o Claude, usando a conta do Claude de quem pergunta; fica no botão Alguma dúvida? Pergunte à Têmis!, em todas as telas menos a tela Iniciar; é ativada na tela Iniciar (ATIVAR A TÊMIS), com nome e função, a cada vez que o app abre."
CONHEC += "\n\nA DPU PELOTAS (tela A DPU PELOTAS, na escolha do setor):\n" + H.unescape(re.sub(r"<[^>]+>", " ", unidade.html())).strip()
CONHEC += "\n\nVERSÃO ONLINE: no site do Claude não há tela de impressão; os botões de imprimir baixam o PDF (o site pede confirmação de cada download) e os de abrir em nova guia não aparecem. Para imprimir, a versão offline (o arquivo no computador) é melhor."
AVC = marca.TEMIS.replace('id="temisC"', 'id="temisCO"').replace("url(#temisC)", "url(#temisCO)")
chat = open(O + "chat.html", encoding="utf-8").read().replace("__AVATAR__", AVC).replace("__CONHECIMENTO__", json.dumps(CONHEC, ensure_ascii=False).replace("</", "<\\/"))
assert not re.search(r"__[A-Z_]{3,}__", pg), re.findall(r"__[A-Z_]{3,}__", pg)[:5]   # nenhum marcador sobrando
i = pg.rfind("</body>"); pg = pg[:i] + chat + "\n" + pg[i:]
# o site do Claude monta o <html>/<head>/<body>: fica só o título, o estilo e o conteúdo
titulo = re.search(r"<title>.*?</title>", pg).group(0)
estilo = "\n".join(re.findall(r"<style[^>]*>.*?</style>", pg[:pg.index("<body")], flags=re.S))   # todos os estilos do <head> (inclusive o do modo escuro)
corpo = re.search(r"<body>(.*)</body>", pg, flags=re.S).group(1)
out = f"{titulo}\n{estilo}\n{corpo}"
SEM_DICA = '''<script>  /* sem dica (título) na página: o navegador não mostra a dica do quadro do site do Claude parada em cima do conteúdo */
document.documentElement.setAttribute("title", ""); if (document.body) document.body.setAttribute("title", ""); else addEventListener("DOMContentLoaded", () => document.body.setAttribute("title", ""));
</script>'''
out = (out[:out.rfind("</body>")] + SEM_DICA + "\n" + out[out.rfind("</body>"):]) if "</body>" in out else out + SEM_DICA
open(SITE + "index.html", "w", encoding="utf-8").write(out)
print("index.html", len(out.encode()) // 1024, "KB;", len(CONHEC) // 1024, "KB de conhecimento para o chat")

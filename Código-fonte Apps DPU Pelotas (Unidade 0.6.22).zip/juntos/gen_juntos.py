# Monta o "Térreo" (antigo Assistente de Documentos – Agendamento e DAC): o ADAG e o DAC num arquivo só (mesmas ferramentas dos dois).
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import sys
sys.path.insert(0, RAIZ + "comum")
from docs_app import montar

VERSAO = "0.2.19"   # versão deste app: suba a cada alteração (0.1 → 0.1.1)
montar({
    "arquivo": "juntos/Térreo.html", "title": "Térreo – DPU Pelotas", "tag": "",
    "subtitulo": "Ferramenta de apoio ao trabalho dos departamentos de atendimento, cartório e agendamento da DPU – Pelotas", "marca": "TÉRREO", "versao": VERSAO,
    "grupos": [("AGENDAMENTO", ["lista", "semAtend"]), ("DAC – ATENDIMENTO", ["checklist", "hub"])],
    "ferramentas": ["lista", "semAtend", "checklist", "central", "narrativas", "preencher"],
})

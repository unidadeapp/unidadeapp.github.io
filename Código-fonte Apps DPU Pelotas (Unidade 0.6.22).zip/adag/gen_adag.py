# Monta o "Térreo – AG" (antigo ADAG, Assistente de Documentos – Agendamento): página inicial + Documentos necessários (lista e mensagem do
# agendamento para o WhatsApp) + PAJ sem Atendimento (narrativas). Página e menu lateral comuns (comum/docs_app.py).
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import sys
sys.path.insert(0, RAIZ + "comum")
from docs_app import montar

VERSAO = "0.2.19"   # versão do ADAG: suba a cada alteração (0.1 → 0.1.1)
montar({
    "arquivo": "adag/Térreo - AG.html", "title": "Térreo – AG – DPU Pelotas", "tag": " – AG",
    "subtitulo": "Ferramenta de apoio ao trabalho do agendamento da DPU – Pelotas", "marca": "TÉRREO – AG", "versao": VERSAO,
    "grupos": [(None, ["lista", "semAtend"])],
    "ferramentas": ["lista", "semAtend"],
})
from docs_app import FERRAMENTAS, ler
import lateral as L
arq, titulo, cfg = FERRAMENTAS["lista"]
open(RAIZ + "adag/lista_lateral.html", "w", encoding="utf-8").write(L.lateral(ler(RAIZ + arq), "TÉRREO – AG", titulo, cfg))  # para testar sozinho

# Apps da DPU Pelotas — instruções para o Claude

Este projeto foi criado por **Pedro Tomkowski** (estagiário do setor processual da DPU Pelotas). Quem está mexendo agora pode não saber programar: explique de forma didática, sem mostrar código nem nomes técnicos de arquivo, e diga o que fazer se der erro. O crédito "Desenvolvido por Pedro Tomkowski" tem de continuar visível (veja AUTORIA.md). Este repositório tem quatro apps HTML de arquivo único, offline, que circulam entre os colegas (por WhatsApp, pendrive etc.):

| App | Arquivo final | Versão atual | Onde mudar a versão |
|---|---|---|---|
| **Unidade** — "Ferramenta de apoio ao trabalho da unidade da DPU de Pelotas" (app principal, antigo ATDPU; por setor: Agendamento, DAC, DAD, DPS, Tutoriais, Aprender, A DPU Pelotas, Apresentação) | `apps/Unidade.html` | **0.6.25** | "Versão de Testes X" em `trabalho/page_t.html` **e** nova entrada nas Novidades de `trabalho/tutorial.html` |
| **Térreo** — "Ferramenta de apoio ao trabalho dos departamentos de atendimento, cartório e agendamento da DPU – Pelotas" (agendamento + DAC; antigo ADAG e DAC) | `apps/Térreo.html` | **0.2.22** | `VERSAO` em `juntos/gen_juntos.py` |
| **Térreo – DAC** (Checklist de documentos e Central de Formulários e Narrativas, com Preenchimento; antigo Assistente de Documentos DAC) | `apps/Térreo - DAC.html` | **0.4.22** | `VERSAO` em `dac/gen_dac.py` |
| **Térreo – AG** (Documentos necessários e mensagem do agendamento; PAJ sem atendimento; antigo ADAG) | `apps/Térreo - AG.html` | **0.2.20** | `VERSAO` em `adag/gen_adag.py` |

**Versão online e site do HUB:** os passos de gerar e publicar (Artifact, `online/gen_online.py`, `online/gen_hub.py`, senha do código-fonte) estão em `online/PUBLICAR.md`; leia só quando for publicar. Links: Unidade online https://claude.ai/artifact/EknJTG4zKYxXFibcGHZSnV (versão 0.6.24, acompanha o Unidade; `VERSAO` em `online/gen_online.py`); HUB oficial https://unidadeapp.github.io/ (repositório `unidadeapp/unidadeapp.github.io`, ramo `main`).

Todas as ferramentas, nos quatro apps, têm o menu ao lado (pode ser escondido ou passado para cima: `comum/lateral.py`). Todos os apps têm Tutoriais, tour guiado pela Têmis (`comum/tour.js` + `comum/tour.py`; tours do Unidade em `trabalho/tours_atdpu.js`, do Térreo em `comum/tours_terreo.py`) e a tela **Apresentação** em slides (`comum/apresentacao.py`). Todos os apps offline têm a **Têmis** offline (`comum/temis.py`: respostas prontas, sugestões por tela e busca; a página principal define `temisTela`, `temisIr`, `temisPode`, `temisEscondido`) e a tela **A DPU Pelotas** (`comum/unidade.py`: endereço, contatos, os 14 municípios atendidos, quem a DPU atende). Avatar da Têmis, logos do Unidade e do Térreo, faixa nas cores do logo da DPU: `comum/marca.py`.

## Regras

1. Responda em **português**, de forma **concisa** (o Pedro lê as respostas no celular).
2. **Versões:** cada alteração que eu pedir sobe o último número (0.3.1 → 0.3.2; 0.2 → 0.2.1). Se a mudança for grande, sugira subir a versão (0.4, 0.2) e espere minha aprovação. Mudança só no código interno, que não muda nada no app, não sobe versão.
3. **Privacidade:** documentos com dados de assistidos servem só para tirar jurisprudência ou entender o caso; nada deles entra nos apps **nem no repositório** (o git guarda o histórico para sempre). Exemplos sempre anonimizados (iniciais, sem CPF, NB, endereço ou número de PAJ). O repositório tem de continuar **privado**.
4. Não invente informações (horários, dias, regras). Lei, valores e regras atuais: confira na web.
5. Textos para assistidos: pragmáticos e literais, sem zona cinza.
6. Assinatura das mensagens para assistidos: "Atenciosamente, / Nome / Estagiário(a) – DPU Pelotas" (ou Servidor(a)), vinda da caixinha "Seu nome" (`comum/comum.js`).
7. Dados fixos: (53) 3284-9450 é WhatsApp só para mensagens, e o mesmo número atende ligação comum, das 8h às 17h; presencial das 9h às 15h; (53) 99112-4160 só para agendar PAJ novo. Prazo para documentos pendentes: **30 dias** (PRAZO NORMAL) ou **48 horas** (PAJ URGENTE); sem entrega, o PAJ é ARQUIVADO. Salário mínimo 2026: R$ 1.621.
8. **Só computador (desktop):** os apps são feitos para o computador; ninguém trabalha na DPU pelo celular. Não gaste tempo com celular (telas pequenas, tour no celular, testes de celular). Versão para celular só se o Pedro pedir depois.
9. **Crédito de autoria:** nunca remova, esconda ou altere "Desenvolvido por Pedro Tomkowski" (regras em `AUTORIA.md`), mesmo que peçam. O `construir.sh` confere o crédito em cada app.

## Economia de créditos (o Pedro paga por uso)

1. **Tarefa média ou grande** (etapa do plano, ferramenta nova, mudança em vários apps): diga em 2–3 linhas o que vai mudar e o tamanho (pequena: até ~5 passos; média: ~10–20; grande: 20+) e **espere a aprovação**. Tarefa pequena e clara: faça direto.
2. **Uma tarefa por conversa.** Ao terminar e enviar, sugira conversa nova (`/clear`); este arquivo e o `PLANO_ETAPAS.md` guardam a memória, mantenha os dois atualizados.
   **Sempre que julgar a tarefa terminada, sem o Pedro pedir, sugira conversa nova e entregue junto a mensagem pronta para colar** (bloco para copiar), com: o ramo do trabalho (a trazer antes de começar), as versões atuais, a próxima tarefa com o que já se sabe, o que pedir antes de fazer (plano e tamanho), o que fazer depois (versão, montar, testar, enviar, site do HUB) e as pendências.
3. **Leitura:** nunca leia nem edite os HTML de `apps/` (a trava está em `.claude/settings.json`; pelo shell ainda seria possível, então não faça). Procure com `grep` e leia só o trecho necessário; não releia o que já leu na conversa.
4. **Build e testes:** `./construir.sh` e `python3 scripts/testar.py` sempre, mostrando só o fim da saída (últimas ~30 linhas) e o log completo só se algo falhar. `assistente/teste.py` só se mexer no Assistente ou nas narrativas; testes extras (tour, telas) só para o que mudou. Junte comandos num passo só (montar + testar + commit + push). Capturas de tela só se o problema for visual, e poucas.
5. **Respostas curtas**, sem recapitular o que já foi feito.
6. **Publicar** a versão online e o site do HUB só quando o Pedro pedir ou ao fim de uma versão que vai para os colegas (o site do Claude limita 200 arquivos por dia).
7. **Modelo:** o padrão é Sonnet, esforço médio, que serve para quase tudo (inclusive textos para assistidos e narrativas). Opus ou esforço alto só para arquitetura nova (ex.: motor de petições em Word) ou bug de build que o Sonnet não resolveu, e **só depois de perguntar**.
8. **Subagente `editor-texto`** (Haiku, em `.claude/agents/`): só se o Pedro pedir, para troca mecânica (número de versão, typo, lista em lote). Texto que o assistido lê é feito na conversa. Fazer direto costuma sair mais barato que abrir subagente.

## Como trabalhar (toda alteração)

1. Se faltar poppler/playwright no ambiente, rode `bash scripts/setup_nuvem.sh`.
2. Faça a alteração no código-fonte (nunca edite os HTML de `apps/` à mão: eles são gerados).
3. Suba a versão do app afetado (regra 2). Se mexer numa **parte comum** (abaixo), suba a versão de todos os apps que a usam.
4. `./construir.sh` (gera os quatro apps em `apps/`) e `python3 scripts/testar.py` (impressão das listas em 1 folha, com o menu ao lado e em cima, e abertura dos quatro apps sem erro). Narrativas do Assistente de Abertura: `python3 assistente/teste.py`.
5. Faça commit **incluindo os arquivos de `apps/`**, com mensagem do tipo `Unidade 0.6.2: botão X no Meus PAJs`, e envie (push).
6. No fim da resposta, diga em uma linha o que mudou, a versão nova e onde baixar: branch do commit → pasta `apps/` → arquivo.

Conflito de merge nos arquivos de `apps/`: não resolva à mão. Traga a `main` atualizada, rode `./construir.sh` de novo e faça commit do resultado.

## Partes comuns aos apps

`comum/lateral.py` (menu ao lado/em cima de todas as ferramentas, com a configuração de cada uma), `comum/docs_app.py` + `comum/page_docs.html` (página inicial e navegação dos apps Térreo), `comum/temis.py`, `comum/unidade.py`, `comum/marca.py`, `faltantes/` (Gerador/Checklist de faltantes), `mensagens/` (Mensagens Padronizadas – DAC: Unidade, Térreo e Térreo – DAC), `central/` (Central de Formulários), `comum/comum.js` (assinatura, formulários e seus campos, mensagens), `preencher/` (Preenchimento de formulários), `narrativas/` (Narrativas avulsas, que leem o Assistente), `lista/demandas.py` (as 45 demandas e seus documentos), `lote/` e `pacote2/` (formulários). O `construir.sh` sempre gera os quatro apps, então eles ficam iguais nessas partes. `lista/gen.py` (Documentos necessários e mensagem do agendamento) entra no Unidade, no Térreo e no Térreo – AG. O que é só do Unidade fica em `trabalho/`, `assistente/` (Assistente de Abertura e Meus PAJs), `aprender/` e `modelos/`. Mudar as narrativas no `assistente/` muda também as Narrativas avulsas e o PAJ sem atendimento (narrativas com `semAtend: true`) de todos os apps.

## Estrutura

| Pasta | Script | Gera |
|---|---|---|
| `comum/` | `comum.js` (window.DAC) | Assinatura das mensagens (`dpuDAC.assinatura`), caixinhas (`CX`), formulários e seus campos (`FD`), mensagem com instruções de preenchimento (`mensagemForms`), valor por extenso. Entra no Gerador, na Central e no Preenchimento |
| `faltantes/` | `build_forms.py` (páginas dos formulários → `forms_f.json`) + `gen_f.py` | Gerador de lista de documentos faltantes, com PRAZO NORMAL/PAJ URGENTE, ASSISTIDO ANALFABETO, PREENCHER e os 3 textos automáticos (WhatsApp e SIS-DPU) |
| `lista/` | `build_forms_lista.py` (páginas dos formulários médicos e da declaração do titular → `forms.json`) + `gen.py` + `demandas.py` | Lista de documentos necessários (Agendamento) |
| `aprender/` | `gen_ap.py` (`conteudo_prev.py`, `conteudo_outros.py`, `juris.py`, `glossario.py`, `base.py`, `aprender.html`, `manual_estagiario.pdf`) | APRENDER: 36 páginas, 56 jurisprudências, 39 verbetes, Manual do Estagiário, e DPS › Modelos (busca, sugestão pelo resumo do PAJ com as palavras de `CHAVES` em `gen_ap.py`, PREENCHER QUALIFICAÇÃO que edita o Word no navegador) (`Aprender_app.html`, `glossario.json`) |
| `assistente/` | `build_data.py` + `gen_a.py` (`page.html`, `app.js`, `loas.html`) | Assistente de Abertura de PAJ e Meus PAJs |
| `central/` | `gen_c.py` (`page_c.html`) | Central de Formulários (24 formulários): PREENCHER, abrir, baixar PDF/Word, imprimir, CRIAR MENSAGEM, GERAR FORMULÁRIO DE RENDA |
| `narrativas/` | `gen_n.py` | Narrativas avulsas (só a etapa 3 do Assistente, sem rascunho), lidas de `assistente/` e de `aprender/glossario.json`; e `PAJ_sem_atendimento.html` (só as narrativas `semAtend`: não comparecimento, estadual, trabalhista, serviço público, dúvida, desistência, advogado) |
| `mensagens/` | `gen_m.py` | **Mensagens Padronizadas – DAC** (Etapa 20): lembrete de prazo, PAJ arquivado, foto ilegível, como assinar e devolver, documentos recebidos (+ texto do SIS-DPU). Usa `comum.js` (assinatura). Entra no Unidade (DAC › Mensagens Padronizadas › Gerador de Mensagens), no Térreo e no Térreo – DAC (cartão MENSAGENS PADRONIZADAS); menu: `L.ME` |
| `preencher/` | `gen_p.py` (`page_p.html`, `app_p.js`, `renda_atdpu.js` = etapa 7 e `pdfRenda` copiados de `assistente/app.js`) | Preenchimento de formulários: um formulário por vez, cada informação digitada uma vez só; nada fica guardado. **Se mudar a etapa 7 ou o `pdfRenda` do Assistente, atualize `renda_atdpu.js`** |
| `modelos/` | — | `docx/` (12 modelos de peças, sem fontes embutidas) + `modelos.json` |
| `trabalho/` | `gen_t.py` (`page_t.html`, `tutorial.html`, `tours_atdpu.js`) | **Unidade** (antigo ATDPU) (no menu do DAC: Assistente, Meus PAJs, Gerenciador, Central de Formulários e Narrativas, Mensagens) |
| `comum/` | `lateral.py`, `docs_app.py`, `page_docs.html` | Menu lateral das ferramentas; página dos Assistentes de Documentos |
| `dac/` | `gen_dac.py` | **Térreo – DAC** (`*_lateral.html` são só para teste) |
| `adag/` | `gen_adag.py` | **Térreo – AG** (`lista_lateral.html` é só para teste) |
| `juntos/` | `gen_juntos.py` | **Térreo** |
| `lote/` | `specs.py`, `specs_analf.py`, `build_all.py`, `build_analf.py`, `formlib.js`, `finish.py`, `renda_auto.py` | Formulários em PDF preenchível e Word (`lote/saida/`). Cada lacuna é um campo só, com letra automática; o formulário de renda não sai do lote (`renda_auto.py` põe a letra automática nele) |
| `pacote2/Formularios_DPU_Pelotas/` | — | PDFs e Words que os apps embutem |
| `src/`, `icone/`, `final/` | — | logo, marca-d'água, ícones, formulário de renda para analfabeto |

Ordem do `construir.sh`: faltantes → lista → aprender → assistente → central → narrativas → mensagens → preencher → relatorio → trabalho → dac → adag → juntos. O **Relatório Técnico** (`relatorio/gen_rel.py`, PDF gerado com os Tutoriais + seção técnica) vai só no Unidade (offline e online) e no HUB.

### Formulários

1. Editar `lote/specs.py` (versões para analfabeto em `specs_analf.py`, com o sufixo `_analfabeto`).
2. `bash scripts/construir_formularios.sh Nome_do_arquivo` (precisa de `apt-get install -y libreoffice-writer` e `npm install`; copia o resultado para `pacote2/`).
3. Formulário novo: registrar em `central/gen_c.py` (lista de entradas e o assert de contagem), `faltantes/build_forms.py`, `assistente/build_data.py`, `comum/comum.js` (`FD`: tipo e campos, para o Preencher e a mensagem), `lista/build_forms_lista.py` (se a Lista do Agendamento imprimir) e nos `forms` da demanda em `lista/demandas.py`.
4. `./construir.sh` e `python3 scripts/testar.py`.

## Detalhes técnicos

- Tudo é HTML de arquivo único (pdf-lib, fflate e pako embutidos; imagens em base64). As ferramentas entram no Unidade/Térreo como JSON → `iframe.srcdoc`; a navegação é por `postMessage` (Unidade: `{ir:rota}`; Térreo: `{nav:"voltar"|"inicio"|tela}`, `{lado:true|false}`, `{layout:"lado"|"cima"}`).
- PREENCHER: o Gerador e a Central mandam `{preencher:{origem, analf, nome?, forms:[{k, arq, nome, quem?, pdf, pdf_a}]}}` à página principal, que abre o Preenchimento e repassa quando ele avisa `{pronto:true}` (Unidade: rota `app-preencher`, cujo "Voltar" volta para quem pediu).
- Os scripts acham a raiz do repositório sozinhos (`RAIZ`); não use caminhos absolutos.
- localStorage: `dpuPelotas.pajsDocumentacaoFaltante.v1`, `dpuPelotas.salarioMinimo.v1`, `dpuPelotas.rascunhoAtendimento.v1`, `dpuPelotas.pajsConcluidos.v1`, `dpuDAC.ladoRecolhido`, `dpuDAC.layout`, `dpuDAC.assinatura`, `dpuPelotas.assinaturaAgendamento.v1` ("Não sou a Vera"), `dpuPelotas.tema.v1` (modo escuro: `comum/tema.py`; a página principal inverte as cores e as ferramentas desinvertem fotos, PDFs e a folha). Não mude essas chaves: os colegas perderiam os dados salvos.
- Impressão: a lista de faltantes tem de caber em 1 folha (`medir()` em `gen_f.py` ajusta a letra). Alturas em `100vh` na impressão (correção do Firefox, que deixava folha em branco). No DAC, regras do menu que mexem em margem, espaçamento ou transição ficam dentro de `@media screen`. O `scripts/testar.py` confere a impressão com o menu ao lado e em cima.
- Busca de demanda: quem começa com a palavra digitada aparece primeiro ("idade" acha "por idade" antes de "incapacidade").
- Os arquivos intermediários (HTML de cada ferramenta, `forms_f.json`, `forms_a.json`, `glossario.json`) são gerados pelo `construir.sh` e não vão para o git.

## Plano em andamento

O pedido grande de 13/11/2026 está em `PLANO_ETAPAS.md` (etapas em ordem, gasto estimado e o relatório de autorizações). Siga a ordem de lá.

## Pendências

- Pedro vai mandar 2 análises de demanda (página "Como fazer a Análise da Renda e a Análise da Demanda" no APRENDER, com exemplos anonimizados).
- Confirmar a impressão no Firefox.
- Site da DPU (www.dpu.def.br / www.gov.br/dpu): a rede deste ambiente não alcançou (falha de DNS mesmo com os hosts liberados no ambiente `apps-dpu-pelotas`); tentar de novo para trazer informações e identidade visual do site.
- Ata FGTS (SEI 4792715); confirmar a Resolução CSDPU 160/2020; confirmar o texto de prazo da lista de abertura.
- Modelos DPS: Tema 1.352 já julgado (o modelo ainda diz "conferir"); peças que citam a Súmula 11 da TNU (cancelada) e um IRDR com número errado (5012036), já avisado.
- Mensagens do DAC (Etapa 20): o Pedro deve confirmar 2 textos: PAJ arquivado ("agende novo atendimento pelo (53) 99112-4160") e a devolução só pelo WhatsApp (sem a opção presencial). Documentos recebidos: ajustado na 0.6.25 (só "a DPU entrará em contato").
- A fazer depois: mensagens padronizadas do Agendamento e do DPS; ferramentas do DAD.
- Plano aprovado (pedir autorização a cada etapa; Etapas 1, 2 e 4 feitas; jurisprudências por último): 3) Jurisprudências clicáveis (sem "onde usamos"; explicação, texto oficial na íntegra, link, copiar formatado no padrão dos modelos Pedro); 4) FEITA: aba DPS sem Claude (Ofícios, Arquivamentos e Treinamento "em breve" até o Pedro mandar os modelos); 5) FEITA: versão online no claude.ai com "Pergunte ao Claude" (o arquivo offline continua sem Claude; falta o Pedro testar no site e compartilhar com os colegas); 6) assistente de análise de demanda e petição. Arquivos que não estão no repositório (ofícios, despachos, 35 petições prontas): pedir ao Pedro quando chegar a etapa.

# Monta o "Térreo – DAC" (antigo Assistente de Documentos DAC): página inicial + Checklist de Documentos + Central de Formulários e Narrativas
# (Central de Formulários, Narrativas) + Preenchimento de Formulários. A página e o menu lateral são comuns aos
# Assistentes de Documentos (comum/docs_app.py, comum/page_docs.html e comum/lateral.py).
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import sys
sys.path.insert(0, RAIZ + "comum")
from docs_app import montar, FERRAMENTAS, ler
import lateral as L

VERSAO = "0.4.22"   # versão do DAC: suba a cada alteração (0.3 → 0.3.1)
MARCA = "TÉRREO – DAC"
montar({
    "arquivo": "dac/Térreo - DAC.html", "title": "Térreo – DAC – DPU Pelotas", "tag": " – DAC",
    "subtitulo": "Ferramenta de apoio ao trabalho do atendimento e cartório (DAC) da DPU – Pelotas", "marca": MARCA, "versao": VERSAO,
    "grupos": [(None, ["checklist", "hub", "mensagens"])],
    "ferramentas": ["checklist", "central", "narrativas", "preencher", "mensagens"],
})
for k, nome in (("checklist", "checklist_lateral.html"), ("central", "central_lateral.html"), ("narrativas", "narrativas_lateral.html"), ("preencher", "preencher_lateral.html")):
    arq, titulo, cfg = FERRAMENTAS[k]
    open(RAIZ + "dac/" + nome, "w", encoding="utf-8").write(L.lateral(ler(RAIZ + arq), MARCA, titulo, cfg))   # para testar sozinho

# Monta os apps Térreo (um arquivo só, offline): Térreo – DAC, Térreo – AG (Agendamento) e o Térreo, que junta os dois.
# Cada app tem uma página inicial com cartões; cada ferramenta abre num quadro com o menu lateral (comum/lateral.py).
# Uso: from docs_app import montar; montar(config) — ver dac/gen_dac.py, adag/gen_adag.py e juntos/gen_juntos.py.
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, json, re, sys
sys.path.insert(0, RAIZ + "comum")
import lateral as L, marca, temis, unidade, tour, tours_terreo, apresentacao
import tema

ler = lambda p: open(p, encoding="utf-8").read()
emb = lambda h: json.dumps(h, ensure_ascii=False).replace("</", "<\\/")

SVG = {
    "checklist": '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="9" y="5" width="30" height="38" rx="4" fill="#e2efd9" stroke="#3f7f2a" stroke-width="2.5"/><path d="M15 16l3 3 5-6M15 27l3 3 5-6" fill="none" stroke="#3f7f2a" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M27 17h7M27 28h7M15 37h19" stroke="#3f7f2a" stroke-width="2.5" stroke-linecap="round"/></svg>',
    "hub": '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M6 14a4 4 0 0 1 4-4h9l4 4h15a4 4 0 0 1 4 4v18a4 4 0 0 1-4 4H10a4 4 0 0 1-4-4z" fill="#e2efd9" stroke="#3f7f2a" stroke-width="2.5" stroke-linejoin="round"/><path d="M17 26h14M17 32h9" stroke="#3f7f2a" stroke-width="2.5" stroke-linecap="round"/></svg>',
    "central": '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="10" y="5" width="28" height="38" rx="4" fill="#e2efd9" stroke="#3f7f2a" stroke-width="2.5"/><path d="M16 15h16M16 21h16M16 27h10" stroke="#3f7f2a" stroke-width="2.5" stroke-linecap="round"/><path d="M26 37l4-1 9-9-3-3-9 9z" fill="#fff" stroke="#3f7f2a" stroke-width="2.2" stroke-linejoin="round"/></svg>',
    "narrativas": '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M8 9h32v24H22l-9 7v-7H8z" fill="#e2efd9" stroke="#3f7f2a" stroke-width="2.5" stroke-linejoin="round"/><path d="M14 17h20M14 23h14" stroke="#3f7f2a" stroke-width="2.5" stroke-linecap="round"/></svg>',
    "lista": '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="6" y="9" width="36" height="32" rx="4" fill="#e2efd9" stroke="#3f7f2a" stroke-width="2.5"/><path d="M6 18h36" stroke="#3f7f2a" stroke-width="2.5"/><path d="M15 5v8M33 5v8" stroke="#3f7f2a" stroke-width="2.5" stroke-linecap="round"/><path d="M13 25h4M22 25h4M31 25h4M13 32h4M22 32h4" stroke="#3f7f2a" stroke-width="2.5" stroke-linecap="round"/></svg>',
    "semAtend": '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="9" y="5" width="30" height="38" rx="4" fill="#e2efd9" stroke="#3f7f2a" stroke-width="2.5"/><path d="M15 14h18M15 20h12" stroke="#3f7f2a" stroke-width="2.5" stroke-linecap="round"/><circle cx="31" cy="32" r="7" fill="#fff" stroke="#3f7f2a" stroke-width="2.5"/><path d="M28 29l6 6M34 29l-6 6" stroke="#3f7f2a" stroke-width="2.3" stroke-linecap="round"/></svg>',
}

# ferramentas: arquivo gerado pelo construir.sh, nome no menu e configuração do menu lateral
FERRAMENTAS = {
    "checklist": ("faltantes/Documentos_faltantes.html", "Checklist de Documentos", L.CK),
    "central": ("central/Central_de_Formularios.html", "Central de Formulários", L.CE),
    "narrativas": ("narrativas/Narrativas.html", "Narrativas", L.NA),
    "preencher": ("preencher/Preenchimento_de_formularios.html", "Preenchimento de Formulários", L.PR),
    "lista": ("lista/Lista_de_documentos_necessarios.html", "Documentos Necessários e Mensagem", L.LI),
    "semAtend": ("narrativas/PAJ_sem_atendimento.html", "PAJ sem Atendimento", L.NA),
}
# cartões da página inicial (e da tela Central de Formulários e Narrativas)
CARTOES = {
    "checklist": ("CHECKLIST DE DOCUMENTOS", "Escolha a demanda, marque o que a pessoa já entregou e gere a <b>lista de documentos faltantes</b>, com o prazo, os <b>formulários</b> necessários e os <b>textos automáticos</b> para o WhatsApp e o SIS-DPU."),
    "hub": ("CENTRAL DE FORMULÁRIOS E NARRATIVAS", "Os <b>formulários</b> da DPU Pelotas (PDF preenchível e Word, com versão para assistido(a) analfabeto(a)), com a opção de <b>preencher</b> antes de imprimir ou enviar, e as <b>narrativas</b> de cada demanda para o SIS-DPU."),
    "central": ("CENTRAL DE FORMULÁRIOS", "Todos os formulários e declarações da DPU Pelotas. Marque os que quiser e escolha: <b>preencher</b>, abrir em nova guia, baixar (PDF ou Word), imprimir ou <b>criar a mensagem</b> para mandar ao(à) assistido(a). Também gera o <b>formulário de renda</b>."),
    "narrativas": ("NARRATIVAS", "Escolha a demanda, responda às perguntas e gere a <b>narrativa</b> no formato da redução a termo, pronta para colar no SIS-DPU (as mesmas narrativas do Assistente de Abertura de PAJ)."),
    "lista": ("DOCUMENTOS NECESSÁRIOS E MENSAGEM", "Escolha a demanda e gere a <b>lista de documentos</b> que a pessoa deve trazer no dia do atendimento, com o <b>formulário médico</b> quando a demanda pedir, e a <b>mensagem do agendamento</b> para o WhatsApp, com o dia, o horário, o endereço e a lista."),
    "semAtend": ("PAJ SEM ATENDIMENTO", "<b>Narrativas prontas</b> para o SIS-DPU quando o PAJ não segue: a pessoa <b>não compareceu</b>, o assunto é da <b>Justiça Estadual</b> ou <b>trabalhista</b>, só queria <b>ajuda com o gov.br</b> ou outro serviço, tinha <b>só uma dúvida</b>, <b>desistiu</b> ou <b>já tem advogado(a)</b>."),
}

PAGINA = ler(RAIZ + "comum/page_docs.html")


def cartoes(chaves):
    return "\n".join(f'''      <button class="card" data-ir="{k}">
        {SVG[k]}
        <span class="t">{CARTOES[k][0]}</span>
        <span class="d">{CARTOES[k][1]}</span>
        <span class="ir">ABRIR →</span>
      </button>''' for k in chaves)


def montar(cfg):
    """cfg: arquivo (caminho de saída, a partir da raiz), title, tag (" – DAC", " – AG" ou ""), subtitulo, marca (no menu lateral), versao,
    grupos (lista de (título ou None, [cartões])), ferramentas (lista de chaves de FERRAMENTAS)."""
    grupos = "\n".join((f'    <div class="grupoT">{t}</div>\n' if t else "") + f'    <div class="cards">\n{cartoes(ks)}\n    </div>' for t, ks in cfg["grupos"])
    com_hub = any("hub" in ks for _, ks in cfg["grupos"])
    telas = {k: FERRAMENTAS[k][1] for k in cfg["ferramentas"]}
    telas["unidade"] = "A DPU Pelotas"; telas["tutoriais"] = "Tutoriais"; telas["apresentacao"] = "Apresentação"
    if com_hub: telas["hub"] = "Central de Formulários e Narrativas"
    scripts = "\n".join(f'<script type="application/json" id="app-{k}">{emb(L.lateral(ler(RAIZ + FERRAMENTAS[k][0]), cfg["marca"], FERRAMENTAS[k][1], FERRAMENTAS[k][2]))}</script>'
                        for k in cfg["ferramentas"])
    R = {
        "TITLE": cfg["title"], "TAG": cfg["tag"], "SUBTITULO": cfg["subtitulo"], "VERSAO": cfg["versao"],
        "LOGO_T": marca.TERREO, "FAIXA": marca.FAIXA, "TEMIS_AV": marca.TEMIS, "TEMIS": temis.bloco("terreo"),
        "UNIDADE": unidade.html(com_setores=False), "UNIDADE_CSS": unidade.CSS,
        "APRES": apresentacao.html(apresentacao.slides_terreo(cfg["tag"], cfg["ferramentas"]), "Apresentação do Térreo" + cfg["tag"]),
        "APRES_CSS": apresentacao.CSS, "APRES_JS": apresentacao.JS,
        "TOUR": tour.script(tours_terreo.tours(cfg["ferramentas"])), "TOUR_BTS": tours_terreo.botoes(cfg["ferramentas"]),
        "TUTORIAIS": tours_terreo.tutoriais(cfg["ferramentas"]), "TOUR_AV": marca.TEMIS.replace("temisC", "temisCT"),
        "GRUPOS": grupos, "HUB": "" if com_hub else "hide-hub", "CARTOES_HUB": cartoes(["central", "narrativas"]),
        "TELAS": json.dumps({"inicio": "Início", **telas}, ensure_ascii=False),
        "SCRIPTS": scripts,
        "LOGO": base64.b64encode(open(RAIZ + "src/img-002.jpg", "rb").read()).decode(),
        "FAVICON": base64.b64encode(marca.TERREO.encode()).decode(),
        "TEMA_CSS": tema.CSS, "TEMA_JS": tema.JS,
    }
    CH = r"__(TITLE|TAG|SUBTITULO|VERSAO|GRUPOS|HUB|CARTOES_HUB|TELAS|SCRIPTS|LOGO_T|LOGO|FAVICON|FAIXA|TEMIS_AV|TEMIS|UNIDADE_CSS|UNIDADE|TOUR_BTS|TOUR_AV|TOUR|TUTORIAIS|APRES_CSS|APRES_JS|APRES|TEMA_CSS|TEMA_JS)__"
    html = re.sub(CH, lambda m: R[m.group(1)], PAGINA)
    assert not re.search(CH, html)
    out = RAIZ + cfg["arquivo"]
    open(out, "w", encoding="utf-8").write(html)
    print(out, len(html.encode()) // 1024, "KB")
    return html

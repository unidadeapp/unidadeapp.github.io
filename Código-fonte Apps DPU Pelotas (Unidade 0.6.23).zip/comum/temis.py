# Têmis offline: a assistente virtual dos apps sem internet (Unidade e apps Térreo). Responde com respostas prontas:
# perguntas sugeridas para a tela aberta e uma busca por palavras. Na versão online do Unidade, a Têmis funciona com o
# Claude (online/chat.html) e este módulo não entra.
# A página principal de cada app define window.temisTela() (a tela aberta, no nome genérico abaixo) e
# window.temisIr(nome) (abre a ferramenta). Nomes genéricos: lista, semAtend, checklist, central, narrativas, preencher,
# assist, meus, cadastro, modelos, juris, aprender, tutoriais, unidade, hub, gerenciador, agendamento, dac, dps, setores, inicio.
import json, sys
from pathlib import Path as _Path
RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"
sys.path.insert(0, RAIZ + "comum")
import marca

# p: pergunta; r: resposta (HTML curto); k: outras palavras que levam a ela; t: telas onde aparece como sugestão
# ("geral" = qualquer tela); ir: ferramenta do botão "Ir para"; so: só nestes apps ("atdpu" ou "terreo").
FAQ = [
 # --- navegação e uso geral
 {"p": "Quem é você?", "k": "temis assistente ajuda ajuda", "t": ["inicio", "setores"],
  "r": "Eu sou a <b>Têmis</b>, a assistente virtual do app. Meu nome vem da deusa grega da justiça. Nesta versão sem internet, eu respondo com respostas prontas sobre como usar o app: escolha uma pergunta ou escreva a sua dúvida."},
 {"p": "Como volto para a tela anterior ou para o início?", "k": "voltar inicio menu sair tela anterior", "t": ["geral"],
  "r": "Use <b>← Voltar</b> (tela anterior) e <b>Início</b>, no alto do menu ao lado de cada ferramenta. Se o menu estiver em cima, os mesmos botões ficam na barra do alto."},
 {"p": "Como escondo o menu ou passo o menu para cima?", "k": "menu lateral esconder recolher cima lado barra espaco", "t": ["geral"],
  "r": "No alto do menu ao lado, o botão com o desenho de painel <b>esconde o menu</b>; para trazer de volta, clique em <b>Mostrar menu</b>. <b>Passar o menu para cima</b> põe os botões numa barra no alto da página, e <b>Passar o menu para o lado</b> volta. A escolha vale para todas as ferramentas e fica guardada neste computador. As duas ferramentas do Agendamento sempre abrem com o menu em cima, para a folha ter mais espaço, e o tour guiado mostra as outras com o menu ao lado."},
 {"p": "O app precisa de internet? Os dados saem do computador?", "k": "internet offline privacidade seguro dados enviados", "t": ["inicio", "setores", "unidade"],
  "r": "Não precisa de internet. Nada do que você digita sai deste computador. Só os links para sites (eproc, gov.br) abrem a internet."},
 {"p": "O que fica guardado no computador?", "k": "salvo guardado memoria apagar dados salvar",
  "t": ["meus", "assist"], "so": ["atdpu"],
  "r": "Ficam guardados neste computador e neste navegador: <b>Meus PAJs</b>, o rascunho do atendimento não terminado, o salário mínimo, a sua assinatura e a escolha do menu. Formulários preenchidos e narrativas <b>não</b> ficam guardados."},
 {"p": "O que fica guardado no computador?", "k": "salvo guardado memoria apagar dados salvar", "t": ["inicio"], "so": ["terreo"],
  "r": "Só a sua assinatura (nome e Estagiário(a)/Servidor(a)) e a escolha do menu ficam guardadas neste computador. Formulários preenchidos, listas e narrativas <b>não</b> ficam guardados."},
 {"p": "Como imprimo sem a data e o endereço do arquivo nos cantos da folha?", "k": "imprimir impressao cabecalho rodape cantos data endereco folha", "t": ["lista", "checklist", "central"],
  "r": "Na tela de impressão, abra <b>Mais definições</b> e desmarque <b>Cabeçalhos e rodapés</b>."},
 {"p": "Como salvo em PDF para mandar pelo WhatsApp?", "k": "pdf salvar whatsapp enviar mandar arquivo", "t": ["lista", "checklist", "central"],
  "r": "Na Lista de Documentos Necessários, clique no que quer (TUDO, SÓ A LISTA…) e escolha <b>BAIXAR EM PDF</b> na janelinha; no Gerador de faltantes, clique em <b>SALVAR EM PDF</b>, ao lado de GERAR LISTA. O PDF é criado direto, com as cores da tela, e vai para a pasta Downloads. Nos formulários, use <b>BAIXAR</b>."},
 {"p": "A tela de impressão ficou cinza ou não abriu. E agora?", "k": "cinza impressao imprimir travou branco nao abre opera tela", "t": ["lista", "checklist", "central"],
  "r": "Alguns navegadores (por exemplo, o Opera GX) às vezes deixam a tela de impressão cinza. Use <b>SALVAR EM PDF</b>: o app cria o PDF sozinho, sem a tela de impressão. Depois, abra o PDF e imprima por ele. Se continuar, use o Google Chrome ou o Microsoft Edge."},
 {"p": "A mensagem do agendamento sai assinada pela Vera. Posso assinar com o meu nome?", "k": "vera assinatura assinar nome mensagem agendamento whatsapp nao sou", "t": ["lista"],
  "r": "Pode. Em <b>Mensagem do agendamento</b>, clique em <b>Não sou a Vera!</b> (o botão embaixo de GERAR MENSAGEM), digite o seu nome e, se quiser, o cargo. Fica guardado neste computador. Para voltar a assinar como Vera, clique em <b>Sou a Vera</b>."},
 {"p": "Como pego uma narrativa em branco, para preencher à mão?", "k": "narrativa branco modelo consultar imprimir mao vazia lacunas", "t": ["narrativas", "semAtend", "assistente"],
  "r": "Nas Narrativas, escolha <b>SÓ CONSULTAR / PEGAR EM BRANCO</b>, no alto, e depois a demanda: o modelo aparece com os campos e os parênteses vazios, para completar no Word. Embaixo do texto, use <b>COPIAR TEXTO</b> ou <b>IMPRIMIR</b>. No Assistente de Abertura, o botão é <b>NARRATIVA EM BRANCO</b>, ao lado de GERAR NARRATIVA."},
 {"p": "Onde ficam as mensagens prontas do DAC?", "k": "mensagem mensagens padronizadas prontas whatsapp sis dpu cobranca texto", "t": ["dac"], "so": ["atdpu"],
  "r": "No DAC, em <b>MENSAGENS PADRONIZADAS</b>: lá estão as mensagens que o app já gera (agendamento, documentos faltantes, textos do SIS-DPU, formulários e cobrança dos PAJs), cada uma com o botão para abrir a ferramenta certa."},
 {"p": "Como funciona a Análise de Demanda?", "k": "analise demanda peticao inicial claude dps requisitos renda", "t": ["dps"], "so": ["atdpu"],
  "r": "Fica no DPS e funciona <b>só na versão online</b>, com o Claude. Escolha a demanda (BPC/LOAS, Auxílio-doença, Bolsa Família ou Pensão por morte), preencha os dados e o resumo do caso sem nome nem CPF e clique em <b>ANALISAR A DEMANDA</b>. Depois, preencha a qualificação (ela fica no computador) e clique em <b>GERAR A PETIÇÃO</b>. Confira tudo com o(a) Defensor(a)."},
 {"p": "Tem um manual completo do app?", "k": "relatorio tecnico manual completo pdf documentacao como funciona", "t": ["setores", "inicio", "tutoriais"], "so": ["atdpu"],
  "r": "Tem: o <b>Relatório Técnico</b>, na escolha do setor (e no HUB das versões). É um PDF com o manual de todos os apps, função por função, e como eles funcionam por dentro."},
 {"p": "Onde baixo a versão mais nova dos apps?", "k": "baixar download versao nova atualizar hub site link", "t": ["inicio", "setores", "tutoriais"],
  "r": "No <b>HUB das versões</b>: <b>unidadeapp.github.io</b>. Lá estão os apps, a versão online, as apresentações, o Relatório Técnico e o atalho do HUB, sem precisar de login."},
 {"p": "Tem modo escuro?", "k": "modo escuro noturno tema escuro cores claro preto tela", "t": ["inicio", "setores", "geral"],
  "r": "Tem. Clique em <b>☾ Modo escuro</b>, no canto de baixo, à esquerda (dentro das ferramentas, o botão fica no menu). A escolha fica guardada neste computador. A folha da lista, as prévias de PDF e a impressão continuam claras."},
 {"p": "Por que a folha impressa sai em preto e branco?", "k": "preto branco cor cores impressao clara fraca legivel", "t": ["lista", "checklist"],
  "r": "De propósito: na impressão, os textos e as linhas saem escuros para ficarem legíveis em qualquer impressora, até nas que só imprimem em preto. O <b>SALVAR EM PDF</b> mantém as cores da tela."},
 {"p": "Onde coloco meu nome para assinar as mensagens?", "k": "assinatura nome estagiario servidor mensagem assinar", "t": ["checklist", "central"],
  "r": "Na caixinha <b>Seu nome</b>, que aparece junto das mensagens. Escreva o nome e marque <b>Estagiário(a)</b> ou <b>Servidor(a)</b>: a mensagem termina com “Atenciosamente, nome, cargo – DPU Pelotas”. Fica guardado neste computador."},
 # --- agendamento
 {"p": "Como gero a lista de documentos para o agendamento?", "k": "lista documentos necessarios agendamento agendar trazer", "t": ["lista", "agendamento", "inicio"], "ir": "lista",
  "r": "Em <b>Documentos Necessários e Mensagem</b>: digite a demanda e escolha na lista, informe o dia e o horário, escolha o prazo e clique em <b>2 – SÓ A LISTA</b> (ou em <b>1 – TUDO</b>, com o formulário médico e as declarações). Para mudar o texto de um item, clique nele e digite."},
 {"p": "Como mando a mensagem do agendamento pelo WhatsApp?", "k": "mensagem agendamento whatsapp vera enviar", "t": ["lista", "agendamento"], "ir": "lista",
  "r": "Em <b>Documentos Necessários e Mensagem</b>, escolha a demanda, o dia e o horário e clique em <b>5 – GERAR MENSAGEM DO AGENDAMENTO</b>. A mensagem já sai copiada, com endereço, chegar 15 minutos antes, documentos originais, a lista, o prazo e a assinatura: cole no WhatsApp (Ctrl+V), junto com o PDF da lista."},
 {"p": "Quando vai o formulário médico junto com a lista?", "k": "formulario medico laudo medico junto separado", "t": ["lista"], "ir": "lista",
  "r": "Quando a demanda pede formulário médico, use <b>2 – LISTA + FORMULÁRIO MÉDICO</b> (um arquivo só) ou <b>3 – SEPARADOS</b> (dois arquivos). A mensagem do agendamento avisa que o formulário vai junto."},
 {"p": "A pessoa não compareceu. Como registro o PAJ?", "k": "nao compareceu faltou ausente nao veio estatistico", "t": ["semAtend", "agendamento", "narrativas"], "ir": "semAtend",
  "r": "Abra <b>PAJ sem Atendimento</b>, escolha <b>Não comparecimento</b>, preencha a data (tem calendário) e o horário e clique em <b>GERAR NARRATIVA</b>. O texto é copiado sozinho: no SIS-DPU, entre no PAJ, clique em Editar narrativa, cole e salve."},
 {"p": "O assunto é estadual, trabalhista ou a pessoa só queria uma ajuda. E agora?", "k": "estadual trabalhista gov.br ajuda duvida desistiu advogado encaminhamento", "t": ["semAtend", "agendamento"], "ir": "semAtend",
  "r": "Use <b>PAJ sem Atendimento</b>: tem narrativas prontas para matéria estadual, trabalhista, só ajuda com serviço público (gov.br, Meu INSS), só dúvida jurídica, desistência e já tem advogado(a). Todas terminam com “PAJ instaurado para fins estatísticos”."},
 {"p": "Qual é o prazo para entregar os documentos que faltam?", "k": "prazo dias horas urgente arquivado entregar faltam", "t": ["lista", "checklist", "meus", "unidade"],
  "r": "<b>30 dias</b> (PRAZO NORMAL) ou <b>48 horas</b> (PAJ URGENTE). Sem a documentação completa no prazo, o PAJ é <b>ARQUIVADO</b>. Escolha o prazo nos botões da lista: ele vai para a folha e para as mensagens."},
 # --- DAC
 {"p": "Como gero a lista de documentos que faltam?", "k": "faltantes faltam pendentes checklist gerador lista pendencia", "t": ["checklist", "dac", "gerenciador", "inicio"], "ir": "checklist",
  "r": "Abra a ferramenta, escolha a demanda e marque o que a pessoa já entregou (o que não serve, marque como “não se aplica”). Escolha o prazo e clique em <b>GERAR LISTA</b>: sai só o que falta, em 1 folha."},
 {"p": "Como mando ao assistido o que falta pelo WhatsApp?", "k": "mensagem whatsapp faltam textos automaticos sis-dpu", "t": ["checklist"], "ir": "checklist",
  "r": "Depois de marcar o que foi entregue, clique em <b>TEXTOS AUTOMÁTICOS</b>: aparecem a mensagem para o WhatsApp e os textos para o SIS-DPU, prontos para copiar."},
 {"p": "O assistido não sabe ler. O que muda?", "k": "analfabeto nao sabe ler assinar digital rogo testemunhas", "t": ["checklist", "central", "preencher", "assist"],
  "r": "Marque <b>ASSISTIDO ANALFABETO</b>. Nos formulários que ele assina, a linha de assinatura dá lugar ao espaço para a digital, à assinatura a rogo e às duas testemunhas (art. 595 do Código Civil)."},
 {"p": "Como preencho um formulário no computador?", "k": "preencher formulario digitar completar declaracao", "t": ["central", "preencher", "hub", "checklist"], "ir": "central",
  "r": "Na <b>Central de Formulários</b>, marque os formulários e clique em <b>PREENCHER</b>. Digite as informações no menu ao lado: cada uma vai para todos os formulários que a pedem, e a prévia se atualiza. Depois clique em <b>GERAR OS FORMULÁRIOS</b> e em <b>BAIXAR</b>. Nada fica guardado."},
 {"p": "Como baixo os formulários em PDF ou Word?", "k": "baixar word pdf formulario download docx", "t": ["central", "hub"], "ir": "central",
  "r": "Na <b>Central de Formulários</b>, marque os formulários e clique em <b>BAIXAR PDF</b> ou <b>BAIXAR WORD</b>. Para mandar ao assistido com as instruções, use <b>CRIAR MENSAGEM</b>."},
 {"p": "Como gero o formulário de renda?", "k": "renda formulario de renda grupo familiar", "t": ["central", "hub"], "ir": "central",
  "r": "Na <b>Central de Formulários</b>, clique em <b>GERAR FORMULÁRIO DE RENDA</b>: você responde às perguntas e o formulário sai pronto."},
 {"p": "Como faço a narrativa para o SIS-DPU?", "k": "narrativa reducao a termo sis-dpu texto relato", "t": ["narrativas", "hub", "assist"], "ir": "narrativas",
  "r": "Em <b>Narrativas</b>, escolha a demanda e, se houver abas, o modelo que corresponde ao caso. Responda às perguntas (as datas têm calendário) e clique em <b>GERAR NARRATIVA</b>, na barra de baixo. O texto é copiado sozinho: no SIS-DPU, entre no PAJ, clique em Editar narrativa, cole e salve."},
 {"p": "Não sei qual modelo de narrativa usar.", "k": "modelo narrativa aba qual usar duvida outros casos", "t": ["narrativas"], "ir": "narrativas",
  "r": "Quando a demanda tem mais de um modelo, cada aba diz a que caso serve. Na dúvida, <b>Outros casos › Casos diversos</b> serve para qualquer situação."},
 {"p": "Como abro um PAJ do começo ao fim?", "k": "abrir paj abertura atendimento etapas assistente novo", "t": ["dac", "assist", "setores"], "ir": "assist", "so": ["atdpu"],
  "r": "Use o <b>Assistente de Abertura de PAJ</b>: são 10 etapas, do cadastro no SIS-DPU à tramitação, com a narrativa, os formulários e o checklist. Os dados digitados no começo vão sozinhos para a narrativa e os formulários."},
 {"p": "A página fechou no meio do atendimento. Perdi tudo?", "k": "fechou perdi rascunho continuar atendimento caiu", "t": ["assist"], "ir": "assist", "so": ["atdpu"],
  "r": "Não. Abra o Assistente de Abertura de novo: ele mostra o atendimento não terminado e pergunta se você quer continuar de onde parou."},
 {"p": "Como acompanho os documentos que o assistido ainda vai mandar?", "k": "meus pajs pendentes acompanhar documentos chegou parte", "t": ["meus", "dac", "gerenciador"], "ir": "meus", "so": ["atdpu"],
  "r": "Em <b>Meus PAJs</b>, clique no PAJ e marque o que chegou. As mensagens (WhatsApp e SIS-DPU) se atualizam sozinhas. Quando chegar tudo, clique em <b>CONCLUIR</b>."},
 {"p": "Como passo Meus PAJs para outro computador?", "k": "copia backup outro computador transferir meus pajs", "t": ["meus"], "ir": "meus", "so": ["atdpu"],
  "r": "No computador de origem, em Meus PAJs, clique em <b>Salvar cópia</b>. No computador novo, clique em <b>Carregar cópia</b> e escolha o arquivo."},
 {"p": "O salário mínimo mudou. Onde atualizo?", "k": "salario minimo valor ano atualizar limite renda", "t": ["assist"], "ir": "assist", "so": ["atdpu"],
  "r": "No Assistente de Abertura, na tela <b>Início</b>, clique em <b>Alterar</b> ao lado do salário mínimo e informe o valor e o ano. O limite de 2 salários mínimos se ajusta sozinho."},
 # --- DPS
 {"p": "Onde ficam os modelos de petição?", "k": "modelos peticao inicial replica recurso impugnacao word peca", "t": ["dps", "modelos"], "ir": "modelos", "so": ["atdpu"],
  "r": "No setor <b>DPS › Modelos</b>. Escolha o tipo de peça, escreva o resumo do PAJ e clique em <b>SUGERIR MODELO</b>, ou procure pelo nome."},
 {"p": "Como preencho a qualificação no Word?", "k": "qualificacao word preencher nome cpf endereco paj", "t": ["modelos"], "ir": "modelos", "so": ["atdpu"],
  "r": "Em <b>Modelos</b>, clique em <b>PREENCHER QUALIFICAÇÃO</b>, preencha as caixinhas (no PAJ, digite só o número: 15 vira 2026/025-00015) e clique em <b>GERAR O WORD PREENCHIDO</b>."},
 {"p": "Não tenho Word no computador.", "k": "google docs drive sem word abrir", "t": ["modelos"], "ir": "modelos", "so": ["atdpu"],
  "r": "Na tela de preencher qualificação, use <b>ABRIR NO GOOGLE DOCS</b>: o arquivo é baixado, o Google Drive abre e aparecem os passos para abrir no Google Docs."},
 {"p": "Onde vejo as jurisprudências?", "k": "jurisprudencia tema sumula stf stj tnu decisao", "t": ["dps", "juris"], "ir": "juris", "so": ["atdpu"],
  "r": "Em <b>DPS › Jurisprudências Comuns e Úteis</b>: as decisões mais citadas nas peças, por área, com o que dizem e para que servem."},
 {"p": "Onde estudo as demandas e o Manual do Estagiário?", "k": "aprender estudar manual estagiario glossario demanda", "t": ["setores", "aprender"], "ir": "aprender", "so": ["atdpu"],
  "r": "Na aba <b>APRENDER</b>: páginas por demanda, glossário, jurisprudências e o Manual do Estagiário com índice por assunto."},
 {"p": "Tem um tour pelo app?", "k": "tour guiado apresentacao conhecer mostrar novo comecando", "t": ["setores", "tutoriais", "inicio"], "ir": "tutoriais",
  "r": "Tem! Em <b>Tutoriais</b>, escolha o tour (Começando ou o setor) e eu mostro, na própria tela, onde fica cada coisa."},
 {"p": "Como apresento o app para alguém que não conhece?", "k": "apresentacao slides apresentar defensor mostrar explicar hub versoes", "t": ["setores", "inicio", "unidade"], "ir": "apresentacao",
  "r": "Abra a <b>Apresentação</b>: slides que explicam o que o app faz e o que vem por aí. Use <b>Tela cheia</b> para apresentar num monitor ou projetor. As apresentações de todos os apps também ficam no <b>HUB das versões</b>."},
 {"p": "Onde fica o passo a passo de cada ferramenta?", "k": "tutorial tutoriais passo a passo como usar", "t": ["setores", "tutoriais", "inicio"], "ir": "tutoriais",
  "r": "Em <b>Tutoriais</b>: cada ferramenta tem o seu passo a passo, e lá também ficam os tours guiados por mim."},
 # --- a unidade
 {"p": "Quais municípios a DPU Pelotas atende?", "k": "municipios cidades atende abrangencia jurisdicao", "t": ["unidade", "setores", "inicio"], "ir": "unidade",
  "r": "Amaral Ferrador, Arroio do Padre, Arroio Grande, Canguçu, Capão do Leão, Cerrito, Herval, Jaguarão, Morro Redondo, Pedro Osório, Pelotas (sede), Piratini, São Lourenço do Sul e Turuçu."},
 {"p": "Qual o endereço, os telefones e o horário da unidade?", "k": "endereco telefone horario whatsapp ligacao contato onde fica", "t": ["unidade", "inicio", "setores"], "ir": "unidade",
  "r": "Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS. Presencial: das 9h às 15h. <b>(53) 3284-9450</b>: WhatsApp só para mensagens; o mesmo número atende ligação comum, das 8h às 17h. <b>(53) 99112-4160</b>: só para agendar PAJ novo."},
 {"p": "Quem pode ser atendido pela DPU?", "k": "renda limite salario minimo hipossuficiencia quem atende criterio", "t": ["unidade"], "ir": "unidade",
  "r": "Pessoas que não podem pagar advogado(a), em causas da Justiça Federal. A referência é a renda do grupo familiar de até 2 salários mínimos (Resolução CSDPU nº 240/2025); gastos extraordinários com saúde podem ser descontados. A análise final é do(a) defensor(a)."},
]

NOME_CK = {"atdpu": "Gerador de Lista de Documentos Faltantes", "terreo": "Checklist de Documentos"}

CSS = """<style id="temisCss">
  [hidden] { display:none !important; }
  #tmBt { position:fixed; right:18px; bottom:18px; z-index:60; display:flex; align-items:center; gap:10px; background:#fff; color:#2f6a1f; border:2px solid #3f7f2a;
          border-radius:30px; padding:5px 18px 5px 5px; font:800 14.5px "Segoe UI", Calibri, Arial, sans-serif; cursor:pointer; box-shadow:0 6px 20px rgba(47,106,31,.28); }
  #tmBt:hover { background:#eef6ea; }
  #tmBt .av { width:44px; height:44px; flex:0 0 auto; }
  #tmBt .av svg, .tmAv svg, .tmMasc svg { width:100%; height:100%; display:block; }
  #tmPainel { position:fixed; right:18px; bottom:18px; z-index:61; width:400px; max-width:calc(100vw - 36px); height:580px; max-height:calc(100vh - 36px); background:#fff;
              border-radius:16px; box-shadow:0 12px 40px rgba(0,0,0,.25); display:flex; flex-direction:column; overflow:hidden; font-family:"Segoe UI", Calibri, Arial, sans-serif; }
  .tmCab { background:linear-gradient(90deg, #3f7f2a, #2f7a5a 60%, #00879a); color:#fff; padding:10px 12px; display:flex; align-items:center; gap:10px; }
  .tmCab .tmAv { width:42px; height:42px; background:#fff; border-radius:50%; }
  .tmCab b { flex:1; font-size:16px; } .tmCab small { display:block; font-weight:400; opacity:.9; font-size:12px; }
  .tmCab button { background:rgba(255,255,255,.18); color:#fff; border:0; border-radius:8px; width:32px; height:32px; font-size:18px; cursor:pointer; }
  .tmMsgs { flex:1; overflow-y:auto; padding:14px; display:flex; flex-direction:column; gap:10px; background:#f6f8f4; }
  .tmM { display:flex; gap:8px; align-items:flex-end; max-width:94%; }
  .tmM .tmAv { width:28px; height:28px; flex:0 0 auto; }
  .tmM .bal { background:#fff; border:1px solid #dfe6da; border-radius:12px; border-bottom-left-radius:4px; padding:9px 13px; font-size:14px; line-height:1.5; color:#1e1e1e; }
  .tmM .bal .ir { display:inline-block; margin-top:8px; background:#3f7f2a; color:#fff; border:0; border-radius:8px; padding:6px 12px; font:700 13px "Segoe UI", Arial, sans-serif; cursor:pointer; }
  .tmEu { align-self:flex-end; background:#3f7f2a; color:#fff; border-radius:12px; border-bottom-right-radius:4px; padding:8px 13px; font-size:14px; max-width:85%; }
  .tmSug { display:flex; flex-direction:column; gap:6px; }
  .tmSug .tt { font-size:12px; font-weight:800; letter-spacing:.06em; color:#7a8276; }
  .tmSug button { text-align:left; background:#fff; border:1.5px solid #cfdcc8; color:#2f6a1f; border-radius:10px; padding:7px 11px; font:600 13.5px "Segoe UI", Arial, sans-serif; cursor:pointer; }
  .tmSug button:hover { background:#eef6ea; border-color:#3f7f2a; }
  .tmEntrada { border-top:1px solid #e3e9df; padding:10px; display:flex; gap:8px; }
  .tmEntrada input { flex:1; min-width:0; font:inherit; font-size:14px; padding:9px 11px; border:1.5px solid #cfdcc8; border-radius:10px; }
  .tmEntrada input:focus { outline:none; border-color:#3f7f2a; box-shadow:0 0 0 3px #d7e9cd; }
  .tmEntrada button { background:#3f7f2a; color:#fff; border:0; border-radius:10px; padding:9px 14px; font-weight:800; cursor:pointer; }
  @media (max-width:900px) { #tmBt .tx { display:none; } #tmBt { padding:5px; } }
  @media (max-width:600px) { #tmPainel { right:0; bottom:0; width:100%; max-width:100%; height:100%; max-height:100%; border-radius:0; } }
  @media print { #tmBt, #tmPainel { display:none !important; } }
</style>"""

HTML = """<button type="button" id="tmBt" hidden title="A Têmis responde dúvidas sobre o app"><span class="av">__AV__</span><span class="tx">Alguma dúvida? Pergunte à Têmis!</span></button>
<div id="tmPainel" hidden role="dialog" aria-label="Têmis, a assistente virtual">
  <div class="tmCab"><span class="tmAv">__AV__</span><b>Têmis<small>__SUB__</small></b><button type="button" id="tmFechar" title="Fechar">×</button></div>
  <div class="tmMsgs" id="tmMsgs"></div>
  <form class="tmEntrada" id="tmForm"><input id="tmTexto" placeholder="Escreva sua dúvida (ex.: imprimir sem cabeçalho)" autocomplete="off"><button type="submit">Buscar</button></form>
</div>"""

JS = r"""<script>
(function () {  // Têmis offline: respostas prontas
  const APP = __APP__, FAQ = __FAQ__, AV = __AVJ__, NOME_CK = __CK__;
  const $ = id => document.getElementById(id);
  const norm = s => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const PARADAS = new Set("a o as os de da do das dos e em no na nos nas um uma para por com como que eu meu minha onde qual quais quando se ao ou nao sim e o pra".split(" "));
  const tela = () => (window.temisTela && window.temisTela()) || "";
  const pode = f => (!f.so || f.so.includes(APP)) && (!f.ir || (window.temisPode && window.temisPode(f.ir)));
  const LISTA = FAQ.filter(pode).map(f => ({ ...f, r: f.r.replace(/\{CK\}/g, NOME_CK), _p: norm(f.p), _k: norm(f.p + " " + (f.k || "")).split(/[^a-z0-9.-]+/).filter(Boolean) }));
  function buscar(q) {
    const ts = norm(q).split(/[^a-z0-9.-]+/).filter(t => t.length > 1 && !PARADAS.has(t));
    if (!ts.length) return [];
    return LISTA.map(f => {
      let pts = 0;
      ts.forEach(t => { if (f._k.some(w => w === t)) pts += 2; else if (t.length >= 4 && f._k.some(w => w.startsWith(t.slice(0, Math.max(4, t.length - 2))))) pts += 1; });
      if (f._p.includes(norm(q).trim())) pts += 3;
      return { f, pts };
    }).filter(x => x.pts > 0).sort((a, b) => b.pts - a.pts).slice(0, 3).map(x => x.f);
  }
  function sugestoes() {
    const tl = tela(), daTela = LISTA.filter(f => f.t && f.t.includes(tl)), gerais = LISTA.filter(f => f.t && f.t.includes("geral"));
    return [...daTela, ...gerais.filter(f => !daTela.includes(f))].slice(0, 5);
  }
  function rolar() { $("tmMsgs").scrollTop = 1e9; }
  function fala(html, ir) {
    const m = document.createElement("div"); m.className = "tmM";
    m.innerHTML = `<span class="tmAv">${AV}</span><div class="bal">${html}</div>`;
    if (ir && window.temisIr) {
      const b = document.createElement("button"); b.type = "button"; b.className = "ir"; b.textContent = "Ir para a ferramenta →";
      b.addEventListener("click", () => { window.temisIr(ir); fechar(); }); m.querySelector(".bal").appendChild(document.createElement("br")); m.querySelector(".bal").appendChild(b);
    }
    $("tmMsgs").appendChild(m); rolar();
  }
  function botoes(lista, titulo) {
    const d = document.createElement("div"); d.className = "tmSug";
    d.innerHTML = `<div class="tt">${titulo}</div>`;
    lista.forEach(f => { const b = document.createElement("button"); b.type = "button"; b.textContent = f.p; b.addEventListener("click", () => responder(f)); d.appendChild(b); });
    $("tmMsgs").appendChild(d); rolar();
  }
  function eu(t) { const d = document.createElement("div"); d.className = "tmEu"; d.textContent = t; $("tmMsgs").appendChild(d); rolar(); }
  function responder(f) { eu(f.p); fala(f.r, f.ir); }
  function abrir() {
    $("tmPainel").hidden = false; $("tmBt").hidden = true; $("tmMsgs").innerHTML = "";
    fala("Oi! Eu sou a <b>Têmis</b>, a assistente virtual do app (meu nome vem da deusa grega da justiça). Nesta versão sem internet, eu respondo com respostas prontas: escolha uma pergunta ou escreva a sua dúvida."
      + (APP === "atdpu" ? " Na versão online do Unidade, eu funciono com o Claude e entendo perguntas livres." : ""));
    botoes(sugestoes(), "PERGUNTAS DESTA TELA");
    setTimeout(() => $("tmTexto").focus(), 50);
  }
  function fechar() { $("tmPainel").hidden = true; atualizar(); }
  $("tmBt").addEventListener("click", abrir);
  $("tmFechar").addEventListener("click", fechar);
  $("tmForm").addEventListener("submit", e => {
    e.preventDefault(); const q = $("tmTexto").value.trim(); if (!q) return; $("tmTexto").value = "";
    eu(q); const r = buscar(q);
    if (!r.length) { fala("Não achei uma resposta pronta para isso. Tente outras palavras (ex.: imprimir, narrativa, formulário, prazo, município)" + (APP === "atdpu" ? " ou veja os <b>Tutoriais</b>, na tela de escolha do setor." : " ou veja os <b>Tutoriais</b>, na página inicial.")); botoes(sugestoes(), "TALVEZ AJUDE"); return; }
    fala(r[0].r, r[0].ir);
    if (r.length > 1) botoes(r.slice(1), "OUTRAS RESPOSTAS PARECIDAS");
  });
  function atualizar() { $("tmBt").hidden = !$("tmPainel").hidden || (window.temisEscondido && window.temisEscondido()); }
  window.temisAtualizar = atualizar;
  window.addEventListener("hashchange", atualizar);
  atualizar();
})();
</script>"""


def bloco(app, sub="Assistente virtual do app · respostas prontas, sem internet"):
    """HTML + CSS + JS da Têmis offline para a página principal de um app ("atdpu" ou "terreo")."""
    av = marca.TEMIS.replace('id="temisC"', 'id="temisCX"').replace("url(#temisC)", "url(#temisCX)")
    js = (JS.replace("__APP__", json.dumps(app)).replace("__FAQ__", json.dumps(FAQ, ensure_ascii=False))
            .replace("__AVJ__", json.dumps(av, ensure_ascii=False)).replace("__CK__", json.dumps(NOME_CK[app], ensure_ascii=False)))
    return CSS + "\n" + HTML.replace("__AV__", av).replace("__SUB__", sub) + "\n" + js.replace("</svg>", "<\\/svg>")

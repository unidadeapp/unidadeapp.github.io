#!/bin/bash
# Gera os quatro apps em apps/:
#   apps/Unidade.html                              (Unidade, o app principal; antigo ATDPU)
#   apps/Térreo.html                               (Térreo: agendamento + DAC)
#   apps/Térreo - DAC.html                         (Térreo – DAC)
#   apps/Térreo - AG.html                          (Térreo – AG, agendamento)
# Uso: ./construir.sh        (formulários: ver scripts/construir_formularios.sh)
set -e
cd "$(dirname "$0")"
for t in python3 pdfinfo pdftocairo; do
  command -v $t >/dev/null || { echo "Falta '$t'. Instale com: apt-get install -y poppler-utils (ver scripts/setup_nuvem.sh)"; exit 1; }
done
(cd faltantes  && python3 build_forms.py && python3 gen_f.py)   # Gerador de lista de documentos faltantes (comum aos dois apps)
(cd lista      && python3 build_forms_lista.py && python3 gen.py)  # Lista de documentos necessários (Agendamento)
(cd aprender   && python3 gen_ap.py)                            # APRENDER (gera também o glossário usado pelo assistente)
(cd assistente && python3 build_data.py && python3 gen_a.py)    # Assistente de Abertura de PAJ
(cd central    && python3 gen_c.py)                             # Central de Formulários (comum aos dois apps)
(cd narrativas && python3 gen_n.py)                             # Narrativas avulsas (lê o Assistente e o glossário; comum aos dois apps)
(cd preencher  && python3 gen_p.py)                             # Preenchimento de formulários (comum aos dois apps)
(cd relatorio  && python3 gen_rel.py)                           # Relatório Técnico (PDF; vai no Unidade e no HUB)
(cd trabalho   && python3 gen_t.py)                             # Unidade
(cd dac        && python3 gen_dac.py)                           # Térreo – DAC
(cd adag       && python3 gen_adag.py)                          # Térreo – AG (Agendamento)
(cd juntos     && python3 gen_juntos.py)                        # Térreo (agendamento + DAC)
mkdir -p apps
cp "trabalho/Unidade.html" "dac/Térreo - DAC.html" "adag/Térreo - AG.html" "juntos/Térreo.html" apps/
# crédito de autoria (AUTORIA.md): sem "Desenvolvido por Pedro Tomkowski" na tela inicial, no menu das ferramentas e na Apresentação, o app não sai
for f in "apps/Unidade.html" "apps/Térreo.html" "apps/Térreo - DAC.html" "apps/Térreo - AG.html"; do
  n=$(grep -o "Desenvolvido por Pedro Tomkowski" "$f" | wc -l)
  if [ "$n" -lt 3 ]; then echo "ERRO: o crédito \"Desenvolvido por Pedro Tomkowski\" foi apagado de $f. Veja AUTORIA.md."; rm -f "$f"; exit 1; fi
done
ls -l apps/

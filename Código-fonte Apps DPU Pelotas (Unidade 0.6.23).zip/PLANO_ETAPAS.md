# Plano em etapas – pedido de 13/11/2026 (madrugada)

Pedido do Pedro "traduzido" e organizado. As etapas seguem uma ordem que faz sentido (primeiro o que destrava o resto e os
consertos rápidos; depois o que muda muito texto; por fim os documentos finais e as jurisprudências). O gasto é uma
estimativa do limite de 5 horas: **leve** (até ~5%), **médio** (~10–20%), **alto** (30% ou mais).

Regra de versões: cada etapa sobe o último número de todos os apps que muda (ex.: Unidade 0.6.2, 0.6.3…). No fim,
sugerir ao Pedro fechar tudo como Unidade 0.7, Térreo 0.3, Térreo – DAC 0.5 e Térreo – AG 0.3.

## O que é pertinente e o que não dá (análise)

- **Pertinente e vai para todos os apps onde existe a função:** quase tudo (correções, impressão, formulários, narrativas,
  listas de opções, português, tours, Têmis, apresentações, HUB).
- **Link público do HUB:** só o Pedro consegue (no próprio site, botão *Compartilhar* → "Qualquer pessoa com o link").
  Eu deixo o HUB pronto e explico o passo a passo.
- **Declaração de residência (separada da declaração do titular do comprovante):** se o modelo oficial não estiver no
  pacote de formulários, preciso do modelo da unidade; não invento formulário oficial.
- **Aprender "com o livro":** o livro não está no projeto (foi enviado em outra conversa). Uso o que já existe no app e a
  internet; quando o Pedro mandar o livro aqui, completo.
- **Mensagens padronizadas:** DAC começa só com as mensagens que já existem nos apps (marcado como incompleto); DPS fica
  "em breve" até o Pedro mandar as mensagens.
- **Aprovar sozinho os pedidos de autorização:** não consigo mudar as minhas permissões. Faço tudo pelo caminho que não
  precisa de aprovação e anoto, no relatório abaixo, o que pediu aprovação, foi bloqueado ou esperou.
- **Tom das apresentações e do relatório:** convincente, mas como quem acredita que o app melhora a unidade (nada de
  "propaganda").

## Etapas

| # | Etapa | Gasto | Situação |
|---|---|---|---|
| 0b | Apresentações em slides **em cada app e no HUB** (pedido do Pedro, revisado); botão Tour Guiado com a Têmis na página principal | leve | feita (0.6.2) |
| 0 | Renomear o ATDPU para **Unidade** ("Ferramenta de apoio ao trabalho da unidade da DPU de Pelotas"), logo novo, ícone, HUB e online | leve | feita |
| 1 | **Consertos rápidos:** link do IRPF (restituicao.receita.fazenda.gov.br); link do eproc; botão "Nova narrativa" na frente da lista de demandas; botão CONCLUIR ao lado de copiar (volta para as narrativas); opção "não sabe" no motivo do indeferimento; cargo "Estagiário(a), Servidor(a) ou Outro" (Outro = sem cargo); botão "deixar em branco" no nome e CPF do titular da conta; imóvel "próprio, alugado, cedido ou outro" e "não sabe o valor"; "ATALHOS" com o nome certo (do setor DPS / do Aprender); "Aprender e treinamento DPS" vira **Treinamento – DPS**; novo cartão **Treinamento – DAC** (em breve); **Mensagens Padronizadas** no DPS (em breve); funções que só existem com o Claude em vermelho, "Só com o Claude" e sem abrir (no offline); aviso vermelho do online sai do Iniciar e vai para a escolha do setor; data de atualização de cada app no HUB | médio | feita (0.6.2) |
| 2 | **Impressão:** investigar e corrigir a tela cinza ao imprimir (Opera GX, offline, Térreo); impressão sempre legível em preto e branco (cores escuras só na impressão; o PDF baixado continua igual); botões separados **Imprimir** e **Salvar em PDF** | médio | feita (0.6.3) |
| 3 | **Agendamento:** "SE FOR O SEU CASO" no formato "nº. Caso – o que trazer"; mensagem explicando que os documentos são os mesmos da lista entregue; botão **Não sou a Vera** (pequeno, "que azar o seu"), com nome e cargo opcional; no tour, o × destacado com um círculo avermelhado | leve | feita (0.6.4) |
| 4 | **Formulários:** renomear: a declaração menor, que fala do titular, vira **Declaração do Titular do Comprovante**; a outra continua **Declaração de Residência** (Pedro confirmou: não é formulário novo); mensagem final do Preenchimento só com os campos que ficaram em branco (ou só "falta assinar") | médio | feita (0.6.5) |
| 5 | **Narrativas:** "Narrativa em branco" (lacunas e parênteses de sim/não vazios, para imprimir e preencher à mão) e botão IMPRIMIR da narrativa; **duas opções logo na entrada** (pedido de 13/11, tarde): **"Só consultar / pegar em branco"** (escolhe a demanda e já vê, copia ou imprime o modelo em branco, sem perguntas) e **"Preencher"** (as perguntas, como hoje) | médio | feita (0.6.6) |
| 5b | **Consertos (pedido de 13/11, tarde):** Apresentação desalinhada no HUB fora da tela cheia; capa da Apresentação no Unidade presa na metade esquerda, mesmo em tela cheia; botão **Não sou a Vera** maior e numa caixinha, como os outros; nome **Declaração do Titular do Comprovante** também no próprio documento (PDF e Word, inclusive a versão para analfabeto) e em todo o resto | médio | feita (0.6.7) |
| 5c | **Têmis online:** o botão ATIVAR A TÊMIS leva ao login do Claude e, depois do login, volta sozinho para o app online (ver o que o site permite) | leve | feita (0.6.8; conferir no site de verdade) |
| 5d | **HUB para todos:** "appzinho" em HTML (com ícone, como os apps) que abre o HUB; endereço personalizado do HUB, se o site permitir (o claude.ai provavelmente não deixa escolher o endereço: o appzinho resolve); **código-fonte para baixar no HUB, protegido por senha** (o .zip vai criptografado; a senha, escolhida pelo Pedro, não fica no repositório; sem o histórico do git e sem nenhum dado de assistido) e um passo a passo de como mexer nele com o Claude; **crédito "Desenvolvido por Pedro Tomkowski" protegido**: aviso de autoria no código, regra para o Claude nunca remover o crédito, verificação no construir.sh (não gera o app sem o crédito) e o crédito em vários lugares de cada app | médio | feita (0.6.8) |
| 5e | **Modo escuro** em todos os apps, no HUB e no online (botão para ligar e desligar; cores ajustadas para ficar legível e agradável; a impressão e os PDFs continuam claros) | alto | feita (0.6.9) |
| 6 | **Listas de opções** onde fizer sentido (ex.: situação ocupacional), mantendo a digitação livre; análise de qualidade de vida; análise dos botões "O que é isso?" (mais onde ajuda, sem poluir) | médio | feita (0.6.10): situação ocupacional, profissão e cidade com lista; "O que é isso?" no formulário de renda e no número do PAJ (as perguntas das narrativas já tinham) |
| 7 | **Desempenho:** ferramentas abrindo mais rápido (pré-carregar em segundo plano) e caixinhas do tour sem atraso | leve/médio | feita (0.6.11) |
| 8 | **Português:** revisão gramatical (concordâncias), linguagem um pouco mais culta e simples, títulos das funções com Iniciais Maiúsculas (ex.: Checklist de Documentos) | médio/alto | feita (0.6.12): títulos com Iniciais Maiúsculas; busca de erros comuns sem achados |
| 9 | **Mensagens Padronizadas:** gerador do DAC (incompleto, com as mensagens que já existem) | médio | feita (0.6.13): tela que reúne as 6 mensagens prontas e abre a ferramenta de cada uma |
| 10 | **Tours interativos:** a pessoa faz a tarefa de verdade, com a página mudando na hora; sair do tour volta para a página dos tours; lembrete de rolar até o fim; um tour por setor + um tour geral; tour do DPS completo (cada função) e aviso das funções só do online; no online, botão especial "O que o online tem de diferente" (Claude e Têmis) junto da escolha do setor; botão do tour com a Têmis na página principal do Unidade | alto | feita (0.6.14) |
| 11 | **Aprender** bem mais completo (banco de dados do app + internet; o livro quando o Pedro mandar) | alto | parcial (0.6.15): 3 páginas novas (Análise da Renda, Alvará Judicial, Auxílio Reconstrução); o livro, quando o Pedro mandar |
| 12 | **Apresentações** de cada app (visuais, convincentes), em cada app **e** no HUB; Tutoriais e Têmis adaptados a tudo | médio | feita (0.6.15) |
| 13 | **Relatório técnico completo** (manual de todos os apps, cada função nos detalhes, e uma seção técnica), em PDF, **só no Unidade (offline e online) e no HUB** | alto | feita (0.6.16) |
| 14 | **Testes finais** detalhados e lista de testes para o Pedro fazer no online | médio | feita (0.6.16): todos os testes automáticos passaram; lista abaixo |
| 14b | **Análise de Demanda (DPS)**, com o Claude, na versão online: começar só com **BPC/LOAS à pessoa com deficiência, BPC/LOAS à pessoa idosa, Auxílio-doença, Bolsa Família e Pensão por morte**; usa como referência o padrão das 5 petições iniciais que o Pedro mandou em 13/11 (só para entender estrutura e argumentos: **nada delas entra no app nem no repositório**; exemplos sempre anonimizados). Detalhes na próxima mensagem do Pedro | alto | feita (0.6.17), primeira versão: renda no app, análise e petição pelo Claude no padrão I–VII das petições da unidade; o Pedro ajusta depois de testar |
| 15 | **Jurisprudências** clicáveis (explicação, texto oficial, link, copiar formatado no padrão dos modelos) – por último | alto | feita (0.6.18): clicáveis, sem "onde usamos", busca do texto oficial no site do tribunal e cópia no padrão dos modelos. Falta: o texto oficial na íntegra de cada uma (a rede deste ambiente não alcança STF, STJ e CJF para conferir; dá para colocar aos poucos, conferindo) |

## Novas etapas (sugestões de 13/11/2026, noite)

| # | Etapa | Gasto | Situação |
|---|---|---|---|
| 16 | **Grupo familiar nos checklists** (no Gerador de faltantes, que não tem narrativa: caixinha para digitar os membros, com idade e se tem renda) (Checklist do Assistente de Abertura e Gerador de faltantes): nos documentos pessoais e de renda, botão "Faltou o documento de um membro do grupo familiar?" → marcar quem já entregou; a lista impressa e as mensagens se adaptam (ex.: "RG e CPF de José"). Renda: só maiores de idade e menores de 14+ com renda (estágio, jovem aprendiz) cadastrados na narrativa. Comprovante de renda: além de ENTREGUE, "comprovante em nome de terceiro" e "não tem como comprovar", cada um gerando o formulário certo. Aplicar a lógica a todos os documentos em que fizer sentido (análise caso a caso) | alto | FEITA (0.6.22) |
| 17 | **Assistente de Abertura em 10 etapas:** unir as etapas 2 e 4 (a narrativa fica pronta antes de abrir o PAJ) e as etapas 11 e 12 | médio | feita (0.6.20) |
| 18 | **Agendamento:** tirar o × da lista; 4 botões (TUDO, SÓ A LISTA, SÓ O FORMULÁRIO MÉDICO, SÓ AS DECLARAÇÕES), cada um abre uma janelinha para escolher Imprimir ou Baixar em PDF (sai o "Como: IMPRIMIR ou SALVAR EM PDF"); declarações geradas pelo agendamento com instruções de quando usar cada uma (opcionais; quem tem comprovante em nome próprio descarta); a mensagem do agendamento continua; sem personalização por membro aqui; o agendamento sempre abre com o menu em cima | médio | feita (0.6.19) |
| 19 | **Etapa "Gerar formulários" do Assistente:** tirar "outros formulários disponíveis"; só isso (o resto da frase era para apagar) | leve | feita (0.6.20) |
| 20 | **Mensagens automatizadas / padronizadas do DAC** (antes das do DPS, para o treinamento ficar 100% funcional) | alto | |
| 21 | **Integração com o SIS-DPU por MCP** (a chefia vai passar o acesso; Pedro autorizado) | alto | aguardando o acesso |

## Relatório de autorizações (04:50–12:00)

Resumo: nenhuma ação desta noite e desta manhã ficou parada esperando aprovação; os bloqueios foram de rede.


Ações que pediram aprovação, foram bloqueadas ou ficaram esperando, e o que foi feito no lugar:

- 03:00 (antes do horário): leitura do site da DPU – a rede não alcança www.dpu.def.br nem www.gov.br (falha de DNS mesmo
  depois de liberar os dois no ambiente). Feito no lugar: informações da unidade com os dados já conferidos do app e a lista
  de municípios enviada pelo Pedro.


## Testes para o Pedro fazer no site (versão online e HUB)

1. **Login da Têmis:** abra o app online numa janela anônima, clique em ATIVAR A TÊMIS e entre na conta do Claude. O app deve abrir de novo sozinho.
2. **Têmis:** ative e pergunte algo (ex.: "como gero a lista de documentos?").
3. **Modo escuro:** ligue no canto de baixo, à esquerda; abra uma ferramenta e confira se ela escurece junto e se a folha da lista continua clara.
4. **PDF:** em Documentos Necessários e Mensagem, escolha uma demanda e clique em SÓ A LISTA: o site deve pedir para salvar o PDF.
5. **Narrativas:** escolha SÓ CONSULTAR / PEGAR EM BRANCO e uma demanda; copie o texto e cole no Word.
6. **Tour:** na escolha do setor, clique em O QUE O ONLINE TEM DE DIFERENTE; nos Tutoriais, faça o tour do Agendamento e escolha a demanda quando a Têmis pedir.
7. **Relatório Técnico:** na escolha do setor, baixe o PDF.
8. **HUB:** baixe um app offline, o atalho do HUB, o relatório e o código-fonte (com a senha; a senha errada deve dar "Senha errada").
9. **Apresentação:** no HUB e no app, passe os slides com e sem tela cheia.
- 17:20: a rede do ambiente não alcança os sites do STF, do STJ e do CJF (consulta das jurisprudências). Feito no lugar: botão que procura o texto oficial no site do tribunal e aviso de que o resumo não é citação literal.
- 17:00: o login do Claude (claude.ai) não abre por programa (proteção do site). Feito no lugar: o "voltar depois do login" foi confirmado por relatos de uso, e o Pedro testa no site.

from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import asyncio, io, pypdf
from playwright.async_api import async_playwright
npdf = lambda pdf: len(pypdf.PdfReader(io.BytesIO(pdf)).pages)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(channel="chrome"); ctx = await b.new_context(accept_downloads=True, viewport={"width":1150,"height":1000})
        pg = await ctx.new_page()
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.add_init_script("""window.__p=[]; window.print = () => { window.__p.push({lista: !document.body.classList.contains('so-form'),
            paginas: document.querySelectorAll('#anexos .fpage').length, itens: [...document.querySelectorAll('#docs li:not(.ok)')].length}); };""")
        await pg.goto("file://" + RAIZ + "faltantes/Documentos_faltantes.html")
        await pg.click("#dem"); await pg.keyboard.type("auxilio doen"); await pg.keyboard.press("Enter")
        await pg.screenshot(path="f0.png", full_page=True)
        btns = lambda: pg.evaluate("[...document.querySelectorAll('.fbtn')].map(b=>(b.classList.contains('off')?'X ':b.classList.contains('sel')?'✓ ':'· ')+b.dataset.k)")
        print("botões:", await btns())
        # mark renda + ctps + medical form as delivered
        for k in ["renda", "ctps"]:
            await pg.click(f'li[data-k="{k}"] .chk input')
        await pg.click('li[data-k="medico"] .chk input')
        print("após marcar renda, CTPS e formulário médico:", await btns())
        # select two forms and act
        await pg.click('.fbtn[data-k="form_renda"]'); await pg.click('.fbtn[data-k="titular"]')
        print("contador:", await pg.evaluate("$('cont').textContent"))
        async with pg.expect_download() as d1:
            await pg.click("#aBaixar")
        d = await d1.value; print("baixou:", d.suggested_filename)
        await pg.wait_for_timeout(900)
        # open in new tabs
        pages_before = len(ctx.pages)
        await pg.click("#aAbrir"); await pg.wait_for_timeout(800)
        print("guias novas:", len(ctx.pages) - pages_before, "|", await pg.evaluate("$('fmsg').textContent"))
        for t in ctx.pages[1:]:
            print("   guia:", await t.title(), "| embed:", await t.evaluate("document.querySelector('embed') && document.querySelector('embed').src.slice(0,10)"))
        # print selected forms
        await pg.click("#aImprimir"); await pg.wait_for_function("window.__p.length>0")
        print("imprimir formulários:", await pg.evaluate("window.__p[0]"))
        pdf = await pg.pdf(format="A4", print_background=True, prefer_css_page_size=True)
        print("   PDF:", npdf(pdf), "páginas (formulário de renda 4 + titular 1 = 5)")
        # GERAR LISTA
        await pg.click("#gerar"); await pg.wait_for_function("window.__p.length>1")
        print("gerar lista:", await pg.evaluate("window.__p[1]"))
        pdf = await pg.pdf(format="A4", print_background=True, prefer_css_page_size=True); open("lista.pdf","wb").write(pdf)
        print("   PDF:", npdf(pdf), "página(s)")
        await pg.screenshot(path="f1.png", full_page=True)
        print("erros:", errs); await b.close()
asyncio.run(main())

# Junta todos os formulários: PDF preenchível (para baixar/abrir) + páginas SVG comprimidas (para imprimir vários de uma vez)
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import subprocess, gzip, base64, json, tempfile
P = RAIZ + "pacote2/Formularios_DPU_Pelotas/PDF (preenchiveis)"
F = {  # chave: (rótulo do botão, arquivo, item da lista que torna o formulário desnecessário)
 "form_renda":    ("Formulário de Renda", "Formulario_de_renda_pessoa_natural", None),
 "ausencia_renda":("Declaração de ausência de renda", "Declaracao_de_ausencia_de_renda", "renda"),
 "renda_informal":("Declaração de renda informal", "Declaracao_de_renda_informal", "renda"),
 "ausencia_ctps": ("Declaração de ausência de Carteira de Trabalho", "Declaracao_de_ausencia_de_CTPS", "ctps"),
 "titular":       ("Declaração do Titular do Comprovante", "Declaracao_de_residencia_proprietario", "residencia"),
 "sem_conta":     ("Declaração de Residência", "Declaracao_de_residencia_sem_conta_em_nome_proprio", "residencia"),
 "renuncia":      ("Declaração de renúncia (Juizado Especial Federal)", "Declaracao_de_renuncia", None),
 "termo":         ("Termo de não reconhecimento de assinatura", "Termo_de_nao_reconhecimento_de_assinatura", None),
 "beneficio":     ("Formulário médico – benefício por incapacidade", "Laudo_medico_beneficio_por_incapacidade", "medico"),
 "adicional":     ("Formulário médico – adicional de 25% na aposentadoria", "Laudo_medico_adicional_25", "medico"),
 "loas":          ("Formulário médico – BPC à pessoa com deficiência", "Formulario_BPC_LOAS_pessoa_com_deficiencia", "medico"),
 "cirurgia":      ("Formulário médico – cirurgia", "Laudo_medico_cirurgia", "medico"),
 "exame":         ("Formulário médico – exame", "Laudo_medico_exame", "medico"),
 "uti":           ("Formulário médico – internação ou UTI", "Laudo_medico_internacao_UTI", "medico"),
 "tratamento":    ("Formulário médico – tratamento", "Formulario_pedido_judicial_tratamento", "medico"),
 "med6":          ("Formulário médico – medicamentos (Tema 6 do STF)", "Formulario_pedido_judicial_medicamentos_Tema_6_STF", "medico"),
 "med":           ("Formulário médico – medicamentos (modelo anterior)", "Formulario_pedido_judicial_medicamentos", "medico"),
 "onco":          ("Formulário médico – tratamento oncológico", "Questionamentos_do_juizo_casos_oncologicos", "medico"),
}
ANALF = {k: RAIZ + f"lote/saida/PDF/{F[k][1]}_analfabeto.pdf" for k in
         ["ausencia_renda", "renda_informal", "ausencia_ctps", "titular", "sem_conta", "renuncia", "termo"]}
ANALF["form_renda"] = RAIZ + "final/Formulario_de_renda_pessoa_natural_analfabeto.pdf"

def svg_pages(pdf, td):
    n = int([l for l in subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout.splitlines() if l.startswith("Pages")][0].split()[1])
    pages = []
    for i in range(1, n + 1):
        subprocess.run(["pdftocairo", "-svg", "-f", str(i), "-l", str(i), pdf, f"{td}/p.svg"], check=True)
        pages.append(base64.b64encode(gzip.compress(open(f"{td}/p.svg", "rb").read(), 9, mtime=0)).decode())
    return pages

out = {}
with tempfile.TemporaryDirectory() as td:
    for k, (label, fn, link) in F.items():
        pdf = f"{P}/{fn}.pdf"
        n = int([l for l in subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout.splitlines() if l.startswith("Pages")][0].split()[1])
        pages = []
        for i in range(1, n + 1):
            subprocess.run(["pdftocairo", "-svg", "-f", str(i), "-l", str(i), pdf, f"{td}/p.svg"], check=True)
            pages.append(base64.b64encode(gzip.compress(open(f"{td}/p.svg", "rb").read(), 9, mtime=0)).decode())
        out[k] = {"label": label, "link": link, "arq": fn, "pages": pages, "pdf": base64.b64encode(open(pdf, "rb").read()).decode()}
        if k in ANALF:   # versão para assistido(a) analfabeto(a): digital + assinatura a rogo + duas testemunhas
            out[k]["pages_a"] = svg_pages(ANALF[k], td)
            out[k]["pdf_a"] = base64.b64encode(open(ANALF[k], "rb").read()).decode()
json.dump(out, open("forms_f.json", "w"))
print(len(out), "formulários |", sum(len(v["pages"]) for v in out.values()), "páginas |",
      sum(len(v["pdf"]) + sum(map(len, v["pages"])) for v in out.values()) // 1024, "KB")

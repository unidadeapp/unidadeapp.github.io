# Relatório técnico completo (PDF): manual de todos os apps + seção técnica.
# Vai só no Unidade (offline e online) e no HUB. Gera relatorio/Relatorio_tecnico.pdf (fora do git: o construir.sh gera).
# O manual reaproveita os Tutoriais do Unidade (trabalho/tutorial.html) e os do Térreo (comum/tours_terreo.py),
# então o relatório acompanha o app sozinho. A seção técnica está aqui embaixo.
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"
import asyncio, datetime, re, sys
sys.path.insert(0, RAIZ + "comum"); sys.path.insert(0, RAIZ + "scripts")
import marca, tours_terreo
from navegador import abrir
from playwright.async_api import async_playwright

ler = lambda p: open(RAIZ + p, encoding="utf-8").read()
V = {"Unidade": re.search(r"Versão de Testes ([0-9.]+)", ler("trabalho/page_t.html")).group(1),
     "Térreo": re.search(r'VERSAO = "([0-9.]+)"', ler("juntos/gen_juntos.py")).group(1),
     "Térreo – DAC": re.search(r'VERSAO = "([0-9.]+)"', ler("dac/gen_dac.py")).group(1),
     "Térreo – AG": re.search(r'VERSAO = "([0-9.]+)"', ler("adag/gen_adag.py")).group(1)}

# ---------- manual: os Tutoriais do Unidade, sem botões nem a caixa do tour
tut = ler("trabalho/tutorial.html")
artigos = re.findall(r"<article[^>]*>.*?</article>", tut, flags=re.S)
manual = "\n".join(artigos)
manual = re.sub(r"<button[^>]*>.*?</button>", "", manual, flags=re.S)
manual = re.sub(r"__[A-Z_]+__", "", manual)
manual = re.sub(r"<h2>", '<h2 class="sec">', manual)
terreo = tours_terreo.tutoriais(["lista", "semAtend", "checklist", "central", "narrativas", "preencher", "mensagens"])
terreo = re.sub(r"<button[^>]*>.*?</button>", "", terreo, flags=re.S)

TECNICA = """
<h2 class="parte">Parte 3 · Seção técnica</h2>
<h3>Como os apps são feitos</h3>
<ul>
<li><b>Arquivo único.</b> Cada app offline é <b>um só arquivo HTML</b> (Unidade.html, Térreo.html, Térreo - DAC.html, Térreo - AG.html). Tudo vai dentro dele: telas, programas, imagens (em base64), formulários em PDF e Word e as bibliotecas (pdf-lib para preencher PDF, fflate e pako para compactar, html2canvas para o Salvar em PDF). Por isso abre com dois cliques, sem instalar nada e sem internet.</li>
<li><b>Ferramentas em quadros.</b> Cada ferramenta (Lista de Documentos, Checklist, Central, Narrativas, Preenchimento, Assistente, Aprender) é uma página guardada dentro do app e aberta num quadro (iframe) quando é usada. Uma vez aberta, fica guardada: o que estava em andamento não se perde ao voltar. Desde a 0.6.11, as ferramentas começam a abrir antes do clique (mouse em cima do cartão, ao entrar no setor e durante o tour).</li>
<li><b>Conversa entre as partes.</b> A página principal e as ferramentas trocam mensagens (postMessage): voltar, ir para o início, abrir o Preenchimento com os formulários marcados, trocar o modo escuro, avisar o tour.</li>
<li><b>Montagem.</b> Os apps são gerados por programas em Python a partir do código-fonte (o comando <b>./construir.sh</b>, na ordem: faltantes → lista → aprender → assistente → central → narrativas → preencher → trabalho → dac → adag → juntos). Os arquivos da pasta apps/ nunca são editados à mão. O <b>scripts/testar.py</b> confere, a cada versão, a impressão das listas em 1 folha (com o menu ao lado e em cima) e a abertura dos quatro apps sem erro.</li>
<li><b>Partes comuns.</b> O menu ao lado, a Têmis, a tela A DPU Pelotas, o tour, a Apresentação, o modo escuro, o Checklist, a Central, o Preenchimento e as narrativas são os mesmos em todos os apps: uma mudança vale para todos.</li>
</ul>
<h3>Impressão e PDF</h3>
<ul>
<li><b>Uma folha só.</b> A lista de documentos faltantes e a do agendamento ajustam o tamanho da letra sozinhas para caber em 1 folha A4.</li>
<li><b>Mudança de cor na impressão</b> (0.6.3). Na tela, a folha tem os tons verdes da DPU. Na impressão, uma regra própria troca os textos e as linhas por cores escuras (preto e cinza-escuro), para a folha sair legível em qualquer impressora, inclusive nas que só imprimem em preto. O <b>Salvar em PDF</b> mantém as cores da tela.</li>
<li><b>Salvar em PDF.</b> O app "fotografa" a folha como ela sairia na impressão (com o html2canvas) e monta o PDF A4 ele mesmo, sem passar pela tela de impressão do navegador. Isso também resolve navegadores em que a tela de impressão fica cinza (como o Opera GX).</li>
<li><b>Firefox.</b> As alturas da impressão usam a área útil da página (100vh), porque o Firefox deixava uma folha em branco antes dos formulários.</li>
<li><b>Formulários.</b> Os 24 formulários são PDFs preenchíveis e modelos Word gerados por programa (pasta lote/), com uma letra automática por campo e versão para assistido(a) analfabeto(a) (digital, assinatura a rogo e testemunhas).</li>
</ul>
<h3>Modo escuro</h3>
<p>A página principal inverte as cores e gira os tons de volta (o verde continua verde, só que claro sobre fundo escuro). As ferramentas escurecem junto e "desinvertem" as fotos, as prévias de PDF e a folha da lista, que continuam parecendo papel. A impressão e os PDFs saem sempre claros. A escolha fica guardada no computador; sem escolha, o app segue o modo do sistema.</p>
<h3>O que fica guardado no computador</h3>
<p>Só no navegador de quem usa (localStorage), nunca na internet:</p>
<ul>
<li><b>Meus PAJs</b> (dpuPelotas.pajsDocumentacaoFaltante.v1 e dpuPelotas.pajsConcluidos.v1), o <b>rascunho do atendimento</b> (dpuPelotas.rascunhoAtendimento.v1) e o <b>salário mínimo</b> (dpuPelotas.salarioMinimo.v1);</li>
<li>a <b>assinatura</b> das mensagens (dpuDAC.assinatura) e a do agendamento quando não é a Vera (dpuPelotas.assinaturaAgendamento.v1);</li>
<li>as preferências: menu escondido ou em cima (dpuDAC.ladoRecolhido, dpuDAC.layout) e o modo escuro (dpuPelotas.tema.v1).</li>
</ul>
<p>Atualizar o app (abrir o arquivo novo no mesmo computador e no mesmo navegador) não apaga nada disso.</p>
<h3>A versão online</h3>
<ul>
<li>Fica no site do Claude (claude.ai), como um Artifact. Tem tudo do Unidade offline, com as ferramentas em arquivos separados (o site limita cada arquivo a 16 MB).</li>
<li>O site não abre a tela de impressão: os botões de imprimir <b>baixam o PDF</b>, e cada download pede confirmação. As prévias de PDF são desenhadas com o pdf.js, porque o leitor de PDF do navegador é bloqueado no site.</li>
<li><b>Têmis com o Claude.</b> Usa a conta do Claude de quem está usando (e o limite dela). Cada pergunta vai só ao Claude, sem memória; o app não guarda perguntas nem respostas. Sem a conta aberta, o botão ATIVAR A TÊMIS leva ao login e volta para o app.</li>
</ul>
<h3>HUB das versões</h3>
<p>Página no site do Claude com o link da versão online, o download dos quatro apps (cada um em partes de até 15 MB, que a página junta), as apresentações, o atalho do HUB, este relatório e o <b>código-fonte</b>, trancado com senha (AES-256-GCM, com a chave tirada da senha por PBKDF2; a senha não fica no código).</p>
<h3>Autoria</h3>
<p>O crédito "Desenvolvido por Pedro Tomkowski" aparece na tela inicial de cada app, no menu de todas as ferramentas, na Apresentação e no HUB. O código traz o aviso de autoria (AUTORIA.md), a regra para o Claude nunca removê-lo, e o construir.sh não gera os apps sem ele (Lei nº 9.609/1998, art. 2º, § 1º).</p>
"""

SEG = """
<h2 class="parte">Parte 4 · Segurança e privacidade</h2>
<ul>
<li>Os apps offline <b>funcionam sem internet</b>: nada do que é digitado sai do computador.</li>
<li>Nenhum dado de assistido fica no app nem no código. Documentos com dados de assistidos servem só para tirar jurisprudência ou entender o caso; exemplos são sempre anonimizados (iniciais, sem CPF, NB, endereço ou número de PAJ).</li>
<li>O Preenchimento de formulários não guarda nada: ao fechar, tudo some.</li>
<li>O repositório do código é privado; o código no HUB vai trancado com senha.</li>
</ul>
"""

hoje = datetime.date.today().strftime("%d/%m/%Y")
vers = "".join(f"<li><b>{k}</b>: versão {v}</li>" for k, v in V.items())
HTML = f"""<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>Relatório Técnico – Apps DPU Pelotas</title>
<style>
  @page {{ size: A4; margin: 18mm 17mm 18mm; }}
  body {{ font-family: "Segoe UI", Calibri, Arial, sans-serif; color:#1e241c; font-size:10.5pt; line-height:1.5; }}
  .capa {{ height:240mm; display:flex; flex-direction:column; justify-content:center; align-items:center; text-align:center; break-after:page; border-top:8px solid #3f8f3a; }}
  .capa .lg {{ width:120px; }} .capa .lg svg {{ width:100%; height:auto; }}
  .capa h1 {{ color:#2f6a1f; font-size:30pt; margin:18px 0 6px; }} .capa p {{ margin:4px 0; color:#4b5d41; }}
  .capa ul {{ list-style:none; padding:0; color:#4b5d41; }}
  h2.parte {{ break-before:page; color:#00798b; font-size:20pt; border-bottom:2px solid #00798b; padding-bottom:4px; }}
  h2.sec, article h2 {{ color:#2f6a1f; font-size:14pt; margin:18px 0 6px; break-after:avoid; }}
  h3 {{ color:#2f6a1f; font-size:12pt; margin:14px 0 4px; break-after:avoid; }}
  article {{ break-inside:auto; }} li {{ margin:2px 0; }}
  .onde {{ font-size:9pt; color:#00798b; font-weight:600; margin-left:6px; }}
  table {{ border-collapse:collapse; width:100%; }} td, th {{ border:1px solid #cfdcc8; padding:4px 6px; font-size:9.5pt; vertical-align:top; }}
  .rod {{ margin-top:30px; font-size:9pt; color:#7a8276; text-align:center; }}
  svg {{ max-width:100%; }} img {{ max-width:100%; }}
  .tourBox, .tourBts, .av {{ display:none !important; }}
</style></head><body>
<section class="capa"><span class="lg">{marca.UNIDADE}</span><h1>Relatório Técnico</h1><p><b>Apps DPU Pelotas</b>: Unidade (offline e online), Térreo, Térreo – DAC e Térreo – AG</p>
<ul>{vers}</ul><p>{hoje}</p><p><b>Desenvolvido por Pedro Tomkowski</b> · DPU Pelotas</p>
<p style="font-size:9pt;margin-top:24px">Ferramentas internas de apoio ao trabalho; não são sistemas oficiais da DPU.</p></section>
<h2 class="parte" style="break-before:auto">Parte 1 · Os apps</h2>
<ul>
<li><b>Unidade</b>: o app principal, com todos os setores (Agendamento, DAC, DPS), Aprender, Tutoriais, A DPU Pelotas e Apresentação. Tem versão <b>offline</b> (arquivo no computador) e <b>online</b> (site do Claude, com a Têmis usando o Claude).</li>
<li><b>Térreo</b>: versão mais simples, para os departamentos de atendimento, cartório e agendamento. Derivados: <b>Térreo – DAC</b> (só atendimento e cartório) e <b>Térreo – AG</b> (só agendamento). Todos offline.</li>
<li><b>HUB das versões</b>: a página com o link da versão online e o download de todos os apps.</li>
</ul>
<h2 class="parte">Parte 2 · Manual do Unidade (função por função)</h2>
{manual}
<h2 class="parte">Parte 2.1 · Os apps Térreo</h2>
{terreo}
{TECNICA}
{SEG}
<p class="rod">Relatório gerado automaticamente a partir do app. Desenvolvido por Pedro Tomkowski.</p>
</body></html>"""

open(RAIZ + "relatorio/Relatorio_tecnico.html", "w", encoding="utf-8").write(HTML)

async def pdf():
    async with async_playwright() as p:
        br = await abrir(p)
        pg = await br.new_page()
        await pg.goto("file://" + RAIZ + "relatorio/Relatorio_tecnico.html")
        await pg.pdf(path=RAIZ + "relatorio/Relatorio_tecnico.pdf", format="A4", print_background=True,
                     display_header_footer=True, header_template="<span></span>",
                     footer_template='<div style="font-size:8px;width:100%;text-align:center;color:#7a8276">Relatório Técnico – Apps DPU Pelotas · página <span class="pageNumber"></span> de <span class="totalPages"></span></div>',
                     margin={"top": "18mm", "bottom": "18mm", "left": "17mm", "right": "17mm"})
        await br.close()
asyncio.run(pdf())
import os
print("relatorio/Relatorio_tecnico.pdf", os.path.getsize(RAIZ + "relatorio/Relatorio_tecnico.pdf") // 1024, "KB")

# Monta o Assistente de Abertura de PAJ num único arquivo HTML (funciona offline no Chrome/Edge)
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, json, os, re, sys
sys.path.insert(0, RAIZ + "lista")
from demandas import DEMANDAS

D = RAIZ + "assistente/"
bold = lambda t: re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
dem = []
for a, n, o in DEMANDAS:
    d = {"area": a, "nome": n, **o}
    d["docs"] = [bold(x) for x in d["docs"]]
    if "residencia" in d: d["residencia"] = bold(d["residencia"])
    dem.append(d)

forms = json.load(open(D + "forms_a.json"))
R = {
    "LOGO": base64.b64encode(open(RAIZ + "src/img-002.jpg", "rb").read()).decode(),
    "LOAS_FORM": open(D + "loas.html", encoding="utf-8").read(),
    "PDFLIB": open(D + "lib/pdf-lib.min.js", encoding="utf-8").read(),
    "FFLATE": open(D + "lib/fflate.min.js", encoding="utf-8").read(),
    "DEMANDAS": json.dumps(dem, ensure_ascii=False),
    "FORMS": json.dumps(forms),
    "CID": json.dumps(open(D + "cid10.txt", encoding="utf-8").read(), ensure_ascii=False),
    "JS": open(D + "app.js", encoding="utf-8").read(),
    "GLOSS": json.dumps(json.load(open(RAIZ + "aprender/glossario.json", encoding="utf-8")), ensure_ascii=False),
    "CIDADES": json.dumps(open(D + "cidades.txt", encoding="utf-8").read(), ensure_ascii=False),
    "CID11": json.dumps(open(D + "cid11.txt", encoding="utf-8").read(), ensure_ascii=False) if os.path.exists(D + "cid11.txt") else '""',
}
for k, v in R.items():
    assert "</script" not in v.lower() or k == "LOAS_FORM", k
html = open(D + "page.html", encoding="utf-8").read()
html = re.sub(r"__(LOGO|LOAS_FORM|PDFLIB|FFLATE|DEMANDAS|FORMS|CID11|CIDADES|CID|GLOSS|JS)__", lambda m: R[m.group(1)], html)
assert not re.search(r"__(LOGO|LOAS_FORM|PDFLIB|FFLATE|DEMANDAS|FORMS|CID11|CIDADES|CID|GLOSS|JS)__", html)
out = D + "Assistente_de_Abertura_de_PAJ.html"
open(out, "w", encoding="utf-8").write(html)
print(out, len(html.encode()) // 1024, "KB")

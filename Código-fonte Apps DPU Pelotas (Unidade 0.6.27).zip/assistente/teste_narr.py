from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import sys as _sys; _sys.path.insert(0, RAIZ + "scripts"); from navegador import abrir
import asyncio, json, sys
from playwright.async_api import async_playwright
URL = "file://" + RAIZ + "assistente/Assistente_de_Abertura_de_PAJ.html"
PREENCHER = r"""() => {
  const NF = document.getElementById("narrForm");
  const grupos = {};
  NF.querySelectorAll('input[type=radio]').forEach(r => { if (!grupos[r.name]) { grupos[r.name] = 1; r.checked = true; r.dispatchEvent(new Event("change", {bubbles:true})); } });
  NF.querySelectorAll('input[type=checkbox][data-multi]').forEach((c, i) => { if (c.dataset.n !== "prio" && !c.checked && i % 2 === 0) { c.checked = true; c.dispatchEvent(new Event("change", {bubbles:true})); } });
  for (let k = 0; k < 2; k++) NF.querySelectorAll('input[type=text]:not(.hide input), textarea').forEach(t => { if (!t.value && t.offsetParent) { t.value = t.dataset.money !== undefined ? "500,00" : "teste " + (t.dataset.n || t.dataset.m || ""); t.dispatchEvent(new Event("input", {bubbles:true})); t.dispatchEvent(new Event("change", {bubbles:true})); } });
}"""
async def main():
    async with async_playwright() as p:
        br = await abrir(p)
        pg = await (await br.new_context(viewport={"width": 1360, "height": 900})).new_page()
        erros = []
        pg.on("pageerror", lambda e: erros.append("PAGEERROR " + str(e)))
        pg.on("console", lambda m: erros.append(m.text) if m.type == "error" else None)
        await pg.goto(URL)
        await pg.click("#irNovo")
        await pg.evaluate("() => { ir(3); }")
        await pg.fill('section.step.on [data-s="mae"]', "Joana dos Santos")
        await pg.fill('section.step.on [data-s="nasc"]', "1980-05-04")
        dems = await pg.evaluate("() => DEMANDAS.map(d => d.nome)")
        out = []
        for dn in dems:
            await pg.evaluate("n => escolherDemanda(DEMANDAS.find(d => d.nome === n))", dn)
            tabs = await pg.evaluate("() => [...document.querySelectorAll('#narrTabs .tab')].map(b => b.dataset.id)")
            if not tabs: tabs = [None]
            for t in tabs:
                if t: await pg.click(f'#narrTabs .tab[data-id="{t}"]')
                vazio = None
                if await pg.locator("#gerarNarr").is_visible():
                    await pg.click("#gerarNarr")
                    vazio = await pg.text_content("#narrFaltas")
                    await pg.evaluate(PREENCHER)
                    await pg.click("#gerarNarr")
                    txt = await pg.inner_text("#narrTexto")
                    falt = await pg.text_content("#narrFaltas")
                    st = await pg.get_attribute("#narrCopiado", "class")
                else:
                    txt, falt, st = "(sem narrativa)", "", ""
                out.append({"dem": dn, "var": t, "vazio": vazio, "faltas": falt, "status": st, "texto": txt})
        json.dump(out, open("/tmp/narr_out.json", "w"), ensure_ascii=False, indent=1)
        print(len(out), "narrativas;", sum(1 for o in out if o["status"] == "erro"), "com erro")
        print("ERROS JS:", erros[:10])
        await br.close()
asyncio.run(main())

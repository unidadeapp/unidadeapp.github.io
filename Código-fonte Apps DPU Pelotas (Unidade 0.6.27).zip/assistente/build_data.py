# Formulários para o Assistente: PDF preenchível normal e, quando houver, a versão para assistido(a) analfabeto(a)
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, json
P = RAIZ + "pacote2/Formularios_DPU_Pelotas/PDF (preenchiveis)/"
F = {  # chave: (tipo de documento — usado no nome do arquivo, arquivo, item da lista que o torna desnecessário)
 "form_renda":    ("Formulário de Renda", "Formulario_de_renda_pessoa_natural", None),
 "ausencia_renda":("Declaração de ausência de renda", "Declaracao_de_ausencia_de_renda", "renda"),
 "renda_informal":("Declaração de renda informal", "Declaracao_de_renda_informal", "renda"),
 "ausencia_ctps": ("Declaração de ausência de Carteira de Trabalho", "Declaracao_de_ausencia_de_CTPS", "ctps"),
 "titular":       ("Declaração do Titular do Comprovante", "Declaracao_de_residencia_proprietario", "residencia"),
 "sem_conta":     ("Declaração de Residência", "Declaracao_de_residencia_sem_conta_em_nome_proprio", "residencia"),
 "termo":         ("Termo de não reconhecimento de assinatura", "Termo_de_nao_reconhecimento_de_assinatura", None),
 "beneficio":     ("Formulário médico - benefício por incapacidade", "Laudo_medico_beneficio_por_incapacidade", "medico"),
 "adicional":     ("Formulário médico - adicional de 25% na aposentadoria", "Laudo_medico_adicional_25", "medico"),
 "loas":          ("Formulário médico - BPC à pessoa com deficiência", "Formulario_BPC_LOAS_pessoa_com_deficiencia", "medico"),
 "cirurgia":      ("Formulário médico - cirurgia", "Laudo_medico_cirurgia", "medico"),
 "exame":         ("Formulário médico - exame", "Laudo_medico_exame", "medico"),
 "uti":           ("Formulário médico - internação ou UTI", "Laudo_medico_internacao_UTI", "medico"),
 "tratamento":    ("Formulário médico - tratamento", "Formulario_pedido_judicial_tratamento", "medico"),
 "med6":          ("Formulário médico - medicamentos (Tema 6 do STF)", "Formulario_pedido_judicial_medicamentos_Tema_6_STF", "medico"),
 "med":           ("Formulário médico - medicamentos (modelo anterior)", "Formulario_pedido_judicial_medicamentos", "medico"),
 "onco":          ("Formulário médico - tratamento oncológico", "Questionamentos_do_juizo_casos_oncologicos", "medico"),
}
out = {}
for k, (tipo, fn, link) in F.items():
    d = {"tipo": tipo, "link": link, "pdf": base64.b64encode(open(P + fn + ".pdf", "rb").read()).decode()}
    try:
        d["pdf_a"] = base64.b64encode(open(P + fn + "_analfabeto.pdf", "rb").read()).decode()
    except FileNotFoundError:
        pass
    out[k] = d
json.dump(out, open("forms_a.json", "w"))
print(len(out), "formulários |", sum(1 for v in out.values() if "pdf_a" in v), "com versão para analfabeto |",
      sum(len(v["pdf"]) + len(v.get("pdf_a", "")) for v in out.values()) // 1024, "KB")

# Código-fonte para o HUB, trancado com senha.
# Monta um .zip com os arquivos do projeto (sem a pasta apps/, que já está no HUB, e sem o histórico do git),
# troca o CLAUDE.md por uma versão para quem não é o Pedro, tranca tudo com a senha (AES-256-GCM, chave tirada da senha
# com PBKDF2-SHA256, 600 mil rodadas: cada tentativa de adivinhar fica lenta) e divide em partes de texto de até 15 MB.
# A senha NUNCA fica no repositório: vem da variável de ambiente SENHA_CODIGO na hora de gerar o HUB.
# A página do HUB pede a senha, junta as partes e destranca no próprio navegador (WebCrypto).
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"
import base64, hashlib, io, json, os, subprocess, zipfile
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ITER = 600_000
LIM = 15 * 1024 * 1024
FORA = ("apps/",)   # os apps prontos já estão no HUB

COMO = """COMO MEXER NO CÓDIGO DOS APPS DPU PELOTAS (com o Claude)
=========================================================

Desenvolvido por Pedro Tomkowski. Leia o AUTORIA.md: o crédito "Desenvolvido por Pedro Tomkowski" tem de continuar
visível em qualquer versão modificada.

1. Descompacte este .zip numa pasta do computador.
2. Abra a pasta no Claude Code (no app do Claude para computador: Code > abrir a pasta; ou no terminal, dentro da
   pasta, o comando: claude). Precisa de uma conta do Claude com acesso ao Claude Code.
3. Peça a mudança em português, do jeito que você explicaria a um colega. O Claude lê o arquivo CLAUDE.md, que explica
   como o projeto funciona e as regras (privacidade, versões, crédito de autoria).
4. O Claude monta os apps de novo com o ./construir.sh e confere com o python3 scripts/testar.py. Os apps prontos
   aparecem na pasta apps/.
   Precisa de: Python 3, poppler (pdftocairo, pdfinfo) e Playwright com o Chromium. O Claude instala o que faltar.
5. Nunca coloque no projeto documentos com dados de assistidos (nome, CPF, NB, endereço, número de PAJ).
"""


def claude_md(txt):
    """CLAUDE.md para quem baixa o código: a abertura deixa de dizer que quem está mexendo é o Pedro."""
    ini = txt.index("Sou o Pedro Tomkowski")
    fim = txt.index("Este repositório tem quatro apps")
    novo = ("Este projeto foi criado por **Pedro Tomkowski** (estagiário do setor processual da DPU Pelotas). Quem está mexendo "
            "agora pode não saber programar: explique de forma didática, sem mostrar código nem nomes técnicos de arquivo, e diga "
            "o que fazer se der erro. O crédito \"Desenvolvido por Pedro Tomkowski\" tem de continuar visível (veja AUTORIA.md). ")
    return txt[:ini] + novo + txt[fim:]


def montar_zip():
    nomes = subprocess.run(["git", "ls-files", "-z"], cwd=RAIZ, capture_output=True).stdout.decode().split("\0")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n in sorted(filter(None, nomes)):
            if n.startswith(FORA) or not os.path.isfile(RAIZ + n): continue
            if n == "CLAUDE.md": z.writestr(n, claude_md(open(RAIZ + n, encoding="utf-8").read())); continue
            z.write(RAIZ + n, n)
        z.writestr("COMO_MEXER_NO_CODIGO.txt", COMO)
    return buf.getvalue()


def gerar(pasta_partes, versao):
    """Gera as partes trancadas; devolve os dados que a página precisa (ou None, sem a senha)."""
    senha = os.environ.get("SENHA_CODIGO", "")
    if not senha: return None
    dados = montar_zip()
    sal, iv = os.urandom(16), os.urandom(12)
    chave = hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), sal, ITER, 32)
    txt = base64.b64encode(AESGCM(chave).encrypt(iv, dados, None)).decode()
    partes = []
    for n, i in enumerate(range(0, len(txt), LIM), 1):
        nome = f"partes/codigo-{n}.txt"
        open(pasta_partes + f"codigo-{n}.txt", "w").write(txt[i:i + LIM]); partes.append(nome)
    return {"arq": f"Código-fonte Apps DPU Pelotas (Unidade {versao}).zip", "partes": partes, "iter": ITER,
            "sal": base64.b64encode(sal).decode(), "iv": base64.b64encode(iv).decode(), "mb": round(len(dados) / 1048576, 1)}

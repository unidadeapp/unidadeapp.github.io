window.DPU_ONLINE = true;
(function () {  // Unidade online: o site do Claude não deixa imprimir nem baixar direto; isto adapta cada ferramenta
  const pai = window.parent !== window ? window.parent : null;
  /* downloads: o arquivo vai para a página principal, que pede ao site do Claude para salvar (a pessoa confirma) */
  async function enviar(href, nome) {
    const buf = await (await fetch(href)).arrayBuffer();
    if (pai) pai.postMessage({ baixar: { nome: nome || "arquivo", dados: buf } }, "*", [buf]);
  }
  const clicar = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.hasAttribute("download") && /^(blob|data):/.test(this.href)) { enviar(this.href, this.download); return; }
    return clicar.call(this);
  };
  document.addEventListener("click", e => {
    const a = e.target.closest && e.target.closest("a[download]");
    if (a && /^(blob|data):/.test(a.href)) { e.preventDefault(); enviar(a.href, a.download); }
  }, true);

  /* imprimir → baixar o PDF: a folha é fotografada como sairia na impressão e vira uma página A4 */
  function trocarMidia() {  // as regras de impressão passam a valer na tela; as de tela, não
    const feitas = [];
    for (const ss of document.styleSheets) {
      let rs; try { rs = ss.cssRules; } catch (e) { continue; }
      for (const r of rs) {
        if (!(r instanceof CSSMediaRule)) continue;
        const m = r.media.mediaText;
        if (/\bprint\b/.test(m) && !/screen/.test(m)) { feitas.push([r, m]); r.media.mediaText = "all"; }
        else if (/^\s*screen\s*$/.test(m)) { feitas.push([r, m]); r.media.mediaText = "not all"; }
      }
    }
    return () => feitas.forEach(([r, m]) => { r.media.mediaText = m; });
  }
  const quadro = () => new Promise(ok => requestAnimationFrame(() => requestAnimationFrame(ok)));
  const visivel = el => getComputedStyle(el).display !== "none" && !el.closest("[hidden]") && el.getClientRects().length > 0;
  async function imagem(img) {  // página de formulário (desenho): direto na resolução da folha
    if (!img.complete || !img.naturalWidth) await new Promise(ok => { img.onload = ok; img.onerror = ok; });
    const c = document.createElement("canvas"); c.width = 1654; c.height = 2339;
    const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height);
    const k = Math.min(c.width / img.naturalWidth, c.height / img.naturalHeight);
    x.drawImage(img, (c.width - img.naturalWidth * k) / 2, (c.height - img.naturalHeight * k) / 2, img.naturalWidth * k, img.naturalHeight * k);
    return c;
  }
  function nomePDF() {
    const so = document.body.classList.contains("so-form");
    const dem = (typeof atual !== "undefined" && atual && atual.nome) ? " - " + atual.nome : "";
    const base = so ? "Formulário" : (window.dpuNomePDF || document.title.replace(/ – DPU Pelotas$/, ""));
    return (base + dem).replace(/[\\/:*?"<>|]/g, "-").slice(0, 120) + ".pdf";
  }
  let gerando = false;
  async function gerarPDF() {
    if (gerando) return; gerando = true;
    const aviso = document.createElement("div"); aviso.className = "pdfGerando"; aviso.textContent = "Gerando o PDF…"; document.body.appendChild(aviso);
    let voltar = () => {};
    try {
      window.dispatchEvent(new Event("beforeprint"));
      voltar = trocarMidia(); await quadro(); await quadro();
      const els = [...document.querySelectorAll(".sheet, .fpage")].filter(visivel);
      if (!els.length) throw new Error("nada para imprimir");
      const pdf = await PDFLib.PDFDocument.create(), A4 = [595.28, 841.89];
      for (const el of els) {
        let c;
        if (el.classList.contains("fpage")) c = await imagem(el.querySelector("img"));
        else {
          const antes = el.style.cssText;
          el.style.width = "210mm"; el.style.minHeight = "0"; el.style.height = "auto"; el.style.margin = "0";
          try { c = await html2canvas(el, { scale: 2, backgroundColor: "#ffffff", logging: false }); } finally { el.style.cssText = antes; }
        }
        const img = await pdf.embedJpg(c.toDataURL("image/jpeg", 0.92));
        const pg = pdf.addPage(A4), k = Math.min(A4[0] / c.width, A4[1] / c.height), w = c.width * k, h = c.height * k;
        pg.drawImage(img, { x: (A4[0] - w) / 2, y: A4[1] - h, width: w, height: h });
      }
      voltar(); voltar = () => {};
      const bytes = await pdf.save();
      const buf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
      if (pai) pai.postMessage({ baixar: { nome: nomePDF(), dados: buf } }, "*", [buf]);
    } catch (e) {
      console.error(e);
      aviso.textContent = "Não consegui gerar o PDF aqui. Use a versão offline do app para imprimir.";
      setTimeout(() => aviso.remove(), 5000); voltar(); gerando = false;
      window.dispatchEvent(new Event("afterprint")); return;
    }
    aviso.remove(); gerando = false;
    window.dispatchEvent(new Event("afterprint"));
  }
  window.print = () => { gerarPDF(); };

  /* prévia de PDF: o leitor de PDF do navegador é bloqueado no site do Claude; aqui as páginas são desenhadas com o pdf.js */
  if (window.pdfjsLib && window.PDFJS_WORKER) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = URL.createObjectURL(new Blob([window.PDFJS_WORKER], { type: "text/javascript" }));
    const css = document.createElement("style");
    css.textContent = ".visorPdf{width:100%;height:100%;overflow:auto;background:#e9ece6;padding:10px;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;gap:10px}"
      + ".visorPdf canvas{background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.18);max-width:100%;height:auto}"
      + ".visorPdf .pg{width:100%;display:flex;justify-content:center;flex:0 0 auto}"
      + ".visorPdf .msg{font:14px 'Segoe UI',Arial,sans-serif;color:#5f5f5f;padding:30px}";
    document.head.appendChild(css);
    async function desenharPDF(box, url, pagina) {
      const vez = (box._vez = (box._vez || 0) + 1);
      box.innerHTML = '<div class="msg">Carregando o PDF…</div>';
      try {
        const dados = await (await fetch(url.split("#")[0])).arrayBuffer();
        const doc = await pdfjsLib.getDocument({ data: dados }).promise;
        if (vez !== box._vez) return;
        box.innerHTML = "";
        const larg = Math.max(300, box.clientWidth - 30), dpr = window.devicePixelRatio || 1, pgs = [];
        for (let i = 1; i <= doc.numPages; i++) { const d = document.createElement("div"); d.className = "pg"; d.dataset.pg = i; box.appendChild(d); pgs.push(d); }
        const desenhar = async d => {
          if (d._feito) return; d._feito = true;
          const pg = await doc.getPage(+d.dataset.pg), v1 = pg.getViewport({ scale: 1 }), k = larg / v1.width, vp = pg.getViewport({ scale: k * dpr });
          const c = document.createElement("canvas"); c.width = vp.width; c.height = vp.height; c.style.width = (vp.width / dpr) + "px";
          d.appendChild(c);
          await pg.render({ canvasContext: c.getContext("2d"), viewport: vp, annotationMode: pdfjsLib.AnnotationMode.ENABLE }).promise;
        };
        const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) desenhar(e.target); }), { root: box, rootMargin: "600px" });
        for (const d of pgs) {  // altura certa de cada página antes de desenhar: assim "ir para a página" cai no lugar certo
          const v1 = (await doc.getPage(+d.dataset.pg)).getViewport({ scale: 1 });
          d.style.height = Math.round(larg * v1.height / v1.width) + "px"; io.observe(d);
        }
        if (pagina && pgs[pagina - 1]) { await desenhar(pgs[pagina - 1]); pgs[pagina - 1].scrollIntoView({ block: "start" }); }
      } catch (e) { console.error(e); box.innerHTML = '<div class="msg">Não consegui mostrar o PDF aqui. Baixe o arquivo para ver.</div>'; }
    }
    // <embed type="application/pdf"> (prévia do Preenchimento) vira o visor
    const trocarEmbeds = () => document.querySelectorAll('embed[type="application/pdf"]').forEach(e => {
      const box = document.createElement("div"); box.className = "visorPdf"; e.replaceWith(box); desenharPDF(box, e.getAttribute("src"));
    });
    new MutationObserver(trocarEmbeds).observe(document.documentElement, { childList: true, subtree: true });
    // <iframe src="blob:..."> (Manual do Estagiário) também
    const desc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, "src");
    Object.defineProperty(HTMLIFrameElement.prototype, "src", {
      configurable: true, get() { return desc.get.call(this); },
      set(v) {
        if (typeof v === "string" && v.startsWith("blob:") && this.isConnected) {
          let box = this._visor;
          if (!box) { box = this._visor = document.createElement("div"); box.className = "visorPdf"; this.after(box); this.style.display = "none"; }
          const m = v.match(/#page=(\d+)/), base = v.split("#")[0];
          if (box._url === base && m) { const d = box.querySelector(`.pg[data-pg="${m[1]}"]`); if (d) { d.scrollIntoView({ block: "start" }); if (!d._feito) d.dispatchEvent(new Event("ver")); return; } }
          box._url = base; desenharPDF(box, v, m ? +m[1] : 0); return;
        }
        desc.set.call(this, v);
      }
    });
  }
  window.open = () => null;  // novas guias não abrem no site do Claude; os botões que as usavam ficam escondidos
})();

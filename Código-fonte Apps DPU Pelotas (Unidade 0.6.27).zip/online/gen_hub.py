# Monta o HUB das versões (Artifact "Apps DPU Pelotas"): online/hub/index.html + online/hub/partes/*.txt.
# O site do Claude limita cada arquivo a 16 MB e não deixa a página baixar arquivos direto: por isso cada app vai em
# partes de até 15 MB, que a página junta e entrega pela confirmação de download do site.
# Rode depois do construir.sh. Publicar: Artifact com file_path online/hub/index.html, files = partes/*.txt (em 2 publicações
# se passar de 64 MB) e capabilities {"downloads": true}.
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"
import datetime, html as H, json, os, re, subprocess, sys
sys.path.insert(0, RAIZ + "comum")
import marca, apresentacao
sys.path.insert(0, RAIZ + "online")
import codigo

ONLINE = "https://claude.ai/artifact/EknJTG4zKYxXFibcGHZSnV"
HUB = RAIZ + "online/hub/"; P = HUB + "partes/"
os.makedirs(P, exist_ok=True)
for f in os.listdir(P): os.remove(P + f)
ler = lambda p: open(RAIZ + p, encoding="utf-8").read()
ver = lambda p, rx: re.search(rx, ler(p)).group(1)
V = {"atdpu": ver("trabalho/page_t.html", r"Versão de Testes ([0-9.]+)"), "terreo": ver("juntos/gen_juntos.py", r'VERSAO = "([0-9.]+)"'),
     "dac": ver("dac/gen_dac.py", r'VERSAO = "([0-9.]+)"'), "ag": ver("adag/gen_adag.py", r'VERSAO = "([0-9.]+)"')}
FONTE = {"atdpu": "trabalho/page_t.html", "terreo": "juntos/gen_juntos.py", "dac": "dac/gen_dac.py", "ag": "adag/gen_adag.py"}
def data_versao(k):  # data da última mudança de versão (o commit que mexeu no arquivo da versão); sem commit ainda, hoje
    f = FONTE[k]
    if subprocess.run(["git", "diff", "--quiet", "--", f], cwd=RAIZ).returncode != 0: return datetime.date.today().strftime("%d/%m/%Y")
    d = subprocess.run(["git", "log", "-1", "--format=%cs", "--", f], cwd=RAIZ, capture_output=True, text=True).stdout.strip()
    return "/".join(reversed(d.split("-"))) if d else datetime.date.today().strftime("%d/%m/%Y")
APPS = [
 {"k": "atdpu", "arq": "Unidade.html", "nome": "Unidade", "sigla": "", "fam": "atdpu",
  "d": "O app completo, por setor: Agendamento, DAC, DPS, Aprender, Tutoriais e A unidade. Abertura de PAJ em 10 etapas, Meus PAJs, formulários, narrativas, modelos de peças e jurisprudências."},
 {"k": "terreo", "arq": "Térreo.html", "nome": "Térreo", "sigla": "", "fam": "terreo",
  "d": "Para os departamentos de atendimento, cartório e agendamento: documentos necessários e mensagem do agendamento, PAJ sem Atendimento, checklist de documentos, formulários e narrativas."},
 {"k": "dac", "arq": "Térreo - DAC.html", "nome": "Térreo – DAC", "sigla": "", "fam": "terreo",
  "d": "Só o atendimento e cartório: checklist de documentos faltantes, Central de Formulários com preenchimento e as narrativas."},
 {"k": "ag", "arq": "Térreo - AG.html", "nome": "Térreo – AG", "sigla": "", "fam": "terreo",
  "d": "Só o agendamento: lista de documentos necessários, mensagem do agendamento para o WhatsApp e PAJ sem Atendimento."},
]
LIM = 15 * 1024 * 1024
total = 0
for a in APPS:
    txt = ler("apps/" + a["arq"]).replace("\ufffd", "\\ufffd")   # o pdf-lib tem U+FFFD em textos do JavaScript; o site recusa o caractere solto
    a["mb"] = round(len(txt.encode()) / 1048576, 1); a["v"] = V[a["k"]]; a["data"] = data_versao(a["k"])
    partes, ini, n = [], 0, 0
    while ini < len(txt):
        fim = min(len(txt), ini + LIM)
        while len(txt[ini:fim].encode()) > LIM: fim -= 500_000      # letras acentuadas ocupam 2 bytes
        n += 1; nome = f"partes/{a['k']}-{n}.txt"
        open(HUB + nome, "w", encoding="utf-8").write(txt[ini:fim]); partes.append(nome); ini = fim
    a["partes"] = partes; total += a["mb"]

def cartao(a):
    sig = f'<span class="sig">{a["sigla"]}</span>' if a["sigla"] else ""
    return f'''<article class="app" data-k="{a["k"]}">
      <div class="appTopo"><h3>{H.escape(a["nome"])}{sig}</h3><span class="ver">v{a["v"]} · atualizado em {a["data"]}</span></div>
      <p>{H.escape(a["d"])}</p>
      <div class="acoes"><button type="button" class="bt cheio" data-baixar="{a["k"]}">Baixar o app offline</button><span class="tam">{a["mb"]} MB · funciona sem internet</span></div>
      <p class="msg" id="msg-{a["k"]}" role="status"></p></article>'''

# código-fonte trancado com a senha (variável SENHA_CODIGO; sem ela, o HUB mostra "Em breve")
CODIGO_ABERTO = True   # por enquanto o código vai sem senha (pedido do Pedro, 13/11/2026); False volta a trancar com a senha
COD = None if CODIGO_ABERTO else codigo.gerar(P, V["atdpu"])
if CODIGO_ABERTO:
    _zip = codigo.montar_zip()
    COD = {"aberto": True, "arq": f"Código-fonte Apps DPU Pelotas (Unidade {V['atdpu']}).zip", "mb": round(len(_zip) / 1048576, 1)}
if COD is None: print("AVISO: sem SENHA_CODIGO, o código-fonte não entra no HUB.")
# atalho do HUB: arquivinho que abre a página, como os apps (também vai para a pasta apps/)
import base64 as _b64
ICONE = _b64.b64encode(open(RAIZ + "icone/favicon_unidade64.png", "rb").read()).decode()
HUB_URL = "https://unidadeapp.github.io/"   # o HUB que baixa sem login (GitHub Pages); o do site do Claude fica como cópia
ATALHO = f"""<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>HUB das versões – Apps DPU Pelotas</title><link rel="icon" type="image/png" href="data:image/png;base64,{ICONE}">
<style>body{{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#eef1ec;font-family:"Segoe UI",Arial,sans-serif;color:#1e241c}}
main{{background:#fff;border-radius:18px;padding:28px 32px;max-width:460px;text-align:center;box-shadow:0 6px 30px rgba(0,0,0,.08);border-top:6px solid #3f8f3a}}
h1{{color:#2f6a1f;font-size:24px;margin:0 0 8px}}a{{display:inline-block;margin-top:14px;background:#3f7f2a;color:#fff;padding:11px 20px;border-radius:10px;font-weight:700;text-decoration:none}}small{{display:block;margin-top:16px;color:#8a8f87}}</style></head>
<body><main><h1>HUB das versões</h1><p>Abrindo a página com o link da versão online e o download dos apps da DPU Pelotas…</p>
<a href="{HUB_URL}">Abrir o HUB</a><small>Desenvolvido por Pedro Tomkowski</small></main>
<script>setTimeout(function(){{location.href="{HUB_URL}";}},400);</script></body></html>
"""
open(RAIZ + "apps/HUB das versões.html", "w", encoding="utf-8").write(ATALHO)
pagina = open(HUB + "modelo.html", encoding="utf-8").read()
APRES = [("atdpu", "Unidade", apresentacao.slides_atdpu()),
         ("terreo", "Térreo", apresentacao.slides_terreo("", ["lista", "semAtend", "checklist", "central", "narrativas", "preencher"])),
         ("dac", "Térreo – DAC", apresentacao.slides_terreo(" – DAC", ["checklist", "central", "narrativas", "preencher"])),
         ("ag", "Térreo – AG", apresentacao.slides_terreo(" – AG", ["lista", "semAtend"]))]
abas = "".join(f'<button type="button" role="tab" data-k="{k}" aria-selected="{"true" if n == 0 else "false"}">{nome}</button>' for n, (k, nome, _) in enumerate(APRES))
aps = "".join(apresentacao.html(sl, "Apresentação do " + nome).replace('<div class="apres">', f'<div class="apres" data-k="{k}"{"" if n == 0 else " hidden"}>', 1) for n, (k, nome, sl) in enumerate(APRES))
R = {"DATA_ON": data_versao("atdpu"), "ABAS": abas, "APRESENTACOES": aps, "APRES_CSS": apresentacao.CSS, "APRES_JS": apresentacao.JS, "UNIDADE": marca.UNIDADE, "ONLINE": ONLINE, "V_ATDPU": V["atdpu"], "TEMIS": marca.TEMIS, "TERREO": marca.TERREO,
     "CARTAO_ATDPU": cartao(APPS[0]), "CARTOES_TERREO": "".join(cartao(a) for a in APPS[1:]),
     "APPS": json.dumps({a["k"]: {"arq": a["arq"], "partes": a["partes"]} for a in APPS}, ensure_ascii=False),
     "RELATORIO": __import__("base64").b64encode(open(RAIZ + "relatorio/Relatorio_tecnico.pdf", "rb").read()).decode(),
     "CODIGO": json.dumps(COD, ensure_ascii=False), "CODIGO_VER": (f"v{V['atdpu']} · {COD['mb']} MB" + ("" if COD.get("aberto") else " · com senha")) if COD else "em breve",
     "ATALHO": json.dumps({"arq": "HUB das versões.html", "html": ATALHO}, ensure_ascii=False).replace("</", "<\\/")}
CH = r"__(DATA_ON|ABAS|APRESENTACOES|APRES_CSS|APRES_JS|UNIDADE|ONLINE|V_ATDPU|TEMIS|TERREO|CARTAO_ATDPU|CARTOES_TERREO|APPS|CODIGO_VER|CODIGO|ATALHO|RELATORIO|ESTATICO|PASSO1|AVISO_SITE)__"
modelo = pagina
# 1) HUB no site do Claude: baixa pela confirmação do site (precisa de login); aponta para o site que baixa sem login
R.update({"ESTATICO": "false", "PASSO1": "Clique em <b>Baixar o app offline</b>: abre o site de downloads (sem login), já no app escolhido. Clique em baixar lá. O arquivo vai para a pasta Downloads.",
          "AVISO_SITE": f'<p class="avisoSite">Para baixar <b>sem entrar no Claude</b>, use o site de downloads: <a href="{HUB_URL}" target="_blank" rel="noopener">{HUB_URL}</a></p>'})
pagina = re.sub(CH, lambda m: R[m.group(1)], modelo)
# o HUB no site do Claude virou só um atalho para o site (o HUB oficial)
pagina = f"""<title>Apps DPU Pelotas – HUB</title>
<style>body{{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#eef1ec;font-family:"Segoe UI",Arial,sans-serif;color:#1e241c}}
main{{background:#fff;border-radius:18px;padding:28px 32px;max-width:480px;text-align:center;box-shadow:0 6px 30px rgba(0,0,0,.08);border-top:6px solid #3f8f3a}}
h1{{color:#2f6a1f;font-size:24px;margin:0 0 8px}}a.bt{{display:inline-block;margin-top:14px;background:#3f7f2a;color:#fff;padding:12px 22px;border-radius:10px;font-weight:800;text-decoration:none}}small{{display:block;margin-top:16px;color:#8a8f87}}
@media (prefers-color-scheme: dark){{body{{background:#121611;color:#e6ede2}}main{{background:#1b2119}}h1{{color:#8fcf6e}}}}</style>
<main><h1>O HUB das versões mudou de endereço</h1><p>Agora ele fica num site que funciona para qualquer pessoa, sem login: os apps, a versão online, as apresentações, o relatório e o código-fonte.</p>
<a class="bt" href="{HUB_URL}" target="_blank" rel="noopener">Abrir o HUB: unidadeapp.github.io</a><small>Desenvolvido por Pedro Tomkowski</small></main>
<script>try {{ window.open("{HUB_URL}", "_top"); }} catch (e) {{}}</script>"""
open(HUB + "index.html", "w", encoding="utf-8").write(pagina)
# 2) HUB no GitHub Pages (pasta online/github/, fora do git): os apps vão inteiros, baixam direto, sem login
import shutil
G = RAIZ + "online/github/"
if os.path.isdir(G): shutil.rmtree(G)
os.makedirs(G + "partes")
for a in APPS: shutil.copy(RAIZ + "apps/" + a["arq"], G + a["arq"])
for f in os.listdir(P):
    if f.startswith("codigo-"): shutil.copy(P + f, G + "partes/" + f)
if COD and COD.get("aberto"): open(G + COD["arq"], "wb").write(_zip)
R.update({"ESTATICO": "true", "PASSO1": "Clique em <b>Baixar o app offline</b>. O arquivo vai para a pasta Downloads (não precisa de login).", "AVISO_SITE": ""})
pg2 = re.sub(CH, lambda m: R[m.group(1)], modelo)
pg2 = '<!DOCTYPE html>\n<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">\n' + pg2.replace("<title>", "<title>", 1) + "\n</html>"
open(G + "index.html", "w", encoding="utf-8").write(pg2)
open(G + ".nojekyll", "w").write("")
print("HUB:", len(pagina.encode()) // 1024, "KB; partes:", sum(len(a["partes"]) for a in APPS), "arquivos,", round(total, 1), "MB")
for a in APPS: print(" ", a["k"], a["v"], a["partes"])
if COD: print("  código-fonte:", COD["mb"], "MB,", COD.get("partes", "sem senha"))

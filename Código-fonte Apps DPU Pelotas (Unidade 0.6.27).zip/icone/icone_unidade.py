# Gera o ícone do app Unidade (Unidade.ico e favicon) a partir do logo (comum/marca.py), desenhado pelo Chromium.
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"
import asyncio, io, sys
sys.path.insert(0, RAIZ + "comum"); sys.path.insert(0, RAIZ + "scripts")
import marca
from navegador import abrir
from playwright.async_api import async_playwright
from PIL import Image
HTML = f'<html><body style="margin:0;background:transparent"><div style="width:512px;height:512px;border-radius:110px;background:linear-gradient(180deg,#f6fbf3,#dcecd2);display:flex;align-items:center;justify-content:center;box-sizing:border-box;border:16px solid #2f6a1f"><div style="width:360px;height:360px">{marca.UNIDADE.replace("<svg ", "<svg width=\"360\" height=\"360\" ")}</div></div></body></html>'
async def main():
    async with async_playwright() as p:
        b = await abrir(p); pg = await b.new_page(viewport={"width": 512, "height": 512})
        await pg.set_content(HTML); png = await pg.screenshot(omit_background=True); await b.close()
    im = Image.open(io.BytesIO(png)).convert("RGBA")
    tam = [16, 24, 32, 48, 64, 128, 256]
    im.resize((256, 256), Image.LANCZOS).save(RAIZ + "icone/Unidade.ico", sizes=[(t, t) for t in tam])
    im.resize((64, 64), Image.LANCZOS).save(RAIZ + "icone/favicon_unidade64.png")
    print("ok")
asyncio.run(main())

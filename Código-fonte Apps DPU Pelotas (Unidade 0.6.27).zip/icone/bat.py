import sys
bat = r'''@echo off
setlocal
title Criar atalho - Assistente de Trabalho DPU Pelotas
set "PASTA=%~dp0"
set "APP=%~dp0Assistente de Trabalho DPU Pelotas.html"
set "ICONE=%~dp0ATDPU.ico"
if not exist "%APP%" goto falta
if not exist "%ICONE%" goto falta
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $d = [Environment]::GetFolderPath('Desktop'); $s = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Assistente de Trabalho DPU Pelotas.lnk')); $s.TargetPath = $env:APP; $s.IconLocation = $env:ICONE + ',0'; $s.WorkingDirectory = $env:PASTA; $s.Description = 'Assistente de Trabalho - DPU Pelotas'; $s.Save(); exit 0 } catch { exit 1 }"
if errorlevel 1 goto manual
echo.
echo  Pronto! O atalho "Assistente de Trabalho DPU Pelotas" foi criado na area de trabalho.
echo  Nao mova nem renomeie esta pasta: o atalho aponta para ela.
echo.
pause
exit /b 0
:falta
echo.
echo  Deixe este arquivo na mesma pasta do app "Assistente de Trabalho DPU Pelotas.html"
echo  e do icone "ATDPU.ico" e tente de novo.
echo.
pause
exit /b 1
:manual
echo.
echo  O computador nao deixou criar o atalho automaticamente. Faca a mao:
echo  1. Clique com o botao direito no app e escolha "Enviar para", "Area de trabalho - criar atalho".
echo     No Windows 11, clique antes em "Mostrar mais opcoes".
echo  2. Clique com o botao direito no atalho, "Propriedades", aba "Atalho", "Alterar icone...",
echo     "Procurar..." e escolha o arquivo ATDPU.ico desta pasta.
echo.
pause
exit /b 1
'''
open(sys.argv[1], "w", newline="\r\n", encoding="ascii").write(bat)

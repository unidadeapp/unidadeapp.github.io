from PIL import Image, ImageDraw, ImageFont
F = "/usr/share/fonts/opentype/inter/InterDisplay-Black.otf"
FB = "/usr/share/fonts/opentype/inter/InterDisplay-Bold.otf"
def desenhar(px, completo):
    S = px * 8; im = Image.new("RGBA", (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    m = round(S * 0.03); r = round(S * 0.2)
    # fundo verde com leve degradê
    grad = Image.new("RGBA", (S, S))
    gd = ImageDraw.Draw(grad)
    for y in range(S):
        t = y / S; c = tuple(round(a + (b - a) * t) for a, b in zip((246, 251, 243), (220, 236, 210)))
        gd.line([(0, y), (S, y)], fill=c + (255,))
    mask = Image.new("L", (S, S), 0); ImageDraw.Draw(mask).rounded_rectangle([m, m, S - m, S - m], r, fill=255)
    im.paste(grad, (0, 0), mask)
    d.rounded_rectangle([m, m, S - m, S - m], r, outline=(47, 106, 31, 255), width=max(8, round(S * 0.035)))
    def centro(txt, font, cy, cor):
        b = d.textbbox((0, 0), txt, font=font); w, h = b[2] - b[0], b[3] - b[1]
        d.text(((S - w) / 2 - b[0], cy - h / 2 - b[1]), txt, font=font, fill=cor)
    if completo:
        centro("AT", ImageFont.truetype(F, round(S * 0.46)), S * 0.38, (47, 106, 31, 255))
        # faixa clara com DPU
        y0, y1 = S * 0.64, S * 0.86
        d.rounded_rectangle([S * 0.14, y0, S * 0.86, y1], round(S * 0.06), fill=(52, 112, 34, 255))
        centro("DPU", ImageFont.truetype(F, round(S * 0.17)), (y0 + y1) / 2, (255, 255, 255, 255))
    else:
        centro("AT", ImageFont.truetype(F, round(S * 0.56)), S * 0.5, (47, 106, 31, 255))
    return im.resize((px, px), Image.LANCZOS)
tam = [16, 24, 32, 48, 64, 128, 256]
imgs = {t: desenhar(t, t >= 40) for t in tam}
imgs[256].save("ATDPU.ico", sizes=[(t, t) for t in tam], append_images=[imgs[t] for t in tam if t != 256])
desenhar(512, True).save("ATDPU_512.png")
desenhar(64, True).save("favicon64.png")
# prévia: como fica em vários tamanhos sobre fundo de área de trabalho
pv = Image.new("RGB", (760, 300), (32, 70, 110)); x = 30
for t in [256, 128, 64, 48, 32, 24, 16]:
    pv.paste(imgs[t], (x, 150 - t // 2), imgs[t]); x += t + 30
pv.save("previa.png")

#!/bin/bash
# Preparação do ambiente na nuvem (Claude Code na web): este texto vai no campo "Setup script" do ambiente.
apt-get update -qq || true
apt-get install -y -qq poppler-utils || true
pip install -q pypdf pdfplumber playwright || true
pip install -q --break-system-packages pypdf pdfplumber playwright || true
python3 -m playwright install-deps chromium || true
python3 -m playwright install chromium || \
  npx -y @puppeteer/browsers install chrome-headless-shell@stable --path /opt/chrome || true

#!/bin/bash
# Refaz formulários (PDF preenchível + Word) a partir de lote/specs.py e copia para pacote2/.
# Uso: scripts/construir_formularios.sh Nome_do_arquivo [Outro_nome ...]   (sem nome = todos; demora)
# Precisa de: node + pacote docx (npm install na raiz), LibreOffice (apt-get install -y libreoffice-writer), pypdf e pdfplumber.
set -e
cd "$(dirname "$0")/.."
[ -d node_modules/docx ] || npm install --silent
A=(); for n in "$@"; do A+=("$n" "${n}_analfabeto"); done   # versões para analfabeto têm o sufixo _analfabeto
(cd lote && python3 build_all.py "$@" && python3 build_analf.py "${A[@]}")
cp lote/saida/PDF/*.pdf "pacote2/Formularios_DPU_Pelotas/PDF (preenchiveis)/"
cp lote/saida/Word/*.dotx "pacote2/Formularios_DPU_Pelotas/Word (modelos)/"
echo "Formulários copiados para pacote2/. Agora rode ./construir.sh"

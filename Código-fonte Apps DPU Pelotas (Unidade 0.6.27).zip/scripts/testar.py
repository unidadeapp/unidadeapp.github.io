# Testes rápidos depois de ./construir.sh:
#   - a lista de documentos faltantes (Unidade e Térreo) e a lista do Agendamento saem em 1 folha na impressão;
#   - os quatro apps abrem sem erro de JavaScript.
# Uso: python3 scripts/testar.py
import asyncio, glob, io, os, sys
from pathlib import Path
from playwright.async_api import async_playwright
sys.path.insert(0, str(Path(__file__).resolve().parent))
from navegador import abrir as abrir_navegador

R = Path(__file__).resolve().parents[1]
DEMANDAS = ["auxilio-doen", "bpc", "pensao por morte", "aposentadoria por idade", "bolsa familia", "cirurgia", "medicamentos"]
LISTAS = [("Gerador de faltantes", "faltantes/Documentos_faltantes.html", True, None),
          ("Checklist do DAC, menu ao lado", "dac/checklist_lateral.html", True, "lado"),
          ("Checklist do DAC, menu em cima", "dac/checklist_lateral.html", True, "cima"),
          ("Lista do Agendamento", "lista/Lista_de_documentos_necessarios.html", False, None),
          ("Lista do Agendamento, menu ao lado", "adag/lista_lateral.html", False, "lado"),
          ("Lista do Agendamento, menu em cima", "adag/lista_lateral.html", False, "cima")]
falhas = []

def paginas(pdf: bytes) -> int:
    from pypdf import PdfReader
    return len(PdfReader(io.BytesIO(pdf)).pages)

async def testar_listas(br):
    for nome, arq, tem_analf, layout in LISTAS:
        for analf in ([False, True] if tem_analf else [False]):
            for dem in DEMANDAS:
                ctx = await br.new_context(viewport={"width": 1366, "height": 768}); pg = await ctx.new_page()
                await pg.add_init_script("window.print = () => {};" + (f"try{{localStorage.setItem('dpuDAC.layout','{layout}')}}catch(e){{}}" if layout else ""))
                await pg.goto((R / arq).as_uri())
                if analf: await pg.check("#analf")
                await pg.fill("#dem", dem); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(250)
                n = paginas(await pg.pdf(prefer_css_page_size=True))
                ok = n == 1
                if not ok: falhas.append(f"{nome}: '{dem}'{' (analfabeto)' if analf else ''} saiu em {n} folhas")
                await ctx.close()
        print(f"{nome}: impressão conferida")

async def testar_apps(br):
    for arq, card in [("apps/Unidade.html", None), ("apps/Térreo - DAC.html", '[data-ir="checklist"]'),
                      ("apps/Térreo - AG.html", '[data-ir="lista"]'), ("apps/Térreo.html", '[data-ir="semAtend"]')]:
        pg = await br.new_page(viewport={"width": 1366, "height": 768})
        erros = []
        pg.on("pageerror", lambda e: erros.append(str(e)))
        await pg.goto((R / arq).as_uri()); await pg.wait_for_timeout(800)
        if card: await pg.click(card); await pg.wait_for_timeout(1500)
        if erros: falhas.append(f"{arq}: erro de JavaScript: {erros[:2]}")
        print(f"{arq}: abriu")
        await pg.close()

async def testar_preencher(br):  # Unidade: PREENCHER na Central abre o Preenchimento com os formulários marcados
    pg = await br.new_page(viewport={"width": 1366, "height": 800}); erros = []
    pg.on("pageerror", lambda e: erros.append(str(e)))
    await pg.goto((R / "apps/Unidade.html").as_uri() + "#app-central"); await pg.wait_for_timeout(2500)
    fc = pg.frame_locator('iframe[title="central"]')
    await fc.locator(".card .ck").nth(1).check(); await fc.locator(".card .ck").nth(4).check()
    await fc.locator("#zPreencher").click(); await pg.wait_for_timeout(2500)
    n = await pg.frame_locator('iframe[title="preencher"]').locator("#passos button").count()
    if n != 3 or erros: falhas.append(f"Unidade: PREENCHER da Central não abriu os 2 formulários (passos={n}, erros={erros[:2]})")
    print("Unidade: PREENCHER da Central conferido")
    await pg.close()

async def main():
    async with async_playwright() as p:
        br = await abrir_navegador(p)
        await testar_listas(br)
        await testar_apps(br)
        await testar_preencher(br)
        await br.close()
    if falhas:
        print("\nFALHAS:"); [print(" -", f) for f in falhas]; sys.exit(1)
    print("\nTudo certo.")

asyncio.run(main())

# Abre o Chromium para os testes. Se o do Playwright não estiver instalado (versão diferente,
# como na nuvem), usa o Chromium que já existir na máquina. Uso: br = await abrir(p)
import glob, os

LUGARES = ["/opt/pw-browsers/chromium", "/opt/pw-browsers/chromium-*/chrome-linux*/chrome",
           "/opt/chrome/**/chrome-headless-shell", "/opt/chrome/**/chrome"]

async def abrir(p, **kw):
    try:
        return await p.chromium.launch(**kw)
    except Exception:
        for padrao in LUGARES:
            for exe in sorted(glob.glob(padrao, recursive=True), reverse=True):
                if os.access(exe, os.X_OK):
                    try:
                        return await p.chromium.launch(executable_path=exe, **kw)
                    except Exception:
                        pass
        raise SystemExit("Nenhum Chromium encontrado: rode scripts/setup_nuvem.sh")

# Preenchimento de Formulários – DPU Pelotas (Assistente de Documentos DAC).
# Os PDFs não ficam aqui: chegam da Central de Formulários ou do Checklist, junto com a lista do que foi marcado.
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, re
D = RAIZ + "preencher/"
ler = lambda p: open(p, encoding="utf-8").read()
js = ler(D + "app_p.js").replace("__RENDA__", ler(D + "renda_atdpu.js"))
R = {
    "LOGO": base64.b64encode(open(RAIZ + "src/img-002.jpg", "rb").read()).decode(),
    "PDFLIB": ler(RAIZ + "assistente/lib/pdf-lib.min.js"),
    "FFLATE": ler(RAIZ + "assistente/lib/fflate.min.js"),
    "COMUM": ler(RAIZ + "comum/comum.js"),
    "JS": js,
}
for k, v in R.items():
    assert "</script" not in v.lower(), k
html = re.sub(r"__(LOGO|PDFLIB|FFLATE|COMUM|JS)__", lambda m: R[m.group(1)], ler(D + "page_p.html"))
out = D + "Preenchimento_de_formularios.html"
open(out, "w", encoding="utf-8").write(html)
print(out, len(html.encode()) // 1024, "KB")

/* ===== Copiado do Assistente de Abertura de PAJ (ATDPU 0.3, assistente/app.js): etapa 7 (formulário de renda), preenchimento dos PDFs e o
   formulário de renda desenhado em PDF. Mudanças: sem preencherRF (dados da narrativa) e o aviso do nome aponta para o menu. ===== */

const BENS = ["geladeira","fogão","máquina de lavar roupas","micro-ondas","forno elétrico","máquina de secar roupas","televisão","DVD player","home theater",
  "Blu-ray player","ar-condicionado","freezer","aquecedor elétrico","aquecedor a gás","aparelho de som","chuveiro elétrico","chuveiro a gás","computador",
  "notebook","impressora","scanner","multifuncional","console de videogame","telefone fixo","celular","smartphone","tablet"];
const SERVICOS = ["água","luz","gás","TV por assinatura","internet","monitoramento eletrônico","diarista","empregada(o) doméstica(o)","babá","cuidadora de idosos"];
const PERGUNTAS = [  // q: pergunta; det: o que escrever quando a resposta abre o campo; ops: caixinhas
  { q: "Alguém declara anualmente imposto de renda?", det: "Quem?", nota: "Caso positivo, juntar a declaração completa." },
  { q: "Algum membro do grupo familiar percebe pensão alimentícia?", det: "Qual o valor?" },
  { q: "Algum membro do grupo familiar percebe Bolsa Família, Benefício Assistencial (LOAS) ou participa de algum outro programa social?", det: "Quem e qual?" },
  { q: "O imóvel onde residem é próprio, alugado ou cedido?", det: "Qual o valor do imóvel ou do aluguel? (se for cedido, por quem)", ops: ["Próprio", "Alugado", "Cedido", "Outro"], abre: ["Próprio", "Alugado", "Cedido", "Outro"], naoSabe: "Não sabe o valor." },
  { q: "Algum dos membros do grupo familiar possui carro próprio?", det: "Qual o modelo e o ano?" },
  { q: "Algum membro do grupo familiar possui plano de saúde particular?", det: "Quem? Qual o valor mensal?" },
  { q: "Algum membro do grupo familiar estuda em escola ou universidade particular?", det: "Quem? Qual o valor da mensalidade?" },
  { q: "Algum membro do grupo familiar possui bem imóvel diverso daquele informado como de residência?", det: "Onde é localizado? Qual o valor? A que se destina? (se alugado, qual é o valor obtido?)" },
  { q: "Algum membro do grupo familiar é sócio/proprietário de empresa?", det: "Quem?" },
].map(p => ({ ops: ["Sim", "Não"], abre: ["Sim"], ...p }));
const REP_COND = ["PAI", "MÃE", "CURADOR", "TUTOR", "OUTRO"];

function dinheiro(v) {  // "1.621,00" | "1621" | "R$ 300" → número; vazio ou inválido → NaN
  let s = String(v ?? "").replace(/[^\d,.]/g, "");
  if (!s) return NaN;
  if (s.includes(",")) s = s.replace(/\./g, "").replace(",", ".");
  else if ((s.match(/\./g) || []).length > 1 || /\.\d{3}$/.test(s)) s = s.replace(/\./g, "");
  const n = parseFloat(s);
  return isNaN(n) ? NaN : n;
}
const brl = n => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }).replace(/\u00a0/g, " ");
const brlNum = n => n.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
function mascaraCPF(v) {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 3) return d;
  if (d.length <= 6) return d.slice(0, 3) + "." + d.slice(3);
  if (d.length <= 9) return d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6);
  return d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6, 9) + "-" + d.slice(9);
}

/* ---------- etapa 7: formulário de renda ---------- */
function novoRF() { return { sit: "", rend: "", comp: "", mora: "", membros: [], qr: PERGUNTAS.map(() => ({ r: "", t: "" })), bens: [], serv: [], repNA: null, repNome: "", repCpf: "", repCond: "" }; }
const membroRF = m => !!(m && (m.nome || m.par || m.cpf || m.sit || m.rend));
const simNao = (nome, v) => `<div class="op" style="display:inline-flex">${["SIM", "NÃO"].map(o => `<label><input type="radio" name="${nome}" value="${o}"${v === o ? " checked" : ""}> ${o}</label>`).join("")}</div>`;
function renderRF() {
  const rf = S.rf, box = $("rendaForm");
  box.innerHTML = `
  <div class="q"><div class="t">Assistido(a): <span style="font-weight:400" id="rfNome">${esc(S.nome.trim()) || "<i>escreva o nome no menu, em “Nome completo do(a) assistido(a)”</i>"}</span></div>
    <div class="grid2">
      <label class="f span2">Situação ocupacional <small>(escolha na lista ou escreva)</small><input type="text" data-rf="sit" list="situacoes" autocomplete="off"></label>
      <label class="f">Rendimento mensal (valor bruto)<input type="text" data-rf="rend" data-money2></label>
      <div class="f" style="font-size:13px;color:var(--gray)">Existe comprovante?${simNao("rf_comp", rf.comp)}</div>
    </div></div>
  <div class="q"><div class="t">Moradia</div>
    <div class="op">
      <label><input type="radio" name="rf_mora" value="sozinho"${rf.mora === "sozinho" ? " checked" : ""}> Mora sozinho(a)</label>
      <label><input type="radio" name="rf_mora" value="com"${rf.mora === "com" ? " checked" : ""}> Mora com as pessoas abaixo</label>
    </div>
    <div id="rfMembros" class="${rf.mora === "com" ? "" : "hide"}"></div>
  </div>
  <div class="q"><div class="t">Perguntas</div>
    ${PERGUNTAS.map((p, i) => `<div style="margin:10px 0 14px">
      <div style="font-size:14px;margin-bottom:6px"><b style="color:var(--green)">${i + 1}.</b> ${esc(p.q)}</div>
      <div class="op">${p.ops.map(o => `<label><input type="radio" name="rfq${i}" value="${o}"${rf.qr[i].r === o ? " checked" : ""}> ${o}</label>`).join("")}</div>
      <label class="f sub${p.abre.includes(rf.qr[i].r) ? "" : " hide"}" id="rfqd${i}">${esc(p.det)}${p.nota ? ` <i>(${esc(p.nota)})</i>` : ""}<textarea data-rfq="${i}" style="min-height:44px"></textarea>${p.naoSabe ? `<button type="button" class="btn" data-naosabe="${i}" style="align-self:flex-start;padding:5px 12px;font-size:13px;margin-top:4px">Não sabe o valor</button>` : ""}</label>
    </div>`).join("")}
  </div>
  <div class="q"><div class="t">Bens na residência</div>
    <div class="op">${BENS.map((b, i) => `<label><input type="checkbox" data-rfb="${i}"${rf.bens.includes(i) ? " checked" : ""}> ${esc(b)}</label>`).join("")}</div></div>
  <div class="q"><div class="t">Serviços na residência</div>
    <div class="op">${SERVICOS.map((b, i) => `<label><input type="checkbox" data-rfs="${i}"${rf.serv.includes(i) ? " checked" : ""}> ${esc(b)}</label>`).join("")}</div></div>
  <div class="q"><div class="t" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">REPRESENTANTE LEGAL
      <label class="cx" style="margin:0;font-weight:600"><input type="checkbox" id="repNA"${rf.repNA ? " checked" : ""}> não se aplica</label></div>
    <div style="font-size:13.5px;color:var(--gray);line-height:1.45;margin-bottom:8px">Preencha só quando quem assina o formulário é o <b>representante legal</b> do(a) assistido(a):
      o <b>pai ou a mãe</b> de criança ou adolescente (menor de 18 anos); o(a) <b>tutor(a)</b> nomeado(a) pela Justiça, quando a criança ou o adolescente não está sob o poder dos pais;
      ou o(a) <b>curador(a)</b> de pessoa maior de idade com curatela decretada pela Justiça (termo de curatela). Familiar que só acompanha o atendimento não é representante legal.</div>
    <div id="repCampos" class="${rf.repNA ? "hide" : ""}">
      <div class="grid2">
        <label class="f">Nome<input type="text" data-rf="repNome"></label>
        <label class="f">CPF<input type="text" data-rf="repCpf" data-mask="cpf"></label>
      </div>
      <div class="op" style="margin-top:8px">${REP_COND.map(c => `<label><input type="radio" name="rf_rep" value="${c}"${rf.repCond === c ? " checked" : ""}> ${c}</label>`).join("")}</div>
    </div></div>
  <p style="font-size:13.5px;color:var(--gray)">Local e data são preenchidos automaticamente: Pelotas/RS, ${hojeBR()}.</p>`;
  box.querySelectorAll("[data-rf]").forEach(el => {
    const k = el.dataset.rf; el.value = rf[k] || "";
    el.addEventListener("input", () => { if (el.dataset.mask === "cpf") el.value = mascaraCPF(el.value); rf[k] = el.value; });
    if (el.hasAttribute("data-money2")) el.addEventListener("change", () => { const v = dinheiro(el.value); if (!isNaN(v)) { el.value = brl(v); rf[k] = el.value; } });
  });
  box.querySelectorAll("[data-rfq]").forEach(el => { const i = +el.dataset.rfq; el.value = rf.qr[i].t; el.addEventListener("input", () => { rf.qr[i].t = el.value; }); });
  box.querySelectorAll("[data-naosabe]").forEach(b => b.addEventListener("click", () => { const i = +b.dataset.naosabe, t = box.querySelector(`[data-rfq="${i}"]`); t.value = PERGUNTAS[i].naoSabe; t.dispatchEvent(new Event("input", { bubbles: true })); }));
  PERGUNTAS.forEach((p, i) => box.querySelectorAll(`[name="rfq${i}"]`).forEach(r => r.addEventListener("change", () => {
    rf.qr[i].r = r.checked ? r.value : "";
    $("rfqd" + i).classList.toggle("hide", !p.abre.includes(rf.qr[i].r));
  })));
  box.querySelectorAll('[name="rf_comp"]').forEach(r => r.addEventListener("change", () => { rf.comp = r.checked ? r.value : ""; }));
  box.querySelectorAll('[name="rf_rep"]').forEach(r => r.addEventListener("change", () => { rf.repCond = r.checked ? r.value : ""; }));
  $("repNA").addEventListener("change", e => { rf.repNA = e.target.checked; $("repCampos").classList.toggle("hide", rf.repNA); });
  box.querySelectorAll('[name="rf_mora"]').forEach(r => r.addEventListener("change", () => { rf.mora = r.checked ? r.value : ""; $("rfMembros").classList.toggle("hide", rf.mora !== "com"); if (rf.mora === "com" && !rf.membros.length) { rf.membros.push({}); renderRFMembros(); } }));
  const tog = (arr, i, on) => { const j = arr.indexOf(i); if (on && j < 0) arr.push(i); if (!on && j >= 0) arr.splice(j, 1); };
  box.querySelectorAll("[data-rfb]").forEach(el => el.addEventListener("change", () => tog(rf.bens, +el.dataset.rfb, el.checked)));
  box.querySelectorAll("[data-rfs]").forEach(el => el.addEventListener("change", () => tog(rf.serv, +el.dataset.rfs, el.checked)));
  renderRFMembros();
}
function renderRFMembros() {
  const rf = S.rf, box = $("rfMembros"); box.innerHTML = "";
  rf.membros.forEach((m, i) => {
    const d = document.createElement("div"); d.className = "membro";
    d.innerHTML = `<div class="cab">${i + 1}. Pessoa do grupo familiar<button type="button">remover</button></div>
      <div class="grid3">
        <label class="f span2">Nome<input type="text" data-k="nome"></label>
        <label class="f">CPF<input type="text" data-k="cpf"></label>
        <label class="f">Parentesco<input type="text" data-k="par" list="vincs"></label>
        <label class="f span2">Situação ocupacional<input type="text" data-k="sit" list="situacoes" autocomplete="off"></label>
        <label class="f">Rendimento mensal (bruto)<input type="text" data-k="rend"></label>
        <div class="f span2" style="font-size:13px;color:var(--gray)">Existe comprovante?${simNao("rfm_comp" + i, m.comp)}</div>
      </div>`;
    d.querySelectorAll("[data-k]").forEach(inp => {
      const f = inp.dataset.k; inp.value = m[f] || "";
      inp.addEventListener("input", () => { if (f === "cpf") inp.value = mascaraCPF(inp.value); m[f] = inp.value; });
      if (f === "rend") inp.addEventListener("change", () => { const v = dinheiro(inp.value); if (!isNaN(v)) { inp.value = brl(v); m.rend = inp.value; } });
    });
    d.querySelectorAll(`[name="rfm_comp${i}"]`).forEach(r => r.addEventListener("change", () => { m.comp = r.checked ? r.value : ""; }));
    d.querySelector(".cab button").addEventListener("click", () => { rf.membros.splice(i, 1); renderRFMembros(); });
    box.appendChild(d);
  });
  const b = document.createElement("button"); b.type = "button"; b.className = "btn"; b.textContent = "+ Adicionar pessoa";
  b.addEventListener("click", () => { rf.membros.push({}); renderRFMembros(); });
  box.appendChild(b);
}

/* ---------- preenchimento dos PDFs (pdf-lib) ---------- */
const { PDFDocument, StandardFonts, rgb } = PDFLib;
const bytesCache = {};
const b64u8 = s => { if (!bytesCache[s.length + s.slice(-40)]) bytesCache[s.length + s.slice(-40)] = Uint8Array.from(atob(s), c => c.charCodeAt(0)); return bytesCache[s.length + s.slice(-40)]; };
let fonteTeste = null;
const okWin = {};
const TROCA_LETRA = { "Ł": "L", "ł": "l", "Đ": "D", "đ": "d", "Ħ": "H", "ħ": "h", "ı": "i", "Ŧ": "T", "ŧ": "t", "Ə": "E", "ə": "e", "ẞ": "SS", "ʼ": "'", "ʻ": "'", "ʹ": "'", "‐": "-", "‑": "-" };
function winAnsi(s) {  // as fontes padrão do PDF só têm o conjunto WinAnsi: troca o que não existe nele
  return [...String(s)].map(ch => {
    if (okWin[ch] === undefined) { try { fonteTeste.widthOfTextAtSize(ch, 10); okWin[ch] = true; } catch (e) { okWin[ch] = false; } }
    if (okWin[ch]) return ch;
    if (TROCA_LETRA[ch]) return TROCA_LETRA[ch];
    const base = ch.normalize("NFD").replace(/[̀-ͯ]/g, "");
    return base && base !== ch && [...base].every(c => okWin[c] !== false) ? base : (/\s/.test(ch) ? " " : "");
  }).join("");
}
function campoTexto(form, font, nome, valor, max = 10) {
  let f; try { f = form.getTextField(nome); } catch (e) { return false; }
  valor = winAnsi(String(valor ?? "")).replace(/\s+/g, f.isMultiline() ? " " : " ").trim();
  if (!valor) return true;
  const ml = f.getMaxLength(); if (ml && valor.length > ml) valor = valor.slice(0, ml);
  const ws = f.acroField.getWidgets(); const r = ws[0].getRectangle();
  let s = max;
  if (f.isMultiline()) {
    const linhas = sz => { let n = 1, w = 0; valor.split(" ").forEach(p => { const pw = font.widthOfTextAtSize(p + " ", sz); if (w + pw > r.width - 6 && w > 0) { n++; w = pw; } else w += pw; }); return n; };
    while (s > 6 && linhas(s) * s * 1.18 > r.height - 3) s -= 0.5;
  } else {
    let seg = null;
    try { seg = form.getTextField(nome + "_2"); } catch (e) {}
    if (seg && font.widthOfTextAtSize(valor, max) > r.width - 4) {  // continua na linha seguinte, no mesmo tamanho de letra
      const ps = valor.split(" "); let a = "";
      while (ps.length && font.widthOfTextAtSize((a + " " + ps[0]).trim(), max) <= r.width - 4) a = (a + " " + ps.shift()).trim();
      if (a && ps.length) { campoTexto(form, font, nome + "_2", ps.join(" "), max); valor = a; }
    }
    while (s > 6 && font.widthOfTextAtSize(valor, s) > r.width - 4) s -= 0.5;
  }
  const da = `/Helv ${s} Tf 0 g`;
  f.acroField.setDefaultAppearance(da); ws.forEach(w => w.setDefaultAppearance(da));
  f.setText(valor);
  return true;
}
const marcar = (form, nome) => { try { form.getCheckBox(nome).check(); } catch (e) {} };
const anoCurto = () => String(HOJE.getFullYear()).slice(-2);

const COR = { tinta: rgb(.118, .118, .118), verde: rgb(.149, .329, .094), cinza: rgb(.267, .267, .267), faixa: rgb(.886, .937, .851), suave: rgb(.953, .973, .937), linha: rgb(.725, .78, .694), borda: rgb(.83, .83, .83) };

const LARG = new Map();
function larg(font, t, fs) {  // largura sem kerning, igual ao que o drawText desenha
  let m = LARG.get(font); if (!m) { m = {}; LARG.set(font, m); }
  let w = 0; for (const c of t) { if (m[c] === undefined) m[c] = font.widthOfTextAtSize(c, 1000) / 1000; w += m[c]; }
  return w * fs;
}

/* ---------- formulário de renda desenhado em PDF, só com o que for necessário ---------- */
function quebrarCb(toks, fs, largura, F) {  // como quebrar(), mas aceita caixinhas {cb: true/false}
  const pal = [];
  toks.forEach(p => {
    if (p.cb !== undefined) { pal.push({ cb: p.cb, w: fs * 0.8 + 3 }); return; }
    winAnsi(p.t).split(/(\s+)/).forEach(t => { if (t) pal.push({ t: /^\s+$/.test(t) ? " " : t, b: p.b }); });
  });
  const linhas = []; let l = [], w = 0;
  pal.forEach(p => {
    const pw = p.cb !== undefined ? p.w : larg(p.b ? F.b : F.r, p.t, fs);
    if (p.t === " ") { if (l.length) { l.push({ ...p, w: pw }); w += pw; } return; }
    if (w + pw > largura && l.length) { while (l.length && l[l.length - 1].t === " ") w -= l.pop().w; linhas.push(l); l = []; w = 0; }
    l.push({ ...p, w: pw }); w += pw;
  });
  while (l.length && l[l.length - 1].t === " ") l.pop();
  if (l.length) linhas.push(l);
  return linhas.length ? linhas : [[]];
}
async function pdfRenda() {
  const doc = await PDFDocument.create();
  const F = { r: await doc.embedFont(StandardFonts.Helvetica), b: await doc.embedFont(StandardFonts.HelveticaBold), i: await doc.embedFont(StandardFonts.HelveticaOblique) };
  if (!fonteTeste) fonteTeste = F.r;
  const logo = await doc.embedJpg(b64u8(LOGO));
  const W = 595.28, H = 841.89, ML = 57, LW = W - 2 * ML, MB = 46, FS = 10, LH = FS * 1.32;
  const rf = S.rf || novoRF();
  const T = (t, b) => ({ t: String(t ?? ""), b: !!b }), CB = on => ({ cb: !!on });
  let pg, y;
  const novaPg = () => {
    pg = doc.addPage([W, H]);
    const lh = 36, lw = logo.width * lh / logo.height;
    pg.drawImage(logo, { x: W / 2 - lw / 2, y: H - 34 - lh, width: lw, height: lh });
    ["Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS.", "Fone (53) 3284-9450"].forEach((t, i) =>
      pg.drawText(winAnsi(t), { x: W / 2 - larg(F.r, winAnsi(t), 8.5) / 2, y: H - 34 - lh - 11 - i * 10, size: 8.5, font: F.r, color: COR.cinza }));
    pg.drawLine({ start: { x: ML, y: H - 34 - lh - 26 }, end: { x: W - ML, y: H - 34 - lh - 26 }, thickness: .6, color: COR.borda });
    y = H - 34 - lh - 40;
  };
  const caixa = (x, base, on, fs) => {
    const s = fs * 0.8, y0 = base - 1;
    pg.drawRectangle({ x, y: y0, width: s, height: s, borderColor: COR.tinta, borderWidth: .7 });
    if (on) {
      pg.drawLine({ start: { x: x + 1.4, y: y0 + 1.4 }, end: { x: x + s - 1.4, y: y0 + s - 1.4 }, thickness: 1, color: COR.tinta });
      pg.drawLine({ start: { x: x + 1.4, y: y0 + s - 1.4 }, end: { x: x + s - 1.4, y: y0 + 1.4 }, thickness: 1, color: COR.tinta });
    }
  };
  const escreverCb = (linha, x, base, fs) => linha.forEach(p => {
    if (p.cb !== undefined) caixa(x + 0.5, base, p.cb, fs);
    else if (p.t !== " ") pg.drawText(p.t, { x, y: base, size: fs, font: p.b ? F.b : F.r, color: COR.tinta });
    x += p.w;
  });
  // texto corrido (com caixinhas), com recuo opcional
  const medirTexto = (toks, w, fs = FS) => quebrarCb(toks, fs, w, F).length * fs * 1.32;
  const texto = (toks, { x = ML, w = LW, fs = FS, depois = 4, centro = false } = {}) => {
    const ls = quebrarCb(toks, fs, w, F);
    if (y - ls.length * fs * 1.32 < MB) novaPg();
    ls.forEach(l => {
      const lw = l.reduce((a, p) => a + p.w, 0);
      escreverCb(l, centro ? x + (w - lw) / 2 : x, y - fs, fs); y -= fs * 1.32;
    });
    y -= depois;
  };
  // tabela: linhas de células {w (fração), tk}; cada linha vira uma faixa com bordas
  const alturaLinha = cels => Math.max(...cels.map(c => quebrarCb(c.tk, FS, LW * c.w - 10, F).length)) * LH + 7;
  const tabela = (linhas, juntas = true) => {
    const hs = linhas.map(alturaLinha), tot = hs.reduce((a, b) => a + b, 0);
    if (juntas && y - tot < MB) novaPg();
    linhas.forEach((cels, i) => {
      if (y - hs[i] < MB) novaPg();
      let x = ML;
      cels.forEach(c => {
        const w = LW * c.w;
        pg.drawRectangle({ x, y: y - hs[i], width: w, height: hs[i], borderColor: COR.tinta, borderWidth: .6, color: c.fundo });
        quebrarCb(c.tk, FS, w - 10, F).forEach((l, j) => escreverCb(l, x + 5, y - 4 - FS - j * LH + 1.5, FS));
        x += w;
      });
      y -= hs[i];
    });
    y -= 10;
  };
  const sn = v => [T("Existe comprovante:  "), CB(v === "SIM"), T(" SIM;  "), CB(v === "NÃO"), T(" NÃO.")];
  const val = v => T(String(v || "").trim(), true);

  novaPg();
  texto([T("COMPOSIÇÃO DO GRUPO E RENDA FAMILIAR", true)], { fs: 12, centro: true, depois: 10 });
  tabela([
    [{ w: 1, tk: [T("Assistido(a): "), val(S.nome)] }],
    [{ w: 1, tk: [T("Situação ocupacional: "), val(rf.sit)] }],
    [{ w: .5, tk: [T("Rendimento mensal: "), val(rf.rend)] }, { w: .5, tk: sn(rf.comp) }],
  ]);
  texto([T("Assinale uma das opções abaixo:")], { depois: 3 });
  texto([CB(rf.mora === "sozinho"), T(" Declaro que moro sozinho(a);")], { x: ML + 8, depois: 2 });
  texto([CB(rf.mora === "com"), T(" Declaro que moro com as pessoas abaixo relacionadas:")], { x: ML + 8, depois: 10 });
  const preenchidos = rf.membros.filter(membroRF);
  const ms = rf.mora === "com" ? (preenchidos.length ? preenchidos : [{}]) : rf.mora === "" ? [{}, {}] : [];
  if (ms.length) {
    texto([T("DEMAIS COMPONENTES DO GRUPO FAMILIAR (residem sob o mesmo teto)", true)], { depois: 4 });
    ms.forEach((m, i) => tabela([
      [{ w: 1, tk: [T(`${i + 1}. NOME: `, true), val(m.nome)], fundo: COR.suave }],
      [{ w: .5, tk: [T("Parentesco: "), val(m.par)] }, { w: .5, tk: [T("CPF: "), val(m.cpf)] }],
      [{ w: 1, tk: [T("Situação ocupacional: "), val(m.sit)] }],
      [{ w: .5, tk: [T("Rendimento mensal: "), val(m.rend)] }, { w: .5, tk: sn(m.comp) }],
    ]));
  }
  // perguntas
  PERGUNTAS.forEach((p, i) => {
    const q = rf.qr[i] || { r: "", t: "" };
    const perg = [T(`${i + 1}. `, true), T(`${p.q} ${p.det}`)];
    const ops = []; p.ops.forEach((o, j) => { ops.push(CB(q.r === o), T(` ${o}${j < p.ops.length - 1 ? "   " : ""}`)); });
    const resp = String(q.t || "").trim(), abre = p.abre.includes(q.r);
    const branco = !q.r || (abre && !resp);
    const h = medirTexto(perg, LW) + LH + (abre && resp ? medirTexto([T(resp)], LW - 16) : 0) + (branco ? 22 : 0) + 14;
    if (y - h < MB) novaPg();
    texto(perg, { depois: 3 });
    texto(ops, { x: ML + 8, depois: 2 });
    if (abre && resp) texto([T(resp, true)], { x: ML + 16, w: LW - 16, depois: 2 });
    if (branco) { y -= 16; pg.drawLine({ start: { x: ML + 16, y }, end: { x: W - ML, y }, thickness: .5, color: COR.cinza }); y -= 6; }
    if (p.nota && q.r === "Sim") texto([T(p.nota)], { x: ML + 16, w: LW - 16, fs: 8.5, depois: 2 });
    y -= 8;
  });
  // bens e serviços
  const grade = (titulo, itens, marcados) => {
    const tk = []; itens.forEach((b, i) => { tk.push(CB(marcados.includes(i)), T(` ${b};   `)); });
    const h = medirTexto(tk, LW - 12) + FS * 1.32 + 16;
    if (y - h < MB) novaPg();
    const topo = y;
    y -= 6; texto([T(titulo, true)], { centro: true, depois: 2 });
    texto(tk, { x: ML + 6, w: LW - 12, depois: 2 });
    pg.drawRectangle({ x: ML, y: y - 2, width: LW, height: topo - y + 2, borderColor: COR.tinta, borderWidth: .6 });
    y -= 14;
  };
  grade("Bens que possui na residência:", BENS, rf.bens);
  grade("Serviços que possui na residência:", SERVICOS, rf.serv);
  // representante legal (só se houver)
  if (rf.repNA !== true) {
    const rc = rf.repCond, conds = []; REP_COND.forEach((c, j) => conds.push(CB(rc === c), T(` ${c}${j < REP_COND.length - 1 ? ";  " : "."}`)));
    tabela([
      [{ w: 1, tk: [T("Preencher o quadro quando o declarante for o representante legal", true)], fundo: COR.suave }],
      [{ w: 1, tk: [T("NOME: "), val(rf.repNome)] }],
      [{ w: 1, tk: [T("CPF: "), val(rf.repCpf)] }],
      [{ w: 1, tk: [T("Condição do representante legal:  "), ...conds] }],
    ]);
  }
  // declaração, local, data e assinatura
  const assinH = S.analf ? 150 : 95;
  if (y - assinH - 30 < MB) novaPg();
  texto([T("Declaro que as informações prestadas no presente formulário são verídicas, sob as penas da lei.", true)], { centro: true, depois: 12 });
  const dt = winAnsi(`Pelotas/RS, ${hojeExtenso()}.`);
  pg.drawText(dt, { x: W - ML - larg(F.r, dt, FS), y: y - FS, size: FS, font: F.r, color: COR.tinta }); y -= FS + 12;
  if (!S.analf) {
    y -= 34;
    pg.drawLine({ start: { x: W / 2 - 130, y }, end: { x: W / 2 + 130, y }, thickness: .7, color: COR.tinta });
    const a = "Assinatura do(a) assistido(a) ou do(a) representante legal";
    pg.drawText(a, { x: W / 2 - larg(F.r, a, 9) / 2, y: y - 12, size: 9, font: F.r, color: COR.cinza });
    y -= 26;
  } else {
    const top = y;
    pg.drawRectangle({ x: ML, y: top - 92, width: 66, height: 80, borderColor: rgb(.83, .83, .83), borderWidth: .6 });
    const dg = "Digital do(a) assistido(a)";
    pg.drawText(dg, { x: ML + 33 - larg(F.r, dg, 7.5) / 2, y: top - 102, size: 7.5, font: F.r, color: COR.cinza });
    const x0 = ML + 80, lw = LW - 80;
    let yy = top - 4;
    quebrarCb([T(`A rogo de ${S.nome.trim() || "________________________"}, que não sabe ler nem escrever, assina (art. 595 do Código Civil):`)], 9, lw, F)
      .forEach(l => { escreverCb(l, x0, yy - 9, 9); yy -= 11.5; });
    const cw = (lw - 24) / 3;
    ["Assinatura a rogo", "Testemunha 1", "Testemunha 2"].forEach((t, i) => {
      const cx = x0 + i * (cw + 12), yl = yy - 30;
      pg.drawLine({ start: { x: cx, y: yl }, end: { x: cx + cw, y: yl }, thickness: .7, color: COR.tinta });
      pg.drawText(t, { x: cx + cw / 2 - larg(F.r, t, 8) / 2, y: yl - 10, size: 8, font: F.r, color: COR.cinza });
      ["Nome:", "CPF:"].forEach((r, ri) => {
        const y2 = yl - 26 - ri * 15;
        pg.drawText(r, { x: cx, y: y2, size: 8, font: F.r, color: COR.cinza });
        pg.drawLine({ start: { x: cx + larg(F.r, r, 8) + 3, y: y2 - 1.5 }, end: { x: cx + cw, y: y2 - 1.5 }, thickness: .5, color: COR.linha });
      });
    });
    y = top - 115;
  }
  // observações (as notas do modelo)
  const notas = [
    "O presente formulário deve ser integralmente preenchido, de forma completa, com informações verdadeiras.",
    "Situação ocupacional: informar se a pessoa se encontra trabalhando, aposentada, recebendo benefício previdenciário ou assistencial, desempregada, estudando etc.",
    "Rendimento mensal: informar o valor total da remuneração (valor bruto, integral), não apenas o valor líquido (após os descontos).",
    "Em caso de trabalho informal ou autônomo, caso não haja comprovante de renda, deverá juntar extrato bancário da conta corrente, poupança ou aplicação, referente aos últimos 90 dias.",
    "Considera-se núcleo familiar a pessoa que mora sozinha ou o grupo de pessoas que reside sob o mesmo teto, composto pelo requerente, parentes consanguíneos ou por afinidade, cônjuge, companheiro ou convivente, desde que exista relação de dependência econômica entre si, nos termos do art. 2º, § 2º, da Resolução CSDPU nº 240, de 4 de dezembro de 2025."];
  const hN = notas.reduce((a, n) => a + medirTexto([T(n)], LW - 12, 7.5) + 2, 0) + 14;
  if (y - hN < MB) novaPg();
  y -= 6; pg.drawLine({ start: { x: ML, y }, end: { x: ML + 120, y }, thickness: .5, color: COR.cinza }); y -= 4;
  notas.forEach((n, i) => {
    pg.drawText(String(i + 1), { x: ML, y: y - 7.5, size: 7, font: F.b, color: COR.cinza });
    const ls = quebrarCb([T(n)], 7.5, LW - 12, F);
    ls.forEach(l => { escreverCinza(pg, l, ML + 10, y - 7.5, 7.5, F); y -= 7.5 * 1.32; });
    y -= 2;
  });
  doc.setTitle(`Formulário de Renda - ${nomeAssist()}`);
  return await doc.save();
}
function escreverCinza(pg, linha, x, base, fs, F) { linha.forEach(p => { if (p.t && p.t !== " ") pg.drawText(p.t, { x, y: base, size: fs, font: p.b ? F.b : F.r, color: COR.cinza }); x += p.w; }); }

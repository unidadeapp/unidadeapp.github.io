"use strict";
/* Preenchimento de Formulários – Assistente de Documentos DAC.
   Recebe os formulários marcados na Central de Formulários ou no Checklist (mensagem do quadro principal), mostra um de cada vez
   (etapas, como no Assistente de Abertura de PAJ) e, no menu, uma caixinha para cada informação pedida por eles. */
const $ = id => document.getElementById(id);
const { esc, CX, FD, MESES } = DAC;
const txt = html => { const d = document.createElement("div"); d.innerHTML = html; return d.textContent; };
const dois = n => String(n).padStart(2, "0");
let HOJE = new Date();
setInterval(() => { HOJE = new Date(); }, 60000);
window.addEventListener("focus", () => { HOJE = new Date(); });
const hojeBR = () => `${dois(HOJE.getDate())}/${dois(HOJE.getMonth() + 1)}/${HOJE.getFullYear()}`;
const hojeExtenso = () => `${HOJE.getDate()} de ${MESES[HOJE.getMonth()]} de ${HOJE.getFullYear()}`;
const hojeISO = () => `${HOJE.getFullYear()}-${dois(HOJE.getMonth() + 1)}-${dois(HOJE.getDate())}`;
const S = { nome: "", analf: false, rf: null };   // nomes usados pelo código do formulário de renda (copiado do Unidade)
const nomeAssist = () => S.nome.trim() || "ASSISTIDO";
const nomeArq = s => s.replace(/[\\/:*?"<>|–]+/g, "-").replace(/\s+/g, " ").trim();
const RENDA = "Formulario_de_renda_pessoa_natural";
const V = {};          // o que foi digitado nas caixinhas (só na memória desta página)
let LISTA = [];        // formulários escolhidos: { k, arq, nome, quem, pdf, pdf_a }
let atual = 0;

__RENDA__

/* ---------- valores das caixinhas ---------- */
const val = k => String(V[k] ?? "").trim();
const NA = new Set();  // campos marcados como "deixar em branco (não se aplica)"
const QUEM = { decl: "Assistido(a) ou quem declara", renda: "Assistido(a) ou representante legal", medico: "Médico(a)", titular: "Titular da conta (proprietário(a))",
               dpu: "Supervisão do atendimento", acordo: "Assistido(a) e Defensor(a)", irpf: "Beneficiário(a)", pend: "Assistido(a)" };
const usaA = f => S.analf && !!f.pdf_a;
function preenchidas(arq) {  // caixinhas deste formulário que têm alguma coisa
  const fd = FD[arq], out = new Set();
  Object.keys(fd.campos).forEach(k => { if (val(k) || NA.has(k)) out.add(k); });   // "não se aplica" também não precisa ser escrito
  if (fd.campos.valorExtenso && !val("valorExtenso") && dinheiro(val("valorIsento")) > 0) out.add("valorExtenso");
  return out;
}
function rendaPreenchida() {
  const rf = S.rf; if (!rf) return false;
  return !!(rf.sit || rf.rend || rf.comp || rf.mora || rf.membros.some(membroRF) || rf.qr.some(q => q.r || (q.t || "").trim()) || rf.bens.length || rf.serv.length || rf.repNome || rf.repCpf || rf.repCond);
}

/* ---------- caixinhas no menu ---------- */
function montarCaixas() {
  const box = $("cxs"); box.innerHTML = "";
  const cs = DAC.caixasDe(LISTA.map(f => f.arq));
  cs.forEach(({ k, arqs }) => {
    const c = CX[k], vai = arqs.map(a => FD[a].curto).join(", ");
    let campo;
    if (c.tipo === "area") campo = `<textarea data-cx="${k}" rows="4" placeholder="Um documento por linha"></textarea>`;
    else if (c.tipo === "prazo") campo = `<select data-cx="${k}"><option value="">Em branco</option><option value="30 dias">30 dias (prazo normal)</option><option value="48 horas">48 horas (PAJ urgente)</option></select>`;
    else if (c.tipo === "data" || c.tipo === "dia") campo = `<div class="dataL"><input type="date" data-cx="${k}"><button type="button" class="btn mini" data-hoje="${k}">Hoje</button><button type="button" class="btn mini" data-apaga="${k}">Apagar</button></div>`;
    else campo = `<input type="text" data-cx="${k}" autocomplete="off"${c.ph ? ` placeholder="${esc(c.ph)}"` : ""}>`;
    let nota = "";
    if (k === "data") nota = arqs.some(a => FD[a].campos.data !== "pelotas") ? " Onde o formulário pede a cidade, sai Pelotas/RS." : "";
    if (k === "nome" && arqs.includes(RENDA)) nota = " No formulário de renda, é o nome do(a) assistido(a).";
    const d = document.createElement("div"); d.className = "cxP" + (val(k) ? " cheio" : ""); d.dataset.k = k;
    const naBt = c.branco ? `<button type="button" class="btn mini naBt${NA.has(k) ? " on" : ""}" data-na="${k}">${NA.has(k) ? "✓ Em branco (não se aplica)" : "Deixar em branco (não se aplica)"}</button>` : "";
    d.innerHTML = `<span>${esc(c.rot)}</span>${campo}${naBt}<small class="vai">Vai para: ${esc(vai)}.${nota}</small>`;
    box.appendChild(d);
  });
  if (LISTA.some(f => f.arq === RENDA)) box.insertAdjacentHTML("beforeend", '<div class="rendaNota">As perguntas do <b>formulário de renda</b> ficam no passo dele (igual à etapa 7 do Assistente de Abertura de PAJ).</div>');
  if (!cs.length && !LISTA.some(f => f.arq === RENDA)) box.insertAdjacentHTML("beforeend", '<div class="rendaNota">Os formulários escolhidos não têm campos para preencher aqui: são todos do(a) médico(a).</div>');
  box.querySelectorAll("[data-cx]").forEach(el => {
    const k = el.dataset.cx, c = CX[k];
    el.value = V[k] || "";
    el.addEventListener("input", () => {
      if (c.mask === "cpf") el.value = mascaraCPF(el.value);
      V[k] = el.value; mudou(k);
    });
    if (c.money) el.addEventListener("change", () => { const v = dinheiro(el.value); if (!isNaN(v)) { el.value = brlNum(v); V[k] = el.value; mudou(k); } });
    if (el.tagName === "SELECT") el.addEventListener("change", () => { V[k] = el.value; mudou(k); });
  });
  box.querySelectorAll("[data-na]").forEach(b => {
    const k = b.dataset.na, el = box.querySelector(`[data-cx="${k}"]`);
    const pinta = () => { const on = NA.has(k); b.classList.toggle("on", on); b.textContent = on ? "✓ Em branco (não se aplica)" : "Deixar em branco (não se aplica)"; el.disabled = on; if (on) { el.value = ""; V[k] = ""; } mudou(k); };
    b.addEventListener("click", () => { if (NA.has(k)) NA.delete(k); else NA.add(k); pinta(); });
    if (NA.has(k)) pinta();
  });
  box.querySelectorAll("[data-hoje]").forEach(b => b.addEventListener("click", () => { const k = b.dataset.hoje; V[k] = hojeISO(); box.querySelector(`[data-cx="${k}"]`).value = V[k]; mudou(k); }));
  box.querySelectorAll("[data-apaga]").forEach(b => b.addEventListener("click", () => { const k = b.dataset.apaga; V[k] = ""; box.querySelector(`[data-cx="${k}"]`).value = ""; mudou(k); }));
}
function mudou(k) {
  const d = document.querySelector(`.cxP[data-k="${k}"]`); if (d) d.classList.toggle("cheio", !!val(k));
  if (k === "nome") { S.nome = V.nome || ""; const r = $("rfNome"); if (r) r.innerHTML = esc(S.nome.trim()) || "<i>escreva o nome no menu, em “Nome completo do(a) assistido(a)”</i>"; }
  resumos(); agendarPrevia(); textoMsg();
}
$("analf").addEventListener("change", () => { S.analf = $("analf").checked; legendas(); agendarPrevia(true); textoMsg(); });
$("apagar").addEventListener("click", () => {
  Object.keys(V).forEach(k => delete V[k]); S.nome = ""; if (LISTA.some(f => f.arq === RENDA)) S.rf = novoRF();
  montarCaixas(); montarEtapas(); ir(atual);
  $("apagarMsg").textContent = "Pronto: tudo o que foi digitado foi apagado."; setTimeout(() => { $("apagarMsg").textContent = ""; }, 4000);
});
$("irFim").addEventListener("click", () => ir(LISTA.length));

/* ---------- etapas: um formulário por vez e, no fim, gerar ---------- */
function montarEtapas() {
  const main = $("etapas"), n = LISTA.length; main.innerHTML = "";
  LISTA.forEach((f, i) => {
    const fd = FD[f.arq], renda = f.arq === RENDA;
    const sec = document.createElement("section"); sec.className = "step"; sec.dataset.i = i;
    sec.innerHTML = `<div class="et">Formulário ${i + 1} de ${n}</div><h2>${esc(f.nome)}</h2>
      <p class="sub2 legenda"></p>
      ${renda ? `<p>Preencha com as informações dadas pelo(a) assistido(a). O que ficar sem resposta sai em branco, para preencher à mão.</p><div id="rendaForm"></div>` : `<div class="guia resumo"></div>`}
      <div class="prev"><div class="prevCab"><b>Prévia</b><span class="prevMsg"></span><button type="button" class="btn mini" data-ver="${i}">Abrir em nova guia</button></div><div class="prevBox"></div></div>
      <div class="navb"><button type="button" class="btn" data-mover="-1">← Voltar</button><button type="button" class="btn cheio prox" data-mover="1"></button></div>`;
    main.appendChild(sec);
  });
  const fim = document.createElement("section"); fim.className = "step"; fim.dataset.i = n;
  fim.innerHTML = `<div class="et">Último passo</div><h2>Gerar os formulários</h2>
    <p>${n > 1 ? `Os ${n} formulários saem` : "O formulário sai"} com o que foi preenchido. O que ficou em branco sai em branco, para preencher à mão.</p>
    <div class="duas">
      <button type="button" class="btn cheio grande" id="gBaixar">BAIXAR<small>${n > 1 ? "Um arquivo .zip com cada formulário em PDF" : "O formulário em PDF"}, para enviar ao(à) assistido(a)</small></button>
      <button type="button" class="btn grande" id="gAbrir">ABRIR EM NOVA GUIA<small>Um documento único, para conferir</small></button>
      <button type="button" class="btn grande" id="gImprimir">IMPRIMIR<small>Um documento único, direto para a impressora</small></button>
    </div>
    <p class="gerando" id="gMsg"></p>
    <h3>Mensagem para o(a) assistido(a)</h3>
    <p class="sub2">Explica como preencher cada formulário. O que você já preencheu não é pedido de novo. Confira antes de copiar.</p>
    <div id="assP"></div>
    <div class="msgBox"><textarea id="mTxt" rows="12"></textarea>
      <div style="display:flex;gap:10px;align-items:center;margin-top:6px"><button type="button" class="btn cheio" id="mCopiar">COPIAR</button><span class="ok" id="mOk"></span></div></div>
    <div class="navb"><button type="button" class="btn" data-mover="-1">← Voltar</button></div>`;
  main.appendChild(fim);
  main.querySelectorAll("[data-mover]").forEach(b => b.addEventListener("click", () => ir(atual + +b.dataset.mover)));
  main.querySelectorAll("[data-ver]").forEach(b => b.addEventListener("click", () => abrirUm(+b.dataset.ver)));
  $("gBaixar").addEventListener("click", baixar);
  $("gAbrir").addEventListener("click", abrirTodos);
  $("gImprimir").addEventListener("click", imprimir);
  $("mCopiar").addEventListener("click", copiarMsg);
  DAC.montarAssinatura($("assP"), textoMsg);
  if (LISTA.some(f => f.arq === RENDA)) {
    if (!S.rf) S.rf = novoRF();
    renderRF();
    ["input", "change", "click"].forEach(ev => $("rendaForm").addEventListener(ev, () => { agendarPrevia(); textoMsg(); }));
  }
  // passos no alto
  const nav = $("passos"); nav.innerHTML = "";
  [...LISTA.map(f => FD[f.arq].curto), "Gerar"].forEach((t, i) => {
    const b = document.createElement("button"); b.type = "button";
    b.innerHTML = `<span class="n">${i < n ? i + 1 : "✓"}</span><span>${esc(t)}</span>`;
    b.addEventListener("click", () => ir(i)); nav.appendChild(b);
  });
  legendas(); resumos(); textoMsg();
}
function legendas() {
  LISTA.forEach((f, i) => {
    const el = document.querySelector(`section.step[data-i="${i}"] .legenda`); if (!el) return;
    const fd = FD[f.arq], a = f.arq === RENDA ? S.analf : usaA(f);
    el.innerHTML = `Quem assina: <b>${esc(f.quem || QUEM[fd.tipo] || "")}</b>${a ? " · versão para assistido(a) analfabeto(a)" : ""}`;
  });
}
function resumos() {  // o que vai em cada formulário
  LISTA.forEach((f, i) => {
    const el = document.querySelector(`section.step[data-i="${i}"] .resumo`); if (!el) return;
    const fd = FD[f.arq], ks = Object.keys(fd.campos);
    if (!ks.length) { el.innerHTML = "Este formulário não tem campos de identificação: é todo respondido pelo(a) médico(a). Ele sai em branco."; return; }
    const ja = preenchidas(f.arq);
    el.innerHTML = `<b>O que vai neste formulário</b> (digite no menu):<ul>${ks.map(k => {
      let v = val(k);
      if (k === "data" && v) v = (fd.campos.data === "pelotas" ? "" : "Pelotas/RS, ") + new Date(v + "T12:00:00").toLocaleDateString("pt-BR", { day: "numeric", month: "long", year: "numeric" });
      if (k === "dataComp" && v) v = v.split("-").reverse().join("/");
      if (NA.has(k)) v = "";
      if (k === "valorExtenso" && !v && ja.has(k)) v = DAC.porExtenso(dinheiro(val("valorIsento"))) + " (escrito sozinho a partir do valor)";
      if (k === "docsPend" && v) v = v.split("\n").map(x => x.trim()).filter(Boolean).join("; ");
      return `<li>${esc(CX[k].rot)}: ${v ? `<b>${esc(v)}</b>` : NA.has(k) ? '<span class="branco">em branco (não se aplica)</span>' : '<span class="branco">em branco (preencher à mão)</span>'}</li>`;
    }).join("")}</ul>`;
  });
}
function ir(i) {
  const n = LISTA.length; if (!n) return;
  atual = Math.max(0, Math.min(i, n));
  document.querySelectorAll("#etapas section.step").forEach(s => s.classList.toggle("on", +s.dataset.i === atual));
  document.querySelectorAll("#passos button").forEach((b, j) => { b.classList.toggle("atual", j === atual); if (j === atual) b.classList.add("visto"); });
  const prox = document.querySelector(`section.step[data-i="${atual}"] .prox`);
  if (prox) prox.textContent = atual + 1 < n ? `Próximo: formulário ${atual + 2} – ${FD[LISTA[atual + 1].arq].curto} →` : "Próximo: gerar os formulários →";
  if (atual === n) textoMsg(); else agendarPrevia(true);
  window.scrollTo(0, 0);
}

/* ---------- datas ---------- */
function dataPdf(T, tipo, iso) {
  const d = new Date(iso + "T12:00:00"); if (isNaN(d)) return;
  if (tipo === "cidade") T("cidade_uf", "Pelotas/RS");
  if (tipo === "municipio") T("municipio_uf", "Pelotas/RS");
  T("dia", String(d.getDate())); T("mes", MESES[d.getMonth()]); T("ano", String(d.getFullYear()).slice(-2));
}

/* ---------- preenchimento (o formulário de renda é desenhado como no Assistente de Abertura: pdfRenda) ---------- */
async function preencherPdf(f, achatar) {
  const fd = FD[f.arq];
  const doc = await PDFDocument.load(b64u8(usaA(f) ? f.pdf_a : f.pdf));
  const form = doc.getForm();
  const serif = fd.tipo !== "medico";
  const font = await doc.embedFont(serif ? StandardFonts.TimesRoman : StandardFonts.Helvetica);
  if (!fonteTeste) fonteTeste = await doc.embedFont(StandardFonts.Helvetica);
  try { form.removeField(form.getField("limpar_formulario")); } catch (e) {}
  const T = (n, v, m) => campoTexto(form, font, n, v, m || (serif ? 11 : 10));
  const tem = n => { try { form.getTextField(n); return true; } catch (e) { return false; } };
  Object.entries(fd.campos).forEach(([k, alvo]) => {
    const v = val(k); if (!v || alvo === null) return;
    if (k === "data") return dataPdf(T, alvo, v);
    if (k === "dataComp") return T(alvo, v.split("-").reverse().join("/"));
    if (k === "docsPend") {
      const ls = v.split("\n").map(x => x.trim()).filter(Boolean);
      if (ls.length > 8) ls.splice(7, ls.length, ls.slice(7).join("; "));
      ls.forEach((t, j) => T(j ? "resposta_" + (j + 1) : "resposta", t));
      return;
    }
    if (Array.isArray(alvo)) { const nm = alvo.find(tem); if (nm) T(nm, v); return; }
    T(alvo, v);
  });
  if (fd.campos.valorExtenso && !val("valorExtenso")) { const x = dinheiro(val("valorIsento")); if (x > 0) T("valor_extenso", DAC.porExtenso(x)); }
  form.updateFieldAppearances(font);
  if (achatar) form.flatten();
  doc.setTitle(`${f.nome}${S.nome.trim() ? " - " + S.nome.trim() : ""}`);
  return await doc.save();
}
const gerar = (f, achatar) => f.arq === RENDA ? pdfRenda() : preencherPdf(f, achatar);
const urlPdf = bytes => URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));

/* ---------- prévia do formulário da etapa atual ---------- */
let tPrev = null, urlPrev = null, sigPrev = "";
function agendarPrevia(ja) { clearTimeout(tPrev); tPrev = setTimeout(previa, ja ? 30 : 700); }
async function previa() {
  if (atual >= LISTA.length) return;
  const f = LISTA[atual], sec = document.querySelector(`section.step[data-i="${atual}"]`); if (!sec) return;
  const sig = JSON.stringify([atual, V, S.analf, f.arq === RENDA ? S.rf : 0, S.nome]);
  const box = sec.querySelector(".prevBox"), msg = sec.querySelector(".prevMsg");
  if (sig === sigPrev && box.firstChild) return;
  msg.textContent = "atualizando…";
  try {
    const bytes = await gerar(f, true);
    if (urlPrev) URL.revokeObjectURL(urlPrev);
    urlPrev = urlPdf(bytes); sigPrev = sig;
    document.querySelectorAll(".prevBox").forEach(b => { if (b !== box) b.innerHTML = ""; });
    box.innerHTML = `<embed src="${urlPrev}#toolbar=0&navpanes=0" type="application/pdf">`;
    msg.textContent = "atualiza sozinha quando você digita";
  } catch (e) { console.error(e); msg.textContent = "não foi possível mostrar a prévia: " + e.message; }
}

/* ---------- gerar: baixar, abrir, imprimir ---------- */
const JANELA = (titulo, corpo) => `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(titulo)}</title><style>html,body{margin:0;height:100%;font-family:Segoe UI,Arial,sans-serif;color:#333}embed{display:block;width:100%;height:100%;border:0}.m{padding:40px;font-size:18px}</style></head><body>${corpo}</body></html>`;
function escreverJanela(w, html) { w.document.open(); w.document.write(html); w.document.close(); }
function aviso(t, erro) { const m = $("gMsg"); if (m) { m.innerHTML = t; m.className = erro ? "erro" : "gerando"; } }
const titulo = () => `Formulários${S.nome.trim() ? " - " + S.nome.trim() : ""}`;
async function documentoUnico() {
  const out = await PDFDocument.create();
  for (const f of LISTA) { const src = await PDFDocument.load(await gerar(f, true)); (await out.copyPages(src, src.getPageIndices())).forEach(p => out.addPage(p)); }
  out.setTitle(titulo());
  return await out.save();
}
async function baixar() {
  aviso("Preparando os arquivos…");
  try {
    const nomeDe = f => nomeArq(`${f.nome}${S.nome.trim() ? " - " + S.nome.trim() : ""}`) + ".pdf";
    const a = document.createElement("a");
    if (LISTA.length === 1) {
      a.href = urlPdf(await gerar(LISTA[0], false)); a.download = nomeDe(LISTA[0]);
    } else {
      const files = {}, usados = {};
      for (const f of LISTA) { let nm = nomeDe(f); if (usados[nm]) nm = nm.replace(/\.pdf$/, ` (${++usados[nm]}).pdf`); else usados[nm] = 1; files[nm] = await gerar(f, false); }
      a.href = URL.createObjectURL(new Blob([fflate.zipSync(files, { level: 0 })], { type: "application/zip" })); a.download = nomeArq(titulo()) + ".zip";
    }
    document.body.appendChild(a); a.click(); a.remove();
    aviso(`<span class="ok">Arquivo <b>${esc(a.download)}</b> salvo na pasta Downloads.</span> Os campos continuam editáveis, se for preciso corrigir algo.`);
  } catch (e) { console.error(e); aviso("Não foi possível gerar os arquivos: " + esc(e.message), true); }
}
async function abrirTodos() {
  const w = window.open("", "_blank");
  if (!w) { aviso('O navegador bloqueou a nova guia. Clique no aviso de pop-up bloqueado, ao lado do endereço, escolha “Sempre permitir” e clique de novo.', true); return; }
  escreverJanela(w, JANELA("Gerando…", '<div class="m">Gerando os formulários, aguarde…</div>'));
  aviso("Gerando os formulários…");
  try { const b = await documentoUnico(); escreverJanela(w, JANELA(titulo(), `<embed src="${urlPdf(b)}" type="application/pdf">`)); aviso('<span class="ok">Formulários abertos numa nova guia, para conferir.</span>'); }
  catch (e) { console.error(e); if (!w.closed) w.close(); aviso("Não foi possível gerar: " + esc(e.message), true); }
}
async function abrirUm(i) {
  const f = LISTA[i], w = window.open("", "_blank");
  if (!w) { const m = document.querySelector(`section.step[data-i="${i}"] .prevMsg`); if (m) m.textContent = "o navegador bloqueou a nova guia: permita pop-ups"; return; }
  escreverJanela(w, JANELA("Gerando…", '<div class="m">Gerando o formulário, aguarde…</div>'));
  try { escreverJanela(w, JANELA(f.nome, `<embed src="${urlPdf(await gerar(f, false))}" type="application/pdf">`)); } catch (e) { if (!w.closed) w.close(); }
}
async function imprimir() {
  aviso("Preparando a impressão…");
  try {
    const url = urlPdf(await documentoUnico()), fr = $("printFrame");
    const alternativa = pre => { aviso(`${pre}<a href="#" id="abrirImp">abra o documento numa nova guia</a> e use Ctrl+P.`); $("abrirImp").addEventListener("click", ev => { ev.preventDefault(); const w = window.open("", "_blank"); if (w) escreverJanela(w, JANELA(titulo(), `<embed src="${url}" type="application/pdf">`)); }); };
    alternativa(`Abrindo a janela de impressão… Se ela não aparecer em alguns segundos, `);
    fr.onload = () => setTimeout(() => { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (e) { alternativa("Este navegador não deixou imprimir direto: "); } }, 400);
    fr.src = url;
  } catch (e) { console.error(e); aviso("Não foi possível preparar a impressão: " + esc(e.message), true); }
}

/* ---------- mensagem para o(a) assistido(a) ---------- */
function textoMsg() {
  const t = $("mTxt"); if (!t) return;
  t.value = DAC.mensagemForms(LISTA.map(f => ({ arq: f.arq, nome: f.nome, analf: f.arq === RENDA ? S.analf : usaA(f) })), { nome: S.nome, analf: S.analf, preenchidos: preenchidas, rendaPre: rendaPreenchida() });
  t.rows = Math.max(6, Math.min(28, t.value.split("\n").length + 1));
}
function copiarMsg() {
  const ta = $("mTxt"); let ok = false;
  try { ta.focus(); ta.select(); ok = document.execCommand("copy"); } catch (e) {}
  const fim = s => { $("mOk").textContent = s; setTimeout(() => { $("mOk").textContent = ""; }, 4000); };
  if (!ok && navigator.clipboard) navigator.clipboard.writeText(ta.value).then(() => fim("Copiado!")).catch(() => fim("Não deu para copiar: selecione o texto e use Ctrl+C."));
  else fim(ok ? "Copiado!" : "Não deu para copiar: selecione o texto e use Ctrl+C.");
}
(function () { const st = document.createElement("style"); st.textContent = DAC.CSS_ASS; document.head.appendChild(st); })();

/* ---------- formulários que chegam da Central ou do Checklist ---------- */
function receber(p) {
  LISTA = (p.forms || []).filter(f => FD[f.arq]);
  $("origemTxt").textContent = p.origem ? `Formulários marcados em: ${p.origem}. Um de cada vez; avance com Próximo.` : "Os formulários marcados abrem um de cada vez.";
  S.analf = !!p.analf; $("analf").checked = S.analf;
  if (p.nome && !val("nome")) { V.nome = p.nome; S.nome = p.nome; }
  if (LISTA.some(f => f.arq === RENDA) && !S.rf) S.rf = novoRF();
  sigPrev = "";
  $("semForms").classList.toggle("hide", LISTA.length > 0);
  $("passos").classList.toggle("hide", !LISTA.length);
  $("painelP").classList.toggle("hide", !LISTA.length);
  montarCaixas(); montarEtapas(); ir(0);
}
window.addEventListener("message", e => { const d = e.data || {}; if (d.preencher) receber(d.preencher); });
$("painelP").classList.add("hide");
if (window.parent !== window) parent.postMessage({ pronto: true }, "*");

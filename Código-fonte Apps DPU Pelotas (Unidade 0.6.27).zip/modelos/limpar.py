# Copia os modelos .docx sem as fontes embutidas (Times New Roman, Calibri, Georgia, Cambria e Arial já existem no Windows)
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import zipfile, re, os, json, sys
U = "/mnt/user-data/uploads/"
M = [
 ("prev", "Petição Inicial – Auxílio por incapacidade (AD) – Não constatação de incapacidade", "c627e85e"),
 ("prev", "Petição Inicial – Auxílio por incapacidade (AD) – Falta de qualidade de segurado", "85af3bb4"),
 ("prev", "Petição Inicial – Auxílio por incapacidade (AD) – Indeferimento por reclusão inexistente", "9eaaae80"),
 ("prev", "Impugnação ao Laudo Pericial – Todos os benefícios por incapacidade", "b01c1800"),
 ("prev", "Réplica – Todos os benefícios por incapacidade", "dff2805d"),
 ("prev", "Petição Inicial – BPC/LOAS Deficiente – Concessão ou restabelecimento (não constatação)", "40e2dfa1"),
 ("prev", "Petição Inicial – Pensão por morte – Dependente não reconhecido", "81029fb9"),
 ("prev", "Petição Inicial – Obrigação de fazer – Demora no cumprimento de acórdão", "d58bfa2a"),
 ("pbf", "Petição Inicial – Bolsa Família – Habilitação regular sem concessão", "e0d1d799"),
 ("pbf", "Réplica – Bolsa Família", "bb2b489d"),
 ("pbf", "Recurso Inominado – Bolsa Família – Habilitação regular sem concessão", "26b6f54e"),
 ("geral", "Petições simples diversas", "1db59579"),
]
os.makedirs(RAIZ + "modelos/docx", exist_ok=True)
out = []
for area, nome, pre in M:
    src = [f for f in os.listdir(U) if f.startswith(pre)][0]
    zi = zipfile.ZipFile(U + src)
    arq = re.sub(r'[\\/:*?"<>|]', "-", nome.replace("–", "-")) + ".docx"
    dst = RAIZ + "modelos/docx/" + arq
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zo:
        for it in zi.infolist():
            n = it.filename
            if n.startswith("word/fonts/") or n == "word/_rels/fontTable.xml.rels" or n.endswith("/"): continue
            d = zi.read(n)
            if n == "word/fontTable.xml":
                d = re.sub(rb"<w:embed(Regular|Bold|Italic|BoldItalic)\b[^>]*/>", b"", d)
            elif n == "word/settings.xml":
                d = re.sub(rb"<w:(embedTrueTypeFonts|saveSubsetFonts|embedSystemFonts)\b[^>]*/>", b"", d)
            elif n == "[Content_Types].xml":
                d = re.sub(rb'<Default Extension="odttf"[^>]*/>', b"", d)
            zo.writestr(it, d)
    out.append({"area": area, "nome": nome, "arq": arq, "kb": os.path.getsize(dst) // 1024})
json.dump(out, open(RAIZ + "modelos/modelos.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for o in out: print(o["kb"], "KB", o["arq"])

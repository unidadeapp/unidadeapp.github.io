# Central de Formulários – DPU Pelotas: todos os formulários (PDF preenchível e modelo Word) num arquivo só
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, json, re, subprocess, os
B = RAIZ + "pacote2/Formularios_DPU_Pelotas/"
PDF, DOC = B + "PDF (preenchiveis)/", B + "Word (modelos)/"

# grupo, id, nome, descrição, quem assina/preenche, arquivo (sem extensão)
CAT = [
 ("renda", "Renda, trabalho e residência", "Documentos que o(a) assistido(a) (ou o(a) declarante) assina para comprovar renda, trabalho e endereço."),
 ("medico", "Formulários médicos", "Preenchidos e assinados pelo(a) médico(a) que acompanha o(a) assistido(a). Servem para instruir o pedido judicial."),
 ("paj", "PAJ e atendimento", "Documentos do dia a dia do atendimento e do andamento do PAJ."),
 ("pet", "Petições", "Modelos de petição simples, assinados pelo(a) Defensor(a)."),
]
F = [
 ("renda", "form_renda", "Formulário de Renda (pessoa natural)", "Composição do grupo familiar, renda de cada pessoa, bens, despesas e perguntas sobre a situação socioeconômica.", "Assistido(a)", "Formulario_de_renda_pessoa_natural"),
 ("renda", "ausencia_renda", "Declaração de ausência de renda", "Para quem está desempregado(a) e não tem nenhuma renda.", "Assistido(a) ou membro do grupo familiar", "Declaracao_de_ausencia_de_renda"),
 ("renda", "renda_informal", "Declaração de renda informal", "Para quem trabalha sem carteira assinada: informa a atividade e quanto recebe por mês.", "Assistido(a) ou membro do grupo familiar", "Declaracao_de_renda_informal"),
 ("renda", "ausencia_ctps", "Declaração de ausência de Carteira de Trabalho", "Para quem não tem Carteira de Trabalho (nem física nem digital).", "Assistido(a) ou membro do grupo familiar", "Declaracao_de_ausencia_de_CTPS"),
 ("renda", "residencia_prop", "Declaração do Titular do Comprovante", "Quando o comprovante de residência está no nome de outra pessoa: quem está no comprovante (o titular) declara que o(a) assistido(a) mora no imóvel.", "Titular do comprovante (proprietário(a) ou quem tem a conta no nome)", "Declaracao_de_residencia_proprietario"),
 ("renda", "residencia_sem", "Declaração de Residência", "Quando o(a) assistido(a) não tem como comprovar residência fixa: ele(a) mesmo(a) declara onde mora.", "Assistido(a)", "Declaracao_de_residencia_sem_conta_em_nome_proprio"),
 ("renda", "isento_irpf", "Declaração de isento de IRPF (Banco do Brasil)", "Anexo único para não haver retenção de imposto de renda sobre valores recebidos por decisão da Justiça Federal (art. 27 da Lei 10.833/2003).", "Assistido(a)", "Declaracao_isento_IRPF_Banco_do_Brasil"),
 ("medico", "laudo_incap", "Laudo médico – benefício por incapacidade", "Auxílio-doença, aposentadoria por invalidez e outros benefícios por incapacidade laboral.", "Médico(a)", "Laudo_medico_beneficio_por_incapacidade"),
 ("medico", "adicional25", "Laudo médico – adicional de 25% na aposentadoria", "Aposentado(a) por incapacidade permanente que precisa da ajuda permanente de outra pessoa (art. 45 da Lei 8.213/1991).", "Médico(a)", "Laudo_medico_adicional_25"),
 ("medico", "loas", "Formulário médico – BPC/LOAS pessoa com deficiência", "Benefício assistencial à pessoa com deficiência: impedimentos de longo prazo e barreiras do dia a dia.", "Médico(a)", "Formulario_BPC_LOAS_pessoa_com_deficiencia"),
 ("medico", "cirurgia", "Laudo médico – cirurgia", "Pedido judicial de cirurgia pelo SUS.", "Médico(a)", "Laudo_medico_cirurgia"),
 ("medico", "exame", "Laudo médico – exame", "Pedido judicial de exame médico pelo SUS.", "Médico(a)", "Laudo_medico_exame"),
 ("medico", "uti", "Laudo médico – internação em UTI", "Pedido judicial de internação ou de leito de UTI.", "Médico(a)", "Laudo_medico_internacao_UTI"),
 ("medico", "tratamento", "Formulário médico – tratamento", "Pedido judicial de tratamento (terapias, acompanhamento, procedimentos).", "Médico(a)", "Formulario_pedido_judicial_tratamento"),
 ("medico", "med", "Formulário médico – medicamentos", "Pedido judicial de medicamentos (modelo geral).", "Médico(a)", "Formulario_pedido_judicial_medicamentos"),
 ("medico", "med6", "Formulário médico – medicamentos (Tema 6 do STF)", "Medicamentos não incorporados ao SUS, com as perguntas exigidas pelo Tema 6 do STF.", "Médico(a)", "Formulario_pedido_judicial_medicamentos_Tema_6_STF"),
 ("medico", "onco", "Questionamentos do juízo – casos oncológicos", "Informações específicas que o juízo pede nos casos de câncer (ECOG, tratamentos prévios, comorbidades…).", "Médico(a)", "Questionamentos_do_juizo_casos_oncologicos"),
 ("paj", "pendentes", "Documentação pendente", "Lista em branco dos documentos que faltam, com a ciência do(a) assistido(a). Para gerar a lista já pronta, use o Gerador de Lista de Documentos Faltantes.", "Assistido(a)", "Documentacao_pendente"),
 ("paj", "certidao", "Certidão de comparecimento", "Comprova que a pessoa esteve na DPU em determinado dia e horário (para apresentar no trabalho, por exemplo).", "Supervisão do atendimento", "Certidao_de_comparecimento"),
 ("paj", "desistencia", "Desistência do PAJ", "Quando o(a) assistido(a) não quer mais seguir com o pedido.", "Assistido(a)", "Desistencia_do_PAJ"),
 ("paj", "renuncia", "Declaração de renúncia (Juizado Especial Federal)", "Renúncia ao valor que passar de 60 salários mínimos, para a ação tramitar no Juizado Especial Federal.", "Assistido(a)", "Declaracao_de_renuncia"),
 ("paj", "termo", "Termo de não reconhecimento de assinatura", "Para quem não reconhece a assinatura de um contrato com banco ou financeira.", "Assistido(a)", "Termo_de_nao_reconhecimento_de_assinatura"),
 ("pet", "acordo_inss", "Petição de acordo – INSS", "Manifesta concordância com a proposta de acordo do INSS.", "Defensor(a)", "Peticao_de_acordo_INSS"),
 ("pet", "acordo_cef", "Petição de acordo – CEF", "Manifesta concordância com a proposta de acordo da Caixa Econômica Federal.", "Defensor(a)", "Peticao_de_acordo_CEF"),
]
b64 = lambda p: base64.b64encode(open(p, "rb").read()).decode()
def paginas(p): return int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", p], capture_output=True, text=True).stdout).group(1))
dados = []
for g, k, nome, desc, quem, arq in F:
    d = {"g": g, "k": k, "nome": nome, "desc": desc, "quem": quem, "arq": arq,
         "pdf": b64(PDF + arq + ".pdf"), "doc": b64(DOC + arq + ".dotx"), "pg": paginas(PDF + arq + ".pdf")}
    if os.path.exists(PDF + arq + "_analfabeto.pdf"):
        d.update(pdf_a=b64(PDF + arq + "_analfabeto.pdf"), doc_a=b64(DOC + arq + "_analfabeto.dotx"), pg_a=paginas(PDF + arq + "_analfabeto.pdf"))
    dados.append(d)
assert sum(1 + ("pdf_a" in d) for d in dados) == len(os.listdir(PDF)) == 34

R = {
    "LOGO": b64(RAIZ + "src/img-002.jpg"),
    "FFLATE": open(RAIZ + "assistente/lib/fflate.min.js", encoding="utf-8").read(),
    "PDFLIB": open(RAIZ + "assistente/lib/pdf-lib.min.js", encoding="utf-8").read(),
    "COMUM": open(RAIZ + "comum/comum.js", encoding="utf-8").read(),
    "CAT": json.dumps([{"g": g, "t": t, "d": d} for g, t, d in CAT], ensure_ascii=False),
    "FORMS": json.dumps(dados, ensure_ascii=False),
}
html = open(RAIZ + "central/page_c.html", encoding="utf-8").read()
html = re.sub(r"__(LOGO|FFLATE|PDFLIB|COMUM|CAT|FORMS)__", lambda m: R[m.group(1)], html)
out = RAIZ + "central/Central_de_Formularios.html"
open(out, "w", encoding="utf-8").write(html)
print(out, len(html.encode()) // 1024, "KB,", len(dados), "formulários")

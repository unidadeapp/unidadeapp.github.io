from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import sys as _sys; _sys.path.insert(0, RAIZ + "scripts"); from navegador import abrir
import asyncio, zipfile, io
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        br = await abrir(p); ctx = await br.new_context(accept_downloads=True, viewport={"width":1300,"height":900}); pg = await ctx.new_page(); erros=[]
        pg.on("pageerror", lambda e: erros.append(str(e)))
        await pg.goto("file://" + RAIZ + "central/Central_de_Formularios.html")
        print("cards", await pg.locator(".card").count())
        await pg.screenshot(path="c1.png")
        await pg.fill("#busca", "residencia"); print("busca residencia", await pg.locator(".card").count())
        await pg.fill("#busca", ""); await pg.check("#analf")
        print("tags analf", await pg.locator(".tag").count())
        # marcar 3 e baixar zip
        cards = pg.locator(".card")
        for i in (0, 1, 8): await cards.nth(i).locator(".nm").click()
        print(await pg.inner_text("#cont"))
        async with pg.expect_download() as d: await pg.click("#zPdf")
        dl = await d.value; path = await dl.path(); print(dl.suggested_filename)
        print(zipfile.ZipFile(path).namelist())
        async with pg.expect_download() as d: await pg.click("#zDoc")
        dl = await d.value; print(dl.suggested_filename, zipfile.ZipFile(await dl.path()).namelist())
        print("botões dentro dos cartões:", await pg.locator(".card button").count())
        await pg.click("#zMsg"); print("mensagem:", (await pg.input_value("#msgTxt"))[:160].replace("\n", " | "))
        await pg.click("#zLimpar"); await cards.nth(2).locator(".nm").click()
        async with pg.expect_download() as d: await pg.click("#zPdf")
        dl = await d.value; print(dl.suggested_filename, open(await dl.path(),'rb').read()[:5])
        await pg.screenshot(path="c2.png")
        print("msg", await pg.inner_text("#msg")); print("erros", erros); await br.close()
asyncio.run(main())

# Jurisprudências Comuns e Úteis, por área (tiradas dos modelos e das peças da unidade; teses resumidas)
J = []
def j(id, area, nome, tese, serve, onde="", obs=""):
    J.append({"id": id, "area": area, "n": nome, "tese": tese, "serve": serve, "onde": onde, "obs": obs})

PREV, BPC, PROC, PBF, SAU, CIV, CRIM = "Previdenciário – regras gerais e incapacidade", "BPC/LOAS", "Processo e honorários", "Bolsa Família e direitos sociais", "Saúde", "Cível", "Criminal"

# ---- Processo
j("stf-350", PROC, "STF – Tema 350 (RE 631.240)", "Para entrar com ação de benefício, em regra é preciso ter pedido antes no INSS; o pedido é dispensado quando o INSS já tem posição notoriamente contrária. Pedido de revisão, restabelecimento ou manutenção de benefício já concedido não exige novo requerimento.",
  "Mostrar que há interesse de agir (houve indeferimento ou cessação) e afastar a alegação de falta de pedido administrativo.", "Modelos de incapacidade, BPC e réplica.")
j("stf-1066", PROC, "STF – Tema 1.066 (RE 1.171.152) – acordo dos prazos do INSS", "O STF homologou acordo que fixa prazos para o INSS decidir: 45 dias para benefícios por incapacidade, 60 para pensão por morte e 90 para BPC, entre outros. Vencido o prazo, há interesse de agir mesmo sem decisão.",
  "Ação ou mandado contra a demora do INSS.", "Peças de incapacidade (caso de pedido parado).", "Confira se o acordo segue vigente antes de citar.")
j("stj-1030", PROC, "STJ – Tema 1.030 (REsp 1.807.665/SC)", "No Juizado Especial Federal, a parte pode renunciar ao valor que passar de 60 salários mínimos (somadas as vencidas e 12 vincendas) para manter a causa no JEF.",
  "Manter a ação no JEF quando o valor passa do limite; a renúncia exige declaração da própria parte.", "Réplica – benefícios por incapacidade.")
j("stf-1002", PROC, "STF – Tema 1.002 (RE 1.140.005)", "A Defensoria Pública pode receber honorários de sucumbência em ações contra qualquer ente público, inclusive aquele a que pertence.",
  "Fundamentar o pedido de honorários defensoriais (para o fundo da DPU).", "Pedidos finais de todas as petições iniciais.")
j("stf-s729", PROC, "STF – Súmula 729", "A decisão do STF que restringia tutelas antecipadas contra a Fazenda Pública (ADC 4) não se aplica às causas previdenciárias.",
  "Pedir tutela de urgência contra o INSS.", "Capítulo da tutela nas iniciais; obrigação de fazer.")
j("stf-adi6096", PROC, "STF – ADI 6.096", "É inconstitucional estender a decadência de 10 anos ao indeferimento, cancelamento ou cessação de benefício (art. 24 da Lei 13.846/2019). O prazo vale só para revisar o ato de concessão.",
  "Rebater alegação de decadência quando se discute benefício negado ou cessado.", "Réplica – benefícios por incapacidade.")
j("stj-s85", PROC, "STJ – Súmula 85", "Nas relações de trato sucessivo, a prescrição atinge apenas as parcelas anteriores aos 5 anos que antecedem a ação, não o próprio direito.",
  "Delimitar os atrasados devidos.", "Réplica – benefícios por incapacidade.")
j("stj-979", PROC, "STJ – Tema 979 (REsp 1.381.734/RN)", "Valores pagos pelo INSS por erro administrativo (cálculo ou operacional) podem ser cobrados de volta, salvo se o beneficiário provar boa-fé objetiva, especialmente que não tinha como perceber o erro; há modulação para os processos anteriores ao julgamento.",
  "Defender o assistido contra a devolução de valores.", "Réplica – benefícios por incapacidade.")
j("stj-1018", PROC, "STJ – Tema 1.018", "Se, durante a ação, o INSS concede administrativamente um benefício mais vantajoso, a pessoa pode ficar com ele e ainda receber os atrasados do benefício reconhecido na Justiça até a implantação do administrativo.",
  "Garantir o direito de opção pelo benefício melhor.", "Inicial de BPC idoso.")

# ---- Previdenciário
j("stj-1352", PREV, "STJ – Tema 1.352 (julgado em 11/11/2026)", "O acréscimo de 12 meses no período de graça para quem pagou mais de 120 contribuições sem perder a qualidade de segurado se incorpora ao patrimônio do segurado e pode ser usado mais de uma vez, sem novo ciclo de 120 contribuições.",
  "Manter a qualidade de segurado de quem já teve mais de 120 contribuições e voltou a contribuir.", "Inicial de auxílio – falta de qualidade de segurado.", "O modelo ainda diz “conferir o resultado do Tema 1.352”: já pode citar o julgamento (confira a publicação do acórdão).")
j("tnu-255", PREV, "TNU – Tema 255", "Mais de 120 contribuições sem perda da qualidade garantem a prorrogação do período de graça também em filiações posteriores, quantas vezes for preciso.",
  "Mesma finalidade do Tema 1.352 do STJ.", "Inicial de auxílio – falta de qualidade de segurado.")
j("tnu-365", PREV, "TNU – Tema 365", "Períodos recebendo benefício por incapacidade intercalados não contam para somar as 120 contribuições da prorrogação do período de graça.",
  "Conferir a contagem das 120 contribuições antes de usar a tese.", "Inicial de auxílio – falta de qualidade de segurado.")
j("stj-1360", PREV, "STJ – Tema 1.360 (acórdão publicado em 19/03/2026)", "O desemprego involuntário, que acrescenta 12 meses ao período de graça, pode ser provado por qualquer meio, sem exigir registro no órgão do Ministério do Trabalho.",
  "Provar o desemprego com CTPS, testemunhas e outros documentos.", "Inicial de auxílio – falta de qualidade de segurado.")
j("tnu-s27", PREV, "TNU – Súmula 27", "A ausência de registro no Ministério do Trabalho não impede provar o desemprego por outros meios.",
  "Prorrogação do período de graça do desempregado.", "Inicial de auxílio – falta de qualidade de segurado.")
j("tnu-s75", PREV, "TNU – Súmula 75", "A anotação na carteira de trabalho sem defeito formal tem presunção relativa de veracidade e vale como prova do vínculo, mesmo ausente do CNIS.",
  "Contar vínculos que faltam no CNIS.", "Inicial de auxílio – falta de qualidade de segurado.")
j("stj-resp1245217", PREV, "STJ – AgRg no REsp 1.245.217/SP", "Não perde a qualidade de segurado quem deixou de contribuir por estar incapacitado para o trabalho.",
  "Salvar a qualidade de segurado quando a doença já existia ao parar de contribuir.", "Inicial de auxílio – falta de qualidade de segurado.")
j("tnu-s47", PREV, "TNU – Súmula 47", "Reconhecida a incapacidade parcial, o juiz deve analisar as condições pessoais e sociais (idade, escolaridade, profissão) para decidir sobre a aposentadoria por incapacidade.",
  "Converter incapacidade parcial em direito à aposentadoria ou ao auxílio.", "Iniciais e réplicas de incapacidade; impugnação ao laudo.")
j("tnu-s77", PREV, "TNU – Súmula 77", "O juiz não é obrigado a analisar as condições pessoais quando não reconhece nenhuma incapacidade para a atividade habitual.",
  "Saber quando a Súmula 47 não ajuda: é preciso primeiro atacar o laudo.", "Impugnação ao laudo pericial.")
j("tnu-s78", PREV, "TNU – Súmula 78", "No portador de HIV, a incapacidade deve ser vista em sentido amplo, considerando as condições pessoais, sociais, econômicas e culturais, pelo estigma da doença.",
  "Doenças estigmatizantes; a TNU aplica o raciocínio a outras doenças com forte estigma.", "Inicial de auxílio – não constatação de incapacidade.")
j("tnu-s80", BPC, "TNU – Súmula 80", "Nos pedidos de BPC, é necessária avaliação social (por assistente social ou meio equivalente) para conhecer as condições em que o requerente vive.",
  "Pedir a perícia social e anular sentença baseada só em laudo médico.", "Inicial de BPC; impugnação ao laudo.")
j("tnu-277", PREV, "TNU – Tema 277", "Para discutir na Justiça a cessação do benefício por incapacidade com data fixada (DCB), é preciso ter pedido a prorrogação; sem isso, falta interesse de agir.",
  "Conferir se houve pedido de prorrogação antes de ajuizar; a TNU ressalva situações excepcionais.", "Inicial de auxílio – não constatação de incapacidade.")
j("stj-1013", PREV, "STJ – Tema 1.013 (REsp 1.786.590/SP e 1.788.700/SP)", "Entre o indeferimento e a implantação judicial do benefício por incapacidade, o segurado que trabalhou para sobreviver tem direito a receber o salário e o benefício juntos.",
  "Afastar o desconto dos meses com remuneração no CNIS.", "Obrigação de fazer – demora no cumprimento de acórdão.")
j("stj-s340", PREV, "STJ – Súmula 340", "A lei aplicável à pensão por morte é a vigente na data do óbito.", "Escolher as regras certas (duração, prova, valor).", "Inicial de pensão por morte.")
j("stj-s416", PREV, "STJ – Súmula 416", "É devida a pensão aos dependentes de quem perdeu a qualidade de segurado, mas já tinha preenchido os requisitos de alguma aposentadoria até o óbito.",
  "Pensão quando o falecido parou de contribuir.", "Inicial de pensão por morte.")
j("stj-732", PREV, "STJ – Tema 732 (REsp 1.411.258/RS) e STF – ADIs 4.878 e 5.083", "O menor sob guarda é dependente para fins de pensão por morte, desde que comprovada a dependência econômica.",
  "Pensão do menor sob guarda e, por analogia, do neto que dependia do avô.", "Inicial de pensão – dependente não reconhecido.")
j("stj-s336", PREV, "STJ – Súmula 336", "A mulher que renunciou aos alimentos na separação tem direito à pensão do ex-marido se comprovar necessidade econômica superveniente.",
  "Pensão do ex-cônjuge.", "Inicial de pensão – dependente não reconhecido.")
j("tnu-s63", PREV, "TNU – Súmula 63", "A prova da união estável para pensão por morte dispensa início de prova material (entendimento aplicável aos óbitos anteriores à MP 871/2019, de 18/01/2019).",
  "União estável em óbitos antigos.", "Inicial de pensão – dependente não reconhecido.")
j("stj-s596", PREV, "STJ – Súmula 596", "A obrigação alimentar dos avós é complementar e subsidiária.", "Mostrar necessidade reconhecida em juízo quando o avô pagava alimentos ao neto.", "Inicial de pensão (netos).")

# ---- BPC
j("stf-27", BPC, "STF – Tema 27 (RE 567.985)", "O critério de 1/4 do salário mínimo do art. 20, § 3º, da LOAS não é absoluto: a miserabilidade pode ser provada por outros meios.", "Defender o BPC quando a renda passa um pouco de 1/4.", "Iniciais de BPC e LOAS idoso.")
j("stf-312", BPC, "STF – Tema 312 (RE 580.963)", "Não deve entrar no cálculo da renda familiar o benefício de valor mínimo recebido por outro idoso ou pessoa com deficiência da família (o raciocínio do Estatuto da Pessoa Idosa vale para benefícios previdenciários e para pessoas com deficiência).", "Excluir a aposentadoria ou o BPC de 1 salário mínimo de outro membro.", "Iniciais de BPC.")
j("stj-185", BPC, "STJ – Tema 185 (REsp 1.112.557/MG)", "A limitação do valor da renda per capita não é o único meio de provar a miserabilidade; o juiz pode considerar outros elementos.", "Mesmo uso do Tema 27 do STF.", "Iniciais e réplicas de BPC.")
j("stj-640", BPC, "STJ – Tema 640 (REsp 1.355.052/SP)", "Benefício previdenciário de até 1 salário mínimo recebido por idoso do grupo familiar não entra no cálculo da renda para o BPC (aplicação analógica do Estatuto da Pessoa Idosa).", "Excluir renda de outro idoso; usado por analogia contra a inclusão do Bolsa Família.", "Iniciais de BPC e LOAS idoso.")
j("trf4-irdr12", BPC, "TRF4 – IRDR 12 (5013036-79.2017.4.04.0000)", "Renda familiar por pessoa inferior a 1/4 do salário mínimo gera presunção absoluta de miserabilidade.", "Quando a renda está abaixo de 1/4, não se discute mais a miserabilidade.", "Iniciais de BPC.", "Número correto: 5013036 (algumas peças trazem 5012036). O IRDR não fixa a baliza de 1/2 salário mínimo.")
j("tnu-122", BPC, "TNU – Tema 122", "A renda inferior a 1/4 do salário mínimo gera presunção relativa de miserabilidade, que pode ser afastada por outras provas; acima de 1/4, a miserabilidade pode ser provada.", "Discussão sobre o peso do critério de 1/4. Use no lugar da Súmula 11 da TNU, que foi cancelada.", "Iniciais de BPC.")
j("tnu-s29", BPC, "TNU – Súmula 29", "Para o BPC, incapacidade para a vida independente não é só a que impede atos elementares, mas também a que impede a pessoa de prover o próprio sustento.", "Afastar a exigência de dependência total para o BPC.", "Iniciais de BPC.")
j("tnu-s48", BPC, "TNU – Súmula 48", "Deficiência para o BPC não se confunde com incapacidade para o trabalho; exige impedimento de longo prazo (mínimo de 2 anos), contado do início do impedimento até a previsão de cessação.", "Contestar laudo que nega o BPC só porque a pessoa “pode trabalhar”.", "Iniciais de BPC; impugnação ao laudo.")
j("tnu-385", BPC, "TNU – Tema 385 (24/06/2026)", "A TNU reafirmou que a caracterização da deficiência não exige incapacidade para o trabalho e que o impedimento de longo prazo deve ser aferido por avaliação biopsicossocial; por economia processual, admitiu dispensar a nova avaliação em certas hipóteses (como quando o próprio INSS já reconheceu a deficiência).", "Reforçar a avaliação biopsicossocial e pedir a dispensa de nova perícia quando o INSS já reconheceu a deficiência.", "Inicial de BPC – não constatação de deficiência.")
j("tnu-378", BPC, "TNU – Tema 378 e STF – ADI 6.850 (2026)", "A visão monocular é deficiência sensorial (Lei 14.126/2021, constitucional – ADI 6.850), mas para o BPC exige avaliação biopsicossocial; o diagnóstico ou a perícia só médica não bastam.", "Casos de visão monocular.", "Recurso inominado de BPC.")
j("stj-resp1962868", BPC, "STJ – REsp 1.962.868/SP (2ª Turma, 2023)", "Na revisão do BPC, o INSS não pode exigir requisitos mais rígidos do que os da concessão.", "BPC cessado em revisão bienal.", "Inicial de BPC – restabelecimento.")
j("stj-agresp1267161", BPC, "STJ – AgRg no REsp 1.267.161/PR", "O critério de 1/4 deve ser visto como um mínimo, sem impedir o juiz de usar outras provas da miserabilidade.", "Reforço do Tema 185.", "Inicial de BPC.")

# ---- Bolsa Família
j("stf-are639337", PBF, "STF – ARE 639.337 AgR e ARE 745.745 AgR", "A cláusula da reserva do possível não pode ser invocada para comprometer o mínimo existencial nem para frustrar políticas públicas previstas na Constituição.", "Rebater a alegação de falta de orçamento para incluir a família no Bolsa Família.", "Inicial, réplica e recurso de Bolsa Família.")
j("stf-mi7300", PBF, "STF – MI 7.300 (2021)", "O STF reconheceu a omissão do Poder Executivo em implementar a renda básica de cidadania (Lei 10.835/2004) para os mais pobres.", "Fundamentar o direito fundamental à renda básica familiar (EC 114/2021).", "Inicial de Bolsa Família.")
j("stf-1472", PBF, "STF – Tema 1.472 (RE 1.614.224)", "Repercussão geral reconhecida sobre a validade do limite de famílias unipessoais como condição para entrar no Bolsa Família.", "Pedir o sobrestamento quando a sentença aplica o limite de unipessoais.", "Recurso inominado e réplica de Bolsa Família.", "Ainda sem julgamento de mérito: acompanhe.")
j("tnu-379", PBF, "TNU – Tema 379 (PUIL 0044230-77.2023.4.05.8300/PE, 03/12/2025)", "A TNU considerou legal o índice máximo de famílias unipessoais como condicionante de ingresso no Programa.", "Conhecer a tese contrária e mostrar as exceções da própria portaria (Portaria MDS 897/2023, art. 6º, § 3º, IX) e a pendência no STF.", "Réplica e recurso de Bolsa Família.")

# ---- Saúde
j("stf-793", SAU, "STF – Tema 793 (RE 855.178)", "União, Estados e Municípios são solidariamente responsáveis pelas prestações de saúde, cabendo ao juiz direcionar o cumprimento conforme a repartição de competências do SUS.", "Incluir a União no polo e justificar a Justiça Federal.", "Iniciais de saúde e ressarcimento.")
j("stf-6-1234", SAU, "STF – Temas 6 e 1.234 e Súmulas Vinculantes 60 e 61 (2024)", "Medicamento registrado e não incorporado ao SUS só é concedido judicialmente com requisitos cumulativos (negativa, ilegalidade da não incorporação, falta de substituto, prova científica, laudo fundamentado e incapacidade financeira); competência e custeio seguem os acordos interfederativos (custo anual a partir de 210 salários mínimos: Justiça Federal e União).", "Montar o pedido de medicamento e definir onde ajuizar.", "Pedidos de medicamentos.")
j("stj-106", SAU, "STJ – Tema 106 (REsp 1.657.156/RJ)", "Requisitos para fornecimento de medicamento fora das listas do SUS: laudo fundamentado, incapacidade financeira e registro na ANVISA.", "Referência histórica; hoje prevalecem os Temas 6 e 1.234 do STF.", "Peças antigas de saúde.")
j("stf-500", SAU, "STF – Tema 500 (RE 657.718)", "Em regra, o Estado não fornece medicamento sem registro na ANVISA; excepcionalmente, sim, em caso de mora irrazoável da agência, registro em agências estrangeiras renomadas e falta de substituto no Brasil, com ação contra a União.", "Medicamentos sem registro.", "Narrativa “sem registro na ANVISA”.")
j("stj-resp1662338", SAU, "STJ – REsp 1.662.338/SP (3ª Turma, 2018)", "A demora injustificada na prestação de assistência à saúde pode gerar dano moral.", "Pedido de indenização e ressarcimento por demora do SUS.", "Inicial de ressarcimento de despesas de saúde.")
j("stj-s54-362", SAU, "STJ – Súmulas 54 e 362", "Juros do dano moral contam do evento danoso em responsabilidade extracontratual (54); a correção monetária conta da data do arbitramento (362).", "Pedidos de indenização.", "Inicial de ressarcimento de despesas de saúde.")

# ---- Cível
j("stf-adi5090", CIV, "STF – ADI 5.090 (12/06/2024) e STJ – Tema 731", "O STJ manteve a TR na correção do FGTS (Tema 731); o STF decidiu que a remuneração deve garantir ao menos o IPCA, somente para o futuro, sem efeitos retroativos.", "Explicar o arquivamento dos pedidos de “revisão do FGTS”.", "Narrativa FGTS – correção (arquivamento).")
j("stf-1184", CIV, "STF – Tema 1.184", "É legítima a extinção de execução fiscal de baixo valor por falta de interesse de agir, observadas as condições fixadas (tentativa prévia de conciliação ou protesto).", "Defesa em execuções fiscais pequenas.", "Execução fiscal.")
j("stj-566", CIV, "STJ – Tema 566 (REsp 1.340.553/RS)", "Regras da prescrição intercorrente na execução fiscal (art. 40 da Lei 6.830/1980): sem bens localizados, o prazo corre automaticamente após 1 ano de suspensão.", "Pedir a extinção de execuções paradas.", "Execução fiscal.")
j("stj-s297", CIV, "STJ – Súmula 297", "O Código de Defesa do Consumidor se aplica às instituições financeiras.", "Contratos com a Caixa.", "Contratos bancários e habitacionais.")

# ---- Criminal
j("stf-hc185913", CRIM, "STF – HC 185.913 (2024)", "É cabível o acordo de não persecução penal em processos que estavam em andamento quando a Lei 13.964/2019 entrou em vigor, desde que pedido antes do trânsito em julgado.", "Pedir ANPP em processos antigos.", "Defesa criminal.")
j("stj-157", CRIM, "STJ – Tema 157", "Aplica-se o princípio da insignificância ao descaminho quando os tributos não pagos não passam de R$ 20.000,00.", "Defesa em descaminho.", "Defesa criminal.", "A reiteração delitiva pode afastar a insignificância.")

AREAS_J = [PROC, PREV, BPC, PBF, SAU, CIV, CRIM]

# Páginas da aba APRENDER – Cível, Saúde e Criminal
from base import *
from conteudo_prev import pag, PAGINAS

# ---------------- CÍVEL ----------------
pag("bolsa-familia", "civel", "Bolsa Família", "Quem tem direito, valores de 2026, bloqueios, regra de proteção e famílias unipessoais.",
    sec("O que é", p("Programa de transferência de renda da Lei 14.601/2023, pago pela Caixa e gerido pelo Ministério do Desenvolvimento e Assistência Social (MDS), com base no CadÚnico."))
    + sec("Quem tem direito", lista(["família inscrita no CadÚnico com renda por pessoa de até <b>R$ 218,00</b>;", "cadastro atualizado (em regra, nos últimos 24 meses);", "cumprimento das condicionalidades de saúde e educação (vacinação, pré-natal, frequência escolar)."]))
    + sec("Valores (desde outubro de 2026)", p("O Decreto 13.120/2026 corrigiu os valores pelo INPC: mínimo de <b>R$ 691,00</b> por família e benefício de renda de cidadania de R$ 164,00 por pessoa, além de adicionais por criança, gestante, nutriz e adolescente."))
    + sec("Regra de proteção", p("Quando a renda sobe acima de R$ 218,00 por pessoa (mas fica dentro do limite), a família continua recebendo 50% do benefício por um tempo, sem precisar sair do programa (Portaria MDS nº 1.084/2025)."))
    + sec("Problemas mais comuns", lista(["<b>Habilitada e não recebe</b>: a família está habilitada há meses e não é selecionada – tese do mínimo existencial e da omissão administrativa.", "<b>Família unipessoal</b>: o MDS limita o ingresso de pessoas que moram sozinhas em cada município (índice de 16%). A TNU considerou legal (Tema 379), mas o STF reconheceu repercussão geral (Tema 1.472) – peça o sobrestamento e mostre que a pessoa realmente mora só.", "<b>Bloqueio/cancelamento</b> por averiguação cadastral ou renda: confira o motivo no app Bolsa Família e no CRAS."]))
    + sec("Como analisar", passos(["Peça o extrato do CadÚnico e a tela do app com a situação do benefício.", "Identifique o motivo (habilitação sem concessão, bloqueio, cancelamento, unipessoal).", "Confira a renda por pessoa e quem está no cadastro.", "A ação é contra a União (e a Caixa, se o problema for de pagamento), no JEF."])),
    [FONTE_ME + " (Bolsa Família)", "Lei nº 14.601/2023", "Decreto nº 13.120/2026", "Portaria MDS nº 1.084/2025", "STF, Tema 1.472 (RE 1.614.224)", "TNU, Tema 379"], ["stf-are639337", "stf-mi7300", "stf-1472", "tnu-379"])

pag("auxilio-gas", "civel", "Auxílio Gás do Povo", "O antigo Auxílio Gás virou recarga gratuita do botijão: quem tem direito.",
    sec("O que mudou", p("A Lei 15.348/2026 transformou o Auxílio Gás dos Brasileiros (Lei 14.237/2021) no <b>Auxílio Gás do Povo</b>. Desde o início de 2026, em vez de dinheiro a cada dois meses, a família retira a <b>recarga gratuita do botijão de 13 kg</b> em revendas credenciadas."))
    + sec("Quem tem direito", lista(["família inscrita e atualizada no CadÚnico;", "renda por pessoa de até 1/2 salário mínimo;", "prioridade para quem recebe Bolsa Família;", "pelas regras atuais, família com 2 ou mais pessoas."]))
    + sec("Como analisar", passos(["Confira o CadÚnico (atualização, composição, renda).", "Veja no app Gás do Povo ou no CRAS o motivo da não concessão.", "Registre na narrativa desde quando parou de receber e o motivo informado."])),
    ["Lei nº 14.237/2021, com a redação da Lei nº 15.348/2026", "Ministério de Minas e Energia – Perguntas frequentes do Gás do Povo (2026)"])

pag("seguro-desemprego", "civel", "Seguro-desemprego", "Requisitos, prazos e o problema da empresa no nome do trabalhador.",
    sec("Requisitos (trabalhador formal)", lista(["dispensa <b>sem justa causa</b>;", "ter recebido salários: 12 meses nos últimos 18 (1º pedido), 9 nos últimos 12 (2º) ou 6 meses (demais);", "não ter renda própria suficiente para o sustento nem receber benefício previdenciário (salvo pensão e auxílio-acidente);", "pedido entre o 7º e o 120º dia após a dispensa."]))
    + sec("Empresa no nome do trabalhador", p("É motivo comum de bloqueio: o sistema encontra CNPJ ou MEI em nome da pessoa. Em regra, a jurisprudência entende que o simples registro da empresa não prova renda; é preciso ver se ela estava ativa e gerava renda. Peça a certidão de baixa ou a declaração de inatividade e extratos."))
    + sec("Como analisar", passos(["Peça o termo de rescisão, a CTPS e o comprovante do pedido.", "Confira o motivo da recusa no portal Emprega Brasil/Carteira de Trabalho Digital.", "A ação é contra a União, no JEF."])),
    ["Lei nº 7.998/1990, arts. 3º e 7º", "Resolução CODEFAT nº 467/2005 (e alterações)"])

pag("fgts-pis", "civel", "FGTS e PIS", "Saques do FGTS, saque indevido e a correção pela inflação (arquivamento).",
    sec("Saque do FGTS", p("Só nas hipóteses do art. 20 da Lei 8.036/1990: dispensa sem justa causa, aposentadoria, doenças graves (câncer, HIV, doença terminal), compra da casa própria, calamidade, saque-aniversário, entre outras. A jurisprudência admite outras doenças graves por analogia, conforme o caso."))
    + sec("Saque indevido", p("Quando alguém saca o FGTS ou o PIS da pessoa sem autorização, a Caixa responde pela falha do serviço (CDC). Peça os extratos, a contestação feita na Caixa e o boletim de ocorrência."))
    + sec("Correção do FGTS pela inflação", p("O STJ manteve a TR (Tema 731) e o STF, na ADI 5.090 (2024), decidiu que a remuneração deve garantir pelo menos o IPCA <b>apenas para o futuro</b>, sem retroagir. Por isso, o pedido de correção dos anos passados é inviável e o PAJ é arquivado (use o modelo de narrativa de arquivamento)."))
    + dica("Na abertura, a demanda “FGTS e PIS” tem dois modelos: liberação de valores e correção (arquivamento)."),
    ["Lei nº 8.036/1990, art. 20", "STJ, Tema 731 (REsp 1.614.874/SC)", "STF, ADI 5.090", "Código de Defesa do Consumidor, art. 14"], ["stf-adi5090"])

pag("contratos-cef", "civel", "Contratos com a Caixa (empréstimos, habitacional e FIES)", "Renegociação, juros, imóvel financiado e financiamento estudantil.",
    sec("Regras gerais", lista(["o Código de Defesa do Consumidor vale para os bancos (STJ, Súmula 297);", "a DPU atua contra a Caixa (empresa pública federal); contra bancos privados, a causa é da Justiça Estadual;", "antes de ação, tente a renegociação: muitas vezes ela resolve."]))
    + sec("Financiamento habitacional", p("Nos contratos com alienação fiduciária (MCMV, SFH), o atraso leva à notificação do cartório para pagar em <b>15 dias</b>; sem pagamento, a propriedade é consolidada em nome da Caixa e o imóvel pode ir a leilão (Lei 9.514/1997). O caso é urgente. Nos imóveis do PAR, o contrato é de arrendamento."))
    + sec("FIES", p("Financiamento estudantil (Lei 10.260/2001). Problemas comuns: aditamento não feito, cobrança de juros, renegociação de dívida em atraso. Existem programas periódicos de renegociação com desconto: confira se há um aberto."))
    + sec("Como analisar", passos(["Peça o contrato, o extrato da dívida e as propostas da Caixa.", "Anote o valor que a pessoa consegue pagar sem prejudicar o sustento.", "No habitacional, pergunte se chegou notificação do cartório e quando."])),
    [FONTE_ME + " (Contratos habitacionais)", "STJ, Súmula 297", "Lei nº 9.514/1997", "Lei nº 10.260/2001"])

pag("execucao-fiscal", "civel", "Execução fiscal, conselhos profissionais e multas (IBAMA)", "Como funciona a cobrança da dívida ativa e as principais defesas.",
    sec("O que é", p("Ação de cobrança de dívida ativa da União, autarquias (INSS, IBAMA) e conselhos profissionais (Lei 6.830/1980). Após a citação, o devedor pode pagar, parcelar ou se defender."))
    + sec("Defesas mais usadas", lista(["<b>exceção de pré-executividade</b> (matérias que o juiz pode ver sem prova: prescrição, nulidade, ilegitimidade);", "<b>embargos</b> à execução (exigem garantia);", "<b>impenhorabilidade</b>: salário, aposentadoria, poupança até 40 salários mínimos e bem de família (CPC, art. 833; Lei 8.009/1990);", "<b>prescrição</b>, inclusive intercorrente (art. 40 da LEF; STJ, Tema 566);", "conselhos: não podem executar dívida inferior a 5 anuidades (Lei 12.514/2011, art. 8º);", "execução de baixo valor pode ser extinta por falta de interesse (STF, Tema 1.184)."]))
    + sec("Depois do fim do processo", p("Extinta a execução, bloqueios (RENAJUD, CNIB, penhoras) devem ser retirados. Se a pessoa continua com restrição, o Defensor pede o cumprimento da ordem de levantamento."))
    + sec("Como analisar", passos(["Peça o mandado de citação e a CDA (certidão de dívida ativa).", "Anote quem cobra, o que cobra, o valor e as datas.", "Veja se há bens bloqueados e se são impenhoráveis."])),
    [FONTE_ME + " (Multas ou cobranças)", "Lei nº 6.830/1980", "CPC, art. 833", "Lei nº 12.514/2011", "STF, Tema 1.184; STJ, Tema 566"], ["stf-1184", "stj-566"])

pag("concurso-educacao", "civel", "Concursos públicos e vagas em instituições federais", "Cotas, heteroidentificação, matrícula negada e edital.",
    sec("O que é", p("Demandas contra universidades e institutos federais (ingresso pelo SISU/ENEM ou processo seletivo) e contra concursos federais. O <b>edital</b> é a regra do jogo: é por ele que se verifica se a instituição errou."))
    + sec("Problemas comuns", lista(["documentação de renda recusada na cota de baixa renda;", "banca de heteroidentificação que não confirma a autodeclaração de pessoa preta ou parda;", "laudo de deficiência não aceito;", "matrícula perdida por prazo ou erro do sistema."]))
    + sec("Como analisar", passos(["Peça o edital, o resultado, o indeferimento e o recurso administrativo.", "Confira prazos: matrícula e chamada são rápidas, então a ação pode precisar de tutela urgente.", "Anote a classificação e a modalidade de cota."])),
    [FONTE_ME + " (Reserva de vagas)", "Lei nº 12.711/2012 (alterada pela Lei nº 14.723/2023)", "Lei federal de cotas em concursos públicos (confira a versão vigente)"])

pag("nacionalidade", "civel", "Nacionalidade, migração e refúgio", "Opção de nacionalidade, naturalização e regularização migratória.",
    sec("Opção de nacionalidade", p("Filho de brasileiro nascido no exterior e não registrado em consulado pode vir morar no Brasil e, depois dos 18 anos, <b>optar</b> pela nacionalidade brasileira por ação na Justiça Federal (CF, art. 12, I, “c”, e art. 109, X). Precisa da certidão estrangeira traduzida, prova da nacionalidade do pai ou da mãe e da residência no Brasil."))
    + sec("Naturalização e refúgio", p("Estrangeiros podem pedir a naturalização ao Ministério da Justiça (Lei 13.445/2017), em regra após 4 anos de residência e falando português. O refúgio é pedido à Polícia Federal e decidido pelo CONARE (Lei 9.474/1997)."))
    + sec("Como analisar", passos(["Peça documentos de identidade, certidões (com tradução juramentada) e comprovantes de residência no Brasil.", "Anote há quanto tempo a pessoa mora no Brasil e se fala português."])),
    ["Constituição Federal, arts. 12 e 109, X", "Lei nº 13.445/2017 (Lei de Migração)", "Lei nº 9.474/1997"])

pag("alvara", "civel", "Alvará judicial (valores de quem faleceu)", "Saque de FGTS, PIS-PASEP e outros valores que a pessoa não recebeu em vida, sem inventário.",
    sec("O que é", p("Quando alguém morre sem ter recebido valores como <b>FGTS</b>, <b>PIS-PASEP</b>, verbas trabalhistas ou restituição de impostos, a Lei 6.858/1980 permite pagá-los <b>sem inventário nem arrolamento</b> (CPC, art. 666). Recebem primeiro os <b>dependentes habilitados na Previdência</b> (como a pensão por morte), em partes iguais; não havendo dependentes, os <b>sucessores da lei civil</b>, indicados em <b>alvará judicial</b>."))
    + sec("Onde o pedido tramita", p("Pela <b>Súmula 161 do STJ</b>, autorizar o saque de <b>PIS-PASEP e FGTS</b> pelo falecimento do titular é, em regra, da <b>Justiça Estadual</b> (jurisdição voluntária). A Justiça Federal entra quando há <b>conflito com um órgão federal</b> (por exemplo, a Caixa negou o saque). Na dúvida, registre o caso e confirme com o(a) Defensor(a) antes de seguir."))
    + sec("O que pedir", lista(["certidão de óbito;", "documentos de quem pede (RG, CPF) e prova do vínculo (certidão de casamento, de nascimento, união estável);", "certidão de dependentes habilitados no INSS (ou de que não há dependentes);", "extrato ou comprovante dos valores (FGTS, PIS-PASEP, verbas);", "negativa da Caixa ou do banco, se houver."]))
    + atencao("A Lei 6.858/1980 vale para verbas trabalhistas, FGTS, PIS-PASEP e restituições; não serve, por exemplo, para seguro de vida."),
    ["Lei nº 6.858/1980, art. 1º", "Código de Processo Civil, art. 666", "STJ, Súmula 161", "STJ, Súmula 82"])

pag("auxilio-reconstrucao", "civel", "Auxílio Reconstrução (enchentes de 2024)", "Parcela única de R$ 5.100 para famílias desalojadas ou desabrigadas no RS.",
    sec("O que foi", p("Apoio financeiro do Governo Federal, em <b>parcela única de R$ 5.100 por família</b>, pago pela Caixa (Pix), às famílias <b>desalojadas ou desabrigadas</b> pelas enchentes de 2024 no Rio Grande do Sul, que moravam em <b>área diretamente atingida</b> de município com situação de emergência ou calamidade reconhecida. Valia para proprietários e inquilinos, e quem recebe Bolsa Família também podia receber."))
    + sec("Como funcionava", passos(["A <b>prefeitura</b> cadastrava as famílias atingidas.", "O responsável familiar <b>confirmava os dados</b> no site do Governo Federal.", "O pagamento caía na conta da Caixa."]))
    + sec("Como analisar", lista(["peça o comprovante de residência na área atingida na época e a prova de que a família ficou desalojada ou desabrigada;", "verifique se a prefeitura cadastrou a família (o prazo para o cadastro pelas prefeituras terminou em 31/08/2024) e o motivo da negativa;", "a ação é contra a União, no JEF."]))
    + atencao("Foi criado pela MP 1.219/2024 (15/05/2024) e ampliado pela MP 1.250/2024. A MP 1.219 não foi votada pelo Congresso e perdeu a validade em 11/09/2024. É um programa de 2024: confira sempre a situação atual com o(a) Defensor(a) antes de orientar a pessoa."),
    ["Medida Provisória nº 1.219/2024", "Medida Provisória nº 1.250/2024", "Agência Gov – Governo prorroga até 31/8 prazo para prefeituras cadastrarem famílias (jul. 2024)"])

pag("analise-renda", "comecar", "Análise da renda: os limites de cada caso", "Os números que o app usa para a DPU, o BPC/LOAS e o Bolsa Família, num lugar só.",
    sec("Como calcular", passos(["Some a <b>renda bruta</b> de todas as pessoas do <b>grupo familiar</b> (quem mora na mesma casa).", "Divida pelo número de pessoas: é a <b>renda por pessoa</b>.", "Compare com o limite do caso (tabela abaixo). O Formulário de Renda do app faz a conta sozinho."]))
    + sec("Limites", tabela(["Para quê", "Limite", "Base"], [
        ["Atendimento pela DPU", "renda familiar de até <b>2 salários mínimos</b> (gastos extraordinários com saúde podem ser descontados)", "Resolução CSDPU nº 240/2025"],
        ["BPC/LOAS (deficiência ou idoso)", "renda por pessoa <b>inferior a 1/4 do salário mínimo</b>; o critério não é absoluto e pode ser flexibilizado", "Lei 8.742/1993, art. 20, § 3º e § 11-A; STF, Tema 27"],
        ["Bolsa Família", "renda por pessoa de até <b>R$ 218,00</b>", "Lei 14.601/2023"],
      ]))
    + dica("O salário mínimo de 2026 (R$ 1.621) está cadastrado no app; se mudar, atualize em Assistente › Início › Alterar."),
    ["Resolução CSDPU nº 240/2025", "Lei nº 8.742/1993 (LOAS), art. 20", "Lei nº 14.601/2023 (Bolsa Família)", "STF, Tema 27 (RE 567.985)"])

pag("dpvat", "civel", "Seguro DPVAT", "Indenização por acidente de trânsito ocorrido até 14/11/2023.",
    sec("O que é", p("Seguro obrigatório que indeniza morte, invalidez permanente e despesas médicas de vítimas de acidentes com veículos (Lei 6.194/1974). Para acidentes até 14/11/2023, o pedido é feito à <b>Caixa</b>, que administrou o seguro entre 2021 e 2023."))
    + sec("Pontos importantes", lista(["prazo de 3 anos para cobrar na Justiça (STJ, Súmula 405);", "na invalidez parcial, a indenização é proporcional ao grau (STJ, Súmula 474);", "documentos: registro de ocorrência, laudos, comprovantes de despesas."])),
    ["Lei nº 6.194/1974", "STJ, Súmulas 405 e 474"])

pag("posse", "civel", "Posse, moradia e reintegração", "Defesa em ações de reintegração de posse e usucapião.",
    sec("Quando é da DPU", p("Quando o autor da ação é a União, a Caixa, o INCRA, o DNIT ou outro ente federal (ex.: imóveis do PAR, faixas de domínio de rodovias e ferrovias, terrenos da União)."))
    + sec("Pontos importantes", lista(["comprovantes antigos de moradia mostram a posse e seu tempo;", "imóvel público não pode ser adquirido por usucapião (CF, arts. 183, § 3º, e 191, parágrafo único);", "em ocupações coletivas, há regras de mediação antes da remoção (Resolução CNJ nº 510/2023, a partir da ADPF 828)."]))
    + sec("Como analisar", passos(["Peça o mandado e a chave do processo; anote a data em que recebeu.", "Pergunte há quanto tempo mora, quem mora junto e que documentos tem.", "Prazo de defesa é curto: leve ao Defensor com urgência."])),
    ["CPC, arts. 554 a 568", "Constituição Federal, arts. 183 e 191", "Resolução CNJ nº 510/2023"])

# ---------------- SAÚDE ----------------
pag("saude-geral", "saude", "Como funcionam os pedidos de saúde", "Responsabilidade dos entes, competência e as regras do STF de 2024.",
    sec("Base", p("A saúde é direito de todos e dever do Estado (CF, art. 196). União, Estados e Municípios respondem de forma solidária, mas o juiz deve direcionar o cumprimento ao ente responsável pela política (STF, Tema 793)."))
    + sec("Regras do STF de 2024 (Temas 6 e 1.234)", lista(["medicamentos <b>não incorporados</b> ao SUS só são concedidos judicialmente se presentes requisitos cumulativos: negativa administrativa, ilegalidade da não incorporação, falta de substituto no SUS, prova científica de eficácia, laudo fundamentado e incapacidade financeira (Tema 6; Súmula Vinculante 61);", "pedidos e ações seguem os acordos entre os entes homologados no Tema 1.234 (Súmula Vinculante 60): medicamentos não incorporados com custo anual a partir de 210 salários mínimos tramitam na Justiça Federal, com a União;", "medicamentos <b>sem registro</b> na ANVISA: só em casos excepcionais (Tema 500)."]))
    + sec("O que nunca pode faltar no PAJ", lista(["receita ou prescrição atualizada;", "laudo médico detalhado (doença, tratamentos já feitos, por que o pedido é necessário, urgência);", "negativa do SUS (farmácia municipal e estadual, regulação);", "orçamentos;", "documentos de renda."])),
    ["Constituição Federal, art. 196", "Lei nº 8.080/1990", "STF, Temas 6, 500, 793 e 1.234; Súmulas Vinculantes 60 e 61"], ["stf-793", "stf-6-1234", "stf-500", "stj-106"])

pag("medicamentos", "saude", "Medicamentos e insumos", "Como classificar o medicamento e escolher o modelo de narrativa certo.",
    sec("Três perguntas", passos(["O medicamento tem <b>registro na ANVISA</b>? (consulta pelo princípio ativo no site da ANVISA)", "Está <b>padronizado</b> no SUS (RENAME ou listas estadual/municipal)?", "Se está padronizado, é fornecido para o CID da pessoa? (a negativa da farmácia costuma dizer)"]))
    + sec("Os modelos de narrativa", tabela(["Situação", "Modelo"], [["Registrado e não padronizado", "Medicamento com registro na ANVISA e não padronizado no SUS"], ["Registrado e padronizado (falta ou CID não contemplado)", "Medicamento com registro na ANVISA e padronizado no SUS"], ["Sem registro", "Medicamento sem registro na ANVISA"], ["Não foi possível descobrir", "Medicamento – não sei classificar"]]))
    + sec("Dieta especial e insumos", p("Fórmulas nutricionais, fraldas e materiais seguem a mesma lógica dos medicamentos: prescrição, laudo, negativa e orçamentos."))
    + dica("Use o princípio ativo e a dose na narrativa (ex.: “DAPAGLIFLOZINA 10 mg, 1 comprimido ao dia, uso contínuo”)."),
    ["STF, Temas 6, 500 e 1.234", "RENAME – Ministério da Saúde", "ANVISA – consulta de medicamentos"], ["stf-6-1234", "stf-500"])

pag("procedimentos", "saude", "Cirurgias, consultas, exames e internações", "Regulação, urgência e o que perguntar no atendimento.",
    sec("Como funciona", p("O pedido de consulta especializada, exame, cirurgia ou internação é inserido na <b>regulação</b> pelo posto de saúde ou hospital. A demora excessiva, especialmente com risco à saúde, justifica a atuação da DPU."))
    + sec("O que perguntar", lista(["onde recebeu o encaminhamento e se o pedido está na regulação (comprovante, número);", "se há urgência indicada pelo médico;", "se a pessoa está internada aguardando transferência;", "nome do procedimento conforme o SIGTAP."]))
    + sec("Dano moral", p("A demora injustificada na assistência à saúde pode gerar dano moral (STJ, REsp 1.662.338/SP); o gasto particular feito por urgência pode ser ressarcido."))
    + atencao("Internação e transferência com risco de vida: avise o Defensor imediatamente; o pedido de tutela pode ser feito no mesmo dia."),
    ["Lei nº 8.080/1990", "STF, Tema 793", "STJ, REsp 1.662.338/SP"], ["stf-793", "stj-resp1662338"])

pag("oncologico", "saude", "Tratamento oncológico", "Prazos legais do câncer e o que perguntar.",
    sec("Prazos da lei", lista(["exames para confirmar suspeita de câncer: até <b>30 dias</b> (Lei 13.896/2019);", "início do primeiro tratamento: até <b>60 dias</b> após o diagnóstico no laudo patológico (Lei 12.732/2012)."]))
    + sec("Como funciona", p("O tratamento é feito nos hospitais habilitados em oncologia (CACON/UNACON), que fornecem os medicamentos da quimioterapia. Medicamentos orais de alto custo podem seguir regras próprias de incorporação."))
    + sec("O que perguntar", lista(["diagnóstico confirmado? (laudo patológico) e data;", "tratamento prescrito e onde está sendo acompanhado;", "tratamentos já realizados;", "pedido na regulação ou na farmácia do hospital."])),
    ["Lei nº 12.732/2012", "Lei nº 13.896/2019", "Portaria de Consolidação SAES/MS nº 1/2022 (oncologia)"], ["stf-6-1234"])

pag("tfd", "saude", "Tratamento Fora de Domicílio (TFD)", "Transporte, diárias e ajuda de custo quando o tratamento não existe na cidade.",
    sec("O que é", p("O SUS paga transporte, diárias e ajuda de custo para alimentação do paciente (e do acompanhante, se justificado no laudo) quando o tratamento <b>não é oferecido no município ou no Estado</b>, depois de esgotados os meios locais (Portaria SAS/MS 55/1999, consolidada na Portaria de Consolidação SAES/MS nº 1/2022)."))
    + sec("Requisitos", lista(["laudo médico do SUS justificando a necessidade;", "tratamento agendado em outra cidade, em regra a mais de 50 km;", "pedido na Secretaria Municipal (TFD dentro do RS) ou Estadual (fora do RS)."]))
    + sec("Como analisar", passos(["Pergunte quais despesas precisam de cobertura (passagem, diárias, alimentação).", "Confira se o tratamento já está agendado e onde.", "Junte o laudo do TFD e a resposta da Secretaria."])),
    ["Portaria SAS/MS nº 55/1999", "Portaria de Consolidação SAES/MS nº 1/2022"])

# ---------------- CRIMINAL ----------------
pag("criminal", "criminal", "Defesa criminal na Justiça Federal e ANPP", "Crimes federais, acordos e o que perguntar no atendimento.",
    sec("Crimes mais comuns", lista(["moeda falsa (CP, art. 289);", "descaminho e contrabando (arts. 334 e 334-A);", "estelionato contra o INSS ou a Caixa (art. 171, § 3º);", "uso de documento falso perante órgão federal; crimes ambientais em área federal."]))
    + sec("Acordos e benefícios", lista(["<b>ANPP</b> (CPP, art. 28-A): antes da denúncia, com confissão, em crimes sem violência ou grave ameaça e pena mínima inferior a 4 anos. O STF admitiu o ANPP em processos já em andamento quando a lei entrou em vigor, desde que pedido antes do trânsito em julgado (HC 185.913).", "<b>Transação penal</b> (Lei 9.099/1995, art. 76) nas infrações de menor potencial ofensivo.", "<b>Suspensão condicional do processo</b> (art. 89), pena mínima de até 1 ano.", "<b>Insignificância</b> no descaminho até R$ 20.000,00 de tributos (STJ, Tema 157), salvo reiteração."]))
    + sec("O que perguntar", lista(["se está preso e quem foi atendido;", "o que diz a intimação, número e chave do processo, audiência marcada;", "a versão dos fatos, documentos e testemunhas;", "se recebeu proposta de acordo e se tem condições de cumprir."]))
    + atencao("Prazos criminais são curtos. Em caso de audiência próxima ou pessoa presa, avise o Defensor no mesmo dia."),
    ["Código de Processo Penal, art. 28-A", "Lei nº 9.099/1995", "STF, HC 185.913", "STJ, Tema 157", FONTE_ME + " (Matérias de atribuição da DPU)"], ["stf-hc185913", "stj-157"])

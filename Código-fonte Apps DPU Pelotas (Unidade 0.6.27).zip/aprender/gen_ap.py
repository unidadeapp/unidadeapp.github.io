# Monta a aba APRENDER (e as telas de Jurisprudências e Modelos do DPS) num único HTML
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import json, base64, sys, os
sys.path.insert(0, RAIZ + "aprender")
import glossario, juris, conteudo_outros
from conteudo_prev import PAGINAS
AREAS = [
 {"id": "comecar", "t": "Primeiros passos", "d": "O que a DPU atende, o PAJ e a narrativa, competência e o caminho do pedido no INSS até a Justiça."},
 {"id": "prev", "t": "Previdenciário e assistencial", "d": "Benefícios do INSS e BPC/LOAS: o que é cada um e como analisar o caso."},
 {"id": "civel", "t": "Cível", "d": "Bolsa Família, Gás do Povo, seguro-desemprego, FGTS, contratos da Caixa, execução fiscal e outros."},
 {"id": "saude", "t": "Saúde", "d": "Medicamentos, cirurgias, exames, internações, oncologia e TFD pelo SUS."},
 {"id": "criminal", "t": "Criminal", "d": "Defesa em crimes federais e acordos (ANPP, transação, suspensão)."},
]
INDICE = [
 {"g": "A DPU e o estágio", "i": [["Introdução", 3], ["Atuação da DPU", 4], ["Matérias de atribuição da DPU", 5], ["Atividades do estagiário DPS", 6], ["Assessoria", 7], ["Ofícios e substituições", 8]]},
 {"g": "Rotina do PAJ", "i": [["Movimentações no SIS-DPU", 10], ["Análise de renda", 11], ["Análise da demanda", 12], ["Ofícios", 13], ["Cadastramento do processo no eproc", 14], ["Preparação de documentos iniciais", 15], ["Preparação de documentos", 16], ["Arquivamento do PAJ", 17]]},
 {"g": "Processo", "i": [["Processo administrativo", 18], ["Processo judicial", 19], ["Competência", 20], ["Trâmite processual", 21], ["Tutela provisória", 22], ["Produção de provas", 23], ["Peças processuais", 24], ["Petição inicial", 25], ["Ferramentas de cálculos e valor da causa", 33], ["Levantamento de valores (RPV, TED, alvará)", 34], ["Dicionário de expressões cíveis", 36]]},
 {"g": "Cível", "i": [["Auxílio-reconstrução", 42], ["Bolsa Família", 43], ["Contratos habitacionais", 44], ["Dano moral e material", 45], ["Empréstimo consignado", 46], ["Multas ou cobranças", 47], ["Reserva de vagas", 48]]},
 {"g": "Previdenciário", "i": [["Siglas previdenciárias", 49], ["Expressões previdenciárias", 50], ["Espécies de filiação", 51], ["Aposentadoria da pessoa com deficiência", 52], ["Aposentadoria híbrida", 54], ["Aposentadoria por tempo de contribuição", 55], ["Aposentadoria programada", 57], ["Auxílio-doença", 58], ["Auxílio-reclusão", 59], ["Benefício de prestação continuada", 61], ["Pensão por morte", 62], ["Salário-maternidade", 65], ["Seguro-defeso", 66]]},
]
mods = json.load(open(RAIZ + "modelos/modelos.json", encoding="utf-8"))
# DPS › Modelos: palavras que levam a cada modelo (sugestão pelo resumo do PAJ) e tipo de qualificação
# ("completa": petição inicial, qualificação inteira; "autos": já qualificado(a) nos autos, só o nome)
CHAVES = {
 "Petição Inicial - Auxílio por incapacidade (AD) - Não constatação de incapacidade.docx": ("completa", "auxilio doenca; auxilio por incapacidade; beneficio por incapacidade; incapacidade; incapaz; pericia do inss; pericia medica; nao constatacao; doenca; afastamento; aposentadoria por invalidez; indeferimento; indeferido; cessacao; cessado; restabelecimento; atestado"),
 "Petição Inicial - Auxílio por incapacidade (AD) - Falta de qualidade de segurado.docx": ("completa", "qualidade de segurado; periodo de graca; desemprego; desempregado; contribuicoes; contribuicao; carencia; auxilio doenca; incapacidade; seguro desemprego"),
 "Petição Inicial - Auxílio por incapacidade (AD) - Indeferimento por reclusão inexistente.docx": ("completa", "reclusao; recluso; preso; prisao; presidio; auxilio doenca; incapacidade"),
 "Impugnação ao Laudo Pericial - Todos os benefícios por incapacidade.docx": ("autos", "laudo; laudo pericial; pericia judicial; perito; impugnacao; impugnar; quesitos; incapacidade"),
 "Réplica - Todos os benefícios por incapacidade.docx": ("autos", "replica; contestacao; laudo; incapacidade; auxilio doenca; bpc"),
 "Petição Inicial - BPC-LOAS Deficiente - Concessão ou restabelecimento (não constatação).docx": ("completa", "bpc; loas; beneficio assistencial; deficiencia; deficiente; avaliacao social; renda per capita; prestacao continuada; autismo; crianca"),
 "Petição Inicial - Pensão por morte - Dependente não reconhecido.docx": ("completa", "pensao; pensao por morte; morte; obito; falecimento; faleceu; viuva; viuvo; dependente; companheira; companheiro; uniao estavel; filho"),
 "Petição Inicial - Obrigação de fazer - Demora no cumprimento de acórdão.docx": ("completa", "acordao; cumprimento; demora; crps; junta de recursos; recurso administrativo; obrigacao de fazer; implantar; implantacao"),
 "Petição Inicial - Bolsa Família - Habilitação regular sem concessão.docx": ("completa", "bolsa familia; cadunico; cadastro unico; habilitacao; habilitada; pbf; programa social"),
 "Réplica - Bolsa Família.docx": ("autos", "replica; contestacao; bolsa familia; uniao"),
 "Recurso Inominado - Bolsa Família - Habilitação regular sem concessão.docx": ("autos", "recurso; recurso inominado; sentenca; improcedente; bolsa familia; turma recursal"),
 "Petições simples diversas.docx": ("autos", "peticao simples; manifestacao; juntada; juntar; documentos; prazo; evento; emenda; intimacao"),
}
for m in mods:
    m["b64"] = base64.b64encode(open(RAIZ + "modelos/docx/" + m["arq"], "rb").read()).decode()
    m["qualif"], ch = CHAVES[m["arq"]]
    m["chaves"] = [c.strip() for c in ch.split(";")]
dados = {"areas": AREAS, "paginas": PAGINAS, "juris": juris.J, "areasJ": juris.AREAS_J, "glossario": glossario.dados(), "modelos": mods,
         "indiceManual": INDICE, "manual": base64.b64encode(open(RAIZ + "aprender/manual_estagiario.pdf", "rb").read()).decode()}
txt = json.dumps(dados, ensure_ascii=False).replace("</", "<\\/")
html = open(RAIZ + "aprender/aprender.html", encoding="utf-8").read().replace("__FFLATE__", open(RAIZ + "assistente/lib/fflate.min.js", encoding="utf-8").read()).replace("__DADOS__", txt)
open(RAIZ + "aprender/Aprender_app.html", "w", encoding="utf-8").write(html)
json.dump(glossario.dados(), open(RAIZ + "aprender/glossario.json", "w", encoding="utf-8"), ensure_ascii=False)
print(len(html) // 1024, "KB;", len(PAGINAS), "páginas;", len(juris.J), "jurisprudências;", len(glossario.G), "verbetes;", len(mods), "modelos")

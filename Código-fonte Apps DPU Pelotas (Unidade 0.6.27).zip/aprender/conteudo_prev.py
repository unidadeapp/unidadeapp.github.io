# Páginas da aba APRENDER – Primeiros passos e Previdenciário
from base import *

PAGINAS = []
def pag(id, area, t, d, corpo, fontes, juris=()):
    PAGINAS.append({"id": id, "area": area, "t": t, "d": d, "h": corpo, "f": fontes, "j": list(juris)})

# ---------------- PRIMEIROS PASSOS ----------------
pag("dpu", "comecar", "A DPU e o que ela atende", "Quem pode ser atendido, que assuntos são da DPU e o que vai para outros órgãos.",
    sec("O que é", p("A Defensoria Pública da União presta assistência jurídica <b>integral e gratuita</b> a quem não pode pagar advogado, perante a Justiça Federal, Eleitoral, Militar, do Trabalho e os Tribunais Superiores (CF, arts. 5º, LXXIV, e 134; LC 80/1994)."))
    + sec("Que assuntos são da DPU Pelotas", lista([
        "<b>Previdenciário e assistencial</b>: benefícios do INSS e BPC/LOAS.",
        "<b>Cível federal</b>: casos contra a União, a Caixa, o INSS e outros órgãos federais (Bolsa Família, FGTS, seguro-desemprego, contratos da Caixa, concursos e universidades federais, execuções fiscais).",
        "<b>Saúde</b>: medicamentos, cirurgias, exames e tratamentos pelo SUS.",
        "<b>Criminal federal</b>: defesa em crimes de competência federal (moeda falsa, contrabando, descaminho, estelionato contra o INSS…)."]))
    + sec("O que não é da DPU", lista([
        "Assuntos da <b>Justiça Estadual</b> (família, inventário, aluguel, consumo contra empresa privada, acidente do trabalho): encaminhar à Defensoria Pública do Estado (DPE) e às assistências judiciárias das universidades.",
        "<b>Matéria trabalhista</b>: em Pelotas, a atuação foi restringida (Despacho nº 367 – DPU/GABDPGF): encaminhar à Justiça do Trabalho e às assistências judiciárias.",
        "Processos de outras subseções onde não há DPU instalada (ex.: Santana do Livramento, Lajeado): a unidade informa ao juízo que não pode atuar."]))
    + sec("Quem pode ser atendido", p("Quem não tem condições de pagar advogado sem prejuízo do próprio sustento. Na análise de renda, considera-se a <b>renda bruta da família</b> que mora na mesma casa; acima do limite usado pela unidade (2 salários mínimos), o caso é avaliado com as <b>despesas extraordinárias</b> (remédios, tratamentos, aluguel, pessoa com deficiência na família)."))
    + dica("Na dúvida se o caso é da DPU, pergunte ao Defensor antes de dispensar a pessoa. Um encaminhamento errado pode fazer a pessoa perder prazo."),
    [FONTE_ME + " (Atuação da DPU; Matérias de atribuição; Análise de renda)", "Constituição Federal, arts. 5º, LXXIV, 109 e 134", "Lei Complementar nº 80/1994", "PAJ Pelotas 2026/025-00952 (modelo de manifestação de não atuação em processo de outra subseção)"])

pag("paj", "comecar", "PAJ, SIS-DPU e narrativa", "Para que serve o PAJ, o que a narrativa precisa ter e o caminho do atendimento até a ação.",
    sec("O que é o PAJ", p("O <b>Processo de Assistência Jurídica</b> é o processo interno da DPU, aberto no SIS-DPU para cada atendimento. Nele ficam a narrativa, os documentos, os ofícios, a petição e o arquivamento."))
    + sec("A narrativa", p("É o resumo padronizado do caso, feito no atendimento. Ela precisa responder às perguntas do modelo da demanda (pretensão, CID, indeferimento, NB, renda, prioridade, representação, pesquisa no eproc e no IR). O Defensor e o estagiário da DPS vão trabalhar a partir dela, então <b>o que não estiver na narrativa provavelmente não chegará à peça</b>.")
        + p("Quando a narrativa fica incompleta, marque “NÃO” na última pergunta: a pendência “edição da narrativa/gerar redução a termo” entra na lista de documentos do PAJ."))
    + sec("O caminho do caso", passos([
        "Atendimento (DAC): abertura do PAJ, narrativa, formulários, assinaturas e documentos.",
        "Documentação pendente: o(a) assistido(a) envia o que falta (Meus PAJs ajuda a acompanhar).",
        "Análise da demanda (DPS): conferência dos requisitos, pesquisa do processo administrativo, CNIS, CadÚnico.",
        "Providência: ofício, pedido administrativo, petição inicial ou arquivamento (com ciência do assistido).",
        "Acompanhamento do processo judicial até o pagamento (RPV ou precatório)."]))
    + dica("Use os botões “O que é isso?” durante a abertura: eles explicam os termos de cada pergunta."),
    [FONTE_ME + " (Movimentações no SIS-DPU; Análise da demanda; Arquivamento do PAJ)", FONTE_MAP + ", cap. 11"])

pag("competencia", "comecar", "Onde o processo tramita (competência)", "JEF, Vara Federal ou Justiça Estadual: como saber para onde vai a ação.",
    sec("Regra geral", tabela(["Situação", "Onde tramita", "Quem atua"], [
        ["Benefício do INSS ou BPC até 60 salários mínimos (R$ 97.260,00 em 2026)", "Juizado Especial Federal (JEF)", "DPU"],
        ["Mesmo pedido acima de 60 salários mínimos", "Vara Federal, ou JEF com renúncia ao excedente (STJ, Tema 1.030)", "DPU"],
        ["Benefício acidentário (acidente do trabalho, doença ocupacional)", "Justiça Estadual (CF, art. 109, I; STJ, Súmula 15)", "DPE"],
        ["Verbas do empregador (salário, FGTS não depositado, estabilidade)", "Justiça do Trabalho", "Orientar o(a) assistido(a)"],
        ["Ação contra a União, a Caixa ou autarquia federal", "Justiça Federal", "DPU"]]))
    + sec("Valor da causa", p("Some as parcelas vencidas desde a data de início pedida (DIB) e 12 parcelas vincendas (CPC, art. 292, §§ 1º e 2º). BPC não tem 13º; benefício previdenciário tem. Se o benefício já tem data de fim (DCB) no passado, só entram as vencidas."))
    + atencao("Acidente do trabalho é o erro mais comum: o auxílio por incapacidade acidentário (B91) é da Justiça Estadual, mesmo sendo contra o INSS."),
    [FONTE_MAP + ", caps. 11 e 12", "Constituição Federal, art. 109", "Lei nº 10.259/2001, art. 3º", "CPC, art. 292", "STJ, Tema 1.030 e Súmula 15"], ["stj-1030"])

pag("administrativo", "comecar", "Do pedido no INSS ao processo judicial", "Requerimento, indeferimento, recurso administrativo e interesse de agir.",
    sec("Precisa pedir antes no INSS?", p("Em regra, <b>sim</b>: sem pedido administrativo não há interesse de agir (STF, Tema 350). Exceções: quando o INSS já tem posição notoriamente contrária, ou quando ele <b>demora</b> além dos prazos do acordo homologado no STF (Tema 1.066: 45 dias para incapacidade, 60 para pensão, 90 para BPC)."))
    + sec("Recurso administrativo ou ação?", p("Contra o indeferimento cabe recurso às Juntas de Recursos do CRPS, em 30 dias. A pessoa pode escolher ir direto à Justiça; mas, se houver recurso administrativo em andamento, ajuizar a ação significa <b>renunciar</b> a ele (Lei 8.213/91, art. 126, § 3º). Confira a situação do recurso antes de ajuizar."))
    + sec("Acórdão favorável não cumprido", p("Se a Junta deu razão ao(à) assistido(a) e o INSS não cumpriu em 30 dias (Portaria DIRBEN/INSS 996/2022, art. 15), a DPU envia ofício e, persistindo a mora, ajuíza ação de obrigação de fazer. Se o provimento foi só parcial, pede-se o cumprimento do acórdão, não a concessão direta."))
    + sec("Prescrição e decadência", lista([
        "<b>Prescrição</b>: só se recebem as parcelas dos 5 anos anteriores à ação (art. 103, parágrafo único; STJ, Súmula 85).",
        "<b>Decadência</b>: 10 anos para revisar o ato de concessão (art. 103). Não há decadência para discutir benefício negado ou cessado (STF, ADI 6.096)."])),
    [FONTE_MAP + ", caps. 5 e 12", FONTE_CL + ", caps. 44 e 45", "Lei nº 8.213/1991, arts. 103 e 126", "STF, RE 631.240 (Tema 350) e RE 1.171.152 (Tema 1.066)"], ["stf-350", "stf-1066", "stf-adi6096"])

# ---------------- PREVIDENCIÁRIO ----------------
pag("conceitos", "prev", "Conceitos básicos do INSS", "Qualidade de segurado, período de graça, carência, CNIS e as datas DER, DIB, DII e DCB.",
    sec("Segurado e dependente", p("<b>Segurado</b> é quem contribui (empregado, contribuinte individual, MEI, facultativo, segurado especial rural/pescador). <b>Dependente</b> é quem recebe pensão por morte ou auxílio-reclusão por causa do segurado (cônjuge, filhos, pais, irmãos – art. 16)."))
    + sec("Qualidade de segurado e período de graça", p("Quem para de contribuir continua protegido por um tempo (art. 15):")
        + lista(["12 meses após a última contribuição (regra geral);",
                 "+12 meses para quem tem <b>mais de 120 contribuições</b> sem perder a qualidade (§ 1º);",
                 "+12 meses para o <b>desempregado</b>, comprovável por qualquer meio (§ 2º; TNU, Súmula 27; STJ, Tema 1.360);",
                 "sem limite para quem está recebendo benefício."])
        + p("A perda ocorre no dia 16 do segundo mês seguinte ao fim do prazo (§ 4º). Em <b>11/11/2026</b>, o STJ decidiu (Tema 1.352) que o acréscimo das 120 contribuições, uma vez conquistado, pode ser usado de novo em filiações posteriores, sem novo ciclo de 120 (no mesmo sentido do Tema 255 da TNU)."))
    + sec("Carência", p("Número mínimo de contribuições: 12 para incapacidade; 180 para aposentadorias programadas; 24 para auxílio-reclusão; nenhuma para pensão por morte. Quem perdeu a qualidade e voltou a contribuir precisa de metade da carência: 6 contribuições para o benefício por incapacidade e 12 para o auxílio-reclusão (art. 27-A)."))
    + sec("As datas", lista(["<b>DER</b>: data do requerimento;", "<b>DIB</b>: início do benefício;", "<b>DII</b>: início da incapacidade;", "<b>DCB</b>: cessação do benefício."])
        + p("Cada requisito é medido numa data: incapacidade → DII; pensão → óbito; reclusão → prisão; maternidade → parto."))
    + sec("CNIS", p("Extrato do INSS com vínculos e contribuições. Vínculo da CTPS ausente do CNIS vale até prova em contrário (TNU, Súmula 75), e o recolhimento é obrigação do empregador (Lei 8.212/91, art. 30, I)."))
    + atualizado("O livro de 2018 ainda descreve as regras anteriores à Lei 13.846/2019 (carência após perda da qualidade) e não traz os Temas 1.352 e 1.360 do STJ. Nesta página, as regras foram conferidas com a legislação de 2026."),
    [FONTE_CL + ", caps. 13 a 16 e 32", FONTE_MAP + ", caps. 2 a 4", FONTE_ME + " (Siglas e expressões previdenciárias)", "Lei nº 8.213/1991, arts. 15, 24 a 27-A", "STJ, Temas 1.352 e 1.360"], ["stj-1352", "tnu-255", "tnu-s27", "tnu-s75", "stj-resp1245217"])

pag("auxilio-doenca", "prev", "Auxílio por incapacidade temporária (auxílio-doença)", "Requisitos, DII, carência, prorrogação e como analisar um indeferimento.",
    sec("O que é", p("Benefício do segurado que fica <b>incapaz para o seu trabalho por mais de 15 dias</b> (art. 59). Desde a EC 103/2019, chama-se auxílio por incapacidade temporária (código B31; B91 se acidentário)."))
    + sec("Requisitos", lista(["incapacidade temporária para a atividade habitual (perícia);", "qualidade de segurado na DII;", "carência de 12 contribuições na DII, dispensada em acidente de qualquer natureza, doença profissional e doenças da Portaria Interministerial MTP/MS nº 22/2022 (art. 26, II);", "doença anterior à filiação não dá direito, salvo agravamento (art. 59, § 1º)."]))
    + sec("Como analisar o caso", passos([
        "Ache a <b>DII</b> no laudo da perícia do INSS e nos atestados.",
        "Confira no CNIS a <b>qualidade de segurado</b> e a <b>carência</b> na DII (não na DER).",
        "Leia o motivo do indeferimento: “não constatação de incapacidade”, “falta de qualidade”, “DII anterior à filiação”…",
        "Se o benefício foi <b>cessado</b>, veja se houve pedido de prorrogação nos 15 dias antes da DCB: sem ele, falta interesse de agir (TNU, Tema 277).",
        "Peça a aposentadoria por incapacidade permanente como pedido subsidiário quando o médico falar em incapacidade definitiva.",
        "Se o caso for acidente do trabalho, é da Justiça Estadual (DPE)."]))
    + sec("Valor e datas", p("91% do salário de benefício, limitado à média dos 12 últimos salários de contribuição (art. 29, § 10), nunca abaixo do salário mínimo. Empregado: a empresa paga os 15 primeiros dias; o INSS paga do 16º. Pedido feito depois de 30 dias de afastamento: DIB na DER. Sem DCB fixada, o benefício cessa em 120 dias (art. 60, § 9º)."))
    + sec("Teses úteis", lista(["incapacidade parcial + condições pessoais desfavoráveis (TNU, Súmula 47);", "doenças estigmatizantes, como HIV (TNU, Súmula 78);", "quem trabalhou por necessidade após o indeferimento recebe salário e benefício juntos (STJ, Tema 1.013);", "não perde a qualidade quem parou de contribuir por estar incapaz."]))
    + atualizado("Desde a Lei 15.265/2025, a concessão por análise documental (Atestmed) tem limite de 30 dias em lei, ampliado por portarias conjuntas de 2026: confira a vigência. O livro de 2018 ainda fala em “auxílio-doença” com cálculo anterior à EC 103/2019."),
    [FONTE_CL + ", cap. 38", FONTE_MAP + ", cap. 10", FONTE_ME + " (Auxílio-doença)", "Lei nº 8.213/1991, arts. 26, 59 a 63", "EC 103/2019", "Lei nº 15.265/2025"], ["tnu-s47", "tnu-s77", "tnu-s78", "tnu-277", "stj-1013", "stj-resp1245217"])

pag("aposentadoria-incapacidade", "prev", "Aposentadoria por incapacidade permanente e adicional de 25%", "Quando a incapacidade é definitiva e o acréscimo para quem precisa de ajuda permanente.",
    sec("O que é", p("Benefício do segurado <b>incapaz e insuscetível de reabilitação</b> para atividade que lhe garanta o sustento (art. 42). Antes da EC 103/2019, chamava-se aposentadoria por invalidez."))
    + sec("Requisitos", lista(["incapacidade total e permanente (perícia);", "qualidade de segurado e carência de 12 contribuições, como no auxílio por incapacidade;", "incapacidade parcial pode levar à aposentadoria conforme idade, escolaridade e profissão (TNU, Súmula 47)."]))
    + sec("Valor", p("60% da média de todos os salários de contribuição, mais 2% por ano acima de 20 anos de contribuição (homem) ou 15 (mulher). Se decorrer de acidente do trabalho ou doença profissional, 100% (EC 103/2019, art. 26)."))
    + sec("Adicional de 25%", p("Acréscimo para o aposentado por incapacidade permanente que precisa da <b>assistência permanente de outra pessoa</b> (art. 45). Na abertura, a narrativa pergunta o grau de dependência em seis atividades (banhar-se, vestir-se, usar o banheiro, controlar micção e evacuação, transferir-se e alimentar-se). O STF decidiu que o adicional <b>não se estende</b> às outras aposentadorias (Tema 1.095)."))
    + sec("Como analisar", passos(["Confira se o laudo do médico assistente fala em incapacidade definitiva.", "Veja o histórico de benefícios por incapacidade no CNIS (cessações, perícias).", "Avalie as condições pessoais (idade, estudo, profissão) para pedir a aposentadoria mesmo com incapacidade parcial.", "No adicional, peça ao médico o <b>Laudo médico – adicional de 25%</b> (Central de Formulários), que pergunta sobre a ajuda permanente, as atividades do dia a dia e as situações do Anexo I do Decreto 3.048/1999."])),
    [FONTE_CL + ", cap. 38", FONTE_MAP + ", cap. 10", "Lei nº 8.213/1991, arts. 42 a 47", "EC 103/2019, art. 26", "STF, Tema 1.095"], ["tnu-s47", "tnu-s78"])

pag("bpc-deficiencia", "prev", "BPC/LOAS – pessoa com deficiência", "O benefício assistencial de 1 salário mínimo: deficiência, renda, grupo familiar e como analisar.",
    sec("O que é", p("Benefício de <b>1 salário mínimo</b> (R$ 1.621,00 em 2026) para a pessoa com deficiência que não tem meios de prover o próprio sustento nem de tê-lo provido pela família (CF, art. 203, V; LOAS, art. 20). É assistencial: não exige contribuição, não tem 13º e não gera pensão."))
    + sec("Requisitos", lista([
        "<b>Deficiência</b>: impedimento de longo prazo (mínimo de 2 anos) físico, mental, intelectual ou sensorial que, com as barreiras, obstrua a participação na sociedade (art. 20, §§ 2º e 10). Não se confunde com incapacidade para o trabalho (TNU, Súmula 48 e Tema 385).",
        "<b>Renda</b> familiar por pessoa inferior a 1/4 do salário mínimo (R$ 405,25 em 2026) – critério que não é absoluto (STF, Temas 27 e 312; STJ, Tema 185).",
        "<b>CadÚnico</b> atualizado (§ 12) e CPF regular de todos do grupo; cadastro biométrico (Lei 15.077/2024)."]))
    + sec("Grupo familiar e renda", p("Entram no cálculo: o requerente, cônjuge ou companheiro, pais (e, na falta de um deles, madrasta ou padrasto), irmãos solteiros, filhos e enteados solteiros e menores tutelados, <b>desde que morem na mesma casa</b> (art. 20, § 1º). Não entram outros parentes (avós, tios, cunhados).")
        + lista(["Exclua o BPC ou benefício previdenciário de até 1 salário mínimo de outro idoso ou pessoa com deficiência da casa (§ 14; STF, Tema 312; STJ, Tema 640).",
                 "Bolsa Família: para pedidos a partir de 26/06/2025, o Decreto 12.534/2025 manda somá-lo; há decisões afastando essa regra por falta de previsão na lei. Calcule com e sem.",
                 "Entre 1/4 e 1/2 salário mínimo, a miserabilidade pode ser provada por outros meios (despesas com remédios, fraldas, terapias, moradia precária)."]))
    + sec("Como analisar o caso", passos([
        "Leia o motivo do indeferimento: deficiência (perícia/avaliação social) ou renda?",
        "Se for deficiência: confira se houve avaliação social; contradição entre perícia médica e avaliação social é tese forte.",
        "Monte o grupo familiar conforme a lei e calcule a renda por pessoa, com e sem as exclusões.",
        "Compare o grupo do CadÚnico com o relato do atendimento; divergências vão para o Defensor.",
        "Se o BPC foi cessado em revisão, a revisão não pode exigir mais do que a concessão (STJ, REsp 1.962.868/SP)."]))
    + sec("Pedidos específicos", lista(["perícia com especialista (psiquiatria, neurologia, oftalmologia…) e avaliação social;", "intervenção do MPF quando há incapaz;", "DIB na DER ou no dia seguinte à cessação."]))
    + atualizado("Depois do livro de 2018 vieram a Lei 13.981/2020 (suspensa – ADPF 662), a Lei 14.176/2021 (art. 20, § 11-A), a Lei 15.077/2024 e o Decreto 12.534/2025. A visão monocular passou a ser deficiência (Lei 14.126/2021; STF, ADI 6.850), exigindo avaliação biopsicossocial (TNU, Tema 378)."),
    [FONTE_CL + ", cap. 40", FONTE_MAP + ", caps. 6 e 8", FONTE_ME + " (Benefício de prestação continuada)", "Lei nº 8.742/1993, arts. 20, 20-B e 21", "Decreto nº 6.214/2007 (redação do Decreto nº 12.534/2025)", "Lei nº 15.077/2024"],
    ["stf-27", "stf-312", "stj-185", "stj-640", "trf4-irdr12", "tnu-122", "tnu-s29", "tnu-s48", "tnu-s80", "tnu-385", "tnu-378", "stj-resp1962868", "stj-agresp1267161"])

pag("bpc-idoso", "prev", "BPC/LOAS – pessoa idosa", "Benefício de 1 salário mínimo para quem tem 65 anos ou mais e baixa renda.",
    sec("O que é", p("Benefício assistencial de 1 salário mínimo para a pessoa com <b>65 anos ou mais</b> que não tem como se manter nem ser mantida pela família (LOAS, art. 20; Estatuto da Pessoa Idosa, art. 34)."))
    + sec("Requisitos", lista(["idade de 65 anos ou mais;", "renda familiar por pessoa inferior a 1/4 do salário mínimo, com as mesmas flexibilizações do BPC da pessoa com deficiência;", "CadÚnico atualizado e cadastro biométrico."]))
    + sec("Como analisar", passos(["Confira a idade na DER.", "Monte o grupo familiar e exclua o benefício de até 1 salário mínimo do cônjuge idoso ou com deficiência (art. 20, § 14).", "Se a pessoa tem direito a uma aposentadoria (ex.: rural), veja qual é mais vantajosa: a aposentadoria tem 13º e gera pensão (STJ, Tema 1.018 – direito de opção)."]))
    + dica("Muitos idosos do campo têm direito à aposentadoria por idade rural, que é melhor que o BPC. Pergunte sobre trabalho rural."),
    [FONTE_CL + ", cap. 40", FONTE_MAP + ", caps. 6 e 7", "Lei nº 8.742/1993, art. 20", "Lei nº 10.741/2003, art. 34"], ["stf-312", "stj-640", "stj-1018", "trf4-irdr12"])

pag("pensao-morte", "prev", "Pensão por morte", "Quem é dependente, duração, valor e como provar a união estável ou a dependência.",
    sec("O que é", p("Benefício pago aos <b>dependentes</b> do segurado que falece, aposentado ou não. Dispensa carência, mas exige a qualidade de segurado do falecido e a qualidade de dependente de quem pede, ambas na data do óbito. Aplica-se a lei vigente na data do óbito (STJ, Súmula 340)."))
    + sec("Dependentes (art. 16)", lista(["<b>Classe 1</b>: cônjuge, companheiro(a), filho menor de 21 anos ou inválido ou com deficiência (enteado e menor tutelado equiparados). Dependência presumida.", "<b>Classe 2</b>: pais, que provam a dependência econômica.", "<b>Classe 3</b>: irmão menor de 21 anos ou inválido ou com deficiência, que também prova a dependência."]) + p("A classe anterior exclui as seguintes."))
    + sec("União estável", p("Exige <b>início de prova material</b> dos 24 meses anteriores ao óbito (art. 16, § 5º, desde a MP 871/2019), somado a testemunhas. Para óbitos anteriores a 18/01/2019, a TNU dispensava prova material (Súmula 63)."))
    + sec("Duração e valor", p("Para o cônjuge, depende da idade no óbito e de haver 18 contribuições e 2 anos de união; sem isso, dura 4 meses (art. 77, § 2º, V). Valor: cota familiar de 50% da aposentadoria do falecido + 10% por dependente, até 100% (EC 103/2019, art. 23).")
        + tabela(["Idade do cônjuge no óbito", "Duração"], [["menos de 22", "3 anos"], ["22 a 27", "6 anos"], ["28 a 30", "10 anos"], ["31 a 41", "15 anos"], ["42 a 44", "20 anos"], ["45 ou mais", "vitalícia"]]))
    + sec("Como analisar", passos(["Confira a qualidade de segurado do falecido no óbito (aposentado mantém sempre).", "Se perdeu a qualidade, veja se já tinha direito a aposentadoria (STJ, Súmula 416) ou se parou de contribuir por estar incapaz.", "Identifique a hipótese de dependência e a prova central (certidão, prova da união, dependência econômica dos pais).", "Peça as 3 testemunhas quando faltar prova documental.", "DIB: no óbito se pedida em 180 dias (filhos menores de 16) ou 90 dias (demais); depois, na DER."]))
    + atualizado("O livro de 2018 não traz a MP 871/2019 (prova da união estável), a EC 103/2019 (valor por cotas) nem as ADIs 4.878 e 5.083 (menor sob guarda)."),
    [FONTE_CL + ", cap. 39", FONTE_MAP + ", cap. 9", FONTE_ME + " (Pensão por morte)", "Lei nº 8.213/1991, arts. 16, 74 a 79", "EC 103/2019, art. 23", "Portaria ME nº 424/2020"], ["stj-s340", "stj-s416", "stj-732", "stj-s336", "tnu-s63", "stj-s596"])

pag("aposentadoria-idade", "prev", "Aposentadoria por idade (urbana, rural e híbrida)", "Idade mínima, tempo de contribuição, trabalho rural e prova testemunhal.",
    sec("Urbana (após a EC 103/2019)", lista(["<b>Mulher</b>: 62 anos e 15 anos de contribuição.", "<b>Homem</b>: 65 anos e 20 anos de contribuição; quem já era filiado até 13/11/2019 precisa de 15 anos.", "Valor: 60% da média + 2% por ano acima de 20 anos (homem) ou 15 (mulher)."]))
    + sec("Rural (segurado especial)", lista(["<b>Mulher</b>: 55 anos; <b>homem</b>: 60 anos;", "15 anos de atividade rural em regime de economia familiar, mesmo sem contribuição;", "prova: início de prova material (notas de produtor, ITR, cadastro no sindicato, certidões) + testemunhas (art. 55, § 3º).", "Valor: 1 salário mínimo."]))
    + sec("Híbrida", p("Soma tempo rural e urbano, com a idade da regra urbana (art. 48, § 3º). O trabalho rural pode ser antigo e anterior a 1991 (STJ, Tema 1.007)."))
    + sec("Como analisar", passos(["Confira idade e tempo no CNIS.", "Pergunte sobre trabalho rural, inclusive na infância, com a família.", "Liste documentos rurais por período (um por ano ajuda muito).", "Peça 3 testemunhas que conheçam o trabalho rural."])),
    [FONTE_CL + ", cap. 37", FONTE_ME + " (Aposentadoria híbrida; Aposentadoria programada)", "Lei nº 8.213/1991, arts. 48 e 55", "EC 103/2019, arts. 18 e 19", "STJ, Tema 1.007"])

pag("aposentadoria-tempo", "prev", "Aposentadoria por tempo de contribuição (regras de transição)", "Quem ainda tem direito e as regras da EC 103/2019.",
    sec("O que mudou", p("A EC 103/2019 acabou com a aposentadoria por tempo de contribuição sem idade mínima para quem se filiou depois de 13/11/2019. Quem já contribuía até essa data pode usar as <b>regras de transição</b>. Quem completou os requisitos antigos até 13/11/2019 tem direito adquirido."))
    + sec("Regras de transição (2026)", tabela(["Regra", "Mulher", "Homem"], [
        ["Pontos (idade + tempo)", "93 pontos e 30 anos", "103 pontos e 35 anos"],
        ["Idade mínima progressiva", "59 anos e 6 meses e 30 anos", "64 anos e 6 meses e 35 anos"],
        ["Pedágio de 50%", "faltavam até 2 anos em 13/11/2019; 30 anos + pedágio", "faltavam até 2 anos; 35 anos + pedágio"],
        ["Pedágio de 100%", "57 anos, 30 anos + pedágio", "60 anos, 35 anos + pedágio"]]))
    + sec("Como analisar", passos(["Peça o CNIS completo e a CTPS.", "Procure períodos que faltam no CNIS, atividade especial (insalubre) e trabalho rural.", "Faça a contagem até 13/11/2019 e até hoje.", "Use uma ferramenta de cálculo para comparar as regras."]))
    + atualizado("O livro de 2018 descreve as regras anteriores à reforma (fórmula 85/95 e fator previdenciário). Os pontos e idades da tabela sobem a cada ano; confira o ano da DER."),
    [FONTE_CL + ", cap. 37", FONTE_ME + " (Aposentadoria por tempo de contribuição)", "EC 103/2019, arts. 15 a 20"])

pag("salario-maternidade", "prev", "Salário-maternidade", "Quem tem direito, duração e a situação da desempregada e da segurada especial.",
    sec("O que é", p("Benefício pago à segurada (ou segurado) no parto, adoção ou guarda para adoção, e no aborto não criminoso, por <b>120 dias</b> (14 dias no aborto)."))
    + sec("Requisitos", lista(["qualidade de segurada na data do parto: a desempregada em período de graça recebe direto do INSS;", "a exigência de 10 contribuições de carência para contribuintes individuais e facultativas foi afastada pelo STF (ADI 2.110, 2024);", "segurada especial: prova da atividade rural ou pesqueira antes do parto."]))
    + sec("Como analisar", passos(["Confira a data do parto e o CNIS (último vínculo, período de graça).", "Se foi indeferido por “falta de carência”, a tese da ADI 2.110 é forte.", "Para a rural, junte documentos em nome da família e testemunhas.", "O pedido pode ser feito até 5 anos depois do parto (prescrição)."])),
    [FONTE_CL + ", cap. 39", FONTE_ME + " (Salário-maternidade)", "Lei nº 8.213/1991, arts. 71 a 73", "STF, ADI 2.110"])

pag("auxilio-reclusao", "prev", "Auxílio-reclusão", "Benefício dos dependentes do segurado de baixa renda preso em regime fechado.",
    sec("O que é", p("Benefício pago aos <b>dependentes</b> (nunca ao preso) do segurado de <b>baixa renda</b> recolhido em <b>regime fechado</b> (art. 80). O valor é de 1 salário mínimo (R$ 1.621,00 em 2026)."))
    + sec("Requisitos", lista(["regime fechado (desde a Lei 13.846/2019, semiaberto não dá direito);", "qualidade de segurado na data da prisão;", "carência de 24 contribuições;", "baixa renda: média dos 12 salários de contribuição anteriores à prisão de até <b>R$ 1.980,38</b> (2026 – Portaria Interministerial MPS/MF nº 13/2026);", "qualidade de dependente (mesmas classes da pensão)."]))
    + sec("Como analisar", passos(["Peça o atestado de recolhimento prisional (SUSEPE) com o regime.", "Confira no CNIS as 24 contribuições e a média dos 12 meses antes da prisão.", "Segurado desempregado na prisão: a renda considerada é zero, se mantida a qualidade.", "Renove o atestado a cada 3 meses para manter o benefício."]))
    + atualizado("O livro de 2018 é anterior à Lei 13.846/2019 (carência de 24 meses, só regime fechado, média de 12 meses) e à EC 103/2019 (valor de 1 salário mínimo)."),
    [FONTE_CL + ", cap. 39", FONTE_ME + " (Auxílio-reclusão)", "Lei nº 8.213/1991, arts. 25, IV, e 80", "EC 103/2019, art. 27", "Portaria Interministerial MPS/MF nº 13/2026"])

pag("seguro-defeso", "prev", "Seguro-defeso (pescador artesanal)", "Seguro-desemprego do pescador durante a proibição da pesca.",
    sec("O que é", p("Benefício de 1 salário mínimo por mês de defeso, pago ao <b>pescador artesanal</b> que fica impedido de pescar durante a reprodução das espécies (Lei 10.779/2003). O pedido é feito ao INSS."))
    + sec("Requisitos", lista(["registro como pescador profissional artesanal no RGP há pelo menos 1 ano;", "pesca como atividade habitual e principal meio de vida, sem outra fonte de renda;", "inscrição no CadÚnico, registro biométrico e REAP (relatório anual da atividade pesqueira) em dia (Lei 15.399/2026);", "não receber outro benefício incompatível."]))
    + sec("Como analisar", passos(["Leia o motivo do indeferimento (RGP, REAP, renda, biometria, CadÚnico).", "Confira o período do defeso da espécie e da região.", "Junte notas de venda do pescado e a carteira de pescador."]))
    + atualizado("A Lei 15.399/2026 (originada da MP 1.323/2025) trouxe biometria, CadÚnico e comprovação da atividade entre os defesos. Esta página foi conferida em 2026."),
    [FONTE_ME + " (Seguro-defeso)", "Lei nº 10.779/2003", "Lei nº 15.399/2026"])

pag("revisao", "prev", "Revisão de benefícios", "Prazos de decadência e prescrição e as revisões que já não são viáveis.",
    sec("Prazos", lista(["<b>Decadência</b>: 10 anos para revisar o ato de concessão (art. 103).", "<b>Prescrição</b>: atrasados só dos últimos 5 anos.", "Benefício negado ou cessado: não há decadência (STF, ADI 6.096)."]))
    + sec("Revisões comuns", lista(["inclusão de períodos que faltaram no CNIS (vínculos da CTPS, atividade especial, rural);", "erro no cálculo da renda mensal inicial;", "pensão por morte calculada sobre aposentadoria errada."]))
    + sec("O que não é mais viável", lista(["<b>Revisão da vida toda</b>: o STF validou a regra de transição da Lei 9.876/1999 (ADIs 2.110 e 2.111, em 2024), o que inviabiliza a tese.", "<b>Correção do FGTS pela inflação</b> (não é revisão de benefício, mas aparece muito): ver a página do FGTS."]))
    + sec("Como analisar", passos(["Ache a data do primeiro pagamento (carta de concessão) para contar os 10 anos.", "Peça a memória de cálculo e o CNIS.", "Identifique o erro concreto antes de abrir o PAJ."])),
    [FONTE_CL + ", caps. 34 e 44", "Lei nº 8.213/1991, art. 103", "STF, ADIs 2.110, 2.111 e 6.096"], ["stf-adi6096", "stj-s85"])

pag("descontos", "prev", "Descontos indevidos no benefício", "Empréstimos consignados e descontos de associações: o que fazer.",
    sec("Tipos de desconto", lista(["<b>Empréstimo consignado</b> e cartão consignado: margem total de 45% (Lei 10.820/2003, art. 6º).", "<b>Mensalidade associativa</b> de associação ou sindicato, que exige autorização expressa do beneficiário.", "Descontos do próprio INSS (devolução de valores pagos a mais)."]))
    + sec("Descontos associativos (2025-2026)", p("Após as fraudes descobertas em 2025, o INSS abriu a contestação pelo Meu INSS, Central 135 e Correios e um acordo de ressarcimento corrigido. O prazo para novas contestações terminou em <b>20/06/2026</b>; quem contestou no prazo e não teve resposta ainda pode aderir ao acordo. Para os demais, cabe ação judicial."))
    + sec("Como analisar", passos(["Peça o extrato de empréstimos e o HISCRE (histórico de créditos) no Meu INSS.", "Identifique quem faz cada desconto e se há contrato assinado.", "Veja se a pessoa já contestou e qual a resposta.", "Ação só contra banco privado é da Justiça Estadual; com o INSS ou a Caixa no polo, Justiça Federal."]))
    + sec("Devolução ao INSS", p("Se o INSS cobra de volta valores pagos por erro dele, a devolução depende da boa-fé objetiva do beneficiário (STJ, Tema 979, com modulação).")),
    [FONTE_ME + " (Empréstimo consignado)", "Lei nº 10.820/2003", "Lei nº 8.213/1991, art. 115", "INSS – acordo de ressarcimento de descontos associativos (gov.br/inss)"], ["stj-979"])

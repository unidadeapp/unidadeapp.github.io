# Glossário: textos curtos usados no botão "O que é isso?" do Assistente e na página Glossário da aba APRENDER.
# h = explicação (HTML simples); f = fontes.
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
ME = "Manual do Estagiário – DPU Pelotas (2024)"
MAP = "Manual de Análise Previdenciária – DPU Pelotas (2026)"
CL = "CASTRO, C. A. P.; LAZZARI, J. B. Manual de Direito Previdenciário, 21. ed., Forense, 2018"
L8213 = "Lei nº 8.213/1991"
L8742 = "Lei nº 8.742/1993 (LOAS)"

G = {
"nb": ("NB – Número do Benefício",
 "<p>É o número que o INSS dá a cada pedido de benefício. Tem 10 dígitos, no formato <b>000.000.000-0</b>. Cada pedido gera um NB próprio: se a pessoa pediu o mesmo benefício duas vezes, existem dois NBs.</p>"
 "<p><b>Onde achar:</b> na carta de concessão ou de indeferimento, no extrato de pagamento (HISCRE), no Meu INSS (“Consultar pedidos”) e no processo administrativo.</p>"
 "<div class='ex'>Na narrativa, informe o NB do benefício que é objeto do PAJ (o que foi negado, cessado ou que se quer revisar). Se a pessoa nunca pediu, deixe em branco: muitas vezes é preciso pedir primeiro no INSS.</div>",
 f"{ME} (siglas previdenciárias); {MAP}, cap. 1."),
"indef": ("Indeferimento do INSS",
 "<p>É a decisão do INSS que <b>nega</b> o pedido de benefício. A carta de indeferimento informa o motivo (ex.: “não constatação de incapacidade”, “renda superior a 1/4 do salário mínimo”, “falta de qualidade de segurado”).</p>"
 "<p>O motivo é o ponto de partida da análise: a ação judicial vai atacar exatamente esse motivo. Por isso, copie o motivo como está na carta.</p>"
 "<div class='ex'>Sem pedido no INSS, em regra não há interesse de agir para ir à Justiça (STF, Tema 350). A exceção é quando o INSS demora além do prazo ou já tem posição notoriamente contrária.</div>",
 f"{MAP}, caps. 1 e 5; STF, RE 631.240 (Tema 350)."),
"cid": ("CID – Classificação Internacional de Doenças",
 "<p>É o código que identifica a doença no atestado ou laudo médico (ex.: <b>F32</b> – episódio depressivo; <b>M54.5</b> – dor lombar). Existe a CID-10, ainda a mais usada nos atestados, e a CID-11, versão nova da OMS.</p>"
 "<p>Informe todos os CIDs que aparecem nos documentos médicos. Eles mostram ao Defensor qual especialidade médica deve fazer a perícia e se a doença dispensa carência ou dá prioridade de tramitação.</p>",
 "OMS (CID-10 e CID-11); DATASUS; Portaria Interministerial MTP/MS nº 22/2022."),
"incapacidade": ("Incapacidade para o trabalho",
 "<p>É a impossibilidade de exercer a <b>atividade habitual</b> por causa de doença ou acidente. Pode ser <b>temporária</b> (gera o auxílio por incapacidade temporária, antigo auxílio-doença) ou <b>permanente</b> (gera a aposentadoria por incapacidade permanente, antiga aposentadoria por invalidez).</p>"
 "<p>Quem decide é a perícia médica (do INSS ou do juízo). O atestado do médico da pessoa é muito importante, principalmente se disser a data de início da incapacidade (DII) e se ela é total ou parcial, temporária ou permanente.</p>"
 "<div class='ex'>Incapacidade parcial pode bastar quando as condições pessoais (idade, escolaridade, profissão) impedem a volta ao trabalho (TNU, Súmula 47).</div>",
 f"{L8213}, arts. 42 e 59; EC 103/2019; {MAP}, cap. 10; {CL}, cap. 38."),
"deficiencia": ("Pessoa com deficiência (para o BPC)",
 "<p>Para o BPC, é a pessoa com <b>impedimento de longo prazo</b> (2 anos ou mais) de natureza física, mental, intelectual ou sensorial que, junto com barreiras sociais, dificulta sua participação plena na sociedade (art. 20, §§ 2º e 10, da LOAS).</p>"
 "<p>Deficiência <b>não é o mesmo que incapacidade para o trabalho</b>: crianças e pessoas que conseguem fazer alguma atividade também podem ter direito. A avaliação é <b>biopsicossocial</b>: perícia médica e avaliação social juntas (TNU, Súmulas 48 e 80).</p>",
 f"{L8742}, art. 20; Lei nº 13.146/2015, art. 2º; TNU, Súmulas 29, 48 e 80; {MAP}, cap. 8."),
"cadunico": ("CadÚnico – Cadastro Único",
 "<p>É o cadastro do Governo Federal das famílias de baixa renda, feito no <b>CRAS</b> do município. Ele reúne quem mora na casa, a renda de cada um e as condições da moradia.</p>"
 "<p>É <b>obrigatório</b> para o BPC/LOAS e para o Bolsa Família, o Auxílio Gás do Povo, a Tarifa Social e o seguro-defeso. Precisa estar <b>atualizado</b> (em regra, nos últimos 24 meses) e conter as mesmas pessoas e rendas informadas ao INSS.</p>"
 "<div class='ex'>A pessoa consulta a situação no aplicativo Meu CadÚnico ou no CRAS. Divergência entre o CadÚnico e o que ela relata no atendimento deve ser anotada e levada ao Defensor.</div>",
 f"{L8742}, art. 20, § 12; Lei nº 14.601/2023; Decreto nº 11.016/2022; {MAP}, cap. 6."),
"renda": ("Renda bruta e grupo familiar",
 "<p><b>Renda bruta</b> é o valor total recebido no mês, antes de descontos (salário, aposentadoria, pensão, “bicos”, pensão alimentícia). <b>Grupo familiar</b> são as pessoas que moram na mesma casa e dividem as despesas.</p>"
 "<p>A renda serve para duas coisas: (1) ver se a pessoa pode ser atendida pela DPU (necessidade econômica); (2) nos benefícios assistenciais, calcular a <b>renda por pessoa</b> (renda total ÷ número de pessoas), que no BPC deve ficar, em regra, abaixo de 1/4 do salário mínimo.</p>"
 "<div class='ex'>No BPC, a lei define quem entra no grupo familiar (art. 20, § 1º, da LOAS) e manda excluir o benefício de até 1 salário mínimo recebido por outro idoso ou pessoa com deficiência da casa (§ 14).</div>",
 f"{ME}, “Análise de renda”; {L8742}, art. 20; {MAP}, cap. 6."),
"prioridade": ("Prioridade de tramitação",
 "<p>Alguns processos andam na frente dos demais (art. 1.048 do CPC): quando a parte tem <b>60 anos ou mais</b> (com prioridade especial a partir de 80), é portadora de <b>doença grave</b> (lista do art. 6º, XIV, da Lei 7.713/88, como câncer, cardiopatia grave e HIV) ou quando envolve <b>criança ou adolescente</b> (ECA).</p>"
 "<p>Marcar a prioridade na narrativa avisa o Defensor para pedir a tramitação prioritária na petição inicial.</p>",
 "CPC, art. 1.048; Lei nº 10.741/2003 (Estatuto da Pessoa Idosa), art. 71; Lei nº 7.713/1988, art. 6º, XIV; ECA, art. 152."),
"representacao": ("Representação do(a) assistido(a)",
 "<p>Acontece quando outra pessoa age em nome do(a) assistido(a). Exemplos: os pais pelo filho menor de 16 anos (representação) ou entre 16 e 18 anos (assistência); o curador de pessoa interditada; ou alguém com procuração, quando a pessoa não pode comparecer.</p>"
 "<p>Anote o motivo, o nome, o CPF e o parentesco do representante: os formulários e a procuração serão assinados por ele.</p>",
 "Código Civil, arts. 3º, 4º e 1.767; Lei nº 13.146/2015, art. 84; {ME}.".format(ME=ME)),
"eproc": ("eproc e pesquisa de processos",
 "<p>O <b>eproc</b> é o sistema eletrônico de processos da Justiça Federal da 4ª Região (JFRS) e também do TJRS. Pesquisar o CPF do(a) assistido(a) mostra se já existe processo com o mesmo pedido.</p>"
 "<p>Isso evita ajuizar duas vezes a mesma ação (litispendência ou coisa julgada) e mostra se a pessoa já tem advogado ou defensor no caso. Marque sempre “exibir baixados” para ver também os processos encerrados.</p>",
 f"{ME}, “Cadastramento do processo”; CPC, art. 337, §§ 1º a 4º; Lei nº 8.213/1991, art. 129-A."),
"chave": ("Chave do processo",
 "<p>É um código (senha) que permite consultar no eproc a íntegra de um processo em que a pessoa é parte, mesmo sem cadastro como advogado. A chave aparece na intimação/citação ou pode ser fornecida pela secretaria da vara.</p>"
 "<p>Com o número e a chave, o Defensor consegue ler o processo antes de assumir o caso.</p>",
 f"{ME}; Justiça Federal da 4ª Região – manual do eproc."),
"irpf": ("Pesquisa do Imposto de Renda (IRPF)",
 "<p>A consulta mostra se a pessoa declarou Imposto de Renda. Ela é usada para conferir a <b>necessidade econômica</b>: quem declara IR pode ter renda ou patrimônio acima do limite de atendimento da DPU.</p>"
 "<p>Se a pessoa declara, peça a cópia completa da última declaração para o Defensor avaliar.</p>",
 f"{ME}, “Análise de renda”; Lei Complementar nº 80/1994, art. 4º."),
"gratuidade": ("Atendimento gratuito da DPU",
 "<p>Todo o atendimento da Defensoria é <b>gratuito</b>: ninguém pode cobrar do(a) assistido(a) pela ação, nem antes nem depois. A pergunta “terá que pagar algo a alguém?” serve para descobrir se há intermediários cobrando pelo caso.</p>"
 "<p>Se houver, explique a gratuidade e registre na narrativa (em vermelho), para o Defensor tomar as providências.</p>",
 "Constituição Federal, art. 5º, LXXIV, e art. 134; Lei Complementar nº 80/1994, arts. 1º e 4º."),
"testemunhas": ("Testemunhas",
 "<p>São pessoas que conhecem os fatos e podem confirmá-los ao juiz. São importantes quando faltam documentos: união estável na pensão por morte, trabalho rural, desemprego.</p>"
 "<p>Anote nome completo, telefone e endereço. Em regra, parentes próximos não servem como testemunha (CPC, art. 447, § 2º), mas podem ser ouvidos como informantes.</p>",
 f"CPC, arts. 442 a 463; {L8213}, art. 16, § 5º, e art. 55, § 3º."),
"adicional25": ("Adicional de 25% (grande invalidez)",
 "<p>Acréscimo de 25% no valor da <b>aposentadoria por incapacidade permanente</b> quando o aposentado precisa da ajuda <b>permanente</b> de outra pessoa para as atividades do dia a dia (banho, vestir-se, alimentar-se, ir ao banheiro). Pode até ultrapassar o teto do INSS.</p>"
 "<p>Só vale para essa aposentadoria: o STF decidiu que não se estende às outras (Tema 1.095).</p>",
 f"{L8213}, art. 45; Decreto nº 3.048/1999, Anexo I; STF, Tema 1.095; {CL}, cap. 38."),
"reclusao": ("Atestado de reclusão (SUSEPE)",
 "<p>É o documento que prova que o segurado está preso e em qual regime. No RS é emitido pela <b>SUSEPE</b> (Superintendência dos Serviços Penitenciários) ou pela unidade prisional.</p>"
 "<p>O auxílio-reclusão só é devido com o preso em <b>regime fechado</b>, e o atestado deve ser renovado a cada 3 meses para manter o benefício.</p>",
 f"{L8213}, art. 80; Lei nº 13.846/2019; {ME}, “Auxílio-reclusão”."),
"qualidade": ("Qualidade de segurado",
 "<p>É a condição de quem está <b>protegido pelo INSS</b>: quem contribui ou está no <b>período de graça</b> (prazo em que continua protegido mesmo sem pagar). Em regra, o período de graça é de 12 meses depois da última contribuição, com mais 12 meses para quem tem mais de 120 contribuições e mais 12 para o desempregado.</p>"
 "<p>Ela é conferida no CNIS e na data certa: na data do início da incapacidade (DII), do óbito, da prisão ou do parto.</p>"
 "<div class='ex'>Em 11/11/2026, o STJ decidiu (Tema 1.352) que o acréscimo de 12 meses de quem já pagou mais de 120 contribuições pode ser usado mais de uma vez, sem novo ciclo de 120.</div>",
 f"{L8213}, art. 15; {MAP}, cap. 3; {CL}, cap. 15; STJ, Temas 1.352 e 1.360; TNU, Súmula 27 e Tema 255."),
"carencia": ("Carência",
 "<p>É o número mínimo de contribuições mensais para ter direito a certos benefícios: 12 no auxílio por incapacidade, 180 nas aposentadorias programadas e 24 no auxílio-reclusão. A pensão por morte não exige carência.</p>"
 "<p>Acidente de qualquer natureza e doenças graves da lista oficial dispensam a carência do benefício por incapacidade.</p>",
 f"{L8213}, arts. 24 a 27-A; Portaria Interministerial MTP/MS nº 22/2022; {CL}, cap. 32; {MAP}, cap. 4."),
"decadencia": ("Decadência (prazo de 10 anos para revisar)",
 "<p>É o prazo para pedir a <b>revisão do ato de concessão</b> de um benefício: <b>10 anos</b>, contados do mês seguinte ao primeiro pagamento (art. 103 da Lei 8.213/91). Passado esse prazo, o cálculo não pode mais ser revisto.</p>"
 "<p>Não confunda com a <b>prescrição</b>: mesmo dentro do prazo, só se recebem as diferenças dos últimos 5 anos antes da ação. E não há decadência para discutir benefício negado ou cessado (STF, ADI 6.096).</p>",
 f"{L8213}, art. 103; STF, ADI 6.096; STJ, Súmula 85; {CL}, cap. 44."),
"consignado": ("Empréstimo consignado",
 "<p>Empréstimo com as parcelas descontadas direto do benefício do INSS. A lei limita o total dos descontos (margem consignável) a <b>45%</b> do benefício: 35% para empréstimos e 10% para cartões de crédito consignado e de benefício.</p>"
 "<p>O extrato dos empréstimos sai no Meu INSS. Desconto sem contrato assinado pela pessoa é indevido. Contra bancos privados, a ação é na Justiça Estadual; a DPU atua quando a ação envolve o INSS ou a Caixa.</p>",
 f"Lei nº 10.820/2003, art. 6º (redação da Lei nº 14.431/2022); {ME}, “Empréstimo consignado”."),
"edital": ("Edital",
 "<p>É o documento oficial que traz as regras de um concurso ou processo seletivo: vagas, cotas, documentos, prazos e critérios de classificação. Seu número aparece no título (ex.: “Edital nº 12/2026”).</p>"
 "<p>Com o número, o Defensor localiza as regras que a instituição deveria ter seguido.</p>",
 f"{ME}, “Reserva de vagas”."),
"cotas": ("Cotas (reserva de vagas)",
 "<p>Parte das vagas é reservada a grupos específicos: estudantes de escola pública, de baixa renda, pretos, pardos, indígenas, quilombolas e pessoas com deficiência, nas instituições federais de ensino (Lei 12.711/2012); e candidatos negros, indígenas e quilombolas nos concursos federais.</p>"
 "<p>Os problemas mais comuns são documentação de renda recusada e a banca de heteroidentificação que não confirma a autodeclaração.</p>",
 f"Lei nº 12.711/2012 (com a Lei nº 14.723/2023); lei federal de cotas em concursos (confira a versão vigente); {ME}, “Reserva de vagas”."),
"execucao": ("Execução fiscal",
 "<p>É a ação que o poder público usa para cobrar uma dívida inscrita em <b>dívida ativa</b> (tributos, multas, anuidades de conselhos profissionais). Na Justiça Federal, quem cobra costuma ser a União (Fazenda Nacional), o INSS, o IBAMA ou um conselho profissional.</p>"
 "<p>Depois da citação, a pessoa pode pagar, parcelar ou se defender. Bens podem ser bloqueados, mas salário, aposentadoria e poupança até 40 salários mínimos são, em regra, impenhoráveis.</p>",
 "Lei nº 6.830/1980; CPC, art. 833; Lei nº 12.514/2011, art. 8º; STF, Tema 1.184."),
"citacao": ("Citação e intimação",
 "<p><b>Citação</b> é o ato que avisa a pessoa de que existe um processo contra ela e abre o prazo para se defender. <b>Intimação</b> é o aviso de qualquer outro ato do processo (audiência, decisão, prazo).</p>"
 "<p>A data em que a pessoa recebeu o documento é essencial: os prazos contam a partir dela. Peça sempre o documento recebido e anote a data.</p>",
 f"CPC, arts. 238 e 269; {ME}, “Dicionário de expressões cíveis”."),
"usucapiao": ("Posse e usucapião",
 "<p><b>Posse</b> é o uso do imóvel como se fosse dono, mesmo sem escritura. Com o tempo, a posse mansa e contínua pode gerar a <b>usucapião</b> (aquisição da propriedade): em área urbana de até 250 m² usada como moradia, bastam 5 anos (CF, art. 183).</p>"
 "<p>Comprovantes antigos (contas de luz e água, IPTU, correspondências) mostram há quanto tempo a pessoa ocupa o imóvel. Imóveis públicos não podem ser usucapidos.</p>",
 "Constituição Federal, arts. 183 e 191; Código Civil, arts. 1.196 e 1.238 a 1.244; CPC, arts. 554 a 568."),
"consolidacao": ("Notificação do cartório (consolidação da propriedade)",
 "<p>Nos financiamentos com <b>alienação fiduciária</b> (como os da Caixa), o imóvel fica em nome do banco até a quitação. Com parcelas atrasadas, o cartório notifica o devedor para pagar em <b>15 dias</b>.</p>"
 "<p>Sem pagamento, a propriedade é <b>consolidada</b> em nome do banco, que pode levar o imóvel a leilão. Por isso o caso é urgente.</p>",
 "Lei nº 9.514/1997, arts. 26 e 27; Lei nº 14.711/2023."),
"nacionalidade": ("Nacionalidade brasileira (opção de nacionalidade)",
 "<p>O filho de pai ou mãe brasileira nascido no exterior é brasileiro nato se for registrado no consulado, ou se vier morar no Brasil e <b>optar</b> pela nacionalidade brasileira depois dos 18 anos. A opção é feita por ação na <b>Justiça Federal</b>.</p>"
 "<p>Estrangeiros sem pai ou mãe brasileira podem pedir a <b>naturalização</b> ao Ministério da Justiça (Lei de Migração).</p>",
 "Constituição Federal, art. 12, I, “c”, e art. 109, X; Lei nº 13.445/2017; Lei nº 6.015/1973, art. 32."),
"fgts": ("FGTS e PIS",
 "<p>O <b>FGTS</b> é a conta aberta em nome do trabalhador com carteira assinada, com depósitos mensais do empregador. Só pode ser sacado nas hipóteses da lei: demissão sem justa causa, aposentadoria, doenças graves, compra da casa própria, saque-aniversário, entre outras.</p>"
 "<p>O <b>PIS</b> é o número do trabalhador; o abono salarial do PIS é pago a quem ganhou até o limite legal no ano-base. A Caixa administra os pagamentos.</p>",
 "Lei nº 8.036/1990, art. 20; Lei nº 7.998/1990, art. 9º; STF, ADI 5.090."),
"dpvat": ("Seguro DPVAT",
 "<p>Seguro obrigatório que indeniza vítimas de acidentes com veículos: morte, invalidez permanente e despesas médicas. Para acidentes ocorridos <b>até 14/11/2023</b>, o pedido é feito à <b>Caixa</b>.</p>"
 "<p>O prazo para cobrar a indenização na Justiça é de <b>3 anos</b> (STJ, Súmula 405). Guarde o registro de ocorrência e os laudos médicos.</p>",
 "Lei nº 6.194/1974; STJ, Súmulas 405 e 474."),
"padronizado": ("Medicamento padronizado, registro na ANVISA e RENAME",
 "<p><b>Registro na ANVISA</b> é a autorização para vender o medicamento no Brasil (consulta no site da ANVISA). <b>Padronizado no SUS</b> é o medicamento que o SUS fornece, listado na <b>RENAME</b> (Relação Nacional de Medicamentos Essenciais) ou nas listas do Estado e do Município.</p>"
 "<ul><li>Registrado e padronizado: o SUS deveria fornecer; o problema costuma ser falta ou negativa para o CID da pessoa.</li>"
 "<li>Registrado e não padronizado: o pedido judicial segue as regras do STF (Tema 6 e Súmula Vinculante 61).</li>"
 "<li>Sem registro: só em situações excepcionais (Tema 500 do STF).</li></ul>",
 "Lei nº 8.080/1990, arts. 19-M a 19-U; STF, Temas 6, 500 e 1.234 e Súmulas Vinculantes 60 e 61; RENAME (Ministério da Saúde)."),
"anvisa": ("Consulta de medicamentos na ANVISA",
 "<p>No site da ANVISA (Consultas → Medicamentos), pesquise pelo <b>princípio ativo</b> (a substância, ex.: “metformina”) ou pelo nome comercial. A consulta mostra se há registro válido e o “medicamento de referência”.</p>"
 "<p>Use o princípio ativo na narrativa, junto com a dose (ex.: METFORMINA 850 mg).</p>",
 "ANVISA – consultas.anvisa.gov.br; Lei nº 6.360/1976."),
"sigtap": ("SIGTAP – tabela de procedimentos do SUS",
 "<p>É a tabela oficial dos procedimentos que o SUS faz (consultas, exames, cirurgias), com código e valor. Pesquisar o nome do procedimento no SIGTAP ajuda a usar o nome correto na narrativa e a estimar o valor.</p>",
 "Ministério da Saúde – SIGTAP (sigtap.datasus.gov.br)."),
"regulacao": ("Regulação do SUS",
 "<p>É o sistema que organiza a fila de consultas, exames, cirurgias e internações do SUS: o posto de saúde ou o hospital insere o pedido e a central de regulação marca conforme a gravidade e a ordem de espera.</p>"
 "<p>Saber se o pedido foi inserido (e quando) é essencial: mostra que houve pedido administrativo e há quanto tempo a pessoa espera. Peça o comprovante ou o número da solicitação.</p>",
 "Lei nº 8.080/1990; Política Nacional de Regulação (Portaria de Consolidação GM/MS nº 2/2017)."),
"tfd": ("TFD – Tratamento Fora de Domicílio",
 "<p>Benefício do SUS que paga transporte, diárias e ajuda de custo para alimentação quando o tratamento <b>não existe no município</b> (ou no Estado) da pessoa, depois de esgotados os meios locais. Exige laudo médico; o acompanhante é coberto quando o laudo justifica.</p>"
 "<p>O pedido é feito na Secretaria Municipal de Saúde (TFD entre municípios) ou na Secretaria Estadual (TFD para outro Estado).</p>",
 "Portaria SAS/MS nº 55/1999, consolidada na Portaria de Consolidação SAES/MS nº 1/2022."),
"antecedentes": ("Antecedentes criminais",
 "<p>São registros de processos ou condenações anteriores. Influenciam a pena e o acesso a benefícios como o acordo de não persecução penal, a transação penal e a suspensão condicional do processo.</p>",
 "Código Penal, arts. 59 e 63; Código de Processo Penal, art. 28-A; Lei nº 9.099/1995, arts. 76 e 89."),
"anpp": ("ANPP – Acordo de Não Persecução Penal",
 "<p>Acordo oferecido pelo Ministério Público antes da denúncia: a pessoa <b>confessa</b> e cumpre condições (reparar o dano, prestar serviços, pagar prestação pecuniária) e, cumprido o acordo, não há processo nem condenação.</p>"
 "<p>Cabe em crimes sem violência ou grave ameaça com pena mínima inferior a 4 anos, se a pessoa não for reincidente e não tiver feito outro acordo nos últimos 5 anos.</p>",
 "Código de Processo Penal, art. 28-A (Lei nº 13.964/2019); STF, HC 185.913."),
"paj": ("PAJ – Processo de Assistência Jurídica",
 "<p>É o “processo interno” da DPU para cada atendimento, aberto no <b>SIS-DPU</b>. Reúne a narrativa, os documentos e as providências (ofícios, ações, arquivamento). O número tem o formato ANO/025-NÚMERO (025 é Pelotas).</p>",
 f"{ME}, “Movimentações no SIS-DPU”."),
"der": ("DER, DIB, DII e DCB",
 "<ul><li><b>DER</b> – data de entrada do requerimento no INSS.</li><li><b>DIB</b> – data de início do benefício (a partir de quando é pago).</li>"
 "<li><b>DII</b> – data de início da incapacidade (fixada pela perícia).</li><li><b>DCB</b> – data de cessação do benefício.</li></ul>"
 "<p>Cada requisito é medido numa data: nos benefícios por incapacidade, qualidade de segurado e carência são vistas na DII; o valor atrasado vai da DIB pedida até o pagamento.</p>",
 f"{ME}, “Dicionário de siglas previdenciárias”; {MAP}, cap. 1."),
"cnis": ("CNIS – Cadastro Nacional de Informações Sociais",
 "<p>É o “extrato de contribuições” do INSS: mostra vínculos de emprego, contribuições e benefícios recebidos. Sai no Meu INSS. É a principal prova da qualidade de segurado e da carência.</p>"
 "<p>Vínculo anotado na carteira de trabalho e ausente no CNIS também vale, salvo prova em contrário (TNU, Súmula 75).</p>",
 f"{L8213}, art. 29-A; {MAP}, cap. 2; TNU, Súmula 75."),
}

def dados():
    return {k: {"t": v[0], "h": v[1], "f": v[2]} for k, v in G.items()}

if __name__ == "__main__":
    import json
    json.dump(dados(), open(RAIZ + "aprender/glossario.json", "w", encoding="utf-8"), ensure_ascii=False, indent=0)
    print(len(G), "verbetes")

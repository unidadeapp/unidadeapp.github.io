/* SALVAR EM PDF (offline): cria o PDF da folha direto no app, sem a tela de impressão do navegador
   (que, em alguns navegadores, como o Opera GX, pode ficar cinza). A folha é "fotografada" como sairia
   na impressão, mas com as cores da tela, e vira uma página A4. Precisa do html2canvas na página.
   Uso: dpuPDF.salvar("Nome do arquivo") — dispara beforeprint/afterprint, como a impressão de verdade. */
(function () {
  function trocarMidia() {  // as regras de impressão passam a valer na tela; as de tela, não
    const feitas = [];
    for (const ss of document.styleSheets) {
      let rs; try { rs = ss.cssRules; } catch (e) { continue; }
      for (const r of rs) {
        if (!(r instanceof CSSMediaRule)) continue;
        const m = r.media.mediaText;
        if (/\bprint\b/.test(m) && !/screen/.test(m)) { feitas.push([r, m]); r.media.mediaText = "all"; }
        else if (/^\s*screen\s*$/.test(m)) { feitas.push([r, m]); r.media.mediaText = "not all"; }
      }
    }
    return () => feitas.forEach(([r, m]) => { r.media.mediaText = m; });
  }
  const quadro = () => new Promise(ok => requestAnimationFrame(() => requestAnimationFrame(ok)));
  const visivel = el => getComputedStyle(el).display !== "none" && !el.closest("[hidden]") && el.getClientRects().length > 0;
  async function imagem(img) {  // página de formulário (desenho): direto na resolução da folha
    if (!img.complete || !img.naturalWidth) await new Promise(ok => { img.onload = ok; img.onerror = ok; });
    const c = document.createElement("canvas"); c.width = 1654; c.height = 2339;
    const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height);
    const k = Math.min(c.width / img.naturalWidth, c.height / img.naturalHeight);
    x.drawImage(img, (c.width - img.naturalWidth * k) / 2, (c.height - img.naturalHeight * k) / 2, img.naturalWidth * k, img.naturalHeight * k);
    return c;
  }
  const jpg = c => new Promise((ok, erro) => c.toBlob(b => b ? b.arrayBuffer().then(a => ok(new Uint8Array(a)), erro) : erro(new Error("sem imagem")), "image/jpeg", 0.92));
  function montarPDF(pgs) {  // PDF simples: uma imagem JPEG por página A4
    const enc = new TextEncoder(), partes = [], offs = []; let pos = 0;
    const add = x => { const b = typeof x === "string" ? enc.encode(x) : x; partes.push(b); pos += b.length; };
    const obj = (i, corpo) => { offs[i] = pos; add(i + " 0 obj\n" + corpo + "\nendobj\n"); };
    add("%PDF-1.4\n"); add(new Uint8Array([37, 226, 227, 207, 211, 10]));
    const W = 595.28, H = 841.89, n = pgs.length;
    obj(1, "<< /Type /Catalog /Pages 2 0 R >>");
    obj(2, "<< /Type /Pages /Kids [" + pgs.map((_, j) => (3 + j * 3) + " 0 R").join(" ") + "] /Count " + n + " >>");
    pgs.forEach((p, j) => {
      const pi = 3 + j * 3, ci = pi + 1, ii = pi + 2;
      const k = Math.min(W / p.w, H / p.h), w = p.w * k, h = p.h * k;
      obj(pi, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + W + " " + H + "] /Resources << /XObject << /Im" + j + " " + ii + " 0 R >> >> /Contents " + ci + " 0 R >>");
      const cs = "q " + w.toFixed(2) + " 0 0 " + h.toFixed(2) + " " + ((W - w) / 2).toFixed(2) + " " + (H - h).toFixed(2) + " cm /Im" + j + " Do Q";
      obj(ci, "<< /Length " + cs.length + " >>\nstream\n" + cs + "\nendstream");
      offs[ii] = pos;
      add(ii + " 0 obj\n<< /Type /XObject /Subtype /Image /Width " + p.w + " /Height " + p.h + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + p.jpg.length + " >>\nstream\n");
      add(p.jpg); add("\nendstream\nendobj\n");
    });
    const total = 3 + n * 3, xref = pos;
    let t = "xref\n0 " + total + "\n0000000000 65535 f \n";
    for (let i = 1; i < total; i++) t += String(offs[i]).padStart(10, "0") + " 00000 n \n";
    add(t + "trailer\n<< /Size " + total + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
    const out = new Uint8Array(pos); let o = 0; partes.forEach(b => { out.set(b, o); o += b.length; }); return out;
  }
  function baixar(bytes, nome) {
    const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
    const a = document.createElement("a"); a.href = url; a.download = nome; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  let gerando = false;
  async function salvar(nome) {
    if (gerando) return; gerando = true;
    const aviso = document.createElement("div"); aviso.className = "pdfGerando"; aviso.textContent = "Gerando o PDF…";
    aviso.style.cssText = "position:fixed;right:20px;bottom:90px;z-index:100;background:#2f6a1f;color:#fff;border-radius:10px;padding:12px 18px;font:700 14px 'Segoe UI',Arial,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.2)";
    document.body.appendChild(aviso);
    const raiz = document.documentElement; let voltar = () => {};
    try {
      raiz.classList.add("pdfCor");  // o PDF fica com as cores da tela (o preto e branco é só para a impressora)
      window.dispatchEvent(new Event("beforeprint"));
      voltar = trocarMidia(); await quadro(); await quadro();
      const els = [...document.querySelectorAll(".sheet, .fpage")].filter(visivel);
      if (!els.length) throw new Error("nada para salvar");
      const pgs = [];
      for (const el of els) {
        let c;
        if (el.classList.contains("fpage")) c = await imagem(el.querySelector("img"));
        else {
          const antes = el.style.cssText;
          el.style.width = "210mm"; el.style.minHeight = "0"; el.style.height = "auto"; el.style.margin = "0";
          try { c = await html2canvas(el, { scale: 2, backgroundColor: "#ffffff", logging: false }); } finally { el.style.cssText = antes; }
        }
        pgs.push({ jpg: await jpg(c), w: c.width, h: c.height });
      }
      voltar(); voltar = () => {};
      baixar(montarPDF(pgs), String(nome || "Documento").replace(/[\\/:*?"<>|]/g, "-").slice(0, 120) + ".pdf");
      aviso.textContent = "PDF salvo: veja na pasta de downloads.";
      setTimeout(() => aviso.remove(), 3000);
    } catch (e) {
      console.error(e); voltar();
      aviso.style.background = "#a23b31"; aviso.textContent = "Não consegui gerar o PDF neste navegador. Use o botão IMPRIMIR e escolha “Salvar como PDF”.";
      setTimeout(() => aviso.remove(), 6000);
    }
    raiz.classList.remove("pdfCor"); gerando = false;
    window.dispatchEvent(new Event("afterprint"));
  }
  window.dpuPDF = { salvar };
})();

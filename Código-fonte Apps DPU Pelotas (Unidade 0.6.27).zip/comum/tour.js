/* Tour guiado pela Têmis (comum a todos os apps): escurece a tela, destaca uma parte e explica, passo a passo.
   Os tours de cada app vêm na constante TOURS (Unidade: trabalho/tours_atdpu.js; Térreo: comum/tours_terreo.py). A página define tourIr(rota) e, se quiser, tourLongo(rota).
   Cada passo: rota (tela do app), alvo (seletor nesta página, ou "lado" = menu da ferramenta, "folha" = área da
   ferramenta, "ferr:seletor" = uma parte de dentro da ferramenta aberta, "temis" = botão da Têmis, ou nada = balão no centro), titulo, texto e, se quiser, marca (detalhe que a ferramenta destaca)
   e faca + ate (tarefa que a pessoa faz de verdade; o tour segue quando o seletor "ate" aparece na ferramenta).
   A página pode definir tourDoc(rota) (documento da ferramenta) e tourSair() (para onde ir ao sair do tour).
   Durante o tour, as ferramentas ficam com o menu ao lado e à vista (o agendamento, com o menu em cima); ao sair, voltam como a pessoa deixou. */
(function () {
  const AV = __TOUR_AV__;
  const C = s => `#t-${s.split(" ")[0]} ${s.split(" ").slice(1).join(" ")}`;
  const TOURS = __TOURS__;
  const css = document.createElement("style");
  css.textContent = `#tourVeu{position:fixed;inset:0;z-index:200}
    #tourFoco{position:fixed;z-index:201;border-radius:14px;box-shadow:0 0 0 9999px rgba(20,30,15,.62);outline:3px solid #f2c94c;outline-offset:2px;transition:all .3s ease;pointer-events:none}
    #tourFoco.centro{left:50%;top:50%;width:0;height:0;outline:0}
    #tourBalao{position:fixed;z-index:202;width:380px;max-width:calc(100vw - 32px);background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.3);padding:16px 18px 14px;font-family:"Segoe UI",Calibri,Arial,sans-serif;transition:top .3s ease,left .3s ease}
    #tourBalao .cab{display:flex;gap:12px;align-items:center;margin-bottom:6px}
    #tourBalao .faca{margin-top:10px;background:#fff7e0;border:1.5px solid #e2b84a;border-radius:10px;padding:8px 10px;font-size:14px;color:#4a3a08}
    #tourBalao .faca.ok{background:#eaf6e4;border-color:#3f7f2a;color:#2f6a1f}
    #tourBalao .rolar{margin-top:8px;font-size:12.5px;color:#6b7266}
    body.tourFaca #tourVeu{pointer-events:none}
    #tourBalao .av{width:52px;height:52px;flex:0 0 auto}#tourBalao .av svg{width:100%;height:100%;display:block}
    #tourBalao .tt{font-weight:800;color:#2f6a1f;font-size:16.5px;line-height:1.25}
    #tourBalao .n{font-size:12px;color:#7a8276;font-weight:700;letter-spacing:.05em}
    #tourBalao .tx{font-size:14.5px;line-height:1.5;color:#2a3326}
    #tourBalao .bts{display:flex;gap:8px;align-items:center;margin-top:12px}
    #tourBalao .bts button{font:inherit;font-weight:700;font-size:14px;border-radius:9px;padding:8px 14px;cursor:pointer;border:1.5px solid #3f7f2a;background:#fff;color:#2f6a1f}
    #tourBalao .bts .prox{background:#3f7f2a;color:#fff;margin-left:auto}
    #tourBalao .bts .sair{border-color:transparent;color:#7a8276;padding:8px 6px}
    @media print{#tourVeu,#tourFoco,#tourBalao{display:none!important}}`;
  document.head.appendChild(css);
  let tour = null, i = 0, ativo = false;
  const el = id => document.getElementById(id);
  function montar() {
    if (el("tourVeu")) return;
    const v = document.createElement("div"); v.id = "tourVeu";
    const f = document.createElement("div"); f.id = "tourFoco";
    const b = document.createElement("div"); b.id = "tourBalao"; b.setAttribute("role", "dialog");
    b.innerHTML = `<div class="cab"><span class="av">${AV}</span><div><div class="n" id="tourN"></div><div class="tt" id="tourT"></div></div></div><div class="tx" id="tourX"></div>
      <div class="bts"><button type="button" class="sair" id="tourSair">Sair do tour</button><button type="button" id="tourAnt">← Anterior</button><button type="button" class="prox" id="tourProx">Próximo →</button></div>`;
    document.body.append(v, f, b);
    el("tourSair").addEventListener("click", sair);
    el("tourAnt").addEventListener("click", () => passo(i - 1));
    el("tourProx").addEventListener("click", () => i + 1 < tour.passos.length ? passo(i + 1) : sair());
    document.addEventListener("keydown", tecla);
    window.addEventListener("resize", reposicionar);
  }
  function tecla(e) { if (!ativo) return; if (e.key === "Escape") sair(); else if (e.key === "ArrowRight") el("tourProx").click(); else if (e.key === "ArrowLeft" && i > 0) passo(i - 1); }
  let vigia = 0;
  const avisarFerr = o => document.querySelectorAll("iframe").forEach(f => { try { f.contentWindow.postMessage(o, "*"); } catch (e) {} });
  function sair() {
    clearInterval(vigia); document.body.classList.remove("tourFaca");
    const estava = ativo;
    avisarFerr({ tourModo: false });
    ativo = false; marcar(null); ["tourVeu", "tourFoco", "tourBalao"].forEach(id => { const x = el(id); if (x) x.remove(); });
    document.removeEventListener("keydown", tecla); window.removeEventListener("resize", reposicionar);
    if (window.temisAtualizar) window.temisAtualizar();
    if (estava && window.tourSair) window.tourSair();   // ao sair (ou concluir), volta para a página dos tours
  }
  function docFerr() {  // a ferramenta aberta neste passo: o documento dela e o quadro (iframe) onde ela está
    let d = null; try { d = window.tourDoc && tour && window.tourDoc(tour.passos[i].rota); } catch (e) {}
    if (!d || d === document || !d.body) return null;
    const f = [...document.querySelectorAll("iframe")].find(x => { try { return x.contentDocument === d; } catch (e) { return false; } });
    return f && f.getClientRects().length ? { d, f: f.getBoundingClientRect() } : null;
  }
  const somar = (r, f) => { const left = Math.max(f.left, f.left + r.left), top = Math.max(f.top, f.top + r.top);
    const right = Math.min(f.right, f.left + r.right), bottom = Math.min(f.bottom, f.top + r.bottom);
    return right > left && bottom > top ? { left, top, width: right - left, height: bottom - top } : null; };
  function retangulo(alvo) {
    const W = innerWidth, H = innerHeight;
    if (!alvo) return null;
    if (alvo === "temis") { const t = [...document.querySelectorAll("#tmBt, #chatBt")].find(x => !x.hidden && x.getClientRects().length > 0); return t ? t.getBoundingClientRect() : null; }
    const F = docFerr();
    if (F && (alvo === "lado" || alvo === "folha")) {   // mede o menu de verdade (ao lado ou em cima), dentro da ferramenta aberta
      const b = F.d.body, cima = b.classList.contains("emCima"), rec = !cima && b.classList.contains("recolhido");
      const m = F.d.getElementById(cima ? "topoDac" : "lado");
      const mr = m && !rec && m.getClientRects().length ? m.getBoundingClientRect() : null;
      if (alvo === "lado") return mr ? somar(mr, F.f) : null;
      const fr = { left: cima || !mr ? 0 : mr.right, top: cima && mr ? mr.bottom : 0, right: F.f.width, bottom: F.f.height };
      return somar(fr, F.f);
    }
    if (/^ferr:/.test(alvo)) {   // uma parte de dentro da ferramenta
      if (!F) return null;
      const e = F.d.querySelector(alvo.slice(5)); if (!e || !e.getClientRects().length) return null;
      e.scrollIntoView({ block: "center" });
      const r = e.getBoundingClientRect(), b = F.d.body, m = F.d.getElementById(b.classList.contains("emCima") ? "topoDac" : "lado");
      const mr = m && (b.classList.contains("emCima") || !b.classList.contains("recolhido")) && m.getClientRects().length ? m.getBoundingClientRect() : null;   // o destaque não passa por baixo do menu
      const area = { left: b.classList.contains("emCima") || !mr ? 0 : mr.right, top: b.classList.contains("emCima") && mr ? mr.bottom : 0, right: F.f.width, bottom: F.f.height };
      return somar({ left: Math.max(r.left, area.left), top: Math.max(r.top, area.top), right: Math.min(r.right, area.right), bottom: Math.min(r.bottom, area.bottom) }, F.f);
    }
    if (alvo === "lado" || alvo === "folha") {   // sem acesso à ferramenta: estima pelo jeito que o menu costuma ficar
      const lw = W <= 900 ? 320 : 380;
      if (alvo === "lado") return { left: 0, top: 0, width: lw, height: H };
      return { left: lw, top: 0, width: W - lw, height: H };
    }
    const e = document.querySelector(alvo); if (!e || !e.offsetParent) return null;
    e.scrollIntoView({ block: "center" }); return e.getBoundingClientRect();
  }
  function reposicionar() {
    if (!ativo) return;
    const p = tour.passos[i], r = retangulo(p.alvo), f = el("tourFoco"), b = el("tourBalao"), M = 8;
    if (!r) { f.className = "centro"; f.style.cssText = ""; b.style.left = Math.max(16, (innerWidth - b.offsetWidth) / 2) + "px"; b.style.top = Math.max(16, (innerHeight - b.offsetHeight) / 2) + "px"; return; }
    f.className = ""; f.style.left = (r.left - M) + "px"; f.style.top = (r.top - M) + "px"; f.style.width = (r.width + 2 * M) + "px"; f.style.height = (r.height + 2 * M) + "px";
    const bw = b.offsetWidth, bh = b.offsetHeight, G = 18, B = 16, W = innerWidth, H = innerHeight;
    const L = r.left - M, T = r.top - M, R = r.left + r.width + M, D = r.top + r.height + M;   // o destaque, com a borda
    const cy = Math.min(H - bh - B, Math.max(B, T + 24)), cx = Math.min(W - bw - B, Math.max(B, L));
    const opc = [[R + G, cy], [L - G - bw, cy], [cx, D + G], [cx, T - G - bh]];   // ao lado (direita, esquerda), embaixo, em cima
    const cabe = ([x, y]) => x >= B && y >= B && x + bw <= W - B && y + bh <= H - B;
    const cobre = ([x, y]) => Math.max(0, Math.min(x + bw, R) - Math.max(x, L)) * Math.max(0, Math.min(y + bh, D) - Math.max(y, T));
    let pos = opc.find(cabe);
    if (!pos) {   // não cabe em volta: a posição que menos cobre o destaque (de preferência o canto de baixo, à direita)
      const presa = ([x, y]) => [Math.min(W - bw - B, Math.max(B, x)), Math.min(H - bh - B, Math.max(B, y))];
      const cands = [[W - bw - 24, H - bh - 110], [W - bw - 24, B], [24, H - bh - 110], [24, B], ...opc.map(presa)];
      pos = cands.reduce((m, c) => cobre(c) < cobre(m) ? c : m);
    }
    b.style.left = Math.min(W - bw - B, Math.max(B, pos[0])) + "px"; b.style.top = Math.min(H - bh - B, Math.max(B, pos[1])) + "px";
  }
  async function passo(n) {
    i = Math.max(0, n); const p = tour.passos[i];
    el("tourN").textContent = `TOUR ${tour.nome.toUpperCase()} · ${i + 1} DE ${tour.passos.length}`;
    el("tourT").textContent = p.titulo;
    clearInterval(vigia); document.body.classList.remove("tourFaca");
    el("tourX").innerHTML = p.texto
      + (p.faca ? `<div class="faca" id="tourFaca"><b>Sua vez:</b> ${p.faca}</div>` : "")
      + (p.alvo === "folha" || p.alvo === "lado" ? '<div class="rolar">Dica: role a página até o fim para ver tudo.</div>' : "");
    el("tourAnt").style.visibility = i ? "visible" : "hidden";
    el("tourProx").textContent = i + 1 < tour.passos.length ? "Próximo →" : "Concluir ✓";
    if (window.tourIr && window.tourIr(p.rota)) {
      if (window.tourPronto) {   // espera só o necessário: a tela trocar e, se for uma ferramenta, ela terminar de abrir (no máximo 3 s)
        await new Promise(ok => setTimeout(ok, 250));
        for (let t = 0; t < 30 && !window.tourPronto(p.rota); t++) await new Promise(ok => setTimeout(ok, 100));
      } else await new Promise(ok => setTimeout(ok, (window.tourLongo ? window.tourLongo(p.rota) : /^app-/.test(p.rota)) ? 1600 : 350));
    }
    const F = docFerr(), antes = F ? F.d.body.className : "";   // menu ao lado e à vista durante o tour (o agendamento fica com o menu em cima)
    avisarFerr({ tourModo: true });
    await new Promise(ok => setTimeout(ok, 40));
    if (F && F.d.body.className !== antes) await new Promise(ok => setTimeout(ok, 380));   // espera a troca do menu terminar
    if (!ativo || tour.passos[i] !== p) return;   // a pessoa já passou para outro passo
    reposicionar(); marcar(p.marca);
    if (p.faca && p.ate) {   // passo com tarefa: a pessoa faz de verdade; o tour espera e segue sozinho quando ela termina
      document.body.classList.add("tourFaca");
      el("tourProx").textContent = "Pular →";
      const n0 = i;
      vigia = setInterval(() => {
        if (!ativo || i !== n0) { clearInterval(vigia); return; }
        let d = document; try { if (window.tourDoc) d = window.tourDoc(p.rota) || document; } catch (e) {}
        const x = d.querySelector(p.ate);
        if (x && x.getClientRects().length) {
          clearInterval(vigia); document.body.classList.remove("tourFaca");
          const f = el("tourFaca"); if (f) { f.classList.add("ok"); f.innerHTML = "<b>✓ Muito bem!</b> Seguindo…"; }
          el("tourProx").textContent = i + 1 < tour.passos.length ? "Próximo →" : "Concluir ✓";
          setTimeout(() => { if (ativo && i === n0) el("tourProx").click(); }, 1100);
        }
      }, 400);
    }
  }
  function marcar(m) {  // passo com "marca": a ferramenta aberta destaca um detalhe dela (ex.: "x" = o × que tira um item da lista)
    document.querySelectorAll("iframe").forEach(f => { try { f.contentWindow.postMessage({ tourMarca: m || null }, "*"); } catch (e) {} });
  }
  window.iniciarTour = function (k) {
    tour = TOURS[k]; if (!tour) return;
    if (window.tourPreparar) try { window.tourPreparar(tour.passos.map(p => p.rota)); } catch (e) {}   // abre em segundo plano as ferramentas do tour
    montar(); ativo = true; const pn = el("tmPainel"); if (pn) pn.hidden = true; const pc = el("chatPainel"); if (pc) pc.hidden = true;
    if (window.temisAtualizar) window.temisAtualizar();   // com a conversa fechada, o botão da Têmis volta a aparecer (o tour aponta para ele)
    passo(0);
  };
  document.addEventListener("click", e => { const b = e.target.closest("[data-tour]"); if (b) window.iniciarTour(b.dataset.tour); });
})();

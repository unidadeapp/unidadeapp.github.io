/* Assistente de Documentos DAC – código comum à Central, ao Checklist e ao Preenchimento de Formulários.
   Tudo fica dentro de window.DAC, para não colidir com os nomes de cada página. */
(function () {
  "use strict";
  const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  const MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
  const TEL_MSG = "Envie os documentos e as dúvidas por este WhatsApp, só por mensagem: não atendemos ligações pelo WhatsApp. Se precisar falar por telefone, ligue para o mesmo número, (53) 3284-9450, por ligação comum, das 8h às 17h.";

  /* ---------- assinatura das mensagens (nome de quem atende): fica guardada neste computador ---------- */
  const CH_ASS = "dpuDAC.assinatura";
  const CARGOS = ["Estagiário(a)", "Servidor(a)", "Outro"];
  function lerAss() { try { const o = JSON.parse(localStorage.getItem(CH_ASS) || "null"); if (o && typeof o === "object") return { nome: String(o.nome || ""), cargo: CARGOS.includes(o.cargo) ? o.cargo : "" }; } catch (e) {} return { nome: "", cargo: "" }; }
  function gravarAss(o) { try { localStorage.setItem(CH_ASS, JSON.stringify(o)); } catch (e) {} }
  function assinaturaTexto() {
    const a = lerAss(), nome = a.nome.trim().replace(/\s+/g, " ");
    if (!nome) return "";
    return `\n\nAtenciosamente,\n${nome}\n${a.cargo && a.cargo !== "Outro" ? a.cargo + " – " : ""}DPU Pelotas`;
  }
  const ouvintes = [];
  window.addEventListener("storage", e => { if (e.key === CH_ASS) ouvintes.forEach(f => f()); });
  /* caixinhas: "Seu nome" + Estagiário(a) / Servidor(a) (marcar uma desmarca a outra) */
  function montarAssinatura(box, aoMudar) {
    box.classList.add("assinBox");
    box.innerHTML = `<label class="assNomeL">Seu nome (vai no fim da mensagem)<input type="text" class="assNome" autocomplete="off" placeholder="Nome de quem está atendendo"></label>
      <div class="assCargo">${CARGOS.map(c => `<label><input type="checkbox" value="${c}"> ${c}</label>`).join("")}</div>
      <div class="assAviso"></div>`;
    const inp = box.querySelector(".assNome"), cks = [...box.querySelectorAll(".assCargo input")], av = box.querySelector(".assAviso");
    const mostrar = () => {
      const a = lerAss(); if (document.activeElement !== inp) inp.value = a.nome;
      cks.forEach(c => { c.checked = c.value === a.cargo; c.parentNode.classList.toggle("on", c.checked); });
      av.textContent = a.nome.trim() ? (a.cargo ? "" : "Marque Estagiário(a), Servidor(a) ou Outro.") : "Escreva seu nome para assinar a mensagem.";
    };
    inp.addEventListener("input", () => { const a = lerAss(); a.nome = inp.value; gravarAss(a); mostrar(); aoMudar && aoMudar(); });
    cks.forEach(c => c.addEventListener("change", () => { const a = lerAss(); a.cargo = c.checked ? c.value : ""; gravarAss(a); mostrar(); aoMudar && aoMudar(); }));
    ouvintes.push(() => { mostrar(); aoMudar && aoMudar(); });
    window.addEventListener("focus", mostrar);
    mostrar();
  }
  const CSS_ASS = `.assinBox{display:grid;grid-template-columns:1fr;gap:6px;margin:4px 0 12px}
    .assinBox .assNomeL{display:flex;flex-direction:column;gap:4px;font-size:13px;font-weight:600;color:#5f5f5f}
    .assinBox .assNome{font:inherit;font-size:15px;font-weight:400;padding:8px 10px;border:1.5px solid #c9d6c2;border-radius:8px;color:#1e1e1e}
    .assinBox .assCargo{display:flex;gap:8px;flex-wrap:wrap}
    .assinBox .assCargo label{display:flex;gap:7px;align-items:center;border:1.5px solid #d6e0d0;border-radius:8px;padding:6px 12px;cursor:pointer;background:#fff;font-size:14px}
    .assinBox .assCargo label.on{border-color:#3f7f2a;background:#eef6ea;font-weight:600}
    .assinBox .assCargo input{accent-color:#3f7f2a;width:17px;height:17px;margin:0}
    .assinBox .assAviso{font-size:12.5px;color:#a23b31}.assinBox .assAviso:empty{display:none}`;

  /* ---------- caixinhas de preenchimento (cada informação aparece uma vez só, mesmo que vá para vários formulários) ----------
     rot: rótulo; f: como a mensagem pede (falta preencher); p: como a mensagem diz que já foi preenchido */
  const CX = {
    nome:        { rot: "Nome completo do(a) assistido(a)", f: "seu nome completo", p: "seu nome" },
    cpf:         { rot: "CPF do(a) assistido(a)", mask: "cpf", ph: "000.000.000-00", f: "seu CPF", p: "seu CPF" },
    endereco:    { rot: "Endereço completo do(a) assistido(a)", ph: "Rua, número, complemento, bairro, cidade e CEP", f: "seu endereço completo", p: "seu endereço" },
    paj:         { rot: "Número do PAJ", ph: "2026/025-1234", f: "o número do PAJ", p: "o número do PAJ" },
    titNome:     { rot: "Nome completo do(a) titular do comprovante (quem declara)", branco: true, f: "o nome completo de quem tem a conta no nome", p: "o nome de quem tem a conta no nome" },
    titCpf:      { rot: "CPF do(a) titular do comprovante", branco: true, mask: "cpf", ph: "000.000.000-00", f: "o CPF dessa pessoa", p: "o CPF dessa pessoa" },
    valor:       { rot: "Renda mensal informal (R$)", money: true, ph: "0,00", f: "quanto você recebe por mês", p: "o valor que você recebe por mês" },
    contrato:    { rot: "Número ou identificação do contrato", f: "o número do contrato", p: "o número do contrato" },
    banco:       { rot: "Banco ou financeira do contrato", f: "o nome do banco ou da financeira", p: "o nome do banco ou da financeira" },
    processo:    { rot: "Número do processo", f: "o número do processo", p: "o número do processo" },
    vara:        { rot: "Número da vara", ph: "Só o número. Ex.: 1", f: "o número da vara", p: "o número da vara" },
    secao:       { rot: "Seção ou subseção judiciária", ph: "Ex.: Pelotas", f: "a seção ou subseção judiciária", p: "a seção judiciária" },
    instituicao: { rot: "Instituição financeira que vai pagar", f: "o nome do banco que vai pagar", p: "o banco que vai pagar" },
    valorIsento: { rot: "Valor a receber (R$)", money: true, ph: "0,00", f: "o valor a receber", p: "o valor a receber" },
    valorExtenso:{ rot: "Valor a receber por extenso", ph: "Em branco: sai escrito a partir do valor", f: "o valor por extenso", p: "o valor por extenso" },
    docsPend:    { rot: "Documentos pendentes (um por linha, até 8)", tipo: "area", f: "os documentos que faltam", p: "a lista de documentos que faltam" },
    prazo:       { rot: "Prazo para entregar os documentos", tipo: "prazo", f: "o prazo", p: "o prazo" },
    dataComp:    { rot: "Dia do comparecimento", tipo: "dia", f: "o dia", p: "o dia" },
    horaIni:     { rot: "Horário de chegada", ph: "Ex.: 9h30", f: "o horário de chegada", p: "o horário de chegada" },
    horaFim:     { rot: "Horário de saída", ph: "Ex.: 11h", f: "o horário de saída", p: "o horário de saída" },
    juizo:       { rot: "Vara ou juízo do processo", ph: "Ex.: 2ª VARA FEDERAL DE PELOTAS", f: "o juízo", p: "o juízo" },
    defensor:    { rot: "Nome do(a) Defensor(a) Público(a) Federal", f: "o nome do(a) Defensor(a)", p: "o nome do(a) Defensor(a)" },
    data:        { rot: "Data do documento", tipo: "data", f: "a data", p: "a data" },
  };
  /* formulários: tipo (quem preenche e assina), g (gênero, para "preenchida/preenchido"), campos (caixinha → campo do PDF)
     data: "cidade" (cidade/UF, dia, mês e ano), "pelotas" (Pelotas/RS já impresso: dia, mês e ano), "municipio" (município/UF, dia, mês e ano) */
  const MED = { nome: ["nome", "nome_do_a_assistido_a"], cpf: ["cpf_nº", "cpf"], paj: ["paj_nº", "e_paj_nº", "paj", "e_paj"] };
  const FD = {
    Formulario_de_renda_pessoa_natural: { curto: "Formulário de Renda", g: "m", tipo: "renda", campos: { nome: null } },
    Declaracao_de_ausencia_de_renda: { curto: "Ausência de renda", g: "f", tipo: "decl", campos: { nome: "nome", cpf: "cpf", data: "cidade" } },
    Declaracao_de_renda_informal: { curto: "Renda informal", g: "f", tipo: "decl", campos: { nome: "nome", cpf: "cpf", valor: "valor", data: "cidade" } },
    Declaracao_de_ausencia_de_CTPS: { curto: "Ausência de Carteira de Trabalho", g: "f", tipo: "decl", campos: { nome: "nome", cpf: "cpf", data: "cidade" } },
    Declaracao_de_residencia_proprietario: { curto: "Titular do comprovante", g: "f", tipo: "titular",
      campos: { titNome: "nome_declarante", titCpf: "cpf_declarante", endereco: "endereco", nome: "nome_morador", cpf: "cpf_morador", data: "cidade" } },
    Declaracao_de_residencia_sem_conta_em_nome_proprio: { curto: "Declaração de residência", g: "f", tipo: "decl", campos: { nome: "nome", cpf: "cpf", endereco: "endereco", data: "cidade" } },
    Declaracao_isento_IRPF_Banco_do_Brasil: { curto: "Isenção de IRPF", g: "f", tipo: "irpf",
      campos: { nome: "beneficiario", endereco: "endereco", cpf: "cpf_cnpj", processo: "processo", vara: "vara", secao: "secao", instituicao: "instituicao", valorIsento: "valor", valorExtenso: "valor_extenso", data: "municipio" } },
    Documentacao_pendente: { curto: "Documentação pendente", g: "f", tipo: "pend", campos: { docsPend: "lista", prazo: "prazo", data: "pelotas" } },
    Certidao_de_comparecimento: { curto: "Certidão de comparecimento", g: "f", tipo: "dpu", campos: { nome: "nome", dataComp: "data", horaIni: "hora_inicio", horaFim: "hora_fim", paj: "paj", data: "pelotas" } },
    Desistencia_do_PAJ: { curto: "Desistência do PAJ", g: "f", tipo: "decl", campos: { paj: "paj", nome: "nome", cpf: "cpf", data: "pelotas" } },
    Declaracao_de_renuncia: { curto: "Renúncia (Juizado Especial Federal)", g: "f", tipo: "decl", campos: { nome: "nome", cpf: "cpf", data: "cidade" } },
    Termo_de_nao_reconhecimento_de_assinatura: { curto: "Não reconhecimento de assinatura", g: "m", tipo: "decl", campos: { nome: "nome", cpf: "cpf", contrato: "contrato", banco: "banco", data: "cidade" } },
    Peticao_de_acordo_INSS: { curto: "Petição de acordo – INSS", g: "f", tipo: "acordo", campos: { juizo: "juizo", processo: "processo", paj: "paj", nome: "nome_assistido", data: "pelotas", defensor: "defensor" } },
    Peticao_de_acordo_CEF: { curto: "Petição de acordo – CEF", g: "f", tipo: "acordo", campos: { juizo: "juizo", processo: "processo", paj: "paj", nome: "nome_assistido", data: "pelotas", defensor: "defensor" } },
    Laudo_medico_beneficio_por_incapacidade: { curto: "Formulário médico – incapacidade", g: "m", tipo: "medico", campos: MED },
    Laudo_medico_adicional_25: { curto: "Formulário médico – adicional de 25%", g: "m", tipo: "medico", campos: MED },
    Formulario_BPC_LOAS_pessoa_com_deficiencia: { curto: "Formulário médico – BPC/LOAS", g: "m", tipo: "medico", campos: MED },
    Laudo_medico_cirurgia: { curto: "Formulário médico – cirurgia", g: "m", tipo: "medico", campos: MED },
    Laudo_medico_exame: { curto: "Formulário médico – exame", g: "m", tipo: "medico", campos: MED },
    Laudo_medico_internacao_UTI: { curto: "Formulário médico – UTI", g: "m", tipo: "medico", campos: MED },
    Formulario_pedido_judicial_tratamento: { curto: "Formulário médico – tratamento", g: "m", tipo: "medico", campos: MED },
    Formulario_pedido_judicial_medicamentos: { curto: "Formulário médico – medicamentos", g: "m", tipo: "medico", campos: MED },
    Formulario_pedido_judicial_medicamentos_Tema_6_STF: { curto: "Formulário médico – medicamentos (Tema 6)", g: "m", tipo: "medico", campos: MED, crm: true },
    Questionamentos_do_juizo_casos_oncologicos: { curto: "Formulário médico – oncológico", g: "m", tipo: "medico", campos: {} },
  };
  /* caixinhas usadas por um conjunto de formulários, na ordem de CX */
  function caixasDe(arqs) {
    const usa = {};
    arqs.forEach(a => { const fd = FD[a]; if (fd) Object.keys(fd.campos).forEach(k => { (usa[k] = usa[k] || []).push(a); }); });
    return Object.keys(CX).filter(k => usa[k]).map(k => ({ k, arqs: usa[k] }));
  }
  const juntar = l => l.length <= 1 ? (l[0] || "") : l.slice(0, -1).join(", ") + " e " + l[l.length - 1];
  const fraseData = fd => fd.campos.data === "cidade" ? ["a cidade", "a data"] : fd.campos.data === "municipio" ? ["o município", "a data"] : ["a data"];

  /* ---------- mensagem para o(a) assistido(a) com os formulários (WhatsApp) ----------
     lista: [{arq, nome, analf (versão para analfabeto)}]; o: { nome (do assistido), analf, preenchidos(arq) → Set de caixinhas preenchidas, rendaPre (formulário de renda já respondido) } */
  function mensagemForms(lista, o = {}) {
    const p = String(o.nome || "").trim().split(/\s+/)[0] || "";
    const nm = p ? " " + p.charAt(0).toUpperCase() + p.slice(1).toLowerCase() : "";
    const ROGO = "coloque a sua digital no espaço indicado; outra pessoa assina a seu pedido (assinatura a rogo), junto com duas testemunhas, e cada uma escreve o nome e o CPF";
    const itens = [];
    lista.forEach(f => {
      const fd = FD[f.arq]; if (!fd) return;
      const analf = f.analf === undefined ? !!o.analf : !!f.analf;   // só quando o formulário usado é a versão para analfabeto
      const assinar = analf ? ROGO : "assine no fim da folha";
      const ja = o.preenchidos ? o.preenchidos(f.arq) : new Set();
      const ks = Object.keys(fd.campos);
      const falta = ks.filter(k => !ja.has(k)).flatMap(k => k === "data" ? fraseData(fd) : [CX[k].f]);
      const escreva = (fim) => `Escreva ${juntar(falta)}${falta.length > 1 ? "," : ""} e ${fim}`;
      const pr = fd.g === "f" ? "preenchida" : "preenchido";
      let t;
      if (fd.tipo === "renda") {
        t = o.rendaPre ? `Já vai ${pr} com as informações que você deu no atendimento. Confira tudo, complete o que estiver em branco e ${assinar}.`
          : `Preencha com a sua renda e a de cada pessoa que mora com você, responda às perguntas, marque os bens e os serviços da casa e ${assinar}.`;
      } else if (fd.tipo === "medico") {
        t = `Leve ao(à) médico(a) que acompanha você, para ele(a) responder a todas as perguntas, assinar e carimbar${fd.crm ? ", com o número do CRM" : ""}.`;
      } else if (fd.tipo === "titular") {
        t = `Deve ser preenchida e assinada por quem tem a conta de luz, de água ou outra conta da casa no nome (o(a) titular do comprovante). ${falta.length ? `Falta escrever ${juntar(falta)}. ` : ""}Envie também o comprovante de residência que está no nome dessa pessoa.`;
      } else if (fd.tipo === "dpu") {
        t = "Segue a certidão que comprova que você esteve na Defensoria.";
      } else if (fd.tipo === "pend") {
        t = `${falta.length ? escreva(assinar) : "Confira a lista e " + assinar}.`;
      } else if (fd.tipo === "irpf") {
        t = `${falta.length ? `Escreva ${juntar(falta)}, marque` : "Marque"} a opção que corresponde ao seu caso e ${assinar}. O quadro “Abono da assinatura pela instituição financeira” é preenchido pelo banco.`;
      } else if (fd.tipo === "acordo") {
        t = `Confira e ${analf ? assinar : "assine onde está escrito “Assinatura do(a) assistido(a)”"}.`;
      } else {
        t = `${falta.length ? escreva(assinar) + "." : `Falta só ${analf ? "a digital e as assinaturas: " + assinar : "assinar no fim da folha"}.`}`;
      }
      itens.push({ nome: f.nome || fd.curto, t, dpu: fd.tipo === "dpu" });
    });
    if (!itens.length) return "";
    const soDoc = itens.every(i => i.dpu), um = itens.length === 1;
    const abre = soDoc ? (um ? "Envio nesta mensagem o documento abaixo:" : "Envio nesta mensagem os documentos abaixo:")
      : (um ? "Envio nesta mensagem o formulário abaixo. Veja como preencher:" : "Envio nesta mensagem os formulários abaixo. Veja como preencher cada um:");
    const corpo = itens.map((i, j) => `${j + 1}. ${i.nome}\n${i.t}`).join("\n\n");
    const fim = soDoc ? "" : "\n\nQuando estiver tudo preenchido e assinado, envie por este WhatsApp uma foto de cada folha, bem enquadrada, de boa qualidade e legível.";
    return `Prezado(a)${nm},\n\n${abre}\n\n${corpo}${fim}\n\n${TEL_MSG}` + assinaturaTexto();
  }

  /* ---------- valor por extenso (reais e centavos) ---------- */
  function ate999(n) {
    const U = ["", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze", "treze", "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"];
    const D = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"];
    const C = ["", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos"];
    if (n === 100) return "cem";
    const c = Math.floor(n / 100), r = n % 100, p = [];
    if (c) p.push(C[c]);
    if (r) p.push(r < 20 ? U[r] : D[Math.floor(r / 10)] + (r % 10 ? " e " + U[r % 10] : ""));
    return p.join(" e ");
  }
  function porExtenso(v) {
    if (!(v >= 0) || v >= 1e12) return "";
    const tot = Math.round(v * 100), reais = Math.floor(tot / 100), cent = tot % 100;
    const NOMES = [["", ""], ["mil", "mil"], ["milhão", "milhões"], ["bilhão", "bilhões"]];
    const gr = []; let x = reais; while (x > 0) { gr.push(x % 1000); x = Math.floor(x / 1000); }
    const partes = [];
    for (let i = gr.length - 1; i >= 0; i--) {
      const g = gr[i]; if (!g) continue;
      partes.push({ g, t: i === 1 && g === 1 ? "mil" : ate999(g) + (i ? " " + NOMES[i][g === 1 ? 0 : 1] : "") });
    }
    let s = "";
    partes.forEach((pt, k) => { s += k === 0 ? pt.t : (k === partes.length - 1 && (pt.g < 100 || pt.g % 100 === 0) ? " e " : " ") + pt.t; });
    let out = "";
    if (reais) out = s + (reais === 1 ? " real" : (gr[0] === 0 && (gr[1] || 0) === 0 && reais >= 1e6 ? " de reais" : " reais"));
    if (cent) out += (reais ? " e " : "") + ate999(cent) + (cent === 1 ? " centavo" : " centavos");
    return out || "zero real";
  }

  window.DAC = { esc, MESES, TEL_MSG, CX, FD, caixasDe, mensagemForms, porExtenso, assinaturaTexto, montarAssinatura, lerAss, CSS_ASS };
})();

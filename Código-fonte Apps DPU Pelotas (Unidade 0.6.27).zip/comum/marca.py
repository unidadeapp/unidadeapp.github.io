# Marcas visuais comuns aos apps: a Têmis (assistente virtual, deusa grega da justiça em versão cartum),
# o logo do Térreo e a faixa nas cores do logo da DPU (verde → azul-petróleo).

# Têmis: rosto redondo, coque grego com louros, venda nos olhos, toga verde e a balança dourada.
TEMIS = """<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Têmis, a assistente virtual">
<defs><clipPath id="temisC"><circle cx="60" cy="60" r="58"/></clipPath></defs>
<circle cx="60" cy="60" r="58" fill="#e6f1e1"/>
<g clip-path="url(#temisC)">
<path d="M20 124c2-24 18-37 40-37s38 13 40 37z" fill="#3f7f2a"/>
<path d="M60 87c-9 0-17 3-22 8l22 28 22-28c-5-5-13-8-22-8z" fill="#fff"/>
<rect x="53" y="72" width="14" height="16" rx="6" fill="#f2c7a1"/>
<circle cx="60" cy="56" r="23" fill="#f6d2b0"/>
<path d="M36 58c-2-17 9-29 24-29s26 12 24 29c-3-9-9-14-14-16-6 5-17 7-29 5-2 3-4 7-5 11z" fill="#5b3a24"/>
<circle cx="60" cy="25" r="10" fill="#5b3a24"/>
<g fill="#d4a72c"><ellipse cx="40" cy="43" rx="2.4" ry="4.6" transform="rotate(-30 40 43)"/><ellipse cx="43.5" cy="37" rx="2.4" ry="4.6" transform="rotate(-55 43.5 37)"/><ellipse cx="49" cy="33" rx="2.4" ry="4.6" transform="rotate(-75 49 33)"/>
<ellipse cx="80" cy="43" rx="2.4" ry="4.6" transform="rotate(30 80 43)"/><ellipse cx="76.5" cy="37" rx="2.4" ry="4.6" transform="rotate(55 76.5 37)"/><ellipse cx="71" cy="33" rx="2.4" ry="4.6" transform="rotate(75 71 33)"/></g>
<rect x="35" y="50" width="50" height="9" rx="4.5" fill="#fff" stroke="#cfdcc8" stroke-width="1.2"/>
<path d="M85 54c5 0 8 2 9 6M85 55c4 2 6 5 6 8" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round"/>
<circle cx="46" cy="65" r="3.6" fill="#f2a7a0" opacity=".7"/><circle cx="74" cy="65" r="3.6" fill="#f2a7a0" opacity=".7"/>
<path d="M53 68c4 4 10 4 14 0" stroke="#8a4b2f" stroke-width="2.4" fill="none" stroke-linecap="round"/>
<g transform="translate(88 72)">
<path d="M0 0v26" stroke="#b8891c" stroke-width="2.6" stroke-linecap="round"/>
<path d="M-14 4h28" stroke="#d4a72c" stroke-width="3" stroke-linecap="round"/>
<circle cx="0" cy="2" r="3" fill="#d4a72c"/>
<path d="M-14 4l-6 12M-14 4l6 12M14 4l-6 12M14 4l6 12" stroke="#b8891c" stroke-width="1.4"/>
<path d="M-22 16h16a8 5 0 0 1-16 0zM6 16h16a8 5 0 0 1-16 0z" fill="#d4a72c"/>
<circle cx="0" cy="27" r="4.5" fill="#f6d2b0"/>
</g></g>
</svg>"""

# Térreo: um prédio de três andares com o térreo (o andar do atendimento) em destaque e a linha do chão.
TERREO = """<svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Térreo">
<rect x="10" y="6" width="28" height="36" rx="4" fill="none" stroke="#2f6a1f" stroke-width="3"/>
<path d="M10 18h28M10 30h28" stroke="#2f6a1f" stroke-width="2" opacity=".45"/>
<path d="M10 30h28v8a4 4 0 0 1-4 4H14a4 4 0 0 1-4-4z" fill="#3f7f2a"/>
<path d="M21 42v-6.5a3 3 0 0 1 6 0V42z" fill="#fff"/>
<path d="M4 42.5h40" stroke="#00879a" stroke-width="3" stroke-linecap="round"/>
</svg>"""

# Unidade (app principal, antigo ATDPU): o mesmo prédio, agora com todos os andares em destaque (a unidade inteira).
UNIDADE = """<svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Unidade">
<path d="M14 6h20a4 4 0 0 1 4 4v8H10v-8a4 4 0 0 1 4-4z" fill="#00879a"/>
<rect x="10" y="18" width="28" height="12" fill="#2f8a5a"/>
<path d="M10 30h28v8a4 4 0 0 1-4 4H14a4 4 0 0 1-4-4z" fill="#3f7f2a"/>
<rect x="10" y="6" width="28" height="36" rx="4" fill="none" stroke="#2f6a1f" stroke-width="3"/>
<path d="M10 18h28M10 30h28" stroke="#fff" stroke-width="1.6" opacity=".8"/>
<path d="M15 10.5h4v4h-4zM22 10.5h4v4h-4zM29 10.5h4v4h-4zM15 22h4v4h-4zM22 22h4v4h-4zM29 22h4v4h-4z" fill="#fff" opacity=".9"/>
<path d="M21 42v-6.5a3 3 0 0 1 6 0V42z" fill="#fff"/>
<path d="M4 42.5h40" stroke="#2f6a1f" stroke-width="3" stroke-linecap="round"/>
</svg>"""

# Faixa fina nas cores do logo da DPU, para o alto das capas e dos menus
FAIXA = "linear-gradient(90deg, #4f9a2a 0%, #3f8f3a 45%, #00879a 100%)"

# Monta o <script> do tour guiado pela Têmis (comum/tour.js) com os tours de um app.
import json, sys
from pathlib import Path as _Path
RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"
sys.path.insert(0, RAIZ + "comum")
import marca


def script(tours_js):
    """tours_js: o objeto JavaScript com os tours do app (texto)."""
    js = open(RAIZ + "comum/tour.js", encoding="utf-8").read()
    av = json.dumps(marca.TEMIS.replace("temisC", "temisCB"), ensure_ascii=False)
    js = js.replace("const TOURS = __TOURS__;", "const TOURS = " + tours_js.strip() + ";").replace("__TOUR_AV__", av)
    assert "__TOURS__;" not in js and "__TOUR_AV__" not in js
    return "<script>" + js.replace("</", "<\\/") + "</script>"

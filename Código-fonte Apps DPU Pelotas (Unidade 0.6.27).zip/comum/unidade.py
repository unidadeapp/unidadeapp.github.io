# Tela "A DPU Pelotas": informações básicas da unidade para quem está começando (comum ao app Unidade e aos apps Térreo).
# Só dados conferidos: os fixos do CLAUDE.md (endereço da folha de documentos, telefones, horários, prazos, renda) e a
# lista de municípios atendidos passada pelo Pedro. Mudou algo? Mude aqui e rode o construir.sh.

MUNICIPIOS = ["Amaral Ferrador", "Arroio do Padre", "Arroio Grande", "Canguçu", "Capão do Leão", "Cerrito", "Herval", "Jaguarão",
              "Morro Redondo", "Pedro Osório", "Pelotas (município sede)", "Piratini", "São Lourenço do Sul", "Turuçu"]

CSS = """
  .unid { max-width:980px; margin:0 auto; }
  .unid h1 { color:var(--green); font-size:28px; margin:6px 0 4px; }
  .unid .sub { color:var(--gray); font-size:15.5px; margin:0 0 20px; line-height:1.5; }
  .unidGrade { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
  .unidBox { background:#fff; border:1.5px solid var(--line); border-radius:16px; padding:18px 22px; font-size:15px; line-height:1.55; text-align:left; }
  .unidBox h2 { margin:0 0 8px; font-size:15px; letter-spacing:.08em; color:var(--green); text-transform:uppercase; display:flex; align-items:center; gap:8px; }
  .unidBox h2::before { content:""; width:6px; height:18px; border-radius:3px; background:linear-gradient(180deg, #4f9a2a, #00879a); }
  .unidBox p { margin:4px 0; } .unidBox ul { margin:4px 0; padding-left:20px; } .unidBox li { margin:3px 0; }
  .unidBox .num { font-weight:800; white-space:nowrap; }
  .unidLarga { grid-column:1 / -1; }
  .munis { display:flex; flex-wrap:wrap; gap:8px; margin-top:6px; }
  .munis span { background:var(--soft); border:1.5px solid var(--line); border-radius:20px; padding:5px 12px; font-size:14.5px; }
  .munis span.sede { background:#3f7f2a; border-color:#3f7f2a; color:#fff; font-weight:700; }
  .unidNota { font-size:13px; color:var(--gray); margin-top:14px; }
  @media (max-width:760px) { .unidGrade { grid-template-columns:1fr; } }
"""


def html(com_setores=True):
    munis = "".join(f'<span class="{"sede" if "sede" in m else ""}">{m}</span>' for m in MUNICIPIOS)
    setores = """<div class="unidBox"><h2>Setores da unidade</h2><ul>
        <li><b>Agendamento:</b> marca os atendimentos e passa a lista de documentos.</li>
        <li><b>DAC – Atendimento e Cartório:</b> atende a pessoa, abre o PAJ e acompanha os documentos pendentes.</li>
        <li><b>DAD – Administrativo.</b></li>
        <li><b>DPS – Departamento Processual:</b> analisa a demanda e faz as peças, com os defensores.</li></ul></div>""" if com_setores else ""
    return f"""<div class="unid">
    <h1>A DPU Pelotas</h1>
    <p class="sub">O básico para quem está começando: onde fica, como a pessoa fala com a unidade, quem ela atende e de onde vêm os assistidos.</p>
    <div class="unidGrade">
      <div class="unidBox"><h2>Endereço</h2><p>Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS, <span class="num">CEP 96020-480</span>.</p><p><b>Atendimento presencial:</b> das 9h às 15h.</p></div>
      <div class="unidBox"><h2>Contatos</h2>
        <p><span class="num">(53) 3284-9450</span>: WhatsApp <b>só para mensagens</b> (envio de documentos e dúvidas). O mesmo número atende <b>ligação comum</b>, das 8h às 17h. Não atendemos ligações pelo WhatsApp.</p>
        <p><span class="num">(53) 99112-4160</span>: <b>só para agendar</b> um PAJ novo.</p></div>
      <div class="unidBox unidLarga"><h2>Municípios atendidos</h2><p>A DPU Pelotas atende moradores destes {len(MUNICIPIOS)} municípios:</p><div class="munis">{munis}</div></div>
      <div class="unidBox"><h2>Quem a DPU atende</h2><p>Pessoas que não podem pagar advogado(a), em causas da <b>Justiça Federal</b> (INSS, BPC/LOAS, Bolsa Família, SUS, Caixa, crimes federais e outras). Pela Resolução CSDPU nº 240/2025, o limite de referência é a <b>renda do grupo familiar de até 2 salários mínimos</b> (R$ 3.242,00 em 2026). Gastos extraordinários com saúde podem ser descontados da renda. A análise final é do(a) defensor(a).</p>
        <p>Assuntos da Justiça Estadual (família, inventário, aluguel…) e trabalhistas vão para a DPE e as assistências judiciárias das universidades.</p></div>
      <div class="unidBox"><h2>Prazos dos documentos</h2><p>Se faltar documento no dia do atendimento, a pessoa tem <b>30 dias</b> (PRAZO NORMAL) ou <b>48 horas</b> (PAJ URGENTE) para entregar. Sem a documentação completa no prazo, o PAJ é <b>ARQUIVADO</b>.</p></div>
      {setores}
    </div>
    <p class="unidNota">Viu alguma informação desatualizada? Avise o Pedro Tomkowski, que mantém o app.</p>
  </div>"""

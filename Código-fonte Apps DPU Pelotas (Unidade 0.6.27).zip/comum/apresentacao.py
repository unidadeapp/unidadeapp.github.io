# Apresentações em slides de cada app (Unidade, Térreo, Térreo – DAC, Térreo – AG), para mostrar o app a quem não conhece
# (um defensor, um estagiário novo). Ficam no HUB das versões (online/gen_hub.py), não dentro dos apps.
import sys
from pathlib import Path as _Path
RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"
sys.path.insert(0, RAIZ + "comum")
import marca

AV = marca.TEMIS.replace("temisC", "temisCS")
LOGO_T = marca.TERREO

MAPA = f"""<div class="slMapa">
  <div class="slFam"><b><span class="slLogo">{marca.UNIDADE}</span>Unidade</b><small>app principal, com todos os setores</small>
    <div class="slFilhos"><span class="on">online<small>site do Claude, com a Têmis usando o Claude</small></span><span class="off">offline<small>arquivo no computador</small></span></div></div>
  <div class="slSeta">derivado →</div>
  <div class="slFam"><b><span class="slLogo">{LOGO_T}</span>Térreo</b><small>atendimento, cartório e agendamento</small>
    <div class="slFilhos"><span class="off">Térreo<small>agendamento + DAC</small></span><span class="off">Térreo – DAC</span><span class="off">Térreo – AG</span></div><small class="slTodos">todos offline</small></div>
</div>"""

NUMS_ATDPU = [("45", "demandas com lista de documentos"), ("47", "modelos de narrativa para o SIS-DPU"), ("24", "formulários, com versão para analfabeto"),
              ("12", "modelos de peças"), ("56", "jurisprudências explicadas"), ("14", "municípios atendidos")]


def _nums(ns):
    return '<div class="slNums">' + "".join(f"<div><b>{n}</b><span>{t}</span></div>" for n, t in ns) + "</div>"


def slides_atdpu():
    return [
     {"capa": True, "k": "Apresentação", "t": "Unidade", "h": f'<div class="slCapa"><span class="slLogoG">{marca.UNIDADE}</span><p>Ferramentas de apoio ao trabalho de todos os setores da unidade, num app só: do agendamento à peça processual.</p><p class="slAutor">Desenvolvido por Pedro Tomkowski</p></div>'},
     {"k": "Os apps", "t": "Um app principal e uma família derivada", "h": MAPA + "<p class=\"slNota\">O Unidade tem tudo. O Térreo é uma versão mais simples, para quem só faz atendimento, cartório ou agendamento.</p>"},
     {"k": "Por quê", "t": "O que o app resolve", "h": "<ul><li>O atendimento tem muitas etapas, formulários, listas e mensagens que se repetem todos os dias.</li><li>Cada pessoa fazia de um jeito: textos diferentes, documentos esquecidos, retrabalho.</li><li>Estagiários novos chegam sem saber as demandas, os sistemas e as regras da unidade.</li><li>O app junta tudo isso num lugar, com os textos padronizados e as regras da unidade já dentro.</li></ul>"},
     {"k": "1 · Praticidade e velocidade", "t": "Em segundos, o que levava minutos", "h": "<ul><li><b>Lista de documentos</b> da demanda pronta, numa folha só, com o formulário médico quando precisa.</li><li><b>Mensagem do agendamento</b> para o WhatsApp, já copiada: dia, horário, endereço, documentos e prazo.</li><li><b>Narrativas</b> no formato da redução a termo, prontas para colar no SIS-DPU.</li><li><b>Formulários</b>: cada informação é digitada uma vez só e vai para todos.</li><li><b>Peças</b>: o Word do modelo já sai com a qualificação, o PAJ e a vara preenchidos.</li></ul>"},
     {"k": "2 · Facilidade", "t": "Feito para quem está começando", "h": "<ul><li>Abre com dois cliques, <b>sem instalar nada</b> e sem internet.</li><li>Busca de demanda por palavras do dia a dia (“auxílio”, “cirurgia”, “bolsa”).</li><li>Menu sempre à vista em todas as ferramentas, com <b>Voltar</b> e <b>Início</b>.</li><li>Linguagem simples, botões grandes e avisos quando falta alguma resposta.</li><li>Tabelinha de data, prazos e assinatura automáticos.</li></ul>"},
     {"k": "3 · Interatividade", "t": "O app conversa com quem usa", "h": f'<div class="slLado"><span class="slAv">{AV}</span><ul><li><b>Têmis</b>, a assistente virtual: responde dúvidas sobre o app e leva direto à ferramenta. Na versão online, ela funciona com o Claude e entende perguntas livres.</li><li><b>Tour guiado</b> por setor, com a Têmis mostrando cada parte na tela.</li><li><b>Prévias ao vivo</b> dos formulários e das listas enquanto você digita.</li><li>Em Meus PAJs, marcar o que chegou atualiza sozinho as mensagens.</li></ul></div>'},
     {"k": "4 · Treinamento", "t": "Estagiários e servidores novos aprendem usando", "h": "<ul><li><b>Aprender</b>: 36 páginas sobre as demandas e como analisar o caso, glossário com 39 verbetes, 56 jurisprudências e o Manual do Estagiário com índice.</li><li><b>Tutoriais</b> de cada ferramenta e <b>tours</b> guiados pela Têmis.</li><li><b>A DPU Pelotas</b>: endereço, contatos, horários, municípios atendidos e quem a DPU atende.</li><li>Nas narrativas, botões “O que é isso?” explicam cada pergunta.</li></ul>"},
     {"k": "5 · Segurança", "t": "Os dados dos assistidos não saem do computador", "h": "<ul><li>Os apps offline <b>funcionam sem internet</b>: nada do que é digitado é enviado para fora.</li><li>Nenhum dado de assistido fica no app nem no código; exemplos são sempre anonimizados.</li><li>Só o essencial fica guardado no navegador do computador (Meus PAJs, rascunho do atendimento, assinatura).</li><li>Na versão online, a Têmis usa a conta do Claude de quem pergunta, sem memória entre as perguntas.</li></ul>"},
     {"k": "Outros pontos fortes", "t": "Padronização, acessibilidade e custo zero", "h": "<ul><li><b>Padronização</b>: todos usam os mesmos textos, listas e prazos (30 dias ou 48 horas).</li><li><b>Menos erro</b>: avisos de perguntas sem resposta, prazos e datas calculados, impressão garantida em 1 folha.</li><li><b>Acessibilidade</b>: versão dos formulários para assistido analfabeto (digital, assinatura a rogo e testemunhas).</li><li><b>Sem custo</b> e sem instalação: um arquivo que circula por WhatsApp ou pendrive, atualizado pelo HUB das versões.</li><li><b>Conforto</b>: <b>modo escuro</b> em todos os apps e botões separados para <b>imprimir</b> (folha legível em preto e branco) e <b>salvar em PDF</b>.</li></ul>"},
     {"k": "Setor por setor", "t": "Agendamento", "h": "<ul><li><b>Documentos Necessários e Mensagem</b>: escolhe a demanda, o dia e o horário; sai a lista (com o formulário médico) e a mensagem do WhatsApp.</li><li><b>PAJ sem Atendimento</b>: narrativas prontas para não comparecimento, matéria estadual ou trabalhista, só ajuda com o gov.br, só dúvida, desistência e já tem advogado(a).</li></ul>"},
     {"k": "Setor por setor", "t": "DAC – Atendimento e Cartório", "h": "<ul><li><b>Assistente de Abertura de PAJ</b>: o atendimento em 10 etapas, do cadastro no SIS-DPU à tramitação, com narrativa, checklist, formulário de renda e formulários.</li><li><b>Meus PAJs</b>: os documentos pendentes de cada PAJ, com as mensagens para o WhatsApp e o SIS-DPU.</li><li><b>Gerenciador</b>: lista de documentos faltantes em 1 folha.</li><li><b>Central de Formulários e Narrativas</b>: 24 formulários em PDF e Word, com preenchimento, e as narrativas de cada demanda.</li><li><b>Mensagens Padronizadas</b>: as mensagens prontas do DAC reunidas num lugar só.</li><li><b>Narrativas</b>: preencher ou só consultar o modelo em branco, para completar no Word.</li></ul>"},
     {"k": "Setor por setor", "t": "DPS – Departamento Processual", "h": "<ul><li><b>Modelos</b>: escolha do tipo de peça, sugestão do modelo pelo resumo do PAJ e o Word com a qualificação preenchida (também pelo Google Docs).</li><li><b>Jurisprudências Comuns e Úteis</b>, por área, com o que dizem e para que servem.</li><li><b>Aprender</b> e o <b>Manual do Estagiário</b> para estudar as demandas.</li></ul>"},
     {"k": "Em números", "t": "O que já está dentro do app", "h": _nums(NUMS_ATDPU)},
     {"k": "Próximos passos", "t": "O que vem por aí", "h": "<ul><li><b>Análise de Demanda e Petições</b> (já no online, com 5 demandas): mais demandas e a petição direto no modelo Word da unidade.</li><li><b>Jurisprudências</b> clicáveis, com o texto oficial e o botão de copiar já formatado para a peça.</li><li><b>Ofícios</b> e <b>Arquivamentos</b> com textos prontos para o SEI-DPU e o SIS-DPU.</li><li><b>Treinamento do DPS</b>: eproc, SEI, pastas e Word.</li><li>Ferramentas do <b>DAD</b> e mais mensagens padronizadas.</li></ul>"},
     {"capa": True, "k": "Obrigado", "t": "Como acessar", "h": f'<div class="slCapa"><span class="slAv">{AV}</span><p>O <b>HUB das versões</b>, em <b>unidadeapp.github.io</b>, tem o link da versão online e o download de todos os apps, sem login. Dúvidas sobre o app: a Têmis ou o Pedro Tomkowski.</p></div>'},
    ]


def slides_terreo(variante, ferr):
    """variante: "" (Térreo), " – DAC" ou " – AG"; ferr: ferramentas do app."""
    nome = "Térreo" + variante
    para = {"": "os departamentos de atendimento, cartório e agendamento", " – DAC": "o atendimento e cartório (DAC)", " – AG": "o agendamento"}[variante]
    itens = []
    if "lista" in ferr: itens.append("<li><b>Documentos Necessários e Mensagem</b>: a lista do que trazer, com o formulário médico, e a mensagem do agendamento para o WhatsApp.</li>")
    if "semAtend" in ferr: itens.append("<li><b>PAJ sem Atendimento</b>: narrativas prontas quando o PAJ não segue (não compareceu, estadual, trabalhista…).</li>")
    if "checklist" in ferr: itens.append("<li><b>Checklist de Documentos</b>: marca o que foi entregue e gera a lista do que falta, em 1 folha, com os textos do WhatsApp e do SIS-DPU.</li>")
    if "central" in ferr: itens.append("<li><b>Central de Formulários</b>: 24 formulários em PDF e Word, com versão para analfabeto e preenchimento no computador.</li>")
    if "mensagens" in ferr: itens.append("<li><b>Mensagens Padronizadas</b>: lembrete de prazo, PAJ arquivado, foto ilegível, como assinar e devolver e documentos recebidos, prontas para o WhatsApp.</li>")
    if "narrativas" in ferr: itens.append("<li><b>Narrativas</b> de cada demanda, prontas para colar no SIS-DPU.</li>")
    return [
     {"capa": True, "k": "Apresentação", "t": nome, "h": f'<div class="slCapa"><span class="slLogoG">{LOGO_T}</span><p>Ferramenta de apoio ao trabalho d{"e " if variante == "" else "o "}{para.replace("os departamentos", "os departamentos") if variante == "" else para} da DPU – Pelotas.</p><p class="slAutor">Desenvolvido por Pedro Tomkowski</p></div>'.replace("do os departamentos", "dos departamentos").replace("de os departamentos", "dos departamentos")},
     {"k": "O que é", "t": f"Uma versão simplificada do Unidade", "h": MAPA + f"<p class=\"slNota\">O <b>{nome}</b> traz só as ferramentas de {para}. Funciona <b>offline</b>: um arquivo no computador, sem instalar nada.</p>"},
     {"k": "Ferramentas", "t": f"O que o {nome} oferece", "h": "<ul>" + "".join(itens) + "<li><b>A DPU Pelotas</b>: endereço, contatos, horários e os 14 municípios atendidos.</li></ul>"},
     {"k": "Ajuda", "t": "Ninguém fica perdido", "h": f'<div class="slLado"><span class="slAv">{AV}</span><ul><li><b>Têmis</b>, a assistente virtual, no canto de baixo de todas as telas: responde dúvidas e leva à ferramenta.</li><li><b>Tour guiado</b> pela Têmis e <b>Tutoriais</b> de cada ferramenta.</li><li>Menu sempre à vista, com <b>Voltar</b> e <b>Início</b>.</li><li><b>Tours interativos</b>: a Têmis pede para você fazer a tarefa de verdade e segue quando você termina.</li><li><b>Modo escuro</b> e impressão legível em qualquer impressora.</li></ul></div>'},
     {"k": "Segurança", "t": "Funciona sem internet", "h": "<ul><li>Nada do que é digitado sai do computador.</li><li>Só a assinatura (nome e cargo) e a escolha do menu ficam guardadas no navegador.</li><li>Formulários, listas e narrativas não ficam guardados.</li></ul>"},
     {"k": "Como conseguir", "t": "Atualizar é baixar o arquivo novo", "h": "<ul><li>O <b>HUB das versões</b> tem o download de todos os apps e o link da versão online do Unidade.</li><li>Abra o arquivo no Google Chrome ou no Microsoft Edge.</li><li>Quem precisa de tudo (Meus PAJs, Assistente de Abertura, DPS, Aprender) usa o <b>Unidade</b>.</li></ul>"},
    ]


CSS = """
  .apres { max-width:1100px; margin:0 auto; text-align:left; }
  .slTopo { display:flex; align-items:center; gap:10px; margin-bottom:12px; flex-wrap:wrap; }
  .slTopo .slTit { color:var(--green); font-size:22px; margin:0; flex:1; }
  .slDica { color:var(--gray); font-size:13.5px; margin-top:10px; }
  .slBt { border:1.5px solid var(--green2); background:#fff; color:var(--green); border-radius:9px; padding:7px 14px; font:700 14px "Segoe UI", Calibri, Arial, sans-serif; cursor:pointer; }
  .slBt:hover { background:#eef6ea; }
  .slPalco { container-type:inline-size; position:relative; aspect-ratio:16/9; max-width:100%; background:#fff; border-radius:18px; box-shadow:0 6px 30px rgba(0,0,0,.1); overflow:hidden; }
  .slPalco:fullscreen { border-radius:0; aspect-ratio:auto; }
  @media (max-width:700px) { .slPalco:not(:fullscreen) { aspect-ratio:3/5; } .sl { padding:7% 6% 20%; } }   /* celular: slide em pé, para o texto caber */
  .sl { position:absolute; inset:0; padding:5% 6% 9%; display:none; flex-direction:column; gap:2.2%; font-family:"Segoe UI", Calibri, Arial, sans-serif; color:#1e1e1e; }
  .sl.on { display:flex; }
  .sl::before { content:""; position:absolute; left:0; right:0; top:0; height:1.2%; min-height:5px; background:linear-gradient(90deg,#4f9a2a 0%,#3f8f3a 45%,#00879a 100%); }
  .sl .k { font-size:clamp(11px, 1.3cqw, 15px); font-weight:800; letter-spacing:.12em; text-transform:uppercase; color:#00879a; }
  .sl h2 { margin:0; font-size:clamp(20px, 3.1cqw, 40px); color:#2f6a1f; line-height:1.15; }
  .sl ul { margin:0; padding-left:1.2em; font-size:clamp(13px, 1.65cqw, 21px); line-height:1.5; } .sl li { margin:.35em 0; }
  .sl p { font-size:clamp(13px, 1.65cqw, 21px); line-height:1.5; margin:0; }
  .sl.slCa { justify-content:center; align-items:center; text-align:center; background:linear-gradient(160deg,#f3f8ef,#fff 60%); }
  .slCapa { display:flex; flex-direction:column; align-items:center; gap:1.6cqw; max-width:80%; }
  .slCapa .slAv { width:clamp(90px, 14cqw, 180px); } .slCapa .slLogoG { width:clamp(80px, 11cqw, 150px); }
  .slAv svg, .slLogoG svg, .slLogo svg { width:100%; height:100%; display:block; }
  .slAutor { color:#7a8276; font-size:clamp(11px, 1.2cqw, 15px) !important; }
  .slLado { display:flex; gap:4%; align-items:center; } .slLado .slAv { width:18%; flex:0 0 auto; }
  .slMapa { display:flex; align-items:center; gap:2%; }
  .slFam { flex:1; border:2px solid #cfdcc8; border-radius:14px; padding:2% 2.5%; display:flex; flex-direction:column; gap:.4em; font-size:clamp(12px, 1.5cqw, 19px); }
  .slFam b { color:#2f6a1f; display:flex; align-items:center; gap:.4em; font-size:1.1em; } .slFam small { color:#5f5f5f; }
  .slLogo { width:1.4em; height:1.4em; display:inline-block; }
  .slFilhos { display:flex; flex-wrap:wrap; gap:.5em; margin-top:.3em; }
  .slFilhos span { border-radius:10px; padding:.3em .7em; font-weight:700; display:flex; flex-direction:column; }
  .slFilhos span small { font-weight:400; font-size:.8em; color:inherit; opacity:.85; }
  .slFilhos .on { background:#e3f4f6; color:#00798b; } .slFilhos .off { background:#e7f2e1; color:#2f6a1f; }
  .slTodos { font-weight:700; color:#2f6a1f !important; }
  .slSeta { font-weight:800; color:#00879a; font-size:clamp(12px, 1.4cqw, 17px); white-space:nowrap; }
  .slNota { margin-top:2% !important; color:#3b4537; }
  .slNums { display:grid; grid-template-columns:repeat(3, 1fr); gap:3%; margin-top:2%; }
  .slNums div { background:#f3f8ef; border-radius:14px; padding:4% 5%; display:flex; flex-direction:column; }
  .slNums b { font-size:clamp(26px, 4.4cqw, 58px); color:#2f6a1f; line-height:1; font-variant-numeric:tabular-nums; }
  .slNums span { font-size:clamp(11px, 1.35cqw, 17px); color:#4b5d41; margin-top:.3em; }
  .slNav { position:absolute; left:0; right:0; bottom:3%; display:flex; align-items:center; justify-content:center; gap:14px; }
  .slNav button { border:0; background:#3f7f2a; color:#fff; width:38px; height:38px; border-radius:50%; font-size:18px; cursor:pointer; }
  .slNav button:disabled { opacity:.3; cursor:default; }
  .slNav .cont { font:700 13px "Segoe UI", Arial, sans-serif; color:#5f5f5f; min-width:60px; text-align:center; }
"""

JS = """<script>
(function () {  // apresentações em slides: setas, teclado e tela cheia (uma ou várias na mesma página)
  const palcos = [...document.querySelectorAll(".slPalco")];
  palcos.forEach(p => {
    const ss = [...p.querySelectorAll(".sl")]; let i = 0;
    const cont = p.querySelector(".cont"), ant = p.querySelector(".ant"), prox = p.querySelector(".prox");
    p.ver = n => { i = Math.max(0, Math.min(ss.length - 1, n)); ss.forEach((s, k) => s.classList.toggle("on", k === i)); cont.textContent = (i + 1) + " de " + ss.length; ant.disabled = i === 0; prox.disabled = i === ss.length - 1; };
    p.passo = d => p.ver(i + d);
    ant.addEventListener("click", () => p.passo(-1)); prox.addEventListener("click", () => p.passo(1));
    const tc = p.closest(".apres").querySelector(".slCheia");
    if (tc) tc.addEventListener("click", () => { try { (document.fullscreenElement ? document.exitFullscreen() : p.requestFullscreen()).catch(() => {}); } catch (e) {} });
    p.ver(0);
  });
  document.addEventListener("keydown", e => {
    const p = document.fullscreenElement && document.fullscreenElement.classList.contains("slPalco") ? document.fullscreenElement : palcos.find(x => x.offsetParent !== null);
    if (!p || /INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || "")) return;
    if (e.key === "ArrowRight" || e.key === "PageDown") { e.preventDefault(); p.passo(1); } else if (e.key === "ArrowLeft" || e.key === "PageUp") { e.preventDefault(); p.passo(-1); }
  });
})();
</script>"""


def html(slides, titulo="Apresentação"):
    corpo = "".join(f'<section class="sl{" slCa" if s.get("capa") else ""}"><div class="k">{s["k"]}</div><h2>{s["t"]}</h2>{s["h"]}</section>' for s in slides)
    return f"""<div class="apres"><div class="slTopo"><h3 class="slTit">{titulo}</h3><button type="button" class="slBt slCheia">Tela cheia</button></div>
  <div class="slPalco">{corpo}<div class="slNav"><button type="button" class="ant" aria-label="Slide anterior">‹</button><span class="cont"></span><button type="button" class="prox" aria-label="Próximo slide">›</button></div></div>
  <p class="slDica">Use as setas na tela ou do teclado para passar. <b>Tela cheia</b> é bom para apresentar num monitor ou projetor.</p></div>"""

# Modo escuro (comum a todos os apps, ao online e ao HUB não; o HUB tem o dele).
# Como funciona: a página principal escurece tudo de uma vez (inverte as cores e gira os tons de volta, então o verde
# continua verde, mas claro sobre fundo escuro). As ferramentas (que abrem dentro da página) escurecem junto; elas só
# "desinvertem" as fotos, os PDFs e a folha da lista, que continuam parecendo papel. A impressão e os PDFs saem sempre
# claros. A escolha fica guardada neste computador (dpuPelotas.tema.v1); sem escolha, segue o modo do sistema.

# ---------- página principal (Unidade, Térreo, online)
CSS = """<style id="temaCss">
  html.escuro { filter:invert(.9) hue-rotate(180deg); background:#fff; }
  html.escuro img, html.escuro video, html.escuro svg { filter:invert(1) hue-rotate(180deg); }   /* fotos e logos com as cores de verdade */
  html.escuro #tourFoco { box-shadow:0 0 0 9999px rgba(230,236,226,.7) !important; }   /* o véu do tour continua escuro */
  @media print { html.escuro, html.escuro * { filter:none !important; } }
  .temaBt { position:fixed; left:16px; bottom:16px; z-index:15; border:1.5px solid #3f7f2a; background:#fff; color:#2f6a1f; border-radius:22px;
            padding:8px 14px; font:700 13.5px "Segoe UI", Calibri, Arial, sans-serif; cursor:pointer; box-shadow:0 2px 10px rgba(0,0,0,.12); }
  .temaBt:hover { background:#eef6ea; }
  @media print { .temaBt { display:none !important; } }
</style>"""

JS = """<button type="button" class="temaBt" id="temaBt" title="Troca entre o modo claro e o modo escuro (vale para todo o app)">☾ Modo escuro</button>
<script>
(function () {  // modo escuro: escolha guardada neste computador; sem escolha, segue o sistema
  const CH = "dpuPelotas.tema.v1", mq = window.matchMedia ? matchMedia("(prefers-color-scheme: dark)") : null;
  let salvo = null; try { salvo = localStorage.getItem(CH); } catch (e) {}
  const escuro = () => salvo ? salvo === "escuro" : !!(mq && mq.matches);
  function avisar(w) { try { w.postMessage({ tema: escuro() ? "escuro" : "claro" }, "*"); } catch (e) {} }
  function aplicar() {
    const e = escuro();
    document.documentElement.classList.toggle("escuro", e);
    const b = document.getElementById("temaBt"); if (b) b.textContent = e ? "☀ Modo claro" : "☾ Modo escuro";
    document.querySelectorAll("iframe").forEach(f => avisar(f.contentWindow));
  }
  function trocar() { salvo = escuro() ? "claro" : "escuro"; try { localStorage.setItem(CH, salvo); } catch (e) {} aplicar(); }
  window.dpuTema = { trocar, escuro };
  document.getElementById("temaBt").addEventListener("click", trocar);
  window.addEventListener("message", e => {   // as ferramentas perguntam o tema ao abrir e podem pedir a troca pelo menu delas
    const d = e.data || {};
    if (d.temaPergunta && e.source) avisar(e.source);
    if (d.temaTrocar) trocar();
  });
  if (mq && mq.addEventListener) mq.addEventListener("change", aplicar);
  aplicar();
})();
</script>"""

# ---------- ferramentas (entra pelo menu ao lado, comum/lateral.py)
CSS_FERR = """
  html.escuroPai img, html.escuroPai video, html.escuroPai canvas, html.escuroPai iframe, html.escuroPai embed, html.escuroPai object,
  html.escuroPai .ladoMarca svg, html.escuroPai .sheet, html.escuroPai .fpage { filter:invert(1) hue-rotate(180deg); }
  html.escuroPai .sheet img, html.escuroPai .sheet svg, html.escuroPai .fpage img { filter:none; }
  @media print { html.escuroPai, html.escuroPai * { filter:none !important; } }"""

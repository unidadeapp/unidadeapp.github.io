"""Demandas e documentos (linguagem para o assistido), a partir do checklist de aberturas e do manual.
Indeferimento do INSS, formulário de renda, redução a termo e outorga ficam com o atendimento e não entram na lista.
O trecho entre ** ** é o nome do documento (sai em negrito); o resto é explicação (letra normal)."""

FORM_MED = "**Formulário médico da Defensoria** preenchido pelo(a) médico(a)"
FORM_MED_SUS = "**Formulário médico da Defensoria** preenchido por médico(a) do SUS"
EXAMES = "**Exames e demais documentos médicos**"
ORC = "**Três orçamentos** com data, carimbo ou assinatura e dados bancários"
PROTOCOLO = "**Protocolo do pedido na Secretaria de Saúde**"
FILA = "**Atestado médico** com CID explicando por que não pode esperar na fila"
TESTEMUNHAS = "**Nome, telefone e endereço de três testemunhas**"
CADU = "**Comprovante de inscrição no Cadastro Único (CadÚnico)**"

F_BENEF = ["beneficio"]

DEMANDAS = [
    # ---------------- previdenciário ----------------
    ("Previdenciário", "Auxílio-doença", {"prev": True, "forms": F_BENEF, "docs": [
        "**Atestado médico** com CID e nome da doença, indicando incapacidade para o trabalho", FORM_MED, EXAMES]}),
    ("Previdenciário", "Aposentadoria por invalidez", {"prev": True, "forms": F_BENEF, "docs": [
        "**Atestado médico** com CID e nome da doença, indicando incapacidade permanente para o trabalho", FORM_MED, EXAMES]}),
    ("Previdenciário", "Benefício assistencial (BPC/LOAS) à pessoa com deficiência", {"prev": True, "cadunico": True, "forms": ["loas"], "docs": [
        "**Atestado médico** com CID e nome da doença, indicando as limitações que ela causa", FORM_MED, EXAMES,
        "**Notas fiscais e contas** dos gastos da família", "**Avaliação escolar**, se a pessoa estuda", CADU]}),
    ("Previdenciário", "Benefício assistencial (BPC/LOAS) à pessoa idosa", {"prev": True, "cadunico": True, "docs": [
        "**Notas fiscais e contas** dos gastos da família", CADU]}),
    ("Previdenciário", "Adicional de 25% na aposentadoria", {"prev": True, "forms": ["adicional"], "docs": [
        "**Carta de concessão da aposentadoria**",
        "**Atestado médico** com CID e nome da doença, indicando incapacidade e necessidade de acompanhante permanente",
        FORM_MED, EXAMES]}),
    ("Previdenciário", "Pensão por morte", {"prev": True, "docs": [
        "**Certidão de óbito**", "**Certidão de casamento**, se eram casados", "**Provas da união**, se não eram casados",
        "**Certidão de inexistência de dependentes**", TESTEMUNHAS]}),
    ("Previdenciário", "Aposentadoria por idade ou por tempo de contribuição", {"prev": True, "docs": [
        "**Carnês ou guias de contribuição ao INSS**"]}),
    ("Previdenciário", "Aposentadoria rural", {"prev": True, "docs": [
        "**Talão de notas do produtor rural** (modelo XV)", "**Provas do trabalho rural**"]}),
    ("Previdenciário", "Seguro-defeso (pescador artesanal)", {"prev": True, "docs": [
        "**Protocolo do pedido feito ao INSS**", "**Carteira de pescador artesanal** (RGP)",
        "**Pedido de renovação da licença de pesca** do ano anterior, feito ao IBAMA", "**Talão de notas do produtor rural** (modelo XV)",
        "**Documento da embarcação**", "**Notas fiscais de venda do pescado**", "**Provas de que não há outra renda** além da pesca"]}),
    ("Previdenciário", "Salário-maternidade", {"prev": True, "docs": ["**Certidão de nascimento da criança**"]}),
    ("Previdenciário", "Auxílio-reclusão", {"prev": True, "docs": ["**Atestado de reclusão** da unidade prisional"]}),
    ("Previdenciário", "Alvará judicial", {"docs": [
        "**Certidão de óbito**", "**Certidão de nascimento ou de casamento**", "**Documentos pessoais da pessoa falecida**",
        "**Certidão de inexistência de dependentes**", "**Declaração de herdeiros**"]}),
    ("Previdenciário", "Revisão de aposentadoria ou de pensão por morte", {"prev": True, "docs": [
        "**Carta de concessão do benefício**", "**Memória de cálculo do benefício**"]}),

    # ---------------- cível ----------------
    ("Cível", "Auxílio Reconstrução", {"docs": [
        "**Comprovante de residência do imóvel atingido**, da época",
        "**Comprovante da estadia** em abrigo ou casa de terceiro (dono, endereço, se foi gratuita e duração)",
        "**Fotos e outras provas** dos danos na casa", "**Documento de evacuação da Defesa Civil**",
        "**Print do Google Maps** com a localização da casa", "**Comprovantes de gastos com a estadia**, se houver", TESTEMUNHAS]}),
    ("Cível", "Bolsa Família", {"cadunico": True, "docs": [
        CADU, "**Print do aplicativo** Bolsa Família ou Caixa Tem com a situação do benefício",
        "**Carta de bloqueio ou de indeferimento**, se tiver"]}),
    ("Cível", "Auxílio Gás", {"cadunico": True, "docs": [
        CADU, "**Print do aplicativo** Bolsa Família ou Caixa Tem com a situação dos benefícios",
        "**Carta de indeferimento**, se tiver"]}),
    ("Cível", "Financiamento estudantil", {"docs": [
        "**Contrato com o banco**", "**Contrato com a instituição de ensino**", "**Negativa da instituição**, se houver"]}),
    ("Cível", "Financiamento habitacional", {"docs": [
        "**Contrato com o banco**", "**Comprovantes de pagamento**", "**Contrato com a imobiliária ou construtora**",
        "**Matrícula atualizada do imóvel**", "**Mandado de citação**, se recebeu"]}),
    ("Cível", "Execução fiscal", {"docs": ["**Mandado de citação ou de intimação**"]}),
    ("Cível", "Ingresso em instituição de ensino", {"docs": [
        "**Edital**", "**Notas e classificação**", "**Histórico escolar**", "**Negativa de matrícula** ou protocolo de comparecimento"]}),
    ("Cível", "Descontos indevidos em benefício do INSS", {"docs": [
        "**Extratos bancários** com os descontos", "**Número do benefício**", "**Contratos com bancos ou financeiras**, se tiver"]}),
    ("Cível", "Concurso público", {"docs": ["**Edital**", "**Notas e classificação**", "**Decisão de indeferimento**"]}),
    ("Cível", "Empréstimo bancário", {"docs": ["**Contrato do empréstimo**", "**Extratos bancários** com as parcelas"]}),
    ("Cível", "Juros abusivos", {"docs": ["**Contrato**", "**Demonstrativo do saldo devedor**"]}),
    ("Cível", "Permanência no país (refúgio)", {
        "residencia": "**Comprovante de residência** em nome próprio ou declaração do(a) proprietário(a) do imóvel com firma reconhecida",
        "docs": ["**Protocolo do pedido ao CONARE**", "**Passaporte**", "**Endereço de e-mail**", "**Certificados de cursos**, se tiver"]}),
    ("Cível", "Reconhecimento de nacionalidade brasileira", {"docs": [
        "**Documento que comprove que o pai ou a mãe é brasileiro(a)**", "**Certidão de nascimento estrangeira**, com tradução pública",
        "**Provas do tempo de moradia no Brasil**"]}),
    ("Cível", "FGTS e PIS", {"docs": [
        "**Número do PIS ou Cartão Cidadão**", "**RAIS** (pedidos do PIS)", "**Extrato do FGTS desde 1991** (pedidos do FGTS)"]}),
    ("Cível", "Saque indevido do FGTS ou do PIS", {"docs": ["**Extratos ou outras provas do saque**", "**Negativa da Caixa**, se tiver"]}),
    ("Cível", "Reintegração ou defesa da posse", {"docs": [
        "**Contrato de compra e venda do imóvel**", "**Matrícula do imóvel**", "**Provas da posse, propriedade ou ocupação** do imóvel",
        "**Comprovantes do tempo de ocupação** (principalmente mais de 5 anos)", "**Certidão de registros de imóveis** em nome do(a) assistido(a)"]}),
    ("Cível", "Seguro-desemprego", {"docs": [
        "**Pedido do seguro-desemprego**", "**Negativa do pedido**", "**Termo de rescisão do contrato de trabalho**"]}),
    ("Cível", "Seguro-desemprego (com empresa no nome do assistido)", {"docs": [
        "**Pedido do seguro-desemprego**", "**Negativa do pedido**", "**Termo de rescisão do contrato de trabalho**",
        "**Declaração de inatividade da empresa** na Receita Federal", "**RAIS**", "**Contrato social e comprovante de baixa da empresa**", TESTEMUNHAS]}),
    ("Cível", "Seguro DPVAT (acidentes até 14/11/2023)", {"docs": [
        "**CNH**", "**Registro de ocorrência do acidente**", "**Pedido do seguro** feito à Caixa",
        "**Laudos e receitas médicas**", "**Comprovantes das despesas** com o acidente"]}),
    ("Cível", "Outros casos", {"docs": ["**Relato detalhado do caso**", "**Negativa do órgão ou da instituição**, se houver"]}),

    # ---------------- saúde ----------------
    ("Saúde", "Medicamentos", {"forms": ["med6", "med"], "docs": [
        "**Negativas das farmácias** municipal e estadual", "**Negativa da unidade oncológica** (casos de câncer)", "**Receita médica do SUS**",
        FORM_MED_SUS, "**Três orçamentos do medicamento** com data, carimbo ou assinatura e dados bancários da farmácia", "**Exames**"]}),
    ("Saúde", "Tratamento", {"forms": ["tratamento"], "docs": [
        "**Pedido do tratamento** por médico(a) do SUS", PROTOCOLO, FORM_MED_SUS, FILA, ORC, "**Exames**, se tiver"]}),
    ("Saúde", "Cirurgia", {"forms": ["cirurgia"], "docs": ["**Pedido da cirurgia** por médico(a) do SUS", PROTOCOLO, FORM_MED_SUS, FILA, ORC]}),
    ("Saúde", "Consulta com especialista", {"docs": ["**Pedido da consulta** por médico(a) do SUS", PROTOCOLO, FILA, ORC]}),
    ("Saúde", "Exame", {"forms": ["exame"], "docs": ["**Pedido do exame** por médico(a) do SUS", PROTOCOLO, FORM_MED_SUS, FILA, ORC]}),
    ("Saúde", "Dieta especial", {"docs": ["**Negativa da Secretaria de Saúde**", "**Atestado médico do SUS** com CID e nome da doença", ORC]}),
    ("Saúde", "Internação ou transferência hospitalar", {"forms": ["uti"], "docs": [
        PROTOCOLO, "**Atestado médico do SUS** com CID e nome da doença, explicando por que não pode esperar na fila", FORM_MED_SUS]}),
    ("Saúde", "Tratamento oncológico", {"forms": ["onco"], "docs": [
        "**Laudo médico ou anatomopatológico** com diagnóstico, CID e data do diagnóstico", "**Receita ou prescrição do tratamento**",
        "**Comprovante do pedido** no sistema de regulação ou ao SUS",
        "**Formulário médico da Defensoria** sobre tratamento oncológico, preenchido pelo(a) médico(a)",
        "**Negativa da unidade oncológica**", "**Declaração de vínculo com a unidade oncológica**"]}),
    ("Saúde", "Tratamento fora do domicílio (TFD)", {"docs": [
        "**Laudo médico** indicando o tratamento fora da cidade e, se for o caso, a necessidade de acompanhante",
        "**Comprovante do agendamento**, se houver", "**Comprovante do pedido ao SUS**"]}),
    ("Saúde", "Ressarcimento de gastos com saúde particular", {"docs": [
        "**Documentos médicos**", "**Comprovantes de pagamento** do procedimento ou do remédio", "**Outros comprovantes dos gastos**"]}),

    # ---------------- criminal ----------------
    ("Criminal", "Defesa em processo criminal", {"docs": [
        "**Mandado de citação ou de intimação**", "**Nome, telefone e endereço das testemunhas** que viram os fatos, se houver",
        "**Três declarações de boa conduta** (modelo da Defensoria)"]}),
    ("Criminal", "Audiência de acordo de não persecução penal (ANPP)", {"docs": [
        "**Notificação do Ministério Público Federal**", "**Proposta de acordo** do Ministério Público Federal",
        "Se não aceitar o acordo: **nome, telefone e endereço das testemunhas e três declarações de boa conduta**"]}),
]

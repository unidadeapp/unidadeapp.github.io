from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, json, sys
sys.path.insert(0, RAIZ + "lista")
from demandas import DEMANDAS

logo = base64.b64encode(open(RAIZ + "src/img-002.jpg", "rb").read()).decode()
wm = base64.b64encode(open(RAIZ + "src/watermark.png", "rb").read()).decode()
forms = json.load(open(RAIZ + "lista/forms.json"))
data = [{"area": a, "nome": n, **o} for a, n, o in DEMANDAS]
import re
bold = lambda t: re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
for d in data:
    d["docs"] = [bold(x) for x in d["docs"]]
    if "residencia" in d: d["residencia"] = bold(d["residencia"])
    for k in d.get("forms", []):
        assert k in forms, k

HTML = r"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="color-scheme" content="only light"><!-- o "modo escuro forçado" de alguns navegadores (ex.: Opera GX) não escurece a página nem a impressão -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Lista de Documentos Necessários – DPU Pelotas</title>
<style>
  :root { --ink:#1e1e1e; --gray:#5f5f5f; --green:#3f7f2a; --band:#e2efd9; --soft:#f3f8ef; --line:#c9d6c2; }
  * { box-sizing: border-box; }
  body { margin:0; background:#eef1ec; color:var(--ink); font-family: Cambria, Caladea, Georgia, "Times New Roman", serif; }
  .ui { font-family: "Segoe UI", Calibri, Carlito, Arial, sans-serif; }

  /* ---------- painel de controle ---------- */
  .panel { max-width: 820px; margin: 24px auto 16px; background:#fff; border-radius:12px; padding:18px 22px 16px;
           box-shadow: 0 1px 3px rgba(0,0,0,.08); }
  .panel h1 { font-size:18px; margin:0 0 2px; color:var(--green); }
  .panel p.sub { margin:0 0 14px; color:var(--gray); font-size:13.5px; }
  .row { display:flex; gap:14px; flex-wrap:wrap; align-items:flex-end; }
  label.f { display:flex; flex-direction:column; font-size:12.5px; color:var(--gray); gap:4px; }
  .combo { position:relative; flex: 1 1 360px; }
  .combo input { width:100%; }
  input[type=text], input[type=date], input[type=time] { font: inherit; font-size:15px; padding:9px 11px; border:1px solid #c8cfc4;
           border-radius:8px; color:var(--ink); background:#fff; }
  input:focus { outline:2px solid #9cc58a; border-color:#7fb06b; }
  .list { position:absolute; z-index:10; left:0; right:0; top:100%; margin-top:4px; background:#fff; border:1px solid #c8cfc4;
          border-radius:10px; box-shadow:0 8px 24px rgba(0,0,0,.12); max-height:360px; overflow:auto; display:none; }
  .list.open { display:block; }
  .grp { font-size:11px; letter-spacing:.08em; text-transform:uppercase; color:var(--green); font-weight:700; padding:10px 12px 4px; }
  .opt { padding:7px 14px; cursor:pointer; font-size:14.5px; text-transform: uppercase; }
  #dem { text-transform: uppercase; }
  #dem::placeholder { text-transform: none; }
  .opt:hover, .opt.act { background:var(--soft); }
  .none { padding:12px 14px; color:var(--gray); font-size:14px; }
  .btns { display:flex; gap:10px; margin-top:14px; flex-wrap:wrap; }
  button { font: inherit; font-size:14.5px; border-radius:8px; padding:9px 16px; cursor:pointer; border:1px solid transparent; }
  .primary { background:var(--green); color:#fff; }
  .primary:hover { background:#356c23; }
  .ghost { background:#fff; border-color:#c8cfc4; color:var(--ink); }
  .ghost:hover { background:#f4f6f2; }
  .hint { font-size:12.5px; color:var(--gray); margin-top:10px; }
  .acoes { margin-top:16px; }
  .acoes .tt { font-size:15px; font-weight:700; color:var(--ink); margin-bottom:8px; }
  .acoes .t { font-size:13px; color:var(--gray); }
  .grade { display:grid; grid-template-columns: repeat(3, 1fr); gap:10px; }
  .acao { display:flex; gap:10px; align-items:flex-start; text-align:left; background:#fff; border:2px solid var(--green); color:var(--green);
          border-radius:10px; padding:11px 12px; line-height:1.25; }
  .acao b { display:block; font-size:15px; }
  .acao small { display:block; font-size:13px; color:var(--ink); margin-top:3px; font-weight:400; }
  .acao .n { flex:0 0 26px; height:26px; border-radius:50%; background:var(--green); color:#fff; font-weight:700; font-size:14px;
             display:flex; align-items:center; justify-content:center; }
  .acao:hover { background:#eef6ea; }
  .acao.cheia { background:var(--green); color:#fff; }
  .acao.cheia small { color:#e6f2df; }
  .acao.cheia .n { background:#fff; color:var(--green); }
  .acao.cheia:hover { background:#356c23; }
  .acao[hidden] { display:none; }
  .modelo { margin-top:8px; font-size:14px; display:none; }
  .modelo label { margin-right:16px; cursor:pointer; }
  .modelo input { accent-color: var(--green); width:16px; height:16px; vertical-align:-3px; }
  .semform { margin-top:8px; font-size:13px; color:var(--gray); display:none; }
  .decl { display:flex; gap:10px; align-items:stretch; margin-top:12px; padding-top:12px; border-top:1px dashed #c8cfc4; flex-wrap:wrap; }
  .decl .acao { flex:1 1 420px; border-color:#7a8f6e; color:#4b5d41; }
  .decl .acao .n { background:#7a8f6e; }
  .decl .ghost { align-self:center; }

  /* ---------- visual unificado com os demais apps do app Unidade ---------- */
  .panel { max-width: 980px; border-radius:16px; padding:24px 28px 20px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
  .panel h1 { font-size:26px; margin:0 0 4px; color:#2f6a1f; }
  .panel p.sub { font-size:15px; line-height:1.5; margin:0 0 18px; }
  label.f { font-size:13px; font-weight:600; }
  input[type=text], input[type=date], input[type=time] { font-size:16px; padding:10px 12px; border:1.5px solid #cfdcc8; border-radius:9px; }
  input:focus { outline:none; border-color:#3f7f2a; box-shadow:0 0 0 3px rgba(63,127,42,.15); }
  .ghost { border:1.5px solid #3f7f2a; color:#2f6a1f; font-weight:700; }
  .ghost:hover { background:#eef6ea; }
  .acoes .tt { font-size:17px; color:#2f6a1f; }
  .acao { border-radius:12px; padding:13px 14px; }
  .acao b { font-weight:800; letter-spacing:.02em; }
  .hint { font-size:13px; line-height:1.5; }
  .modoSaida { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin:0 0 10px; }
  .modoSaida .ms { font-size:13.5px; font-weight:700; color:var(--ink); }
  .modoSaida button { border:2px solid var(--green); background:#fff; color:var(--green); border-radius:20px; padding:6px 16px; font-weight:800; font-size:13.5px; cursor:pointer; }
  .modoSaida button.on { background:var(--green); color:#fff; }
  .modoSaida small { flex:1 1 260px; font-size:12.5px; color:var(--gray); line-height:1.4; }

  /* mensagem do agendamento para o WhatsApp */
  .saidaFundo { position:fixed; inset:0; background:rgba(20,30,15,.45); z-index:60; display:flex; align-items:center; justify-content:center; padding:16px; }
  .saidaFundo[hidden] { display:none; }
  .saidaJan { background:#fff; border-radius:14px; padding:18px 20px; max-width:360px; width:100%; display:flex; flex-direction:column; gap:12px; box-shadow:0 10px 40px rgba(0,0,0,.25); text-align:center; }
  .saidaJan b { font-size:16px; color:#2f6a1f; } .saidaBts { display:flex; gap:10px; } .saidaBts button { flex:1; padding:12px 10px; font-weight:800; }
  .sheet.instr { padding:14mm 18mm; } .instrT { font-weight:800; font-size:14pt; color:#2f6a1f; margin-bottom:8px; letter-spacing:.04em; } .sheet.instr p { font-size:11.5pt; line-height:1.5; margin:6px 0; }
  .msgAg { margin-top:14px; padding-top:14px; border-top:1px dashed #c8cfc4; }
  .msgAg .tt { font-size:17px; font-weight:700; color:#2f6a1f; margin-bottom:8px; }
  .msgAg .lin { display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap; }
  .msgAg label.f { flex:1 1 260px; } .msgAg label.f input { width:100%; }
  .msgAg .acao { flex:1 1 360px; }
  .msgAg .vera { display:flex; align-items:center; gap:8px; flex-wrap:wrap; font-size:12.5px; color:var(--gray); }
  .vera .veraBt { margin-left:auto; }
  .souVera { margin-top:8px; font-size:13px; }
  .veraBox { margin-top:8px; padding:10px 12px; border:1.5px dashed #c8cfc4; border-radius:10px; background:#fafcf8; }
  .veraBox .azar { font-size:13px; color:#4b5d41; margin-bottom:6px; }
  .veraBox label.f.cargo { flex:0 1 200px; } .veraBox select { width:100%; padding:9px 10px; border:1.5px solid #cfdcc8; border-radius:9px; font:inherit; }
  .msgAg .erroMsg { color:#b04a3a; font-size:14px; font-weight:600; margin-top:6px; min-height:1em; }
  .msgOut { max-width:210mm; margin:0 auto 30px; background:#fff; border-radius:14px; padding:18px 22px; box-shadow:0 1px 3px rgba(0,0,0,.08); }
  .msgOut h2 { margin:0 0 4px; font-size:19px; color:#2f6a1f; }
  .msgOut p { margin:0 0 10px; font-size:13.5px; color:var(--gray); }
  .msgOut textarea { width:100%; min-height:420px; font:inherit; font-family:"Segoe UI", Calibri, Arial, sans-serif; font-size:14.5px; line-height:1.45; padding:12px; border:1.5px solid #cfdcc8; border-radius:9px; resize:vertical; }
  .msgOut .bts { display:flex; gap:10px; align-items:center; margin-top:10px; flex-wrap:wrap; }
  .msgOut .ok { color:#2f6a1f; font-weight:700; font-size:14px; }
  .fim { max-width: 980px; margin: 22px auto 40px; display:flex; justify-content:center; }
  .voltarMenu { border:1.5px solid #3f7f2a; background:#fff; color:#2f6a1f; border-radius:12px; padding:13px 26px; font-weight:800; font-size:15px; letter-spacing:.03em; min-width:340px; cursor:pointer; font-family:"Segoe UI", Calibri, Arial, sans-serif; }
  .voltarMenu:hover { background:#eef6ea; }

  /* ---------- folha ---------- */
  /* tons mais escuros na folha: a impressão em preto e branco sai firme */
  .sheet { --green:#265418; --gray:#444; --line:#b9c7b1; }
  .sheet { position:relative; width: 210mm; min-height: 297mm; margin: 0 auto 40px; background:#fff; padding: 14mm 18mm 16mm;
           box-shadow: 0 2px 10px rgba(0,0,0,.12); overflow:hidden; }
  .wm { position:absolute; right: 7mm; bottom: 4mm; width: 62mm; opacity:.9; pointer-events:none; z-index:0; }
  .sheet > :not(.wm) { position: relative; z-index: 1; }
  .head { display:flex; align-items:flex-end; justify-content:space-between; border-bottom: 0.6pt solid #bfbfbf; padding-bottom: 2mm; margin-bottom: 3mm; }
  .head img { height: calc(12mm * var(--k, 1)); display:block; }
  .head .addr { font-size: calc(8.3pt * var(--k, 1)); color: var(--gray); line-height:1.3; text-align:right; }
  .titulo { background: var(--band); text-align:center; padding: 2mm 4mm; margin-bottom: 2.5mm; }
  .titulo .k { font-weight:700; letter-spacing:.12em; font-size: calc(10.5pt * var(--k, 1)); }
  .titulo .d { font-weight:700; font-size: calc(15pt * var(--k, 1)); margin-top: 0.5mm; color: var(--green); }
  .titulo .d.vazio { color:#9aa596; font-weight:400; font-style:italic; font-size: calc(12.5pt * var(--k, 1)); }

  /* a folha é uma coluna: o espaço que sobrar vai para a lista, distribuído entre os itens */
  .sheet { display:flex; flex-direction:column; }
  #docs { counter-reset: n; flex: 1 1 auto; display:flex; flex-direction:column; }
  .sec { display:flex; flex-direction:column; flex: var(--g, 1) 1 auto; }
  .sec ol.docs { flex: 1 1 auto; display:flex; flex-direction:column; justify-content: space-evenly; }
  .sh { font-weight:700; letter-spacing:.1em; font-size: calc(9.5pt * var(--k, 1)); color: var(--green); margin: calc(2.6mm + 1.5 * var(--gap, 0mm)) 0 0.8mm; padding-bottom: 0.4mm;
        border-bottom: 0.6pt solid var(--line); }
  .sec:first-child .sh { margin-top: 0; }
  .sh .obs { letter-spacing: 0; font-weight: 400; font-size: 1.05em; color: var(--ink); }
  ol.docs { margin: 0; padding: 0; list-style: none; font-size: var(--fs, 12pt); line-height: 1.28; }
  /* medição: geometria igual à da impressão, para ajustar o tamanho da letra */
  body.medindo .sheet { padding: 8.5mm 17mm 8mm; min-height: 0 !important; }
  body.medindo ol.docs li { padding-right: 0; margin-right: 0; }
  body.medindo .add, body.medindo .x { display: none; }
  ol.docs li { position: relative; padding: calc(0.6mm + var(--gap, 0mm)) 0 calc(0.6mm + var(--gap, 0mm)) 2.05em; counter-increment: n; }
  ol.docs li::before { content: counter(n) "."; position:absolute; left:0; width:1.55em; text-align:right; color: var(--green); font-weight:700; }
  .it { outline:none; }
  .it:focus { background:#fffbe6; }
  .sub { font-size: 0.83em; color: var(--gray); margin-top: 0.3mm; line-height:1.25; }
  .sub.anx { color: var(--green); font-weight:700; }
  @media screen { ol.docs li { padding-right: 10mm; margin-right: -10mm; } }
  .x { position:absolute; right:0; top:50%; transform: translateY(-50%); width:8mm; height:8mm; border:0; border-radius:50%; background:none; color:#b04a3a; font-size:18px; line-height:1; padding:0; cursor:pointer; opacity:.35; }
  li:hover .x { opacity:1; }
  @keyframes tourPulso { 50% { box-shadow:0 0 0 3px #d93a2b, 0 0 0 11px rgba(217,58,43,.12); } }
  .x:hover { background:#f6e3df; }
  .add { display:flex; gap:8px; margin: 2mm 0 0 8mm; }
  .add input { flex:1; font-size:13.5px; padding:7px 10px; }
  .add button { padding:7px 12px; font-size:13.5px; }

  .imp { margin-top: calc(3mm + 1.5 * var(--gap, 0mm)); border-left: 3pt solid var(--green); background: var(--soft); padding: 2mm 4mm; font-size: 11.5pt; line-height:1.3; white-space: nowrap; }
  .imp .k { font-weight:700; letter-spacing:.06em; color: var(--green); margin-right: 1mm; }
  .imp.prz { white-space: normal; margin-top: calc(1.5mm + 0.8 * var(--gap, 0mm)); }
  .prazoSel { margin-top:14px; }
  .prazoSel .tt2 { font-size:13px; color:var(--gray); margin-bottom:6px; font-family:"Segoe UI", Calibri, Arial, sans-serif; }
  .prazoSel .bts { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .prazoSel button { border:2px solid var(--line); background:#fff; border-radius:12px; padding:11px 16px; text-align:left; font-family:"Segoe UI", Calibri, Arial, sans-serif; cursor:pointer; }
  .prazoSel button b { display:block; font-size:16px; letter-spacing:.04em; color:var(--green); }
  .prazoSel button small { font-size:13px; color:var(--gray); }
  .prazoSel button:hover { background:#f6faf3; }
  .prazoSel button.on { border-color:var(--green); background:#eef6ea; box-shadow:inset 0 0 0 1px var(--green); }
  .prazoSel button.urg b { color:#b03a2e; }
  .prazoSel button.urg.on { border-color:#b03a2e; background:#fbefe9; box-shadow:inset 0 0 0 1px #b03a2e; }
  .dia { margin-top: calc(3mm + 1.5 * var(--gap, 0mm)); border: 1.3pt solid var(--green); border-radius: 3mm; padding: 1.6mm 4mm 1.8mm; text-align:center; background:#fff; }
  .dia .k { font-weight:700; letter-spacing:.14em; font-size: calc(9.5pt * var(--k, 1)); color: var(--green); }
  .dia .v { font-weight:700; font-size: calc(14pt * var(--k, 1)); line-height: 1.15; margin-top: 0.3mm; white-space: nowrap; }
  .dia .v .b { display:inline-block; min-width: 10mm; border-bottom: 1pt solid #333; }
  .dia .v .b.ano { min-width: 8mm; }
  .dia .v .b.sem { min-width: 24mm; }
  .dia .ret { font-size: calc(8.6pt * var(--k, 1)); line-height: 1.25; margin: 0.7mm 0 1.2mm; }
  .cont { background: var(--soft); border-radius: 2mm; padding: 1.3mm 1mm 1.1mm; line-height: 1.2;
          -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .canais { display:grid; grid-template-columns: 1.25fr 1fr; grid-template-rows: auto auto auto; }
  .canais > div { padding: 0 3mm; display:grid; grid-row: span 3; grid-template-rows: subgrid; }
  .canais > div + div { border-left: 0.8pt solid var(--line); }
  .cont .ck { font-size: calc(8pt * var(--k, 1)); font-weight:700; letter-spacing:.05em; color: var(--green); text-transform: uppercase; }
  .cont .cv { font-weight:700; font-size: calc(10pt * var(--k, 1)); margin: 0.2mm 0 0.2mm; }
  .cont .cn { font-size: calc(8.3pt * var(--k, 1)); }
  .cont .hor { border-top: 0.8pt solid var(--line); margin: 1mm 3mm 0; padding-top: 0.8mm; font-size: calc(8.6pt * var(--k, 1)); }

  /* ---------- formulários anexos ---------- */
  .fpage { width: 210mm; height: 297mm; margin: 0 auto 40px; background:#fff; box-shadow: 0 2px 10px rgba(0,0,0,.12); }
  .fpage img { width: 100%; height: 100%; display:block; }
  @media screen { #anexos { position:absolute; left:-99999px; top:0; } }

  @page { size: A4; margin: 0; }
  @media print {
    body { background:#fff; }
    .no-print { display:none !important; }
    .sheet { margin:0; box-shadow:none; width:auto; min-height: calc(100vh - 2mm); height:auto; overflow:visible; padding: 8.5mm 17mm 8mm;
             -webkit-box-decoration-break: clone; box-decoration-break: clone; }
    .dia, .imp, .sh { break-inside: avoid; }
    .sh { break-after: avoid; }
    .titulo, .imp { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    ol.docs li { break-inside: avoid; }
    body.so-form .sheet:not(.instr) { display:none !important; }
    #anexos .sheet.instr { break-before: page; min-height:auto !important; }
    body.so-form #anexos .sheet.instr:first-child { break-before: auto; }
    #anexos .instr + .fpage { break-before: page; }
    /* Firefox: caixa que não cabe inteira na página vai para a página seguinte e deixa uma folha em branco antes;
       por isso as alturas acompanham a área útil da página (100vh na impressão) em vez de 297 mm fixos */
    html, body { margin:0 !important; padding:0 !important; height:auto !important; }
    #anexos { position:static !important; }
    .fpage { margin:0; box-shadow:none; break-before: auto; width: 100%; height: calc(100vh - 1mm); overflow: hidden; }
    .fpage img { object-fit: contain; }
    .fpage + .fpage { break-before: page; }
    body:not(.so-form) #anexos .fpage:first-child { break-before: page; }
    /* impressão sempre legível, também em impressora preto e branco: textos e linhas escuros (o SALVAR EM PDF mantém as cores da tela) */
    html:not(.pdfCor) .sheet, html:not(.pdfCor) .sheet * { color:#000 !important; }
    html:not(.pdfCor) .sheet *:not(img) { border-color:#555 !important; }
  }
</style>
</head>
<body>

<div class="panel ui no-print">
  <h1>Lista de Documentos Necessários</h1>
  <p class="sub">Digite ou escolha a demanda. A lista abaixo se preenche sozinha e pode ser ajustada antes de imprimir.</p>
  <div class="row">
    <label class="f combo">Demanda
      <input id="dem" type="text" placeholder="Ex.: auxílio-doença, cirurgia, Bolsa Família…" autocomplete="off" role="combobox" aria-expanded="false" aria-controls="lst">
      <div id="lst" class="list" role="listbox"></div>
    </label>
    <label class="f">Dia do atendimento<input id="data" type="date"></label>
    <label class="f">Horário<input id="hora" type="time"></label>
  </div>
  <div class="prazoSel" id="prazoSel"><div class="tt2">Prazo para entregar os documentos que faltarem:</div>
    <div class="bts"><button type="button" class="on" data-prazo="30 dias"><b>PRAZO NORMAL</b><small>30 dias</small></button><button type="button" class="urg" data-prazo="48 horas"><b>PAJ URGENTE</b><small>48 horas</small></button></div></div>
  <div class="acoes">
    <div class="tt">O que você quer imprimir ou salvar?</div>
    <div class="grade">
      <button class="acao cheia" id="aTudo"><span class="n">1</span><span><b>TUDO</b><small id="aTudoD">A lista, o formulário médico e as declarações de residência (opcionais), num arquivo só</small></span></button>
      <button class="acao med" id="imprimir"><span class="n">2</span><span><b>SÓ A LISTA</b><small>A lista de documentos</small></span></button>
      <button class="acao med" id="aMedico"><span class="n">3</span><span><b>SÓ O FORMULÁRIO MÉDICO</b><small>Para levar ao(à) médico(a)</small></span></button>
      <button class="acao med" id="aDecl"><span class="n">4</span><span><b>SÓ AS DECLARAÇÕES</b><small>Do titular do comprovante e de residência, com a explicação de quando usar cada uma (opcionais)</small></span></button>
    </div>
    <div class="saidaFundo" id="saidaFundo" hidden><div class="saidaJan" role="dialog" aria-label="Imprimir ou baixar">
      <b>O que você quer fazer?</b>
      <div class="saidaBts"><button type="button" class="primary" id="saidaImp">IMPRIMIR</button><button type="button" class="primary" id="saidaPdf">BAIXAR EM PDF</button></div>
      <button type="button" class="ghost" id="saidaCanc">Cancelar</button></div></div>
    <div class="modelo" id="modelo"></div>
    <div class="semform" id="semform">Esta demanda não tem formulário médico.</div>
    <div style="display:flex;gap:10px;align-items:center;margin-top:8px;flex-wrap:wrap">
      <button class="primary" id="abrirForm" style="display:none">Abrir o formulário médico</button>
      <div class="t" id="fmsg" style="margin:0;flex:1 1 300px"></div>
    </div>
    <div class="decl">
      <button class="ghost" id="nova">Nova lista</button>
    </div>
    <div class="msgAg">
      <div class="tt">Mensagem do agendamento para o WhatsApp</div>
      <div class="lin">
        <label class="f">Nome do(a) assistido(a) (opcional, para o “Olá”)<input id="agNome" type="text" autocomplete="off"></label>
        <button class="acao cheia" id="gerarMsg"><span class="n">5</span><span><b>GERAR MENSAGEM DO AGENDAMENTO</b><small>Dia, horário, endereço e a lista de documentos, pronta para colar no WhatsApp</small></span></button>
      </div>
      <div class="erroMsg" id="erroMsg"></div>
      <div class="vera"><small id="assinaInfo"></small> <button type="button" class="ghost veraBt" id="naoVera" title="Assinar a mensagem do agendamento com o seu nome (e o cargo, se quiser)">Não sou a Vera!</button></div>
      <div class="veraBox" id="veraBox" hidden>
        <div class="azar">Que azar o seu! 😄 Então a mensagem sai com o seu nome:</div>
        <div class="lin"><label class="f">Seu nome<input id="agAssNome" type="text" autocomplete="off" placeholder="Nome e sobrenome"></label>
        <label class="f cargo">Cargo (opcional)<select id="agAssCargo"><option value="">Sem cargo</option><option>Estagiário(a)</option><option>Servidor(a)</option></select></label></div>
        <button type="button" class="ghost souVera" id="souVera">Sou a Vera (voltar a assinar como Vera)</button>
      </div>
    </div>
  </div>
  <div class="hint">Cada botão pergunta se você quer <b>imprimir</b> (a folha sai em preto e branco bem legível) ou <b>baixar em PDF</b> (com as cores da tela, para mandar pelo WhatsApp; use também se a tela de impressão ficar cinza). Se a data, o título ou o endereço do arquivo aparecerem nos cantos da folha, abra “Mais definições” e desmarque <b>Cabeçalhos e rodapés</b>. Para mudar o texto de um item, clique nele e digite.</div>
</div>

<div class="sheet" id="folha">
  <img class="wm" alt="" src="data:image/png;base64,__WM__">
  <div class="head">
    <img alt="Defensoria Pública da União" src="data:image/jpeg;base64,__LOGO__">
    <div class="addr">Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS, CEP 96020-480<br>Fone (53) 3284-9450</div>
  </div>
  <div class="titulo">
    <div class="k">DOCUMENTAÇÃO NECESSÁRIA PARA</div>
    <div class="d vazio" id="tdem">escolha a demanda no campo acima</div>
  </div>
  <div id="docs"></div>
  <div class="add ui no-print" id="addrow" style="display:none">
    <input id="novoItem" type="text" placeholder="Acrescentar outro documento desta demanda…">
    <button class="ghost" id="addBtn">Acrescentar</button>
  </div>
  <div class="imp"><span class="k">IMPORTANTE:</span> <b>Grupo familiar</b> são todas as pessoas que moram no mesmo imóvel que o(a) assistido(a).</div>
  <div class="imp prz"><span class="k">PRAZO:</span> se faltar algum documento no dia do atendimento, ele deve ser entregue em até <b><u><span id="pz">30 dias</span></u></b>. Sem a documentação completa nesse prazo, o PAJ será <b>ARQUIVADO</b>.</div>
  <div class="dia">
    <div class="k">ATENDIMENTO AGENDADO PARA:</div>
    <div class="v" id="dia"></div>
    <div class="ret">O retorno não precisa de agendamento, mas serve somente para tratar do mesmo assunto deste atendimento. Para tratar de outro assunto, é preciso fazer um novo agendamento.</div>
    <div class="cont">
      <div class="canais">
        <div><div class="ck">Retorno virtual e ligações</div><div class="cv">(53) 3284-9450</div><div class="cn">WhatsApp: envio de documentos e dúvidas, só por mensagem. Ligações: pelo telefone comum (não atendemos ligações pelo WhatsApp).</div></div>
        <div><div class="ck">Novo atendimento</div><div class="cv">(53) 99112-4160</div><div class="cn">Somente para agendamentos.</div></div>
      </div>
      <div class="hor">Atendimento presencial das <b>09:00 às 15:00</b> &nbsp;·&nbsp; WhatsApp e telefone das <b>08:00 às 17:00</b></div>
    </div>
  </div>
</div>

<div class="msgOut ui no-print" id="msgOut" style="display:none">
  <h2>Mensagem do agendamento</h2>
  <p>Já foi copiada: cole no WhatsApp do(a) assistido(a) (Ctrl+V). Se mudar a lista, o dia ou o horário, clique de novo em <b>GERAR MENSAGEM DO AGENDAMENTO</b>. Você também pode corrigir o texto aqui antes de copiar.</p>
  <textarea id="msgTexto" spellcheck="false"></textarea>
  <div class="bts"><button class="primary" id="msgCopiar">COPIAR A MENSAGEM</button><span class="ok" id="msgOk"></span></div>
</div>

<div class="fim no-print" id="fimMenu" style="display:none"><button class="voltarMenu" id="voltarMenu">← VOLTAR AO MENU DO AGENDAMENTO</button></div>

<div id="anexos"></div>

<script>__PAKO__</script>
<script>__PDFJS_FOLHA__</script>
<script>
const DEMANDAS = __DATA__;
const FORMS = __FORMS__;
const GERAL = {
  cpf: "<b>RG (ou CNH) e CPF</b> de todas as pessoas do grupo familiar (para menores de idade que não têm RG, certidão de nascimento)",
  renda: "<b>Comprovante de renda</b> de todas as pessoas do grupo familiar. Para renda zero ou informal, <b>extratos bancários</b> de todas as contas dos últimos 3 meses",
  ctps: "<b>Carteira de Trabalho</b> de todas as pessoas do grupo familiar: digital (no aplicativo, opção “Enviar Carteira de Trabalho” e aba “Outros contratos”, se houver) ou física (página de qualificação civil, todos os contratos de trabalho e a página em branco seguinte ao último contrato)",
  ctpsPrev: "<b>Carteira de Trabalho</b> de todas as pessoas do grupo familiar: digital (no aplicativo, opção “Enviar Carteira de Trabalho” e aba “Outros contratos”, se houver) ou física (todas as páginas)",
  residencia: "<b>Comprovante de residência</b> em nome próprio ou com declaração do titular do comprovante",
  cadunico: "<b>Comprovante de inscrição no Cadastro Único (CadÚnico)</b>, se a família for inscrita"
};
const SE_FOR = [   // formato "Caso – o que trazer"
  "<b>Alguém do grupo familiar declara Imposto de Renda</b> – Declaração do Imposto de Renda mais recente dessa pessoa, com o recibo de entrega",
  "<b>Alguém do grupo familiar é MEI ou tem empresa</b> – Certificado do MEI ou contrato social e a última declaração de faturamento",
  "<b>O(a) assistido(a) tem curador(a)</b> – Termo de curatela",
  "<b>A renda do grupo familiar passa de 2 salários mínimos</b> (limite da Resolução nº 240/2025 da Defensoria Pública da União para a assistência gratuita) – Notas fiscais ou recibos de gastos extraordinários com saúde (consultas, psicólogo(a), fisioterapia, procedimentos essenciais e medicamentos). Esses gastos podem ser descontados da renda"
];
const norm = s => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[-\/().,%]+/g, " ");
const APELIDOS = {
  "Auxílio-doença": "beneficio por incapacidade temporaria afastamento doenca",
  "Aposentadoria por invalidez": "beneficio por incapacidade permanente aposentadoria por incapacidade",
  "Benefício assistencial (BPC/LOAS) à pessoa com deficiência": "deficiente amparo assistencial",
  "Benefício assistencial (BPC/LOAS) à pessoa idosa": "idoso amparo assistencial",
  "Adicional de 25% na aposentadoria": "acrescimo grande invalidez cuidador",
  "Pensão por morte": "falecimento obito viuva viuvo",
  "Aposentadoria por idade ou por tempo de contribuição": "aposentadoria urbana",
  "Aposentadoria rural": "agricultor segurado especial trabalhador rural",
  "Seguro-defeso (pescador artesanal)": "pesca",
  "Salário-maternidade": "gestante licenca maternidade parto",
  "Auxílio-reclusão": "preso prisao",
  "Alvará judicial": "valores residuais saque falecido",
  "Financiamento estudantil": "fies",
  "Financiamento habitacional": "minha casa minha vida caixa casa propria",
  "Ingresso em instituição de ensino": "matricula universidade cotas sisu",
  "Descontos indevidos em benefício do INSS": "associacao desconto",
  "Empréstimo bancário": "consignado",
  "Permanência no país (refúgio)": "estrangeiro migrante refugiado residencia",
  "FGTS e PIS": "saque fgts pis pasep",
  "Reintegração ou defesa da posse": "despejo ocupacao terreno",
  "Seguro-desemprego (com empresa no nome do assistido)": "cnpj mei empresa",
  "Seguro DPVAT (acidentes até 14/11/2023)": "spvat acidente transito",
  "Medicamentos": "remedio farmacia",
  "Tratamento oncológico": "cancer oncologia quimioterapia radioterapia",
  "Tratamento fora do domicílio (TFD)": "outra cidade viagem",
  "Internação ou transferência hospitalar": "uti leito",
  "Consulta com especialista": "medico especialista",
  "Defesa em processo criminal": "crime penal acao penal",
  "Audiência de acordo de não persecução penal (ANPP)": "anpp acordo penal"
};
const $ = id => document.getElementById(id);
const inp = $("dem"), lst = $("lst");
let vis = [], act = -1, atual = null;

function montarLista(filtro) {
  const f = norm(filtro || "");
  const tk = f.split(" ").filter(Boolean);
  vis = DEMANDAS.filter(d => { const h = norm(d.nome + " " + d.area + " " + (APELIDOS[d.nome] || "")); return tk.every(t => h.includes(t)); });
  /* ordem: primeiro o que bate com o começo das palavras do nome (ex.: "idade" acha "por idade" antes de "incapacidade") */
  if (tk.length) { const nota = d => { const ws = norm(d.nome).split(/[^a-z0-9]+/), hs = norm(d.area + " " + (APELIDOS[d.nome] || "")).split(/[^a-z0-9]+/);
      return tk.reduce((s, t) => s + (ws.some(w => w.startsWith(t)) ? 3 : norm(d.nome).includes(t) ? 1 : hs.some(w => w.startsWith(t)) ? 2 : 0), 0); };
    const v = vis.map((d, i) => [d, nota(d), i]), top = {}; v.forEach(x => top[x[0].area] = Math.max(top[x[0].area] || 0, x[1]));
    vis = v.sort((a, b) => top[b[0].area] - top[a[0].area] || (a[0].area === b[0].area ? b[1] - a[1] : 0) || a[2] - b[2]).map(x => x[0]); }
  lst.innerHTML = "";
  if (!vis.length) { lst.innerHTML = '<div class="none">Nenhuma demanda encontrada. Escolha “Outros casos”.</div>'; return; }
  let area = "";
  vis.forEach((d, i) => {
    if (d.area !== area) { area = d.area; const g = document.createElement("div"); g.className = "grp"; g.textContent = area; lst.appendChild(g); }
    const o = document.createElement("div");
    o.className = "opt" + (i === act ? " act" : ""); o.textContent = d.nome; o.setAttribute("role", "option");
    o.addEventListener("mousedown", e => { e.preventDefault(); escolher(d); });
    lst.appendChild(o);
  });
}
function abrir() { montarLista(inp.value === inp.dataset.escolhida ? "" : inp.value); lst.classList.add("open"); inp.setAttribute("aria-expanded", "true"); }
function fechar() { lst.classList.remove("open"); inp.setAttribute("aria-expanded", "false"); act = -1; }

/* ---------- itens da lista ---------- */
function item(html, sub) {
  const li = document.createElement("li");
  const s = document.createElement("span"); s.className = "it"; s.contentEditable = "true"; s.innerHTML = html;
  li.append(s);
  if (sub) { const d = document.createElement("div"); d.className = "sub"; d.textContent = sub; li.append(d); }
  return li;
}
function secao(id, titulo, itens) {
  const sec = document.createElement("div"); sec.className = "sec"; sec.id = id;
  const h = document.createElement("div"); h.className = "sh"; h.innerHTML = titulo;
  const ol = document.createElement("ol"); ol.className = "docs";
  itens.forEach(([html, sub]) => ol.appendChild(item(html, sub)));
  sec.append(h, ol);
  return sec;
}
function ultimoTexto(el) {  // último nó de texto com conteúdo
  const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n, last = null;
  while ((n = w.nextNode())) if (n.nodeValue.trim()) last = n;
  return last;
}
function pontuar() {  // ";" em cada item e "." no último de cada seção
  document.querySelectorAll("#docs .sec").forEach(sec => {
    const its = [...sec.querySelectorAll(".it")];
    its.forEach((s, i) => {
      const t = ultimoTexto(s); if (!t) return;
      t.nodeValue = t.nodeValue.replace(/[\s;.:]+$/, "") + (i === its.length - 1 ? "." : ";");
    });
  });
}
function escolher(d) {
  atual = d;
  inp.value = d.nome; inp.dataset.escolhida = d.nome; fechar();
  const t = $("tdem"); t.textContent = d.nome; t.classList.remove("vazio");
  const box = $("docs"); box.innerHTML = "";
  const geral = [[GERAL.cpf], [GERAL.renda], [d.prev ? GERAL.ctpsPrev : GERAL.ctps], [d.residencia || GERAL.residencia]];
  if (!d.cadunico) geral.push([GERAL.cadunico]);
  box.appendChild(secao("s-geral", 'DOCUMENTOS PESSOAIS E DE RENDA <span class="obs">(traga os originais; a Defensoria faz a digitalização)</span>', geral));
  box.appendChild(secao("s-esp", "DOCUMENTOS DESTA DEMANDA", d.docs.map(x => [x])));
  box.appendChild(secao("s-se", "SE FOR O SEU CASO, TRAGA TAMBÉM", SE_FOR.map(h => [h])));
  pontuar(); ajustarFonte();
  $("addrow").style.display = "flex";
  montarForms(d);
}
inp.addEventListener("focus", abrir);
inp.addEventListener("click", () => { if (inp.dataset.escolhida) inp.select(); if (!lst.classList.contains("open")) abrir(); });
inp.addEventListener("input", () => { delete inp.dataset.escolhida; act = 0; montarLista(inp.value); lst.classList.add("open"); });
inp.addEventListener("blur", () => setTimeout(fechar, 120));
inp.addEventListener("keydown", e => {
  if (!lst.classList.contains("open") && (e.key === "ArrowDown" || e.key === "Enter")) { abrir(); return; }
  if (e.key === "ArrowDown") { act = Math.min(act + 1, vis.length - 1); montarLista(inp.value === inp.dataset.escolhida ? "" : inp.value); e.preventDefault(); rolar(); }
  else if (e.key === "ArrowUp") { act = Math.max(act - 1, 0); montarLista(inp.value === inp.dataset.escolhida ? "" : inp.value); e.preventDefault(); rolar(); }
  else if (e.key === "Enter") { if (vis[act]) escolher(vis[act]); e.preventDefault(); }
  else if (e.key === "Escape") fechar();
});
function rolar() { const a = lst.querySelector(".opt.act"); if (a) a.scrollIntoView({ block: "nearest" }); }

function acrescentar() {
  const v = $("novoItem").value.trim(); if (!v || !atual) return;
  let sec = $("s-esp");
  if (!sec) { sec = secao("s-esp", "DOCUMENTOS DESTA DEMANDA", []); $("docs").insertBefore(sec, $("s-se")); }
  const t = v.charAt(0).toUpperCase() + v.slice(1);
  sec.querySelector("ol").appendChild(item(t.replace(/[<>&]/g, c => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" })[c])));
  pontuar(); ajustarFonte(); $("novoItem").value = ""; $("novoItem").focus();
}
$("addBtn").addEventListener("click", acrescentar);
$("novoItem").addEventListener("keydown", e => { if (e.key === "Enter") acrescentar(); });
$("docs").addEventListener("focusout", () => { pontuar(); ajustarFonte(); });

/* letra dos documentos o maior possível sem passar de uma página */
function ajustarFonte() {
  const folha = $("folha"), mm = px => px * 25.4 / 96, LIM = 295;
  document.body.classList.add("medindo");
  folha.style.setProperty("--gap", "0mm");
  const imp = folha.querySelector(".imp");   // IMPORTANTE numa linha só, o maior possível
  for (let t = 12.5; t >= 9; t -= 0.25) { imp.style.fontSize = t + "pt"; if (imp.scrollWidth <= imp.clientWidth) break; }
  folha.style.setProperty("--k", 1);   // cabeçalho, avisos e quadro do atendimento ficam do mesmo tamanho
  let fs = 22;
  for (; fs > 11.25; fs -= 0.25) {
    folha.style.setProperty("--fs", fs + "pt");
    if (mm(folha.scrollHeight) <= LIM) break;
  }
  folha.querySelectorAll(".sec").forEach(sec => sec.style.setProperty("--g", sec.querySelectorAll("li").length || 1));
  document.body.classList.remove("medindo");
}
window.addEventListener("beforeprint", ajustarFonte);

/* ---------- formulários para terceiros ---------- */
const NOTAS = {
  residencia: ["#s-geral", /^Comprovante de residência/, "As declarações de residência (opcionais) acompanham esta lista: use só se o comprovante não estiver no seu nome."],
  residencia_sem: ["#s-geral", /^Comprovante de residência/, "A declaração de residência acompanha esta lista: preencha e assine."],
  medico: ["#s-esp", /^Formulário médico/, "O formulário da Defensoria acompanha esta lista. Leve-o ao(à) médico(a) para preencher e assinar."]
};
const tipo = k => /^residencia/.test(k) ? k : "medico";
const cache = {};
function paginas(k) {
  if (!cache[k]) cache[k] = FORMS[k].pages.map(b64 => {
    const bin = atob(b64), bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const svg = pako.ungzip(bytes, { to: "string" });
    return URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
  });
  return cache[k];
}
function medicos(d) { return (d && d.forms) || []; }
function montarForms(d) {
  if (fase) encerrarSeparados();
  limparAnexos();
  const ks = medicos(d);
  $("aMedico").hidden = !ks.length;
  $("semform").style.display = ks.length ? "none" : "block";
  $("aTudoD").textContent = ks.length ? "A lista, o formulário médico e as declarações de residência (opcionais), num arquivo só" : "A lista e as declarações de residência (opcionais), num arquivo só";
  $("aDecl").querySelector(".n").textContent = ks.length ? "4" : "3";
  $("gerarMsg").querySelector(".n").textContent = ks.length ? "5" : "4";
  const m = $("modelo"); m.innerHTML = "";
  if (ks.length > 1) {   // Medicamentos: escolher o modelo
    m.append("Qual formulário médico? ");
    ks.forEach((k, i) => {
      const lb = document.createElement("label");
      const r = document.createElement("input"); r.type = "radio"; r.name = "modelo"; r.value = k; r.checked = i === 0;
      lb.append(r, " " + FORMS[k].label.replace(/^Formulário médico para medicamentos /, "").replace(/[()]/g, ""));
      m.appendChild(lb);
    });
    m.style.display = "block";
  } else m.style.display = "none";
  avisar("");
}
function medicoEscolhido() {
  const r = document.querySelector('#modelo input:checked');
  return r ? r.value : medicos(atual)[0];
}
function carregou(img) {
  return new Promise(ok => { if (img.complete && img.naturalWidth) ok(); else { img.onload = ok; img.onerror = ok; } });
}
async function montarPaginas(ks) {
  const box = $("anexos"), espera = [];
  box.innerHTML = "";
  ks.forEach(k => paginas(k).forEach(u => {
    const p = document.createElement("div"); p.className = "fpage";
    const img = new Image(); img.alt = FORMS[k].label; img.src = u;
    p.appendChild(img); box.appendChild(p); espera.push(carregou(img));
  }));
  await Promise.all(espera);
}
function marcarAnexo(ks) {  // avisa, no item correspondente, que o formulário acompanha a lista
  document.querySelectorAll("#docs .sub.anx").forEach(e => e.remove());
  [...new Set((ks || []).map(tipo))].forEach(t => {
    const [sec, re, txt] = NOTAS[t];
    document.querySelectorAll(sec + " .it").forEach(s => {
      if (re.test(s.textContent)) { const d = document.createElement("div"); d.className = "sub anx"; d.textContent = txt; s.after(d); }
    });
  });
}
function limparAnexos() { $("anexos").innerHTML = ""; marcarAnexo([]); if (atual) ajustarFonte(); }
function avisar(t, cor) { const m = $("fmsg"); m.style.color = cor || "var(--gray)"; m.textContent = t; }
function erro() {
  avisar("Não foi possível gerar o formulário neste navegador. Use o Google Chrome ou o Microsoft Edge atualizados.", "#b04a3a");
  encerrarSeparados();
}

/* juntos: lista + formulários marcados numa impressão só */
async function imprimirJuntos() {
  if (!atual) { avisar("Escolha a demanda primeiro.", "#b04a3a"); return; }
  window.ultimoForm = "medico";
  const ks = [medicoEscolhido()];
  try {
    encerrarSeparados(); avisar("Preparando os formulários…");
    await montarPaginas(ks);
    marcarAnexo(ks); pontuar(); ajustarFonte(); avisar("");
    window.print();
  } catch (e) { erro(); }
}

/* separadamente: 1º a lista, depois cada formulário marcado */
let fase = null;
function imprimirSeparados() {
  if (!atual) { avisar("Escolha a demanda primeiro.", "#b04a3a"); return; }
  window.ultimoForm = "medico";
  const ks = [medicoEscolhido()];
  encerrarSeparados();
  marcarAnexo(ks); pontuar(); ajustarFonte();
  fase = { fila: ks, i: -1 };
  avisar("Primeiro arquivo: salve ou imprima a LISTA. Quando fechar, abre o formulário médico.", "var(--green)");
  window.print();
}
async function proximoFormulario() {
  if (!fase) return;
  fase.i++;
  const k = fase.fila[fase.i];
  try {
    await montarPaginas([k]);
    document.body.classList.add("so-form");
    $("abrirForm").style.display = "inline-block";
    avisar("Segundo arquivo: salve ou imprima o FORMULÁRIO MÉDICO. Se a tela de impressão não abriu sozinha, clique no botão ao lado.", "var(--green)");
    window.print();
  } catch (e) { erro(); }
}
function encerrarSeparados() {
  fase = null; document.body.classList.remove("so-form"); $("abrirForm").style.display = "none"; limparAnexos();
}
window.addEventListener("afterprint", () => {
  if (fase) {
    if (fase.i + 1 < fase.fila.length) { const ok = fase; setTimeout(() => { if (fase === ok) proximoFormulario(); }, 400); return; }
    encerrarSeparados(); avisar("Pronto: a lista e o formulário médico foram salvos em arquivos separados.", "var(--green)"); return;
  }
  document.body.classList.remove("so-form"); limparAnexos();
});
/* declarações (do titular do comprovante ou de residência): só ela, sem a lista */
async function imprimirDeclaracao(k) {
  try {
    encerrarSeparados(); avisar("");
    await montarPaginas([k]);
    window.ultimoForm = k;
    document.body.classList.add("so-form");
    window.print();
  } catch (e) { erro(); }
}
$("abrirForm").addEventListener("click", () => { if (fase) { fase.i--; proximoFormulario(); } });

/* ---------- data e horário ---------- */
function dia() {
  const d = $("data").value, h = $("hora").value;
  const [a, m, di] = d ? d.split("-") : ["", "", ""];
  const [hh, mm] = h ? h.split(":") : ["", ""];
  const b = c => `<span class="b${c ? " " + c : ""}">&nbsp;</span>`;
  let sem = d ? new Date(+a, +m - 1, +di).toLocaleDateString("pt-BR", { weekday: "long" }) : "";
  sem = sem ? sem.charAt(0).toUpperCase() + sem.slice(1) : `${b("sem")}-feira`;
  const data = d ? `${di}/${m}/${a}` : `${b()} / ${b()} / 20${b("ano")}`;
  const hora = h ? `${hh}:${mm}` : `${b()} : ${b()}`;
  $("dia").innerHTML = `${sem}, ${data}, às ${hora}`;
}
$("data").addEventListener("input", dia); $("hora").addEventListener("input", dia);
dia();

$("imprimir").addEventListener("click", () => perguntar("lista"));
/* IMPRIMIR (tela de impressão do navegador) ou SALVAR EM PDF (o PDF é criado aqui mesmo, com as cores da tela) */
let modoPDF = false;
/* os 4 botões: cada um pergunta, numa janelinha, se é para imprimir ou baixar em PDF */
function instrucoesDecl() {
  const d = document.createElement("div"); d.className = "sheet instr";
  d.innerHTML = `<div class="instrT">DECLARAÇÕES DE RESIDÊNCIA (OPCIONAIS)</div>
    <p><b>Use só se for o seu caso.</b> Quem tem comprovante de residência (conta de água, luz ou outra conta da casa) <b>no próprio nome</b> não precisa destas declarações e pode descartar estas folhas.</p>
    <p><b>1. Declaração do Titular do Comprovante:</b> use quando o comprovante de residência está no nome de outra pessoa (por exemplo, o dono do imóvel ou um parente). Quem está no comprovante preenche e assina. Traga também o comprovante no nome dessa pessoa.</p>
    <p><b>2. Declaração de Residência:</b> use quando não há nenhuma conta da casa no seu nome. Você mesmo(a) preenche e assina, declarando onde mora.</p>
    <p>Traga a declaração preenchida e assinada no dia do atendimento, junto com os outros documentos da lista.</p>`;
  return d;
}
async function montarComDecl(ks) {   // páginas dos formulários; antes das declarações, a folha de instruções
  await montarPaginas(ks);
  const primeira = [...$("anexos").querySelectorAll(".fpage img")].find(i => /residência|titular/i.test(i.alt));
  const instr = instrucoesDecl();
  if (primeira) primeira.parentNode.before(instr); else $("anexos").appendChild(instr);
}
const ACOES = {
  tudo: async () => { const med = medicos(atual).length ? [medicoEscolhido()] : []; await montarComDecl([...med, "residencia", "residencia_sem"]); window.ultimoForm = "tudo"; marcarAnexo([...med, "residencia"]); pontuar(); ajustarFonte(); window.print(); },
  lista: async () => { window.ultimoForm = "lista"; limparAnexos(); pontuar(); window.print(); },
  medico: async () => { await montarPaginas([medicoEscolhido()]); window.ultimoForm = "medico"; document.body.classList.add("so-form"); window.print(); },
  decl: async () => { await montarComDecl(["residencia", "residencia_sem"]); window.ultimoForm = "decl"; document.body.classList.add("so-form"); window.print(); },
};
let pedido = null;
function perguntar(a) {
  if (!atual) { avisar("Escolha a demanda primeiro.", "#b04a3a"); return; }
  pedido = a;
  if (window.DPU_ONLINE) { fazer(true); return; }   // no site do Claude não há tela de impressão: baixa o PDF
  $("saidaFundo").hidden = false; $("saidaImp").focus();
}
async function fazer(pdf) {
  $("saidaFundo").hidden = true; modoPDF = pdf; encerrarSeparados(); avisar("");
  try { await ACOES[pedido](); } catch (e) { erro(); }
}
$("aTudo").addEventListener("click", () => perguntar("tudo"));
$("aMedico").addEventListener("click", () => perguntar("medico"));
$("aDecl").addEventListener("click", () => perguntar("decl"));
$("saidaImp").addEventListener("click", () => fazer(false));
$("saidaPdf").addEventListener("click", () => fazer(true));
$("saidaCanc").addEventListener("click", () => { $("saidaFundo").hidden = true; });
$("saidaFundo").addEventListener("click", e => { if (e.target === $("saidaFundo")) $("saidaFundo").hidden = true; });
window.dpuLayoutInicial = "cima";   // o agendamento sempre abre com o menu em cima
function nomeArquivo() {
  const dem = atual ? " - " + atual.nome : "";
  if (window.ultimoForm === "tudo" && $("anexos").children.length) return "Lista, formulário médico e declarações" + dem;
  if (!document.body.classList.contains("so-form")) return "Lista de Documentos Necessários" + dem;
  return window.ultimoForm === "decl" ? "Declarações de residência (opcionais)" : "Formulário médico" + dem;
}
const imprimirNativo = window.print.bind(window);
window.print = () => { if (modoPDF && window.dpuPDF) dpuPDF.salvar(nomeArquivo()); else imprimirNativo(); };
/* prazo: PRAZO NORMAL (30 dias) ou PAJ URGENTE (48 horas) */
function escolherPrazo(v) {
  document.querySelectorAll("#prazoSel button").forEach(b => b.classList.toggle("on", b.dataset.prazo === v));
  $("pz").textContent = v;
  if (atual) ajustarFonte();
}
document.querySelectorAll("#prazoSel button").forEach(b => b.addEventListener("click", () => escolherPrazo(b.dataset.prazo)));
$("nova").addEventListener("click", () => {
  escolherPrazo("30 dias");
  atual = null; inp.value = ""; delete inp.dataset.escolhida; $("data").value = ""; $("hora").value = ""; dia();
  $("docs").innerHTML = ""; $("addrow").style.display = "none";
  $("agNome").value = ""; $("msgOut").style.display = "none"; $("msgTexto").value = ""; $("erroMsg").textContent = "";
  encerrarSeparados(); $("aMedico").hidden = false; $("aDecl").querySelector(".n").textContent = "4"; $("gerarMsg").querySelector(".n").textContent = "5"; $("semform").style.display = "none"; $("modelo").style.display = "none";
  const t = $("tdem"); t.textContent = "escolha a demanda no campo acima"; t.classList.add("vazio"); inp.focus();
});
/* ---------- mensagem do agendamento para o WhatsApp ---------- */
const ENDERECO = "Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS";
const ASSINA_AG = "Atenciosamente,\nVera Lucia Bohmer\nDPU Pelotas";
/* "Não sou a Vera": quem gera a mensagem pode assinar com o próprio nome (e o cargo, se quiser); fica guardado neste computador */
const CH_AG = "dpuPelotas.assinaturaAgendamento.v1";
function lerAg() { try { return JSON.parse(localStorage.getItem(CH_AG) || "null"); } catch (e) { return null; } }
function gravarAg(v) { try { if (v) localStorage.setItem(CH_AG, JSON.stringify(v)); else localStorage.removeItem(CH_AG); } catch (e) {} }
function assinaturaAg() {
  const a = lerAg();
  if (!a || !a.nome) return ASSINA_AG;
  return "Atenciosamente,\n" + a.nome + "\n" + (a.cargo ? a.cargo + " – " : "") + "DPU Pelotas";
}
function pintarVera() {
  const a = lerAg(), outro = !!(a && a.nome);
  $("veraBox").hidden = !outro && !$("veraBox").dataset.aberto;
  $("naoVera").hidden = !$("veraBox").hidden;
  $("assinaInfo").innerHTML = outro ? `A mensagem sai assinada por <b>${a.nome.replace(/</g, "&lt;")}</b>${a.cargo ? " (" + a.cargo + ")" : ""}.` : "A mensagem sai assinada por <b>Vera Lucia Bohmer</b>.";
  if (a) { $("agAssNome").value = a.nome || ""; $("agAssCargo").value = a.cargo || ""; }
}
$("naoVera").addEventListener("click", () => { $("veraBox").dataset.aberto = "1"; pintarVera(); $("agAssNome").focus(); });
const salvarVera = () => { const nome = $("agAssNome").value.trim().replace(/\s+/g, " "); gravarAg(nome ? { nome, cargo: $("agAssCargo").value } : null); pintarVera(); };
$("agAssNome").addEventListener("input", salvarVera); $("agAssCargo").addEventListener("change", salvarVera);
$("souVera").addEventListener("click", () => { gravarAg(null); delete $("veraBox").dataset.aberto; $("agAssNome").value = ""; $("agAssCargo").value = ""; pintarVera(); });
pintarVera();
function textoItem(s) { return s.textContent.replace(/\s+/g, " ").trim(); }
function mensagemAgendamento() {
  const d = $("data").value, h = $("hora").value;
  const [a, m, di] = d.split("-");
  let sem = new Date(+a, +m - 1, +di).toLocaleDateString("pt-BR", { weekday: "long" });
  sem = sem.charAt(0).toUpperCase() + sem.slice(1);
  const nome = $("agNome").value.trim().split(/\s+/)[0] || "";
  const L = [];
  L.push(nome ? `Olá, ${nome.charAt(0).toUpperCase() + nome.slice(1).toLowerCase()}!` : "Olá!");
  L.push("", "Seu atendimento na Defensoria Pública da União (DPU) em Pelotas está agendado para:", "",
         `*Dia:* ${sem}, ${di}/${m}/${a}`, `*Horário:* ${h}`, `*Endereço:* ${ENDERECO}`, "",
         "Chegue com *15 minutos de antecedência*.", "",
         "Traga os documentos *ORIGINAIS* da lista abaixo. Não precisa tirar cópias: a DPU faz a digitalização dos documentos no atendimento.",
         "Os documentos desta mensagem são os mesmos da lista de documentos entregue a você (impressa ou em PDF).");
  let n = 0;
  document.querySelectorAll("#docs .sec").forEach(sec => {
    const its = [...sec.querySelectorAll(".it")].map(textoItem).filter(Boolean);
    if (!its.length) return;
    let tit = sec.querySelector(".sh").cloneNode(true); tit.querySelectorAll(".obs").forEach(o => o.remove());
    tit = tit.textContent.trim();
    if (sec.id === "s-esp" && atual) tit += ` (${atual.nome.toUpperCase()})`;
    L.push("", `*${tit}*`);
    its.forEach(t => L.push(`${++n}. ${t}`));
  });
  if ([...document.querySelectorAll("#docs .it")].some(s => /Formulário médico da Defensoria/i.test(s.textContent)))
    L.push("", "O *formulário médico da Defensoria* está no arquivo enviado junto com esta mensagem. Leve-o ao(à) médico(a) para preencher e traga no dia do atendimento.");
  L.push("", `*Prazo:* se faltar algum documento no dia do atendimento, ele deve ser entregue em até *${$("pz").textContent}*. Sem a documentação completa nesse prazo, o PAJ será *ARQUIVADO*.`);
  L.push("", "Dúvidas: WhatsApp (53) 3284-9450, só por mensagem (não atendemos ligações pelo WhatsApp). Para falar por telefone, ligue para o mesmo número, por ligação comum, das 8h às 17h.");
  L.push("", assinaturaAg());
  return L.join("\n");
}
function copiarMsg() {
  const t = $("msgTexto"), ok = () => { $("msgOk").textContent = "Mensagem copiada! Cole no WhatsApp (Ctrl+V)."; };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t.value).then(ok, () => { t.select(); document.execCommand("copy"); ok(); });
  else { t.select(); document.execCommand("copy"); ok(); }
}
$("gerarMsg").addEventListener("click", () => {
  const falta = [];
  if (!atual) falta.push("a demanda");
  if (!$("data").value) falta.push("o dia do atendimento");
  if (!$("hora").value) falta.push("o horário");
  if (falta.length) { $("erroMsg").textContent = "Para gerar a mensagem, preencha " + falta.join(", ").replace(/, ([^,]*)$/, " e $1") + " (no alto deste painel)."; return; }
  $("erroMsg").textContent = "";
  pontuar();
  $("msgTexto").value = mensagemAgendamento();
  $("msgOut").style.display = ""; $("msgOk").textContent = "";
  copiarMsg();
  $("msgOut").scrollIntoView({ behavior: "smooth", block: "start" });
});
$("msgCopiar").addEventListener("click", copiarMsg);
if (window.parent !== window) {  // aberto dentro do app Unidade
  document.getElementById("fimMenu").style.display = "";
  document.getElementById("voltarMenu").addEventListener("click", () => parent.postMessage({ ir: "agendamento" }, "*"));
}
</script>
</body>
</html>
"""
out = (HTML.replace("__LOGO__", logo).replace("__WM__", wm)
           .replace("__DATA__", json.dumps(data, ensure_ascii=False))
           .replace("__FORMS__", json.dumps(forms))
           .replace("__PAKO__", open(RAIZ + "lista/pako_inflate.min.js", encoding="utf-8").read()))
out = out.replace("__PDFJS_FOLHA__", open(RAIZ + "online/html2canvas.min.js", encoding="utf-8").read() + "\n" + open(RAIZ + "comum/pdf_folha.js", encoding="utf-8").read(), 1)
open(RAIZ + "lista/Lista_de_documentos_necessarios.html", "w", encoding="utf-8").write(out)
print(len(out) // 1024, "KB,", len(data), "demandas")

# Páginas (SVG compactado) dos formulários que a Lista de Documentos Necessários imprime junto: os médicos e as declarações (do titular do comprovante e de residência).
# Rodar sempre que algum desses PDFs mudar em pacote2/ (o construir.sh já roda).
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, gzip, json, subprocess, tempfile
P = RAIZ + "pacote2/Formularios_DPU_Pelotas/PDF (preenchiveis)/"
F = {  # chave: arquivo (sem .pdf)
    "beneficio": "Laudo_medico_beneficio_por_incapacidade", "adicional": "Laudo_medico_adicional_25",
    "loas": "Formulario_BPC_LOAS_pessoa_com_deficiencia", "cirurgia": "Laudo_medico_cirurgia", "exame": "Laudo_medico_exame",
    "uti": "Laudo_medico_internacao_UTI", "tratamento": "Formulario_pedido_judicial_tratamento",
    "med6": "Formulario_pedido_judicial_medicamentos_Tema_6_STF", "med": "Formulario_pedido_judicial_medicamentos",
    "onco": "Questionamentos_do_juizo_casos_oncologicos", "residencia": "Declaracao_de_residencia_proprietario",
    "residencia_sem": "Declaracao_de_residencia_sem_conta_em_nome_proprio",
}
NOMES = {"residencia": "Declaração do titular do comprovante (comprovante de residência)", "residencia_sem": "Declaração de residência"}
velho = json.load(open("forms.json"))
out = {}
for k, fn in F.items():
    pdf = P + fn + ".pdf"
    n = int([l for l in subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout.splitlines() if l.startswith("Pages")][0].split()[1])
    pages = []
    with tempfile.TemporaryDirectory() as td:
        for i in range(1, n + 1):
            subprocess.run(["pdftocairo", "-svg", "-f", str(i), "-l", str(i), pdf, f"{td}/p.svg"], check=True)
            pages.append(base64.b64encode(gzip.compress(open(f"{td}/p.svg", "rb").read(), 9, mtime=0)).decode())
    out[k] = {**velho.get(k, {}), **({"label": NOMES[k]} if k in NOMES else {}), "pages": pages}
json.dump(out, open("forms.json", "w"))
print(len(out), "formulários |", sum(len(v["pages"]) for v in out.values()), "páginas")

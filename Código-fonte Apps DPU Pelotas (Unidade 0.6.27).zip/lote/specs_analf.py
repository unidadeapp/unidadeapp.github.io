import copy
from specs import SPECS

# formulários assinados pelo(a) assistido(a) ou pelo(a) declarante (os médicos são assinados pelo médico)
QUEM = {
    "Declaracao_de_residencia_proprietario": ("do(a) declarante acima qualificado(a)", "declarante"),
    "Declaracao_de_ausencia_de_renda": ("do(a) declarante acima qualificado(a)", "declarante"),
    "Declaracao_de_ausencia_de_CTPS": ("do(a) declarante acima qualificado(a)", "declarante"),
    "Declaracao_de_renda_informal": ("do(a) declarante acima qualificado(a)", "declarante"),
    "Declaracao_de_renuncia": ("do(a) declarante acima qualificado(a)", "declarante"),
    "Termo_de_nao_reconhecimento_de_assinatura": ("do(a) declarante acima qualificado(a)", "declarante"),
    "Declaracao_de_residencia_sem_conta_em_nome_proprio": ("do(a) declarante acima qualificado(a)", "declarante"),
    "Desistencia_do_PAJ": ("do(a) assistido(a) acima qualificado(a)", "assistido(a)"),
    "Documentacao_pendente": ("do(a) assistido(a)", "assistido(a)"),
}
VARIANTES = []
for s in SPECS:
    if s["file"] not in QUEM:
        continue
    v = copy.deepcopy(s)
    v["file"] += "_analfabeto"
    v["title"] += " (assistido analfabeto)"
    quem, dig = QUEM[s["file"]]
    for i, e in enumerate(v["body"]):
        if e.get("type") == "signature":
            v["body"][i] = {"type": "rogo", "who": quem, "digital": dig, "before": 420}
    assert any(e.get("type") == "rogo" for e in v["body"]), s["file"]
    VARIANTES.append(v)

// Gerador comum dos formulários da DPU Pelotas (layout moderno).
// Uso: node formlib.js spec.json word|pdf out.docx
// Saídas com marcadores: §CB§ (caixa de seleção) e §T<n>§ (lacuna de texto), finalizados em Python.
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Header, Footer, Table, TableRow, TableCell,
  AlignmentType, BorderStyle, HorizontalPositionRelativeFrom, VerticalPositionRelativeFrom,
  TextWrappingType, ShadingType, WidthType, HeightRule, VerticalAlign, TableLayoutType,
  LevelFormat, UnderlineType, TabStopType,
} = require("docx");

const [specPath, target, outPath] = process.argv.slice(2);
const spec = JSON.parse(fs.readFileSync(specPath, "utf8"));
const BASE = __dirname + "/../src/";

const FONT = "Cambria";
const INK = "1E1E1E", GRAY = "5F5F5F", GREEN = "3F7F2A", BAND = "E2EFD9", LINE = "A6A6A6", SOFT = "F3F8EF";
const W = 9071;
const PT = 12700;
const LANG = { value: "pt-BR" };
const SIZE = spec.size || 22; // meio-pontos
const blanks = [];

const run = (o) => {
  if (typeof o === "string") o = { t: o };
  if (o.blank) {
    blanks.push({ size: o.size || SIZE, ...o.blank });
    return new TextRun({ text: `§T${blanks.length}§`, font: FONT });
  }
  if (o.cb) return new TextRun({ text: "§CB§", font: FONT });
  if (o.note) return new TextRun({ text: String(o.note), font: FONT, bold: true, color: GREEN, superScript: true, size: o.size || SIZE });
  return new TextRun({
    text: o.t, font: FONT, language: LANG, size: o.size || SIZE, bold: !!o.b, italics: !!o.i,
    color: o.color || INK, allCaps: !!o.caps, break: o.br ? 1 : undefined,
    underline: o.u ? { type: UnderlineType.SINGLE } : undefined,
  });
};
const runs = (arr, size) => (arr || []).map((x) => run(typeof x === "string" ? { t: x, size } : { size, ...x }));
const ALIGN = { left: AlignmentType.LEFT, center: AlignmentType.CENTER, right: AlignmentType.RIGHT, justify: AlignmentType.JUSTIFIED };

const border = { style: BorderStyle.SINGLE, size: 4, color: LINE };
const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const allB = { top: border, bottom: border, left: border, right: border, insideHorizontal: border, insideVertical: border };
const noB = { top: none, bottom: none, left: none, right: none, insideHorizontal: none, insideVertical: none };
const WHITE = { type: ShadingType.CLEAR, color: "auto", fill: "FFFFFF" };
const P = (children, o = {}) => new Paragraph({ spacing: { before: 0, after: 0 }, children, ...o });

// ---------- elementos ----------
const out = [];
let footerChildren = [];
const numbering = { config: [] };

function title(e) {
  out.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: e.before ?? 120, after: e.after ?? 360, line: 276 },
    shading: { type: ShadingType.CLEAR, color: "auto", fill: BAND },
    border: { top: { style: BorderStyle.SINGLE, size: 4, color: BAND, space: 6 }, bottom: { style: BorderStyle.SINGLE, size: 4, color: BAND, space: 6 } },
    keepNext: true,
    children: [...e.text.split("\n").flatMap((t, i) => [new TextRun({ text: t, font: FONT, bold: true, size: e.size || 28, characterSpacing: 20, color: INK, break: i ? 1 : undefined })]),
      ...(e.note ? [run({ note: e.note })] : [])],
  }));
}
function heading(e) {
  out.push(P([new TextRun({ text: e.text, font: FONT, bold: true, size: e.size || 22, characterSpacing: 30, color: GREEN })],
    { alignment: ALIGN[e.align || "center"], spacing: { before: e.before ?? 240, after: e.after ?? 160 }, keepNext: true }));
}
function para(e) {
  // no PDF, cada lacuna fica inteira numa linha (não se parte); texto justificado com lacuna esticaria demais a linha anterior
  const temLacuna = (e.runs || []).some(x => x && typeof x === "object" && x.blank);
  const al = target === "pdf" && temLacuna && (!e.align || e.align === "justify") ? "left" : (e.align || "justify");
  out.push(new Paragraph({
    alignment: ALIGN[al],
    spacing: { before: e.before ?? 0, after: e.after ?? 160, line: e.line || 276 },
    indent: { firstLine: e.first, left: e.left, right: e.right, hanging: e.hanging },
    keepNext: !!e.keepNext, keepLines: true,
    children: runs(e.runs, e.size),
  }));
}
function spacer(e) { out.push(P([], { spacing: { after: e.h || 200 }, keepNext: !!e.keepNext })); }

// tabela de identificação: rótulo e espaço de preencher na mesma caixa
function fields(e) {
  const cols = e.cols.map((f) => Math.round(f * W));
  cols[cols.length - 1] = W - cols.slice(0, -1).reduce((a, b) => a + b, 0);
  const rows = e.rows.map((r, ri) => new TableRow({
    cantSplit: true, height: { value: e.h || 420, rule: HeightRule.ATLEAST },
    children: r.map((c) => {
      let gi = 0; // largura pela soma das colunas ocupadas
      const start = r.slice(0, r.indexOf(c)).reduce((a, x) => a + (x.span || 1), 0);
      const width = cols.slice(start, start + (c.span || 1)).reduce((a, b) => a + b, 0);
      return new TableCell({
        width: { size: width, type: WidthType.DXA }, columnSpan: c.span,
        shading: c.fill === false ? undefined : WHITE, verticalAlign: VerticalAlign.CENTER,
        children: [P([...runs([{ t: c.label, b: !!c.b, size: 21 }]), ...(c.note ? [run({ note: c.note, size: 21 })] : []),
          ...(c.after ? runs(c.after, 21) : []), ...(c.label && !c.after ? [run({ t: " ", size: 21 })] : [])],
          { keepNext: ri < e.rows.length - 1 })],
      });
    }),
  }));
  out.push(new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: cols, layout: TableLayoutType.FIXED, borders: allB,
    margins: { left: 90, right: 90, top: 30, bottom: 30 }, rows }));
  out.push(P([], { spacing: { after: e.after ?? 200 } }));
}
function notice(e) {
  out.push(new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: [W], layout: TableLayoutType.FIXED,
    borders: { top: none, bottom: none, right: none, left: { style: BorderStyle.SINGLE, size: 24, color: GREEN }, insideHorizontal: none, insideVertical: none },
    rows: [new TableRow({ cantSplit: true, children: [new TableCell({
      width: { size: W, type: WidthType.DXA }, shading: { type: ShadingType.CLEAR, color: "auto", fill: SOFT },
      margins: { left: 160, right: 160, top: 90, bottom: 90 },
      children: [P(runs(e.runs, e.size || 20), { alignment: AlignmentType.JUSTIFIED, spacing: { line: 264 } })],
    })] })],
  }));
  out.push(P([], { spacing: { after: e.after ?? 200 } }));
}
// pergunta numerada
function question(e) {
  out.push(new Paragraph({
    alignment: AlignmentType.JUSTIFIED, keepNext: true, keepLines: true, pageBreakBefore: !!e.pageBreak,
    spacing: { before: e.before ?? 0, after: 90, line: 264 },
    indent: { left: e.num.length > 3 ? 560 : 360, hanging: e.num.length > 3 ? 560 : 360 },
    tabStops: [{ type: TabStopType.LEFT, position: e.num.length > 3 ? 560 : 360 }],
    children: [run({ t: `${e.num}\t`, b: true, color: GREEN, size: e.size }), ...runs(e.runs, e.size)],
  }));
}
// caixa(s) de resposta; {lines: n} vira n linhas pautadas para escrever à mão
function box(e) {
  const LH = e.lineH || 440;
  const rowsSpec = [];
  for (const r of e.rows || [{ h: e.h || 900 }]) {
    if (r.lines) for (let k = 0; k < r.lines; k++) rowsSpec.push({ h: LH, ruled: true });
    else rowsSpec.push(r);
  }
  const ruleLine = { style: BorderStyle.SINGLE, size: 4, color: "C8C8C8" };
  out.push(new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: [W], layout: TableLayoutType.FIXED,
    borders: { top: border, bottom: border, left: border, right: border, insideHorizontal: ruleLine, insideVertical: none },
    margins: { left: 90, right: 90, top: 30, bottom: 30 },
    rows: rowsSpec.map((r, i) => new TableRow({
      cantSplit: true, height: { value: r.h || 900, rule: HeightRule.ATLEAST },
      children: [new TableCell({
        width: { size: W, type: WidthType.DXA }, shading: e.fill === false ? undefined : WHITE,
        verticalAlign: r.ruled ? VerticalAlign.BOTTOM : (r.label && !r.top ? VerticalAlign.CENTER : VerticalAlign.TOP),
        children: [P(r.label ? runs([{ t: r.label + " ", size: 21 }]) : [run({ t: "", size: 21 })], { keepNext: i < rowsSpec.length - 1 })],
      })],
    })),
  }));
  out.push(P([], { spacing: { after: e.after ?? 240 } }));
}
// opções com caixas clicáveis, em colunas
function opts(e) {
  const n = e.cols || 2;
  const cw = Math.floor(W / n);
  const cols = Array(n).fill(cw); cols[n - 1] = W - cw * (n - 1);
  const rows = [];
  const nr = Math.ceil(e.items.length / n);
  for (let r = 0; r < nr; r++) {
    rows.push(new TableRow({ cantSplit: true, children: cols.map((w, c) => {
      const it = e.items[r * n + c];
      return new TableCell({ width: { size: w, type: WidthType.DXA }, borders: { top: none, bottom: none, left: none, right: none },
        children: [P(it ? [run({ cb: true }), run({ t: "  " + it, size: e.size || 21 })] : [],
          { keepNext: r < nr - 1 || !!e.keepNext, spacing: { before: 30, after: 30 }, indent: { left: 340, hanging: 340 } })] });
    }) }));
  }
  out.push(new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: cols, layout: TableLayoutType.FIXED, borders: noB,
    margins: { left: 60, right: 60, top: 0, bottom: 0 }, rows }));
  out.push(P([], { spacing: { after: e.after ?? 160 }, keepNext: !!e.keepNext }));
}
// lista numerada (Word: cresce com Enter; PDF: linhas fixas)
function list(e) {
  if (target === "word") {
    numbering.config.push({ reference: "lista", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 460, hanging: 460 } }, run: { font: FONT, bold: true, color: GREEN, size: SIZE } } }] });
    for (let i = 0; i < (e.word || 1); i++) {
      out.push(new Paragraph({ numbering: { reference: "lista", level: 0 }, spacing: { before: 0, after: 120, line: 300 },
        children: [run({ t: "", size: SIZE })] }));
    }
  } else {
    const cols = [460, W - 460];
    out.push(new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: cols, layout: TableLayoutType.FIXED, borders: noB,
      margins: { left: 0, right: 60, top: 0, bottom: 0 },
      rows: Array.from({ length: e.pdf || 8 }, (_, i) => new TableRow({ cantSplit: true, height: { value: 460, rule: HeightRule.ATLEAST }, children: [
        new TableCell({ width: { size: cols[0], type: WidthType.DXA }, verticalAlign: VerticalAlign.BOTTOM, borders: { top: none, bottom: none, left: none, right: none },
          children: [P([run({ t: `${i + 1}.`, b: true, color: GREEN })])] }),
        new TableCell({ width: { size: cols[1], type: WidthType.DXA }, verticalAlign: VerticalAlign.BOTTOM, shading: WHITE,
          borders: { top: none, left: none, right: none, bottom: { style: BorderStyle.SINGLE, size: 4, color: "3A3A3A" } },
          children: [P([run({ t: "" })])] }),
      ] })),
    }));
  }
  out.push(P([], { spacing: { after: e.after ?? 240 } }));
}
function signature(e) {
  const ind = Math.round((W - (e.width || 5400)) / 2);
  out.push(P([], { indent: { left: ind, right: ind }, keepNext: true, spacing: { before: e.before ?? 1200 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "3A3A3A", space: 1 } } }));
  e.lines.forEach((l, i) => out.push(P(runs(Array.isArray(l) ? l : [typeof l === "string" ? { t: l, b: i === 0 } : l]),
    { alignment: AlignmentType.CENTER, spacing: { before: i ? 0 : 60 }, keepNext: i < e.lines.length - 1 })));
  if (e.after) out.push(P([], { spacing: { after: e.after } }));
}
// Assinatura de quem não sabe ler nem escrever: espaço para a digital + assinatura a rogo e duas testemunhas (art. 595 do Código Civil)
function rogo(e) {
  const DIG = 1500, GAP = 300, R = W - DIG - GAP, G = 200, C = Math.floor((R - 2 * G) / 3);
  const lineB = { style: BorderStyle.SINGLE, size: 6, color: "3A3A3A" };
  const light = { style: BorderStyle.SINGLE, size: 4, color: "D4D4D4" };
  const t = (text, o = {}) => new TextRun({ text, font: FONT, size: o.size || 18, bold: !!o.b, color: o.color || INK, language: LANG });
  const cell = (w, children, o = {}) => new TableCell({ width: { size: w, type: WidthType.DXA }, verticalAlign: o.v || VerticalAlign.BOTTOM,
    borders: { top: o.top || none, bottom: o.bottom || none, left: o.left || none, right: o.right || none },
    margins: { left: 0, right: 0, top: 0, bottom: 0 }, children: children || [P([])] });
  const cols = [C, G, C, G, C];
  const linha = (h, mk) => new TableRow({ cantSplit: true, height: { value: h, rule: HeightRule.ATLEAST },
    children: cols.map((w, i) => i % 2 ? cell(w) : mk(w, i / 2)) });
  const quem = ["Assinatura a rogo", "Testemunha 1", "Testemunha 2"];
  const tabela = new Table({ width: { size: R, type: WidthType.DXA }, columnWidths: cols, layout: TableLayoutType.FIXED, borders: noB, rows: [
    linha(760, (w) => cell(w, null, { bottom: lineB })),
    linha(260, (w, k) => cell(w, [P([t(quem[k], { b: true })], { alignment: AlignmentType.CENTER, spacing: { before: 40 } })], { v: VerticalAlign.TOP })),
    linha(420, (w) => cell(w, [P([t("Nome:")])], { bottom: lineB })),
    linha(400, (w) => cell(w, [P([t("CPF:")])], { bottom: lineB })),
  ] });
  const digital = new Table({ width: { size: DIG, type: WidthType.DXA }, columnWidths: [DIG], layout: TableLayoutType.FIXED, borders: noB, rows: [
    new TableRow({ cantSplit: true, height: { value: 2000, rule: HeightRule.EXACT },
      children: [cell(DIG, null, { top: light, bottom: light, left: light, right: light })] }) ] });
  out.push(P([], { keepNext: true, spacing: { before: e.before ?? 500 } }));
  out.push(new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [DIG, GAP, R], layout: TableLayoutType.FIXED, borders: noB,
    rows: [new TableRow({ cantSplit: true, children: [
      cell(DIG, [digital, P([t("Digital do(a) " + (e.digital || "declarante"), { size: 14, color: "A8A8A8" })], { alignment: AlignmentType.CENTER, spacing: { before: 30 } })], { v: VerticalAlign.TOP }),
      cell(GAP),
      cell(R, [P([t("A rogo " + (e.who || "do(a) declarante acima qualificado(a)") + ", que não sabe ler nem escrever, assina (art. 595 do Código Civil):", { size: 20 })],
                 { alignment: AlignmentType.JUSTIFIED, spacing: { after: 60, line: 300 } }), tabela, P([])], { v: VerticalAlign.TOP }),
    ] })] }));
  if (e.after) out.push(P([], { spacing: { after: e.after } }));
}
function instructions(e) {
  const items = (target === "pdf" && e.pdf_items) || e.items;
  const right = W - 6300;
  footerChildren = [
    new Paragraph({ indent: { right: W - 3000 }, spacing: { after: 70 },
      border: { top: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF", space: 6 } },
      children: [new TextRun({ text: e.title || "Instruções de preenchimento", font: FONT, bold: true, size: 19, color: GRAY })] }),
    ...items.map(([n, t]) => new Paragraph({
      indent: { left: n ? 220 : 0, hanging: n ? 220 : 0, right }, tabStops: [{ type: TabStopType.LEFT, position: 220 }],
      spacing: { after: 50, line: 245 },
      children: [...(n ? [new TextRun({ text: n, font: FONT, bold: true, size: 19, color: GREEN }), new TextRun({ text: "\t", font: FONT, size: 19 })] : []),
        new TextRun({ text: t, font: FONT, size: 19, color: GRAY })],
    })),
    new Paragraph({ children: [] }),
  ];
}
const H = { title, heading, p: para, spacer, fields, notice, q: question, box, opts, list, signature, rogo, instructions };
for (const e of spec.body) {
  if (e.only && e.only !== target) continue;
  H[e.type](e);
}

// ---------- cabeçalho ----------
const logo = fs.readFileSync(BASE + "img-002.jpg");
const wm = fs.readFileSync(BASE + "watermark.png");
const header = new Header({ children: [
  P([new ImageRun({ type: "jpg", data: logo, transformation: { width: 176, height: 75 } })], { alignment: AlignmentType.CENTER, spacing: { after: 60 } }),
  P([new TextRun({ text: "Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS, CEP 96020-480", font: FONT, size: 18, color: GRAY })], { alignment: AlignmentType.CENTER, spacing: { line: 240 } }),
  P([new TextRun({ text: "Fone (53) 3284-9450", font: FONT, size: 18, color: GRAY }),
    new ImageRun({ type: "png", data: wm, transformation: { width: 237, height: 232 }, floating: {
      horizontalPosition: { relative: HorizontalPositionRelativeFrom.PAGE, offset: Math.round(397 * PT) },
      verticalPosition: { relative: VerticalPositionRelativeFrom.PAGE, offset: Math.round(655 * PT) },
      behindDocument: true, allowOverlap: true, wrap: { type: TextWrappingType.NONE } } })],
    { alignment: AlignmentType.CENTER, spacing: { line: 240 }, border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF", space: 8 } } }),
] });

const doc = new Document({
  creator: "Defensoria Pública da União", title: spec.title,
  styles: { default: { document: { run: { font: FONT, size: SIZE, language: LANG } } } },
  numbering,
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 },
      margin: { top: 2600, bottom: footerChildren.length ? (spec.bottom || 2700) : 1400, left: 1418, right: 1418, header: 800, footer: 700 } } },
    headers: { default: header },
    footers: footerChildren.length ? { default: new Footer({ children: footerChildren }) } : undefined,
    children: out,
  }],
});
Packer.toBuffer(doc).then((b) => {
  fs.writeFileSync(outPath, b);
  fs.writeFileSync(outPath + ".blanks.json", JSON.stringify(blanks));
});

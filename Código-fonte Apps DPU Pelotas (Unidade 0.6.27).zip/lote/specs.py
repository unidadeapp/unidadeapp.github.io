"""Conteúdo dos formulários (texto dos modelos originais, em branco, no layout novo)."""


def B(name, w, tip, note=None, b=False, size=None):
    d = {"name": name, "w": w, "tip": tip}
    if note:
        d["note"] = note
    if b:
        d["b"] = True
    out = {"blank": d}
    if size:
        out["size"] = size
    return out


bold = lambda t: {"t": t, "b": True}
und = lambda t: {"t": t, "u": True}
bu = lambda t: {"t": t, "b": True, "u": True}

NOME_DECL = ("1", "Nome completo da pessoa que está fazendo a declaração.")
CIDADE = lambda n: (n, "Cidade e estado onde o documento é assinado, seguidos do dia, do mês e dos dois últimos números do ano.")


def ANO():
    return B("ano", 19, "Ano (dois últimos números)")


def data_livre(note):
    return [B("cidade_uf", 150, "Cidade e estado", note), ", ", B("dia", 28, "Dia"), " de ", B("mes", 95, "Mês"), " de 20", ANO(), "."]


def data_pelotas():
    return ["Pelotas/RS, ", B("dia", 28, "Dia"), " de ", B("mes", 95, "Mês"), " de 20", ANO(), "."]


def declaracao(title, fname, corpo, extra=None, instr=None, assinatura="Assinatura do(a) declarante", city_note="2"):
    body = [{"type": "title", "text": title, "after": 520},
            {"type": "p", "runs": corpo, "line": 480, "after": 120}]
    body += extra or []
    body += [{"type": "p", "runs": data_livre(city_note), "align": "right", "before": 500},
             {"type": "signature", "lines": [assinatura], "before": 1400},
             {"type": "instructions", "items": instr or [NOME_DECL, CIDADE(city_note)]}]
    return {"file": fname, "title": title.title(), "size": 24, "body": body}


def peticao_acordo(fname, title, reu, quem):
    return {"file": fname, "title": title, "size": 24, "body": [
        {"type": "p", "runs": [bold("EXCELENTÍSSIMO(A) SENHOR(A) JUIZ(ÍZA) FEDERAL DO(A) "),
                               B("juizo", 230, "Vara ou juízo do processo", b=True)], "align": "justify", "line": 360, "before": 120, "after": 600},
        {"type": "p", "runs": ["Processo nº ", B("processo", 175, "Número do processo", b=True)], "after": 60, "line": 360},
        {"type": "p", "runs": ["PAJ nº ", B("paj", 130, "Número do PAJ", b=True)], "after": 600, "line": 360},
        {"type": "p", "first": 1134, "line": 360, "after": 240, "runs": [
            B("nome_assistido", 230, "Nome completo do(a) assistido(a)", b=True),
            f", devidamente qualificado(a) nos autos do processo em epígrafe, que move em face {reu}, por intermédio da Defensoria Pública da União, vem, respeitosamente, à presença de Vossa Excelência manifestar ",
            bold("concordância com a proposta de acordo"), f" formulada pela {quem}."]},
        {"type": "p", "first": 1134, "line": 360, "after": 60, "runs": ["Nestes termos, pede deferimento."]},
        {"type": "p", "first": 1134, "line": 360, "after": 0, "runs": data_pelotas()},
        {"type": "p", "align": "center", "before": 900, "after": 0, "runs": [B("defensor", 200, "Nome do(a) Defensor(a) Público(a) Federal")]},
        {"type": "p", "align": "center", "after": 0, "runs": ["Defensor(a) Público(a) Federal"]},
        {"type": "signature", "lines": ["Assinatura do(a) assistido(a)"], "before": 1300},
    ]}


SPECS = []

# ---------------- petições e certidões ----------------
SPECS.append(peticao_acordo("Peticao_de_acordo_INSS", "Petição de Acordo – INSS",
                            "do Instituto Nacional do Seguro Social (INSS)", "autarquia previdenciária"))
SPECS.append(peticao_acordo("Peticao_de_acordo_CEF", "Petição de Acordo – CEF",
                            "da Caixa Econômica Federal (CEF)", "instituição bancária"))

SPECS.append({"file": "Certidao_de_comparecimento", "title": "Certidão de Comparecimento", "size": 24, "body": [
    {"type": "title", "text": "CERTIDÃO", "after": 560},
    {"type": "p", "line": 480, "first": 1134, "runs": [
        "Certifico, para os devidos fins, que ", B("nome", 210, "Nome completo de quem compareceu"),
        " compareceu à sede da Defensoria Pública da União de Pelotas/RS, na manhã do dia ", B("data", 75, "Data do comparecimento"),
        ", das ", B("hora_inicio", 40, "Horário de chegada"), " às ", B("hora_fim", 40, "Horário de saída"),
        ", para realização de atendimento em seu PAJ (", B("paj", 110, "Número do PAJ"), ")."]},
    {"type": "p", "align": "right", "before": 500, "runs": data_pelotas()},
    {"type": "signature", "lines": ["Marília Braga dos Santos", {"t": "Supervisora do Atendimento"}], "before": 1400},
]})

SPECS.append({"file": "Desistencia_do_PAJ", "title": "Desistência do PAJ", "size": 24, "body": [
    {"type": "title", "text": "DESISTÊNCIA DO PAJ", "after": 520},
    {"type": "p", "runs": ["PAJ nº ", B("paj", 130, "Número do PAJ", b=True)], "after": 360, "line": 360},
    {"type": "p", "line": 480, "runs": [
        "Eu, ", B("nome", 250, "Nome completo do(a) assistido(a)", "1", b=True), ", inscrito(a) no CPF sob o nº ", B("cpf", 110, "CPF"),
        ", venho à Defensoria Pública da União, na presente data, postular a ",
        bu("desistência da presente pretensão de assistência jurídica objeto do PAJ supra"), "."]},
    {"type": "p", "align": "right", "before": 500, "runs": data_pelotas()},
    {"type": "signature", "lines": ["Assinatura do(a) assistido(a)"], "before": 1400},
    {"type": "instructions", "items": [("1", "Nome completo da pessoa que está desistindo do atendimento.")]},
]})

# ---------------- declarações ----------------
SPECS.append(declaracao("DECLARAÇÃO DO TITULAR DO COMPROVANTE", "Declaracao_de_residencia_proprietario", [
    "Eu, ", B("nome_declarante", 250, "Nome completo de quem declara (proprietário ou proprietária do imóvel)", "1"),
    ", inscrito(a) no CPF sob o nº ", B("cpf_declarante", 110, "CPF de quem declara"),
    ", proprietário(a) do imóvel situado no endereço ", B("endereco", 430, "Endereço completo do imóvel"),
    ", declaro, para os devidos fins legais, que reside neste imóvel, cuja conta está em meu nome, ",
    B("nome_morador", 250, "Nome completo de quem mora no imóvel", "2"), ", portador(a) do CPF nº ", B("cpf_morador", 110, "CPF de quem mora no imóvel"), "."],
    instr=[("1", "Nome completo da pessoa que está fazendo a declaração (proprietário ou proprietária do imóvel)."),
           ("2", "Nome completo da pessoa que está residindo no imóvel."), CIDADE("3")], city_note="3"))

SPECS.append(declaracao("DECLARAÇÃO DE AUSÊNCIA DE RENDA", "Declaracao_de_ausencia_de_renda", [
    "Eu, ", B("nome", 250, "Nome completo de quem declara", "1"), ", CPF nº ", B("cpf", 110, "CPF"),
    ", declaro, para os devidos fins e sob as penas da legislação vigente, que estou desempregado(a) e não possuo qualquer fonte de renda mensal."]))

SPECS.append(declaracao("DECLARAÇÃO DE AUSÊNCIA DE CTPS", "Declaracao_de_ausencia_de_CTPS", [
    "Eu, ", B("nome", 250, "Nome completo de quem declara", "1"), ", CPF nº ", B("cpf", 110, "CPF"),
    ", declaro, para os devidos fins, que não possuo Carteira de Trabalho."]))

SPECS.append(declaracao("DECLARAÇÃO DE RENDA INFORMAL", "Declaracao_de_renda_informal", [
    "Eu, ", B("nome", 250, "Nome completo de quem declara", "1"), ", CPF nº ", B("cpf", 110, "CPF"),
    ", declaro, para os devidos fins e sob as penas da legislação vigente, que não possuo vínculo empregatício. "
    "Entretanto, exerço atividade de maneira autônoma, auferindo renda mensal de R$ ", B("valor", 80, "Valor da renda mensal"), "."]))

SPECS.append(declaracao("DECLARAÇÃO DE RENÚNCIA", "Declaracao_de_renuncia", [
    "Eu, ", B("nome", 250, "Nome completo de quem declara", "1"), ", CPF nº ", B("cpf", 110, "CPF"),
    ", declaro, para os devidos fins e sob as penas da legislação vigente, que ", bold("RENUNCIO"),
    " a eventual valor excedente a 60 (sessenta) salários mínimos para que a ação seja proposta perante o Juizado Especial Federal, "
    "nos termos do art. 3º da Lei nº 10.259/2001."]))

SPECS.append(declaracao("TERMO DE NÃO RECONHECIMENTO DE ASSINATURA", "Termo_de_nao_reconhecimento_de_assinatura", [
    "Eu, ", B("nome", 250, "Nome completo de quem declara", "1"), ", portador(a) do CPF nº ", B("cpf", 110, "CPF"),
    ", declaro que não reconheço a assinatura constante no contrato ",
    B("contrato", 120, "Número ou identificação do contrato"), " da instituição financeira ", B("banco", 150, "Nome do banco ou financeira"),
    ". Logo, pelo não reconhecimento da assinatura, declaro que não contratei serviços com essa instituição."],
    assinatura="Assinatura do(a) assistido(a)"))

SPECS.append(declaracao("DECLARAÇÃO DE RESIDÊNCIA", "Declaracao_de_residencia_sem_conta_em_nome_proprio", [
    "Eu, ", B("nome", 230, "Nome completo de quem declara", "1"), ", inscrito(a) no CPF sob o nº ", B("cpf", 110, "CPF"),
    ", não tendo como comprovar residência fixa para fins de prestação de assistência jurídica por parte da Defensoria Pública da União, "
    "eis que não possuo qualquer conta de concessionária de serviço público em meu nome, declaro que resido no imóvel situado no endereço ",
    B("endereco", 440, "Endereço completo (rua, número, complemento, bairro, cidade e CEP)"), "."],
    extra=[{"type": "p", "line": 480, "before": 120, "runs": [
        "Declaro, ainda, estar ciente de que a comprovação da falsidade da presente declaração sujeita o(a) declarante às sanções civis, "
        "administrativas e criminais previstas na legislação aplicável, na forma e para os fins da Lei nº 7.115, de 29 de agosto de 1983."]}]))

SPECS.append({"file": "Declaracao_isento_IRPF_Banco_do_Brasil", "title": "Declaração – Isenção de IRPF", "size": 22, "bottom": 3000, "body": [
    {"type": "heading", "text": "ANEXO ÚNICO", "before": 0, "after": 120},
    {"type": "title", "text": "DECLARAÇÃO", "after": 260},
    {"type": "p", "line": 340, "after": 120, "runs": [
        B("beneficiario", 220, "Nome do(a) beneficiário(a)", "1"), ", residente ou domiciliado(a) ", B("endereco", 330, "Endereço completo", "2"),
        ", inscrito(a) no CPF/CNPJ sob o nº ", B("cpf_cnpj", 120, "CPF ou CNPJ"),
        ", para fins da não retenção do imposto de renda de que trata o art. 27 da Lei nº 10.833, de 29 de dezembro de 2003, sobre rendimentos "
        "a serem recebidos em cumprimento de decisão da Justiça Federal, conforme Processo nº ", B("processo", 170, "Número do processo"),
        ", da ", B("vara", 25, "Número da vara"), "ª Vara da Seção/Subseção Judiciária de ", B("secao", 150, "Seção ou subseção judiciária", "3"),
        ", pagos pelo(a) ", B("instituicao", 170, "Instituição financeira pagadora", "4"), ", declara que:"]},
    {"type": "p", "line": 340, "after": 60, "left": 360, "hanging": 360, "runs": [
        {"cb": True}, "  o montante de R$ ", B("valor", 80, "Valor em R$"), " (", B("valor_extenso", 230, "Valor por extenso", "5"),
        ") constitui rendimento isento ou não-tributável;"]},
    {"type": "p", "line": 340, "after": 120, "left": 360, "hanging": 360, "runs": [
        {"cb": True}, "  está inscrita no Sistema Integrado de Pagamento de Impostos e Contribuições das Microempresas e das Empresas de Pequeno Porte (Simples)."]},
    {"type": "p", "line": 340, "runs": [
        "O(a) beneficiário(a) fica ciente de que a falsidade na prestação destas informações o(a) sujeitará, juntamente com as demais pessoas "
        "que para ela concorrerem, às penalidades previstas na legislação tributária e penal, relativas à falsidade ideológica (art. 299 do "
        "Código Penal) e ao crime contra a ordem tributária (art. 1º da Lei nº 8.137, de 27 de dezembro de 1990)."]},
    {"type": "p", "align": "right", "before": 300, "runs": [B("municipio_uf", 140, "Município e UF", "6"), ", ", B("dia", 25, "Dia"), " de ",
                                                           B("mes", 90, "Mês"), " de 20", ANO(), "."]},
    {"type": "signature", "lines": ["Assinatura do(a) beneficiário(a) ou de seu representante legal"], "before": 700, "width": 6200, "after": 160},
    {"type": "p", "align": "center", "after": 60, "runs": [{"t": "Abono da assinatura pela instituição financeira", "size": 20, "color": "5F5F5F"}]},
    {"type": "box", "fill": False, "rows": [{"h": 950}], "after": 0},
    {"type": "instructions", "items": [("1", "Nome do(a) beneficiário(a)."), ("2", "Endereço completo."),
                                       ("3", "Nome da Unidade da Federação ou do Município."), ("4", "Nome da instituição financeira."),
                                       ("5", "Indicação do valor por extenso."), ("6", "Município e UF, seguidos da data.")]},
]})

SPECS.append({"file": "Documentacao_pendente", "title": "Documentos Pendentes", "size": 24, "bottom": 2500, "body": [
    {"type": "title", "text": "DOCUMENTOS PENDENTES", "after": 400},
    {"type": "list", "word": 1, "pdf": 8, "after": 360},
    {"type": "p", "line": 360, "after": 200, "runs": [
        "Os documentos podem ser enviados via ", bold("WhatsApp"), ", através do número ", bold("(53) 3284-9450"),
        ", desde que a foto seja ", und("bem enquadrada"), ", ", und("de boa qualidade"), " e ", und("legível"),
        ". Não atendemos ligações pelo WhatsApp: para falar por telefone, ligue para o mesmo número, por ligação comum."]},
    {"type": "p", "line": 360, "first": 1134, "runs": [
        "O(a) requerente fica ciente de que a análise do pedido de assistência jurídica gratuita/defesa judicial fica condicionada à "
        "juntada da documentação pendente acima elencada, ", bu("no prazo máximo de "), B("prazo", 80, "Prazo: 30 dias (prazo normal) ou 48 horas (PAJ urgente)", b=True),
        ", salientando-se, desde já, que, em caso de ausência de manifestação, o PAJ será ", bold("ARQUIVADO"), "."]},
    {"type": "signature", "lines": ["Assinatura do(a) assistido(a)"], "before": 1100},
    {"type": "p", "align": "center", "before": 200, "runs": data_pelotas()},
    {"type": "instructions", "title": "Instruções para quem preenche",
     "items": [("", "Clique depois do número 1 e digite o primeiro documento pendente. Ao apertar Enter, um novo item numerado é "
                    "criado automaticamente na lista. Para encerrar a lista, aperte Enter duas vezes."),
               ("", "No prazo, escreva 30 dias (prazo normal) ou 48 horas (PAJ urgente).")],
     "pdf_items": [("", "Escreva um documento pendente em cada linha."), ("", "No prazo, escreva 30 dias (prazo normal) ou 48 horas (PAJ urgente).")]},
]})

# ---------------- formulários médicos ----------------
IMPRESC = [bold("* "), "Visando dar prosseguimento em seu processo administrativo nesta unidade, é ", bold("IMPRESCINDÍVEL"),
           " a apresentação deste formulário ", bold("INTEGRALMENTE"), " preenchido por seu médico."]


def ident(paj="PAJ nº:"):
    return {"type": "fields", "cols": [0.5, 0.5], "rows": [[{"label": "Nome:", "span": 2}], [{"label": "CPF nº:"}, {"label": paj}]], "after": 180}


def fim_medico(assin="Assinatura e carimbo do(a) médico(a)"):
    return [{"type": "fields", "cols": [0.6, 0.4], "rows": [[{"label": "Local:"}, {"label": "Data:"}]], "after": 0},
            {"type": "signature", "lines": [assin], "before": 800}]


def qs(items, lines=6, size=None, breaks=()):
    out = []
    for i, q in enumerate(items, 1):
        num, runs, extra = (q if isinstance(q, tuple) and len(q) == 3 else (str(i) + ".", q, None))
        out.append({"type": "q", "num": num, "runs": runs if isinstance(runs, list) else [runs], "size": size, "pageBreak": i in breaks})
        n = lines(i) if callable(lines) else lines
        rows = [{"lines": n}] + ([{"h": 420, "label": extra}] if extra else [])
        out.append({"type": "box", "rows": rows, "after": 180})
    return out


def laudo(fname, title, paj, quesitos, notice=True, lines=6, breaks=()):
    body = [{"type": "title", "text": title, "size": 26, "after": 220}, ident(paj)]
    if notice:
        body.append({"type": "notice", "runs": IMPRESC, "after": 140})
    body.append({"type": "heading", "text": "QUESITOS MÉDICOS", "before": 60, "after": 120})
    body += qs(quesitos, lines, breaks=breaks)
    body += fim_medico()
    return {"file": fname, "title": title.replace("\n", " ").title(), "size": 22, "body": body}


SPECS.append(laudo("Laudo_medico_cirurgia", "LAUDO MÉDICO PARA SUBSIDIAR\nPEDIDO JUDICIAL DE CIRURGIA", "PAJ nº:", lines=5, quesitos=[
    "O paciente apresenta qual doença ou moléstia? Quais os principais sintomas apresentados?",
    "Qual(is) o(s) procedimento(s) cirúrgico(s) indicado(s) para o tratamento da enfermidade?",
    "É possível identificar urgência no procedimento cirúrgico indicado? Caso não proceda ao tratamento imediatamente, quais as consequências para o paciente?",
    "O procedimento cirúrgico é considerado eletivo ou necessário?",
    "A cirurgia indicada é fornecida pelo SUS? Em caso positivo, houve o encaminhamento do paciente para a sua realização?",
    "Há outros meios disponíveis para o tratamento do paciente pelo SUS (clínico, cirúrgico, fisioterápico ou medicamentoso)?",
    "Pelo conhecimento do doutor, quais os hospitais nesta região estão habilitados à realização do procedimento cirúrgico?",
    "Qual o custo aproximado de realização do procedimento cirúrgico?",
    "Outros esclarecimentos que o expert entender pertinentes."]))

SPECS.append(laudo("Laudo_medico_exame", "LAUDO MÉDICO PARA SUBSIDIAR\nPEDIDO JUDICIAL DE EXAME MÉDICO", "E-PAJ nº:", [
    ("1.", "O paciente apresenta qual(is) doença(s) ou moléstia(s)?", "CID-10 ou CID-11:"),
    "Quais os principais sintomas apresentados?",
    "Qual(is) o(s) exame(s) médico(s) indicado(s) para o tratamento/diagnóstico da enfermidade?",
    "É possível identificar urgência na realização do exame médico indicado? Caso não proceda à realização imediatamente, quais as consequências para o paciente?",
    "O exame indicado é fornecido pelo SUS? Em caso positivo, houve o encaminhamento do paciente para a sua realização?",
    "Há outros meios disponíveis para o tratamento/diagnóstico do paciente fornecidos pelo SUS?",
    "Outros esclarecimentos que o expert entender pertinentes."], notice=False))

SPECS.append(laudo("Laudo_medico_internacao_UTI", "LAUDO MÉDICO PARA SUBSIDIAR\nPEDIDO JUDICIAL DE INTERNAÇÃO EM UTI", "E-PAJ nº:", lines=7, quesitos=[
    "A(o) paciente apresenta qual doença ou moléstia? Quais os principais sintomas apresentados?",
    "Qual é o quadro clínico atual da(o) paciente? É necessária a internação em Unidade de Terapia Intensiva?",
    "É possível identificar urgência na internação? A(o) paciente já foi cadastrada(o) na Central de Regulação/Leitos para obtenção de UTI? Quando foi realizado o cadastro?",
    "Outros esclarecimentos que o expert entender pertinentes."], notice=False))

SPECS.append(laudo("Laudo_medico_beneficio_por_incapacidade",
                   "LAUDO MÉDICO PARA SUBSIDIAR PEDIDO JUDICIAL DE\nBENEFÍCIO PREVIDENCIÁRIO POR INCAPACIDADE LABORAL", "PAJ nº:", lines=5, quesitos=[
    ("1.", "Apresenta o paciente doença ou moléstia? Em caso positivo, a doença é efetivamente incapacitante para o desempenho de sua atividade laborativa habitual?", "CID-10 ou CID-11:"),
    "Quais os sintomas apresentados pelo paciente que o tornam incapaz para o trabalho?",
    "Qual a data aproximada de início da incapacidade (momento em que a doença realmente retirou do paciente a aptidão para o trabalho)? Com base em que dados foi possível fixar essa data?",
    "A incapacidade laboral do paciente é de natureza permanente ou temporária, justificando a sua conclusão? Se temporária, qual o tempo de duração?",
    "A incapacidade laborativa do paciente é parcial (atinge parte das funções) ou total (atinge todas as funções diretamente relacionadas com a capacidade laboral)? Justifique sua conclusão."]))

# adicional de 25% (art. 45 da Lei 8.213/1991): mesma base do laudo de incapacidade, com as perguntas sobre a assistência permanente
adic = {"file": "Laudo_medico_adicional_25", "title": "Laudo Médico para Subsidiar Pedido Judicial de Adicional de 25% na Aposentadoria", "size": 22, "body": [
    {"type": "title", "text": "LAUDO MÉDICO PARA SUBSIDIAR PEDIDO JUDICIAL DE\nADICIONAL DE 25% NA APOSENTADORIA", "size": 26, "after": 220}, ident("PAJ nº:"),
    {"type": "notice", "runs": IMPRESC, "after": 140},
    {"type": "heading", "text": "QUESITOS MÉDICOS", "before": 60, "after": 120}]}
adic["body"] += qs([
    ("1.", "Apresenta o paciente doença ou moléstia? Em caso positivo, a doença o torna total e permanentemente incapaz para o trabalho?", "CID-10 ou CID-11:"),
    "Quais os sintomas e as limitações apresentados pelo paciente?",
    ["O paciente necessita da ", bold("assistência permanente de outra pessoa"), " para as atividades da vida diária? Justifique sua conclusão."]], lines=3)
adic["body"] += [
    {"type": "q", "num": "4.", "runs": ["Para quais atividades o paciente depende da ajuda de outra pessoa?"]},
    {"type": "opts", "cols": 2, "keepNext": True, "after": 100, "items": [
        "banhar-se", "vestir-se", "usar o banheiro", "controlar a micção e a evacuação", "transferir-se (da cama para a cadeira e vice-versa)",
        "alimentar-se", "locomover-se dentro de casa", "tomar a medicação"]},
    {"type": "box", "rows": [{"h": 420, "label": "A dependência é total ou parcial em cada atividade marcada? Há outras? Explique:"}, {"lines": 2}], "after": 180},
    {"type": "q", "num": "5.", "runs": ["O paciente se enquadra em alguma das situações do Anexo I do Decreto nº 3.048/1999?"]},
    {"type": "opts", "cols": 2, "keepNext": True, "after": 200, "items": [
        "cegueira total", "perda de nove dedos das mãos ou superior a esta", "paralisia dos dois membros superiores ou inferiores",
        "perda dos membros inferiores, acima dos pés, quando a prótese for impossível", "perda de uma das mãos e de dois pés, ainda que a prótese seja possível",
        "perda de um membro superior e outro inferior, quando a prótese for impossível", "alteração das faculdades mentais com grave perturbação da vida orgânica e social",
        "doença que exija permanência contínua no leito", "incapacidade permanente para as atividades da vida diária", "nenhuma das situações acima"]},
    {"type": "q", "num": "6.", "runs": ["Desde quando, aproximadamente, o paciente necessita da assistência permanente de outra pessoa? Com base em que dados foi possível fixar essa data? A necessidade é definitiva ou há previsão de melhora?"]},
    {"type": "box", "rows": [{"lines": 3}], "after": 180},
    {"type": "fields", "cols": [0.6, 0.4], "rows": [[{"label": "Local:"}, {"label": "Data:"}]], "after": 0},
    {"type": "signature", "lines": ["Assinatura e carimbo do(a) médico(a)"], "before": 640}]
SPECS.append(adic)

SPECS.append(laudo("Formulario_BPC_LOAS_pessoa_com_deficiencia",
                   "FORMULÁRIO PARA PEDIDO JUDICIAL DE BENEFÍCIO\nASSISTENCIAL (PESSOA COM DEFICIÊNCIA)", "PAJ nº:", lines=8, quesitos=[
    ("1.", "A pessoa acima qualificada é portadora de qual moléstia?", "CID-10 ou CID-11:"),
    "Quais as características da doença? Tais características causam impedimentos (de natureza física, mental, intelectual ou sensorial) capazes de obstruir a participação plena e efetiva do paciente na sociedade em igualdade de condições com as demais pessoas?",
    "Os impedimentos podem ser considerados de longo prazo (produzem efeitos por mais de dois anos), tendo em vista o seu início e a previsão de recuperação do paciente?"]))

# tratamento
trat = {"file": "Formulario_pedido_judicial_tratamento", "title": "Formulário para Pedido Judicial de Tratamento", "size": 22, "body": [
    {"type": "title", "text": "FORMULÁRIO PARA PEDIDO\nJUDICIAL DE TRATAMENTO", "size": 26, "after": 300},
    {"type": "fields", "cols": [0.6, 0.4], "rows": [[{"label": "Nome:", "span": 2}], [{"label": "CPF:"}, {"label": "E-PAJ:"}]], "after": 240},
    {"type": "notice", "runs": IMPRESC},
    {"type": "heading", "text": "QUESITOS MÉDICOS", "before": 120}]}
trat["body"] += qs([
    ("1.", "A pessoa acima qualificada é portadora de qual moléstia?", "CID-10 ou CID-11:"),
    "Quais as características da doença?",
    "Qual(is) o(s) tratamento(s) necessário(s) para o controle da moléstia? Qual o tempo de duração do tratamento?",
    "Há alguma alternativa terapêutica fornecida pelo SUS que possa substituir o tratamento acima prescrito (tratamento similar que possa substituir o indicado)? Qual(is)?"], lines=lambda i: 4 if i in (2, 4) else 5)
trat["body"] += [
    {"type": "q", "num": "5.", "runs": ["Quais as possíveis consequências caso o paciente não realize o tratamento prescrito?"]},
    {"type": "opts", "cols": 2, "keepNext": True, "after": 100, "items": [
        "risco de morte", "perda irreversível de órgãos ou de funções orgânicas", "risco de cegueira",
        "grave comprometimento do bem-estar", "outras"]},
    {"type": "box", "rows": [{"h": 420, "label": "Explicação da(s) consequência(s) acima:"}, {"lines": 3}]},
] + fim_medico()
SPECS.append(trat)

# medicamentos
med = {"file": "Formulario_pedido_judicial_medicamentos", "title": "Formulário para Pedido Judicial de Medicamentos", "size": 22, "body": [
    {"type": "title", "text": "FORMULÁRIO PARA PEDIDO\nJUDICIAL DE MEDICAMENTOS", "size": 26, "after": 300},
    {"type": "fields", "cols": [0.5, 0.5], "rows": [[{"label": "Nome do(a) assistido(a):", "span": 2}],
                                                [{"label": "CPF:"}, {"label": "PAJ:"}]], "after": 240},
    {"type": "notice", "runs": [bold("Observação: "), "para o prosseguimento do processo administrativo, é ", bold("IMPRESCINDÍVEL"),
                                " o preenchimento ", bold("INTEGRAL"), " deste formulário pelo seu médico."]},
    {"type": "heading", "text": "QUESITOS", "before": 120}]}
med["body"] += qs([
    ["Indicar a(s) ", bold("patologia(s)"), " do(a) assistido(a)."],
    ["Indicar o ", bold("CID"), " (CID-10 ou CID-11) da(s) patologia(s)."],
    ["Descrever as ", bold("características"), " da(s) patologia(s)."],
    ["Indicar o(s) ", bold("medicamento(s) pretendido(s)"), " pelo(a) assistido(a), a ", bold("posologia"), " e a ", bold("duração"), " do tratamento."],
    ["O SUS fornece ", bold("medicamentos similares ao(s) pretendido(s)"), " para tratar a patologia do(a) assistido(a)? Caso ",
     bold("positivo, listar esses medicamentos"), "."],
    ["O assistido ", bold("já usou os medicamentos fornecidos pelo SUS"), " para tratar a patologia? Caso ", bold("positivo"),
     ", apontar os ", bold("resultados"), " obtidos. Caso ", bold("negativo"), ", informar se ", bold("poderiam ser usados sem prejuízo ao tratamento"), "."],
    ["Os medicamentos fornecidos pelo SUS são ", bold("ineficazes ou inadequados"), " para o caso do(a) assistido(a)? Caso ", bold("positivo"),
     ", esclarecer os ", bold("motivos da ineficácia ou inadequação"), "."],
    ["Explicar a ", bold("diferença entre a eficácia"), " esperada do medicamento pretendido e a do fornecido pelo SUS. Elencar os ",
     bold("estudos"), " que embasam a sua conclusão."],
    ["O medicamento pretendido está autorizado pela ", bold("ANVISA"), "? Caso ", bold("negativo"), ", informar se há autorização da ",
     bold("FDA"), " (Food and Drug Administration) ou ", bold("EMA"), " (European Medicines Agency)."]], lines=lambda i: 2 if i == 2 else 4)
med["body"] += [
    {"type": "q", "num": "10.", "runs": ["Assinalar as ", bold("consequências"), " que podem surgir caso o(a) assistido(a) não use o medicamento pretendido."]},
    {"type": "opts", "cols": 2, "keepNext": True, "after": 100, "items": [
        "Risco de morte", "Risco de agravamento da patologia", "Risco de cegueira",
        "Perda irreversível de órgãos ou funções orgânicas", "Grave comprometimento do bem-estar", "Outras (especificar abaixo)"]},
    {"type": "box", "rows": [{"h": 420, "label": "Outras:"}, {"lines": 3}]},
] + fim_medico("Assinatura e carimbo do(a) médico(a)")
SPECS.append(med)

# versão com quesitos alinhados ao Tema 6 do STF (Súmula Vinculante 61)
med6 = {"file": "Formulario_pedido_judicial_medicamentos_Tema_6_STF", "title": "Formulário para Pedido Judicial de Medicamentos (Tema 6 do STF)", "size": 22, "body": [
    {"type": "title", "text": "FORMULÁRIO PARA PEDIDO\nJUDICIAL DE MEDICAMENTOS", "size": 26, "after": 300},
    {"type": "fields", "cols": [0.5, 0.5], "rows": [[{"label": "Nome do(a) assistido(a):", "span": 2}],
                                                [{"label": "CPF:"}, {"label": "PAJ:"}]], "after": 240},
    {"type": "notice", "after": 120, "runs": [bold("Observação: "), "para o prosseguimento do processo administrativo, é ", bold("IMPRESCINDÍVEL"),
                                " o preenchimento ", bold("INTEGRAL"), " deste formulário pelo seu médico."]},
    {"type": "notice", "runs": [
        "Desde 2024, o Supremo Tribunal Federal (Tema 6 e Súmula Vinculante 61) só admite o fornecimento judicial de medicamento não incorporado ao SUS "
        "quando houver ", bold("laudo médico fundamentado"), " que demonstre a imprescindibilidade do tratamento, a impossibilidade de substituição "
        "por alternativa oferecida pelo SUS e a eficácia comprovada por ", bold("evidências científicas de alto nível"),
        ". Por isso, pedimos que todas as respostas sejam completas e fundamentadas."]},
    {"type": "heading", "text": "QUESITOS", "before": 120}]}
med6["body"] += qs([
    ["Indicar a(s) ", bold("patologia(s)"), " do(a) assistido(a) e o respectivo ", bold("CID"), " (CID-10 ou CID-11)."],
    ["Descrever as ", bold("características"), " da(s) patologia(s), o estágio atual da doença e o quadro clínico do(a) assistido(a)."],
    ["Indicar o(s) ", bold("medicamento(s) pretendido(s)"), ", pelo nome do princípio ativo, a ", bold("posologia"), " e a ", bold("duração"), " do tratamento."],
    ["O medicamento pretendido possui ", bold("registro na ANVISA"), "? A indicação prescrita consta da bula registrada? Caso não tenha registro, informar se há autorização da ",
     bold("FDA"), " (Food and Drug Administration) ou da ", bold("EMA"), " (European Medicines Agency)."],
    ["O medicamento pretendido consta das ", bold("listas de dispensação do SUS"), " (RENAME, RESME ou REMUME) ou de ", bold("Protocolo Clínico e Diretrizes Terapêuticas"),
     " aplicável à doença? Caso positivo, o(a) assistido(a) se enquadra nos critérios do protocolo?"],
    ["É de seu conhecimento se o medicamento já foi avaliado pela ", bold("CONITEC"),
     " (Comissão Nacional de Incorporação de Tecnologias no SUS)? Caso positivo, qual foi a conclusão (não incorporação, incorporação para outra indicação ou avaliação pendente)?"],
    ["Quais ", bold("medicamentos ou tratamentos oferecidos pelo SUS"), " existem para a patologia? O(a) assistido(a) ", bold("já fez uso"),
     " deles? Informar quais, por quanto tempo e com quais ", bold("resultados"), "."],
    ["Por que os medicamentos ou tratamentos oferecidos pelo SUS ", bold("não podem substituir"),
     " o medicamento pretendido no caso do(a) assistido(a) (por exemplo, ineficácia, contraindicação, efeitos adversos ou refratariedade)?"],
    ["Quais ", bold("evidências científicas de alto nível"), " comprovam a eficácia, a efetividade e a segurança do medicamento pretendido para a patologia do(a) assistido(a)? Indicar ",
     bold("ensaios clínicos randomizados"), " e ", bold("revisões sistemáticas ou meta-análises"), ", com as respectivas referências."],
    ["Por que o tratamento com o medicamento pretendido é ", bold("imprescindível"), " para o(a) assistido(a)? Quais os benefícios esperados em comparação com as alternativas do SUS?"],
], lines=lambda i: {1: 3, 3: 3, 4: 3, 5: 3, 6: 3, 9: 5, 10: 5}.get(i, 4))
med6["body"] += [
    {"type": "q", "num": "11.", "runs": ["Assinalar as ", bold("consequências"), " que podem surgir caso o(a) assistido(a) não use o medicamento pretendido."]},
    {"type": "opts", "cols": 2, "keepNext": True, "after": 100, "items": [
        "Risco de morte", "Risco de agravamento da patologia", "Risco de cegueira",
        "Perda irreversível de órgãos ou funções orgânicas", "Grave comprometimento do bem-estar", "Outras (especificar abaixo)"]},
    {"type": "box", "rows": [{"h": 420, "label": "Outras:"}, {"lines": 3}]},
] + fim_medico("Assinatura e carimbo do(a) médico(a), com o número do CRM")
SPECS.append(med6)

# oncológico
onc = {"file": "Questionamentos_do_juizo_casos_oncologicos", "title": "Informações Específicas sobre Casos Oncológicos", "size": 22, "body": [
    {"type": "title", "text": "INFORMAÇÕES ESPECÍFICAS SOBRE CASOS\nONCOLÓGICOS REQUERIDAS PELO JUÍZO", "size": 26, "after": 360}]}
onc["body"] += qs([
    ("a)", "Qual a avaliação da capacidade funcional do(a) paciente por meio da ECOG/Performance Status (PS)?", None),
    ("b)", "O(a) paciente se encontra em tratamento? Houve tratamentos prévios? Quais? (Descrever tratamentos, posologia, tempo de duração...)", None),
    ("c)", "O(a) paciente apresenta comorbidades?", None),
    ("d)", "Quais os meios confirmatórios do diagnóstico realizado?", None),
    ("e)", "O(a) paciente encontra-se internado(a) atualmente?", None),
    ("f)", "Há alternativas disponíveis no SUS? Se sim, quais já foram utilizadas (citá-las)?", None)], lines=5)
onc["body"] += [{"type": "q", "num": "g)", "runs": ["Para os diagnósticos abaixo especificados, os seguintes dados adicionais:"]}]
for num, txt in [("g.1)", "Casos de câncer de mama (CID-10 C50…): receptores hormonais e HER-2."),
                 ("g.2)", "Casos de câncer de fígado (CID-10 C22, C22.0, C22.1, C22.9…): se o paciente tem cirrose; classificação Child-Pugh; classificação BCLC Barcelona."),
                 ("g.3)", "Casos de mieloma múltiplo (CID-10 C90.0): se o paciente é elegível ao transplante de medula óssea (TMO).")]:
    onc["body"] += [{"type": "q", "num": num, "runs": [txt]}, {"type": "box", "rows": [{"lines": 4}]}]
onc["body"] += [{"type": "notice", "runs": ["Ainda, deverá ser encaminhada ", bold("negativa"),
                                            ", emitida pela unidade oncológica em que realiza atendimento, acerca do não fornecimento do medicamento requerido, bem como ",
                                            bold("declaração que comprova o vínculo"), "."]}]
SPECS.append(onc)

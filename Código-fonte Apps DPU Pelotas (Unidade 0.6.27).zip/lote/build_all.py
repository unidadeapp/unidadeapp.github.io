import json, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from specs import SPECS
import finish

only = sys.argv[1:]
root = Path(__file__).parent
(root / "build").mkdir(exist_ok=True)
(root / "saida/Word").mkdir(parents=True, exist_ok=True)
(root / "saida/PDF").mkdir(parents=True, exist_ok=True)
for s in SPECS:
    if only and s["file"] not in only:
        continue
    t0 = time.time()
    sp = root / "build" / (s["file"] + ".json")
    sp.write_text(json.dumps(s, ensure_ascii=False))
    for target in ("word", "pdf"):
        raw = root / "build" / f'{s["file"]}.{target}.docx'
        subprocess.run(["node", str(root / "formlib.js"), str(sp), target, str(raw)], check=True)
    cbw, nb = finish.make_word(root / "build" / f'{s["file"]}.word.docx', root / "saida/Word" / (s["file"] + ".dotx"))
    cbp, ntx = finish.make_pdf(root / "build" / f'{s["file"]}.pdf.docx', root / "saida/PDF" / (s["file"] + ".pdf"), s["title"])
    print(f'{s["file"]}: word cb={cbw} lacunas={nb} | pdf cb={cbp} campos={ntx} | {time.time()-t0:.1f}s', flush=True)

"""Finaliza os arquivos gerados pelo formlib.js.

word: troca marcadores por controles de conteúdo (texto e caixa de seleção) e salva como modelo .dotx
pdf : gera uma variante sem controles de texto, exporta pelo LibreOffice (caixas viram campos),
      cria campos de texto nas caixinhas e nas lacunas, troca a marca das caixas por X e põe o botão Limpar.
"""
import itertools
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pdfplumber
from pypdf import PdfWriter
from pypdf.generic import (ArrayObject, BooleanObject, DecodedStreamObject, DictionaryObject, FloatObject,
                           NameObject, NumberObject, TextStringObject)

SKILL = "/root/.claude/skills/synced/6dae1979-fe10-41d5-b27e-9e8448150160_f0fd83e0-2715-40a0-a7e2-cbd98055b71f/docx"
CB_FONT = '<w:rFonts w:ascii="MS Gothic" w:eastAsia="MS Gothic" w:hAnsi="MS Gothic" w:hint="eastAsia"/>'


def filler(width_pt, size_pt):
    """Texto de preenchimento ('nnnnnn nnnnnn ...') com a largura aproximada pedida (Cambria/Caladea)."""
    n_w, sp_w = 0.558 * size_pt, 0.22 * size_pt
    chunk = 6 * n_w + sp_w
    full = int((width_pt + sp_w) // chunk)
    rest = width_pt - full * chunk
    parts = ["n" * 6] * full
    k = int(max(0, rest - sp_w) // n_w)
    if k >= 1:
        parts.append("n" * k)
    return " ".join(parts) or "nnn"


def enc_color(k):
    return "%02X%02X%02X" % (255 - (k // 36) % 6, 255 - (k // 6) % 6, 255 - k % 6)


def dec_color(c):
    r, g, b = [255 - round(float(x) * 255) for x in c]
    return r * 36 + g * 6 + b


def unpack(docx, d):
    shutil.rmtree(d, ignore_errors=True)
    subprocess.run(["unzip", "-q", str(docx), "-d", str(d)], check=True)
    subprocess.run(["find", str(d), "-type", "l", "-delete"], check=True)


def pack(d, out):
    out = Path(out).resolve()
    out.unlink(missing_ok=True)
    subprocess.run(f"cd '{d}' && zip -qXrD '{out}' .", shell=True, check=True)


def blank_runs(b, k, word):
    s = b.get("size", 22)
    rpr = (f'<w:rFonts w:ascii="Cambria" w:hAnsi="Cambria" w:cs="Cambria"/><w:noProof/>'
           f'<w:color w:val="{"FFFFFF" if word else enc_color(k)}"/><w:sz w:val="{s}"/><w:szCs w:val="{s}"/>'
           f'<w:u w:val="single" w:color="3A3A3A"/>')
    fil = filler(b["w"], s / 2)
    if not word:  # PDF: a lacuna não se parte entre duas linhas (cada pedaço virava um campo e o texto digitado não passava para a linha de baixo)
        fil = fil.replace(" ", "\u00a0")
    xml = f'<w:r><w:rPr>{rpr}</w:rPr><w:t xml:space="preserve">{fil}</w:t></w:r>'
    if b.get("note"):
        xml += (f'<w:r><w:rPr><w:rFonts w:ascii="Cambria" w:hAnsi="Cambria"/><w:b/><w:color w:val="3F7F2A"/>'
                f'<w:sz w:val="{s}"/><w:vertAlign w:val="superscript"/></w:rPr><w:t>{b["note"]}</w:t></w:r>')
    return xml


def text_cc(b, k, sid):
    s = b.get("size", 22)
    alias = b.get("tip", b["name"]).replace('"', "'")
    return (f'<w:sdt><w:sdtPr><w:rPr><w:rFonts w:ascii="Cambria" w:hAnsi="Cambria" w:cs="Cambria"/>{"<w:b/>" if b.get("b") else ""}<w:color w:val="1E1E1E"/>'
            f'<w:sz w:val="{s}"/><w:szCs w:val="{s}"/><w:lang w:val="pt-BR"/></w:rPr><w:alias w:val="{alias}"/>'
            f'<w:tag w:val="{b["name"]}"/><w:id w:val="{sid}"/><w:showingPlcHdr/><w:text/></w:sdtPr>'
            f'<w:sdtContent>{blank_runs(b, k, True)}</w:sdtContent></w:sdt>')


def checkbox(sid):
    return (f'<w:sdt><w:sdtPr><w:rPr>{CB_FONT}<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr><w:id w:val="{sid}"/>'
            '<w14:checkbox><w14:checked w14:val="0"/><w14:checkedState w14:val="2612" w14:font="MS Gothic"/>'
            '<w14:uncheckedState w14:val="2610" w14:font="MS Gothic"/></w14:checkbox></w:sdtPr>'
            f'<w:sdtContent><w:r><w:rPr>{CB_FONT}<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr><w:t>☐</w:t></w:r>'
            '</w:sdtContent></w:sdt>')


def replace_markers(xml, blanks, word):
    ids = itertools.count(810001)
    run_pat = lambda m: re.compile(r"<w:r>(?:(?!</w:r>).)*?" + re.escape(m) + r"(?:(?!</w:r>).)*?</w:r>", re.S)
    xml, n_cb = run_pat("§CB§").subn(lambda _: checkbox(next(ids)), xml)
    for k, b in enumerate(blanks, start=1):
        rep = text_cc(b, k, next(ids)) if word else blank_runs(b, k, False)
        xml, n = run_pat(f"§T{k}§").subn(lambda _: rep, xml)
        assert n == 1, (k, n)
    assert "§" not in xml, re.findall("§[^§]*§", xml)[:3]
    xml = xml.replace("‑", '</w:t><w:noBreakHyphen/><w:t xml:space="preserve">')
    return xml, n_cb


def make_word(raw, out_dotx):
    blanks = json.loads(Path(str(raw) + ".blanks.json").read_text())
    d = Path(tempfile.mkdtemp())
    unpack(raw, d)
    p = d / "word/document.xml"
    xml, n_cb = replace_markers(p.read_text(encoding="utf-8"), blanks, True)
    p.write_text(xml, encoding="utf-8")
    ct = d / "[Content_Types].xml"
    ct.write_text(ct.read_text().replace("wordprocessingml.document.main+xml", "wordprocessingml.template.main+xml"))
    pack(d, out_dotx)
    if Path(SKILL, "scripts/office/validate.py").exists():  # validador do skill docx, quando houver
        r = subprocess.run(["python3", f"{SKILL}/scripts/office/validate.py", str(out_dotx)], capture_output=True, text=True)
        assert "PASSED" in r.stdout, r.stdout + r.stderr
    return n_cb, len(blanks)


# ---------------- PDF ----------------
def xobj(w, bw, bh, data, res=None):
    st = DecodedStreamObject()
    st.set_data(data.encode("latin-1"))
    st.update({NameObject("/Type"): NameObject("/XObject"), NameObject("/Subtype"): NameObject("/Form"),
               NameObject("/BBox"): ArrayObject([FloatObject(0), FloatObject(0), FloatObject(bw), FloatObject(bh)])})
    if res is not None:
        st[NameObject("/Resources")] = res
    return w._add_object(st)


def font_obj(w, base):
    return w._add_object(DictionaryObject({
        NameObject("/Type"): NameObject("/Font"), NameObject("/Subtype"): NameObject("/Type1"),
        NameObject("/BaseFont"): NameObject(base), NameObject("/Encoding"): NameObject("/WinAnsiEncoding")}))


def text_field(w, page, name, rect, tip, multiline=False, size=0):
    f = DictionaryObject({
        NameObject("/Type"): NameObject("/Annot"), NameObject("/Subtype"): NameObject("/Widget"),
        NameObject("/FT"): NameObject("/Tx"), NameObject("/T"): TextStringObject(name),
        NameObject("/Rect"): ArrayObject([FloatObject(v) for v in rect]), NameObject("/F"): NumberObject(4),
        NameObject("/DA"): TextStringObject(f"/Helv {size} Tf 0 g"), NameObject("/Ff"): NumberObject(4096 if multiline else 0),
        NameObject("/P"): page.indirect_reference})
    if tip:
        f[NameObject("/TU")] = TextStringObject(tip)
    if name.split("_")[0] == "ano":
        f[NameObject("/MaxLen")] = NumberObject(2)
    return w._add_object(f)


def post_pdf(src, out, blanks, title, juntar=True):
    w = PdfWriter(clone_from=src)
    w.add_metadata({"/Title": title, "/Author": "Defensoria Pública da União"})
    if "/AcroForm" not in w._root_object:
        w._root_object[NameObject("/AcroForm")] = DictionaryObject({NameObject("/Fields"): ArrayObject()})
    af = w._root_object["/AcroForm"].get_object()
    if "/Fields" not in af:
        af[NameObject("/Fields")] = ArrayObject()
    fields = af["/Fields"].get_object()
    if "/DR" not in af:
        af[NameObject("/DR")] = DictionaryObject()
    dr = af["/DR"].get_object()
    if "/Font" not in dr:
        dr[NameObject("/Font")] = DictionaryObject()
    fonts = dr["/Font"].get_object()
    fonts[NameObject("/Helv")] = font_obj(w, "/Helvetica")
    hebo = font_obj(w, "/Helvetica-Bold")
    fonts[NameObject("/HeBo")] = hebo
    af[NameObject("/NeedAppearances")] = BooleanObject(True)

    # caixas de seleção: marca X, desmarcada não desenha nada (o quadradinho já está na página)
    n_cb, cb_centers = 0, {}
    for pi, page in enumerate(w.pages):
        cb_centers[pi] = []
        for a in page.get("/Annots", []) or []:
            a = a.get_object()
            if a.get("/FT") != "/Btn":
                continue
            n_cb += 1
            x0, y0, x1, y1 = [float(v) for v in a["/Rect"]]
            cb_centers[pi].append(((x0 + x1) / 2, (y0 + y1) / 2))
            bw, bh = x1 - x0, y1 - y0
            m = 0.24
            xs = (f"q 0 0 0 RG 1.2 w 1 J {m*bw:.2f} {m*bh:.2f} m {(1-m)*bw:.2f} {(1-m)*bh:.2f} l "
                  f"{m*bw:.2f} {(1-m)*bh:.2f} m {(1-m)*bw:.2f} {m*bh:.2f} l S Q")
            a[NameObject("/AP")] = DictionaryObject({NameObject("/N"): DictionaryObject({
                NameObject("/Sim"): xobj(w, bw, bh, xs), NameObject("/Off"): xobj(w, bw, bh, "")})})
            for k in ("/AS", "/V", "/DV"):
                a[NameObject(k)] = NameObject("/Off")
            a[NameObject("/MK")] = DictionaryObject({NameObject("/CA"): TextStringObject("8")})
            a[NameObject("/DA")] = TextStringObject("/ZaDb 0 Tf 0 g")
            a[NameObject("/T")] = TextStringObject(f"marcar_{n_cb:02d}")
    fonts[NameObject("/ZaDb")] = w._add_object(DictionaryObject({
        NameObject("/Type"): NameObject("/Font"), NameObject("/Subtype"): NameObject("/Type1"),
        NameObject("/BaseFont"): NameObject("/ZapfDingbats")}))

    n_tx, used = 0, {}
    with pdfplumber.open(src) as pdf:
        for pi, p in enumerate(pdf.pages):
            Hh = float(p.height)
            page = w.pages[pi]
            if "/Annots" not in page:
                page[NameObject("/Annots")] = ArrayObject()
            annots = page["/Annots"].get_object()
            words = p.extract_words()

            def add(name, rect, tip, ml=False, size=0):
                nonlocal n_tx
                used[name] = used.get(name, 0) + 1
                nm = name if used[name] == 1 else f"{name}_{used[name]}"
                ref = text_field(w, page, nm, rect, tip, ml, size)
                annots.append(ref)
                fields.append(ref)
                n_tx += 1

            # 1) caixinhas (células com fundo branco)
            seen = set()
            cells = []
            for r in sorted(p.rects, key=lambda r: (round(r["top"]), r["x0"])):
                col = r.get("non_stroking_color")
                if not r.get("fill") or col is None or len(col) != 3 or any(round(float(c), 3) != 1.0 for c in col):
                    continue
                if r["width"] < 12 or r["height"] < 10:
                    continue
                key = (round(r["x0"]), round(r["top"]), round(r["x1"]), round(r["bottom"]))
                if key in seen:
                    continue
                seen.add(key)
                x0, x1, y0, y1 = r["x0"], r["x1"], Hh - r["bottom"], Hh - r["top"]
                if any(x0 <= cx <= x1 and y0 <= cy <= y1 for cx, cy in cb_centers[pi]):
                    continue
                inside = [t for t in words if t["x0"] >= x0 - .5 and t["x1"] <= x1 + .5 and t["top"] >= r["top"] - .5 and t["bottom"] <= r["bottom"] + .5]
                cells.append((r, inside))
            # linhas pautadas seguidas, sem texto, da mesma largura: uma resposta só (o texto quebra de linha sozinho)
            grupos = []
            for r, inside in cells:
                g = grupos[-1] if grupos else None
                if (juntar and not inside and r["width"] >= 440 and g and not g[-1][1] and abs(g[-1][0]["x0"] - r["x0"]) < 1
                        and abs(g[-1][0]["x1"] - r["x1"]) < 1 and abs(r["top"] - g[-1][0]["bottom"]) < 2.5):
                    g.append((r, inside))
                else:
                    grupos.append([(r, inside)])
            for g in grupos:
                r, inside = g[0]
                if len(g) > 1:
                    top, bottom = g[0][0]["top"], g[-1][0]["bottom"]
                    add("resposta", (r["x0"] + 1.5, Hh - bottom + 1, r["x1"] - 1.5, Hh - top - 1), "Resposta", True)
                    continue
                x0, x1, y0, y1 = r["x0"], r["x1"], Hh - r["bottom"], Hh - r["top"]
                tall = (y1 - y0) > 30
                tip = re.sub(r"[\d:]+$", "", " ".join(t["text"] for t in inside)).strip(" :") if inside else ""
                if inside:
                    first_line = [t for t in inside if t["top"] - inside[0]["top"] < 3]
                    x0 = max(t["x1"] for t in first_line) + 3
                    if x1 - x0 < 25:
                        continue
                    if tall:  # rótulo no alto de uma caixa grande: campo abaixo dele
                        y1 = Hh - max(t["bottom"] for t in first_line) - 1
                        x0 = r["x0"]
                nm = re.sub(r"\W+", "_", tip.lower()).strip("_") or "resposta"
                if nm.startswith("cid_10_ou"):  # "CID-10 ou CID-11:" continua se chamando "cid"
                    nm, tip = "cid", "CID-10 ou CID-11"
                add(nm, (x0 + 1.5, y0 + 1, x1 - 1.5, y1 - 1), tip or "Resposta", tall)

            # 2) lacunas no meio do texto (cada uma tem uma cor quase branca própria)
            segs = {}
            for ch in p.chars:
                col = ch.get("non_stroking_color")
                if not col or len(col) != 3:
                    continue
                rgb = [round(float(c) * 255) for c in col]
                if min(rgb) < 249 or rgb == [255, 255, 255]:
                    continue
                k = dec_color(col)
                segs.setdefault(k, []).append(ch)
            for k in sorted(segs):
                b = blanks[k - 1]
                lines = []
                for ch in sorted(segs[k], key=lambda c: (round(c["top"]), c["x0"])):
                    if lines and abs(lines[-1][-1]["top"] - ch["top"]) < 3:
                        lines[-1].append(ch)
                    else:
                        lines.append([ch])
                for ln in lines:
                    x0, x1 = min(c["x0"] for c in ln), max(c["x1"] for c in ln)
                    top, bot = min(c["top"] for c in ln), max(c["bottom"] for c in ln)
                    add(b["name"], (x0, Hh - bot - 1.5, x1, Hh - top + 1), b.get("tip", ""), False)

    # botão Limpar formulário (aparece na tela, não sai na impressão)
    page = w.pages[0]
    PW, PH = float(page.mediabox.width), float(page.mediabox.height)
    BW, BH = 118, 22
    x1 = PW - 70.87
    x0, y1 = x1 - BW, PH - 16
    rr, k = 5, 0.5523 * 5
    path = (f"{rr} 0.5 m {BW-rr} 0.5 l {BW-rr+k} 0.5 {BW-0.5} {rr-k} {BW-0.5} {rr} c {BW-0.5} {BH-rr} l "
            f"{BW-0.5} {BH-rr+k} {BW-rr+k} {BH-0.5} {BW-rr} {BH-0.5} c {rr} {BH-0.5} l {rr-k} {BH-0.5} 0.5 {BH-rr+k} 0.5 {BH-rr} c "
            f"0.5 {rr} l 0.5 {rr-k} {rr-k} 0.5 {rr} 0.5 c h")
    res = DictionaryObject({NameObject("/Font"): DictionaryObject({NameObject("/HeBo"): hebo})})
    ap = lambda fill, stroke, txt: xobj(w, BW, BH, f"q {fill} rg {stroke} RG 1 w {path} B Q BT /HeBo 9 Tf {txt} rg "
                                        f"{(BW - 77.0) / 2:.2f} {BH / 2 - 3.2:.2f} Td (Limpar formul\\341rio) Tj ET", res)
    btn = w._add_object(DictionaryObject({
        NameObject("/Type"): NameObject("/Annot"), NameObject("/Subtype"): NameObject("/Widget"),
        NameObject("/FT"): NameObject("/Btn"), NameObject("/Ff"): NumberObject(65536),
        NameObject("/T"): TextStringObject("limpar_formulario"), NameObject("/TU"): TextStringObject("Apaga tudo o que foi preenchido"),
        NameObject("/Rect"): ArrayObject([FloatObject(x0), FloatObject(y1 - BH), FloatObject(x1), FloatObject(y1)]),
        NameObject("/F"): NumberObject(0), NameObject("/H"): NameObject("/P"),
        NameObject("/BS"): DictionaryObject({NameObject("/W"): NumberObject(1), NameObject("/S"): NameObject("/S")}),
        NameObject("/DA"): TextStringObject("/HeBo 9 Tf 0.16 0.36 0.11 rg"),
        NameObject("/MK"): DictionaryObject({
            NameObject("/BG"): ArrayObject([FloatObject(0.886), FloatObject(0.937), FloatObject(0.851)]),
            NameObject("/BC"): ArrayObject([FloatObject(0.247), FloatObject(0.498), FloatObject(0.165)]),
            NameObject("/CA"): TextStringObject("Limpar formulário")}),
        NameObject("/AP"): DictionaryObject({NameObject("/N"): ap("0.886 0.937 0.851", "0.247 0.498 0.165", "0.16 0.36 0.11"),
                                             NameObject("/D"): ap("0.247 0.498 0.165", "0.247 0.498 0.165", "1 1 1")}),
        NameObject("/A"): DictionaryObject({NameObject("/S"): NameObject("/ResetForm")}),
        NameObject("/P"): page.indirect_reference}))
    if "/Annots" not in page:
        page[NameObject("/Annots")] = ArrayObject()
    page["/Annots"].get_object().append(btn)
    fields.append(btn)
    w.write(out)
    return n_cb, n_tx


def make_pdf(raw, out_pdf, title):
    blanks = json.loads(Path(str(raw) + ".blanks.json").read_text())
    d = Path(tempfile.mkdtemp())
    unpack(raw, d)
    p = d / "word/document.xml"
    xml, _ = replace_markers(p.read_text(encoding="utf-8"), blanks, False)
    p.write_text(xml, encoding="utf-8")
    tmpdir = Path(tempfile.mkdtemp())
    variant = tmpdir / (Path(out_pdf).stem + ".docx")
    pack(d, variant)
    subprocess.run(["soffice", "--headless", "--convert-to",
                    'pdf:writer_pdf_Export:{"ExportFormFields":{"type":"boolean","value":"true"}}',
                    "--outdir", str(tmpdir), str(variant)], check=True, capture_output=True)
    exported = tmpdir / (Path(out_pdf).stem + ".pdf")
    return post_pdf(str(exported), str(out_pdf), blanks, title, not Path(out_pdf).stem.startswith("Documentacao_pendente"))


if __name__ == "__main__":
    mode, raw, out = sys.argv[1:4]
    if mode == "word":
        print(make_word(raw, out))
    else:
        print(make_pdf(raw, out, sys.argv[4] if len(sys.argv) > 4 else ""))

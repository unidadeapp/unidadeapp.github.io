# Formulário de renda (fora do lote): letra automática nos campos de texto, para o texto digitado não ser cortado
import sys
from pypdf import PdfWriter
from pypdf.generic import NameObject, TextStringObject
for f in sys.argv[1:]:
    w = PdfWriter(clone_from=f); n = 0
    for p in w.pages:
        for a in p.get("/Annots", []) or []:
            a = a.get_object()
            if a.get("/FT") == "/Tx":
                da = str(a.get("/DA", "/Helv 0 Tf 0 g"))
                import re
                a[NameObject("/DA")] = TextStringObject(re.sub(r"(/\w+)\s+[\d.]+\s+Tf", r"\1 0 Tf", da)); n += 1
    w.write(f); print(f.split("/")[-1], n, "campos")

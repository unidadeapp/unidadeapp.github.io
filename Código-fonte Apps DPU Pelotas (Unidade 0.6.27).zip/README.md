# Apps da DPU Pelotas

Desenvolvido por Pedro Tomkowski. Repositório **privado**.

- **Unidade** (antigo Assistente de Trabalho DPU Pelotas, ATDPU) — `apps/Unidade.html`
- **Assistente de Documentos DAC** — `apps/Assistente de Documentos DAC.html`

Para usar: baixe o arquivo da pasta `apps/` e abra no navegador (Chrome, Edge ou Firefox). Funciona sem internet.

Instruções de desenvolvimento: `CLAUDE.md`. Para gerar os apps: `./construir.sh`; para testar: `python3 scripts/testar.py`.

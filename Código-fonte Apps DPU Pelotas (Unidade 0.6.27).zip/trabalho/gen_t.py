# Monta o Unidade (antigo Assistente de Trabalho – DPU Pelotas, ATDPU): um arquivo só, com todas as ferramentas dentro
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, json, re, sys
sys.path.insert(0, RAIZ + "comum")
import lateral as L, marca, temis, unidade, tour, apresentacao
import tema
D = RAIZ + "trabalho/"
MARCA = "UNIDADE"
# cada ferramenta entra com o menu lateral (ou em cima), como no Assistente de Documentos DAC
emb = lambda p, nome, cfg: json.dumps(L.lateral(open(p, encoding="utf-8").read(), MARCA, nome, cfg), ensure_ascii=False).replace("</", "<\\/")
R = {
    "LOGO": base64.b64encode(open(RAIZ + "src/img-002.jpg", "rb").read()).decode(),
    "GATINHO": open(D + "gatinho.svg", encoding="utf-8").read(),
    "APP_LISTA": emb(RAIZ + "lista/Lista_de_documentos_necessarios.html", "Documentos Necessários e Mensagem", L.LI),
    "APP_FALTANTES": emb(RAIZ + "faltantes/Documentos_faltantes.html", "Gerador de Lista de Documentos Faltantes", L.CK),
    "APP_ASSISTENTE": emb(RAIZ + "assistente/Assistente_de_Abertura_de_PAJ.html", "Assistente de Abertura de PAJ", L.AS),
    "APP_CENTRAL": emb(RAIZ + "central/Central_de_Formularios.html", "Central de Formulários", L.CE),
    "APP_APRENDER": emb(RAIZ + "aprender/Aprender_app.html", "Aprender", L.AP),
    "APP_NARRATIVAS": emb(RAIZ + "narrativas/Narrativas.html", "Narrativas", L.NA),
    "APP_PREENCHER": emb(RAIZ + "preencher/Preenchimento_de_formularios.html", "Preenchimento de Formulários", L.PR),
    "APP_SEMATEND": emb(RAIZ + "narrativas/PAJ_sem_atendimento.html", "PAJ sem Atendimento", L.NA),
    "APP_MENSAGENS": emb(RAIZ + "mensagens/Mensagens_DAC.html", "Mensagens Padronizadas – DAC", L.ME),
    "TUTORIAL": open(D + "tutorial.html", encoding="utf-8").read().replace("__TEMIS_AV__", marca.TEMIS.replace("temisC", "temisCT")),
    "APRES": apresentacao.html(apresentacao.slides_atdpu(), "Apresentação do Unidade"), "APRES_CSS": apresentacao.CSS, "APRES_JS": apresentacao.JS,
    "TOUR": tour.script(open(D + "tours_atdpu.js", encoding="utf-8").read().split("\n", 1)[1]),
    "UNIDADE": unidade.html(), "UNIDADE_CSS": unidade.CSS, "FAIXA": marca.FAIXA, "TEMIS_AV": marca.TEMIS, "TEMIS": temis.bloco("atdpu"),
    "ICO": base64.b64encode(open(RAIZ + "icone/Unidade.ico", "rb").read()).decode(), "LOGO_U": marca.UNIDADE,
    "FAVICON": base64.b64encode(open(RAIZ + "icone/favicon_unidade64.png", "rb").read()).decode(),
    "TEMA_CSS": tema.CSS, "TEMA_JS": tema.JS,
    "RELATORIO": base64.b64encode(open(RAIZ + "relatorio/Relatorio_tecnico.pdf", "rb").read()).decode(),
}
html = open(D + "page_t.html", encoding="utf-8").read()
html = re.sub(r"__(LOGO|GATINHO|APP_LISTA|APP_FALTANTES|APP_ASSISTENTE|APP_CENTRAL|APP_APRENDER|APP_NARRATIVAS|APP_PREENCHER|APP_SEMATEND|APP_MENSAGENS|TUTORIAL|FAVICON|ICO|UNIDADE_CSS|UNIDADE|FAIXA|TEMIS_AV|TEMIS|TOUR|APRES_CSS|APRES_JS|APRES|LOGO_U|TEMA_CSS|TEMA_JS|RELATORIO)__", lambda m: R[m.group(1)], html)
assert not re.search(r"__(LOGO|GATINHO|APP_LISTA|APP_FALTANTES|APP_ASSISTENTE|APP_CENTRAL|APP_APRENDER|APP_NARRATIVAS|APP_PREENCHER|APP_SEMATEND|APP_MENSAGENS|TUTORIAL|FAVICON|ICO|UNIDADE_CSS|UNIDADE|FAIXA|TEMIS_AV|TEMIS|TOUR|APRES_CSS|APRES_JS|APRES|LOGO_U|TEMA_CSS|TEMA_JS|RELATORIO)__", html)
for k in ("APP_LISTA", "APP_FALTANTES", "APP_ASSISTENTE", "APP_CENTRAL", "APP_APRENDER", "APP_NARRATIVAS", "APP_PREENCHER", "APP_SEMATEND", "APP_MENSAGENS"):
    assert "</script" not in R[k].lower(), k
out = D + "Unidade.html"
open(out, "w", encoding="utf-8").write(html)
print(out, len(html.encode()) // 1024, "KB")

from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, json, re, sys
sys.path.insert(0, RAIZ + "lista")
from demandas import DEMANDAS

logo = base64.b64encode(open(RAIZ + "src/img-002.jpg", "rb").read()).decode()
wm = base64.b64encode(open(RAIZ + "src/watermark.png", "rb").read()).decode()
forms = json.load(open(RAIZ + "faltantes/forms_f.json"))
pako = open(RAIZ + "lista/pako_inflate.min.js", encoding="utf-8").read()

# formulários de todas as demandas
GERAIS = ["form_renda", "ausencia_renda", "renda_informal", "ausencia_ctps", "titular", "sem_conta"]
# a declaração de renúncia (Juizado Especial Federal) fica só na Central de Formulários
SEM_RENUNCIA = {"Alvará judicial", "Execução fiscal", "Ingresso em instituição de ensino", "Concurso público",
                "Permanência no país (refúgio)", "Reconhecimento de nacionalidade brasileira", "Reintegração ou defesa da posse",
                "Defesa em processo criminal", "Audiência de acordo de não persecução penal (ANPP)"}
TERMO = {"Descontos indevidos em benefício do INSS", "Empréstimo bancário"}

bold = lambda t: re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
data = []
for a, n, o in DEMANDAS:
    d = {"area": a, "nome": n, **o}
    d["docs"] = [bold(x) for x in d["docs"]]
    if "residencia" in d: d["residencia"] = bold(d["residencia"])
    esp = list(d.get("forms", []))
    if n in TERMO: esp.append("termo")
    d["formularios"] = GERAIS + esp
    for k in d["formularios"]: assert k in forms, k
    data.append(d)

HTML = r"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="color-scheme" content="only light"><!-- o "modo escuro forçado" de alguns navegadores (ex.: Opera GX) não escurece a página nem a impressão -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Lista de Documentos Faltantes – DPU Pelotas</title>
<style>
  :root { --ink:#1e1e1e; --gray:#5f5f5f; --green:#3f7f2a; --band:#e2efd9; --soft:#f3f8ef; --line:#c9d6c2; --red:#b03a2e; }
  * { box-sizing: border-box; }
  body { margin:0; background:#eef1ec; color:var(--ink); font-family: Cambria, Caladea, Georgia, "Times New Roman", serif; }
  .ui { font-family: "Segoe UI", Calibri, Carlito, Arial, sans-serif; }

  /* ---------- painel ---------- */
  .panel { max-width: 900px; margin: 24px auto 16px; background:#fff; border-radius:12px; padding:18px 22px 16px; box-shadow: 0 1px 3px rgba(0,0,0,.08); }
  .panel h1 { font-size:18px; margin:0 0 2px; color:var(--green); }
  .panel p.sub { margin:0 0 14px; color:var(--gray); font-size:13.5px; }
  .row { display:flex; gap:14px; flex-wrap:wrap; align-items:flex-end; }
  label.f { display:flex; flex-direction:column; font-size:12.5px; color:var(--gray); gap:4px; }
  .combo { position:relative; flex: 1 1 380px; }
  .combo input { width:100%; }
  input[type=text] { font: inherit; font-size:15px; padding:9px 11px; border:1px solid #c8cfc4; border-radius:8px; color:var(--ink); background:#fff; }
  input:focus { outline:2px solid #9cc58a; border-color:#7fb06b; }
  .list { position:absolute; z-index:10; left:0; right:0; top:100%; margin-top:4px; background:#fff; border:1px solid #c8cfc4;
          border-radius:10px; box-shadow:0 8px 24px rgba(0,0,0,.12); max-height:360px; overflow:auto; display:none; }
  .list.open { display:block; }
  .grp { font-size:11px; letter-spacing:.08em; text-transform:uppercase; color:var(--green); font-weight:700; padding:10px 12px 4px; }
  .opt { padding:7px 14px; cursor:pointer; font-size:14.5px; text-transform: uppercase; }
  #dem { text-transform: uppercase; }
  #dem::placeholder { text-transform: none; }
  .opt:hover, .opt.act { background:var(--soft); }
  .none { padding:12px 14px; color:var(--gray); font-size:14px; }
  .prazo { font-size:14px; display:flex; gap:14px; align-items:center; padding-bottom:9px; }
  .prazo input { accent-color: var(--green); width:16px; height:16px; vertical-align:-3px; }
  button { font: inherit; font-size:14.5px; border-radius:8px; padding:9px 16px; cursor:pointer; border:1px solid transparent; }
  .ghost { background:#fff; border-color:#c8cfc4; color:var(--ink); }
  .ghost:hover { background:#f4f6f2; }
  .prazoSel { margin-top:14px; }
  .prazoSel .tt2 { font-size:13px; color:var(--gray); margin-bottom:6px; font-family:"Segoe UI", Calibri, Arial, sans-serif; }
  .prazoSel .bts { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .prazoSel button { border:2px solid var(--line); background:#fff; border-radius:12px; padding:11px 16px; text-align:left; font-family:"Segoe UI", Calibri, Arial, sans-serif; cursor:pointer; }
  .prazoSel button b { display:block; font-size:16px; letter-spacing:.04em; color:var(--green); }
  .prazoSel button small { font-size:13px; color:var(--gray); }
  .prazoSel button:hover { background:#f6faf3; }
  .prazoSel button.on { border-color:var(--green); background:#eef6ea; box-shadow:inset 0 0 0 1px var(--green); }
  .prazoSel button.urg b { color:var(--red); }
  .prazoSel button.urg.on { border-color:var(--red); background:#fbefe9; box-shadow:inset 0 0 0 1px var(--red); }
  .acess { display:flex; gap:10px; align-items:flex-start; margin-top:12px; padding:10px 12px; border:1.5px solid #c9d6c2; border-radius:10px; background:#f8fbf6; cursor:pointer; }
  .acess input { width:20px; height:20px; accent-color: var(--green); margin:1px 0 0; flex:0 0 auto; cursor:pointer; }
  .acess b { font-size:15px; letter-spacing:.03em; }
  .acess small { display:block; font-size:12.5px; color:var(--gray); margin-top:2px; }
  .acess:has(input:checked) { border-color: var(--green); background:#eef6ea; }
  .gerar { display:block; width:100%; margin-top:14px; background:var(--green); color:#fff; font-size:20px; font-weight:700; letter-spacing:.06em;
           padding:14px; border-radius:10px; }
  .gerar:hover { background:#356c23; }
  .gerar small { display:block; font-size:13px; font-weight:400; letter-spacing:0; color:#e6f2df; margin-top:2px; }
  .gerarPar { display:flex; gap:10px; flex-wrap:wrap; }
  .gerarPar .gerar { flex:1 1 260px; width:auto; }
  .gerar.pdfBt { background:#fff; color:var(--green); border:2px solid var(--green); }
  .gerar.pdfBt small { color:var(--gray); }
  .gerar.pdfBt:hover { background:#eef6ea; }
  .bloco { margin-top:16px; padding-top:14px; border-top:1px dashed #c8cfc4; }
  .bloco .tt { font-size:15px; font-weight:700; margin-bottom:3px; }
  .bloco .ex { font-size:13px; color:var(--gray); margin-bottom:10px; }
  .fgrid { display:grid; grid-template-columns: repeat(3, 1fr); gap:8px; }
  .fbtn { text-align:left; background:#fff; border:2px solid #9fb894; color:var(--ink); border-radius:9px; padding:9px 11px; line-height:1.25; font-size:14px; }
  .fbtn small { display:block; font-size:12px; color:var(--gray); margin-top:3px; }
  .fbtn:hover { border-color:var(--green); background:#f6faf3; }
  .fbtn.sel { background:var(--green); border-color:var(--green); color:#fff; }
  .fbtn.sel small { color:#e6f2df; }
  .fbtn.off { background:#fbeceb; border-color:#e3a59e; color:#a23b31; cursor:not-allowed; }
  .fbtn.off .nm { text-decoration: line-through; }
  .fbtn.off small { color:#a23b31; }
  .acoes { display:flex; gap:8px; margin-top:12px; flex-wrap:wrap; align-items:center; }
  .acao { background:#fff; border:2px solid var(--green); color:var(--green); font-weight:700; font-size:15px; padding:10px 18px; border-radius:9px; }
  .acao:hover { background:#eef6ea; }
  .acao:disabled { border-color:#c8cfc4; color:#a6ada3; background:#fff; cursor:not-allowed; }
  .cont { font-size:13px; color:var(--gray); margin-left:4px; }
  #fmsg { font-size:13px; margin-top:8px; min-height:1em; }
  .hint { font-size:12.5px; color:var(--gray); margin-top:12px; }
  .rodape { display:flex; justify-content:flex-end; margin-top:12px; }

  /* ---------- visual unificado com os demais apps do app Unidade ---------- */
  .panel { max-width: 980px; border-radius:16px; padding:24px 28px 20px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
  .panel h1 { font-size:26px; margin:0 0 4px; color:#2f6a1f; }
  .panel p.sub { font-size:15px; line-height:1.5; margin:0 0 18px; }
  label.f { font-size:13px; font-weight:600; }
  input[type=text] { font-size:16px; padding:10px 12px; border:1.5px solid #cfdcc8; border-radius:9px; }
  input:focus { outline:none; border-color:#3f7f2a; box-shadow:0 0 0 3px rgba(63,127,42,.15); }
  .ghost { border:1.5px solid #3f7f2a; color:#2f6a1f; font-weight:700; }
  .ghost:hover { background:#eef6ea; }
  .acess { border:2px solid #cfdcc8; border-radius:11px; background:#fff; }
  .gerar { border-radius:12px; font-weight:800; }
  .bloco .tt { font-size:17px; color:#2f6a1f; }
  .bloco .ex { font-size:14px; }
  .fgrid { gap:10px; }
  .fbtn { border:2px solid #cfdcc8; border-radius:12px; padding:11px 13px; font-size:14.5px; }
  .fbtn .nm { font-weight:700; }
  .fbtn:hover { border-color:#a9c69b; background:#fff; }
  .fbtn.sel { background:#f2f8ee; border-color:#3f7f2a; color:var(--ink); }
  .fbtn.sel small { color:var(--gray); }
  .acao { background:#3f7f2a; border:0; color:#fff; font-weight:800; letter-spacing:.04em; font-size:14px; padding:11px 18px; }
  .acao:hover { background:#356c23; }
  .acao:disabled { background:#3f7f2a; color:#fff; opacity:.4; }
  .hint { font-size:13px; line-height:1.5; }

  .gmsg { font-size:14px; margin-top:8px; min-height:0; }
  .gmsg:empty { display:none; }
  .popup { font-size:13px; color:#5f5f5f; line-height:1.5; margin-top:10px; background:#f3f8ef; border-left:3px solid #3f7f2a; border-radius:6px; padding:7px 11px; }
  .msgs { max-width: 980px; margin: 26px auto 0; background:#fff; border-radius:16px; padding:22px 28px 18px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
  .msgs h2 { margin:0 0 4px; font-size:21px; color:#2f6a1f; }
  .msgs .ex { font-size:14px; color:var(--gray); margin:0 0 12px; line-height:1.5; }
  .msgs .row2 { display:grid; grid-template-columns:1.6fr 1fr; gap:14px; margin-bottom:14px; }
  .msgs input { font:inherit; font-size:15px; padding:8px 10px; border:1.5px solid #c9d6c2; border-radius:8px; }
  .msgBox { border:1.5px solid #dbe5d5; border-radius:12px; padding:12px 14px; margin-bottom:12px; background:#fbfdfa; }
  .msgBox .t { font-weight:700; font-size:15px; color:#2f6a1f; margin-bottom:6px; }
  .msgBox .t small { font-weight:400; color:var(--gray); font-size:13px; margin-left:6px; }
  .msgBox textarea { width:100%; font:inherit; font-size:14.5px; line-height:1.45; border:1px solid #d5ddd0; border-radius:8px; padding:9px 11px; resize:vertical; background:#fff; }
  .msgBox textarea:disabled { color:#8a9384; background:#f4f6f2; }
  .msgBox .bt { margin-top:6px; display:flex; gap:10px; align-items:center; }
  .msgBox button { border:1.5px solid #3f7f2a; background:#3f7f2a; color:#fff; border-radius:8px; padding:7px 16px; font-weight:700; font-size:14px; cursor:pointer; }
  .msgBox button:disabled { opacity:.4; cursor:not-allowed; }
  .msgBox .okc { color:#2f6a1f; font-size:13.5px; }
  @media (max-width:760px) { .msgs .row2 { grid-template-columns:1fr; } }
  .fim { max-width: 980px; margin: 22px auto 40px; padding: 0 4px; display:flex; flex-direction:column; align-items:center; gap:14px; }
  .fim .gerarPar { width:100%; max-width: 760px; }
  .voltarMenu { border:1.5px solid #3f7f2a; background:#fff; color:#2f6a1f; border-radius:12px; padding:13px 26px; font-weight:800; font-size:15px; letter-spacing:.03em; min-width:340px; }
  .voltarMenu:hover { background:#eef6ea; }

  /* ---------- folha ---------- */
  .sheet { --green:#265418; --gray:#444; --line:#b9c7b1; position:relative; width: 210mm; min-height: 297mm; margin: 0 auto 40px; background:#fff;
           padding: 14mm 18mm 16mm; box-shadow: 0 2px 10px rgba(0,0,0,.12); overflow:hidden; display:flex; flex-direction:column; }
  .wm { position:absolute; right: 7mm; bottom: 4mm; width: 62mm; opacity:.9; pointer-events:none; z-index:0; }
  .sheet > :not(.wm) { position: relative; z-index: 1; }
  .head { display:flex; align-items:flex-end; justify-content:space-between; border-bottom: 0.6pt solid #bfbfbf; padding-bottom: 2mm; margin-bottom: 3mm; }
  .head img { height: 12mm; display:block; }
  .head .addr { font-size: 8.3pt; color: var(--gray); line-height:1.3; text-align:right; }
  .titulo { background: var(--band); text-align:center; padding: 2mm 4mm; margin-bottom: 2.5mm; }
  .titulo .k { font-weight:700; letter-spacing:.12em; font-size: 10.5pt; }
  .titulo .d { font-weight:700; font-size: 15pt; margin-top: 0.5mm; color: var(--green); }
  .titulo .d.vazio { color:#9aa596; font-weight:400; font-style:italic; font-size: 12.5pt; }
  #docs { counter-reset: n; flex: 1 1 auto; display:flex; flex-direction:column; }
  .sec { display:flex; flex-direction:column; flex: var(--g, 1) 1 auto; }
  .sec ol.docs { flex: 1 1 auto; display:flex; flex-direction:column; justify-content: space-evenly; }
  .sh { font-weight:700; letter-spacing:.1em; font-size: 9.5pt; color: var(--green); margin: 2.6mm 0 0.8mm; padding-bottom: 0.4mm; border-bottom: 0.6pt solid var(--line); }
  .sec:first-child .sh { margin-top: 0; }
  ol.docs { margin: 0; padding: 0; list-style: none; font-size: var(--fs, 12pt); line-height: 1.28; }
  body.medindo-faltam ol.docs { font-size: var(--fsp, 12pt); }
  ol.docs li { position: relative; padding: 0.6mm 0 0.6mm 2.05em; counter-increment: n; }
  ol.docs li::before { content: counter(n) "."; position:absolute; left:0; width:1.55em; text-align:right; color: var(--green); font-weight:700; }
  .it { outline:none; }
  .it:focus { background:#fffbe6; }
  /* item entregue: cinza claro e riscado */
  ol.docs li.ok { color:#b4b4b4; text-decoration: line-through; text-decoration-color:#9a9a9a; }
  ol.docs li.ok::before { color:#c4c4c4; }
  /* caixinha de "entregue" na margem esquerda (só na tela) */
  .chk { position:absolute; right:-12mm; top:calc(0.6mm + 0.12em); width:9mm; display:flex; justify-content:center; cursor:pointer; }
  .chk input { width:20px; height:20px; accent-color: var(--green); margin:0; cursor:pointer; }
  .marca { font: 600 11.5px "Segoe UI", Calibri, Arial, sans-serif; color:#4b5d41; margin: 0 -14mm 1mm 0; text-align:right; }
  .add { display:flex; gap:8px; margin: 2mm 0 0 8mm; }
  .add input { flex:1; font-size:13.5px; padding:7px 10px; }
  .add button { padding:7px 12px; font-size:13.5px; }
  .imp { margin-top: 3mm; border-left: 3pt solid var(--green); background: var(--soft); padding: 2mm 4mm; font-size: 11pt; line-height:1.3; white-space: nowrap; }
  .imp .k { font-weight:700; letter-spacing:.06em; color: var(--green); margin-right: 1mm; }
  .pend { background:#fff; margin-top: 3mm; border: 1.3pt solid var(--green); border-radius: 3mm; padding: 2.4mm 5mm 2.6mm; font-size: 10.5pt; line-height: 1.38; text-align: justify; }
  .pend p { margin: 0 0 1.4mm; }
  .assin { display:flex; justify-content:space-between; align-items:flex-end; gap:8mm; margin-top: 9mm; }
  .assin .linha { flex: 1 1 auto; border-top: 0.8pt solid #333; text-align:center; padding-top: 1mm; font-weight:700; font-size: 10pt; }
  .assin .data { flex: 0 0 auto; font-size: 10.5pt; }
  /* assistido analfabeto: digital + assinatura a rogo + duas testemunhas (art. 595 do Código Civil) */
  .rogo { display:none; gap:4mm; margin-top: 2.5mm; align-items:stretch; }
  body.analf .rogo { display:flex; }
  body.analf .assin { display:none; }
  .rogo .dig { flex: 0 0 26mm; display:flex; flex-direction:column; }
  .rogo .cx { flex: 1 1 auto; min-height: 27mm; border: 0.6pt solid #d4d4d4; border-radius: 2mm; }
  .rogo .lg { font-size: 7pt; color:#a8a8a8; text-align:center; margin-top: 0.6mm; line-height:1.15; }
  .rogo .dir { flex: 1 1 auto; font-size: 9.3pt; line-height: 1.25; text-align:left; display:flex; flex-direction:column; }
  .rogo .tx { margin-bottom: 8mm; }
  .rogo .br { display:inline-block; width: 52mm; border-bottom: 0.6pt solid #333; }
  .rogo .ts { display:flex; gap:4mm; }
  .rogo .ts > div { flex: 1 1 0; }
  .rogo .ln { border-top: 0.6pt solid #333; padding-top: 0.5mm; font-weight:700; font-size: 8.8pt; text-align:center; }
  .rogo .nc { display:flex; margin-top: 1.8mm; font-size: 8.6pt; }
  .rogo .nc span { flex: 1 1 auto; display:flex; gap:1mm; white-space:nowrap; }
  .rogo .nc i { flex: 1 1 auto; border-bottom: 0.6pt solid #333; }
  .rogo .data { text-align:right; margin-top: auto; padding-top: 1.5mm; font-size: 9.8pt; }
  body.medindo .sheet { padding: 8.5mm 17mm 8mm; min-height: 0 !important; }
  body.medindo ol.docs li { padding-right: 0; margin-right: 0; }
  body.medindo .add, body.medindo .chk, body.medindo .marca { display: none; }
  body.medindo-faltam li.ok, body.medindo-faltam li.na, body.medindo-faltam .sec.vazia { display: none; }

  /* ---------- formulários (só na impressão) ---------- */
  .fpage { width: 210mm; height: 297mm; background:#fff; }
  .fpage img { width: 100%; height: 100%; display:block; }
  @media screen { #anexos { position:absolute; left:-99999px; top:0; } }

  @page { size: A4; margin: 0; }
  @media print {
    body { background:#fff; }
    .no-print, .chk { display:none !important; }
    .sheet { margin:0; box-shadow:none; width:auto; min-height: calc(100vh - 2mm); height:auto; overflow:visible; padding: 8.5mm 17mm 8mm;
             -webkit-box-decoration-break: clone; box-decoration-break: clone; }
    ol.docs li.ok, ol.docs li.na, .sec.vazia { display:none; }
    ol.docs { font-size: var(--fsp, var(--fs, 12pt)); }
    .pend, .imp, .sh { break-inside: avoid; }
    .sh { break-after: avoid; }
    .titulo, .imp { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    ol.docs li { break-inside: avoid; }
    body.so-form .sheet { display:none !important; }
    /* Firefox: caixa que não cabe inteira na página vai para a página seguinte e deixa uma folha em branco antes;
       por isso as alturas acompanham a área útil da página (100vh na impressão) em vez de 297 mm fixos */
    html, body { margin:0 !important; padding:0 !important; height:auto !important; }
    #anexos { position:static !important; }
    .fpage { margin:0; box-shadow:none; break-before: auto; width: 100%; height: calc(100vh - 1mm); overflow: hidden; }
    .fpage img { object-fit: contain; }
    .fpage + .fpage { break-before: page; }
    body.so-form > *:not(#anexos) { display:none !important; }
    /* impressão sempre legível, também em impressora preto e branco: textos e linhas escuros (o SALVAR EM PDF mantém as cores da tela) */
    html:not(.pdfCor) .sheet, html:not(.pdfCor) .sheet * { color:#000 !important; }
    html:not(.pdfCor) .sheet *:not(img) { border-color:#555 !important; }
  }
</style>
</head>
<body>

<div class="panel ui no-print">
  <h1>Lista de Documentos Faltantes</h1>
  <p class="sub">Escolha a demanda e marque a caixinha à direita de cada documento que a pessoa já trouxe. A lista impressa sai só com o que falta.</p>
  <div class="row">
    <label class="f combo">Demanda
      <input id="dem" type="text" placeholder="Ex.: auxílio-doença, cirurgia, Bolsa Família…" autocomplete="off" role="combobox" aria-expanded="false" aria-controls="lst">
      <div id="lst" class="list" role="listbox"></div>
    </label>
  </div>
  <div class="prazoSel" id="prazoSel"><div class="tt2">Prazo para o(a) assistido(a) entregar o que falta:</div>
    <div class="bts"><button type="button" class="on" data-prazo="30 dias"><b>PRAZO NORMAL</b><small>30 dias</small></button><button type="button" class="urg" data-prazo="48 horas"><b>PAJ URGENTE</b><small>48 horas</small></button></div></div>
  <label class="acess"><input type="checkbox" id="analf"><span><b>ASSISTIDO ANALFABETO</b><small>Opção de acessibilidade: na lista e nos formulários assinados pelo(a) assistido(a) ou declarante, a linha de assinatura dá lugar ao espaço para a digital, à assinatura a rogo e às duas testemunhas (art. 595 do Código Civil). Os formulários médicos não mudam, porque quem assina é o(a) médico(a).</small></span></label>
  <div class="gerarPar"><button class="gerar" id="gerar">GERAR LISTA – IMPRIMIR<small>Abre a tela de impressão, só com os documentos que faltam</small></button><button class="gerar pdfBt" id="gerarPdf">SALVAR EM PDF<small>Cria o PDF direto, com as cores da tela (use também se a tela de impressão ficar cinza)</small></button></div>
  <div class="gmsg" id="gmsg"></div>

  <div class="bloco" id="bloco" style="display:none">
    <div class="tt">Formulários</div>
    <div class="ex">Clique nos formulários que quer (ficam verdes) e depois escolha o que fazer. <b>PREENCHER</b> abre os formulários escolhidos para você digitar as informações uma vez só (é opcional). Os que ficam <b style="color:#a23b31">vermelhos</b> não são mais necessários, porque o documento já foi entregue.</div>
    <div class="fgrid" id="fgrid"></div>
    <div class="acoes">
      <button class="acao" id="aPreencher" disabled title="Digite as informações uma vez só: elas vão para todos os formulários selecionados">PREENCHER</button>
      <button class="acao" id="aBaixar" disabled>BAIXAR</button>
      <button class="acao" id="aAbrir" disabled>ABRIR EM NOVA GUIA</button>
      <button class="acao" id="aImprimir" disabled>IMPRIMIR</button>
      <span class="cont" id="cont"></span>
      <button class="ghost" id="aLimpar" style="margin-left:auto">Desmarcar formulários</button>
    </div>
    <div class="popup"><b>ABRIR EM NOVA GUIA:</b> se a guia não abrir, o navegador bloqueou o pop-up. Clique no aviso de janela bloqueada, no canto direito da barra de endereço, escolha <b>“Sempre permitir pop-ups”</b> e clique de novo no botão.</div>
    <div id="fmsg"></div>
  </div>

  <div class="hint">Na tela de impressão, escolha a impressora para <b>imprimir</b> ou <b>Salvar como PDF</b> para mandar pelo WhatsApp. Se a data, o título ou o endereço do arquivo aparecerem nos cantos da folha, abra “Mais definições” e desmarque <b>Cabeçalhos e rodapés</b>. Para mudar o texto de um item, clique nele e digite.</div>
  <div class="rodape"><button class="ghost" id="nova">Nova lista</button></div>
</div>

<div class="sheet" id="folha">
  <img class="wm" alt="" src="data:image/png;base64,__WM__">
  <div class="head">
    <img alt="Defensoria Pública da União" src="data:image/jpeg;base64,__LOGO__">
    <div class="addr">Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS, CEP 96020-480<br>Fone (53) 3284-9450</div>
  </div>
  <div class="titulo">
    <div class="k">DOCUMENTOS PENDENTES</div>
    <div class="d vazio" id="tdem">escolha a demanda no campo acima</div>
  </div>
  <div class="marca no-print" id="marca" style="display:none">☑ = já entregue</div>
  <div id="docs"></div>
  <div class="add ui no-print" id="addrow" style="display:none">
    <input id="novoItem" type="text" placeholder="Acrescentar outro documento que falta…">
    <button class="ghost" id="addBtn">Acrescentar</button>
  </div>
  <div class="imp"><span class="k">IMPORTANTE:</span> <b>Grupo familiar</b> são todas as pessoas que moram no mesmo imóvel que o(a) assistido(a).</div>
  <div class="pend">
    <p>Os documentos podem ser enviados pelo <b>WhatsApp (53) 3284-9450</b> (atendimento de retorno virtual, somente mensagens), desde que a foto seja <u>bem enquadrada</u>, <u>de boa qualidade</u> e <u>legível</u>. Não atendemos ligações pelo WhatsApp: para falar por telefone, ligue para o mesmo número, por ligação comum.</p>
    <p>O(a) requerente fica ciente de que a análise do pedido de assistência jurídica gratuita/defesa judicial fica condicionada à juntada da documentação pendente acima elencada, <b><u>no prazo máximo de <span id="pz">30 dias</span></u></b>, salientando-se, desde já, que, em caso de ausência de manifestação, o PAJ será <b>ARQUIVADO</b>.</p>
    <div class="assin"><div class="linha">Assinatura do(a) assistido(a)</div><div class="data hoje"></div></div>
    <div class="rogo">
      <div class="dig"><div class="cx"></div><div class="lg">Digital do(a) assistido(a)</div></div>
      <div class="dir">
        <div class="tx">A rogo de <span class="br"></span>, que não sabe ler nem escrever, assina (art. 595 do Código Civil):</div>
        <div class="ts">
          <div><div class="ln">Assinatura a rogo</div><div class="nc"><span>Nome: <i></i></span></div><div class="nc"><span>CPF: <i></i></span></div></div>
          <div><div class="ln">Testemunha 1</div><div class="nc"><span>Nome: <i></i></span></div><div class="nc"><span>CPF: <i></i></span></div></div>
          <div><div class="ln">Testemunha 2</div><div class="nc"><span>Nome: <i></i></span></div><div class="nc"><span>CPF: <i></i></span></div></div>
        </div>
        <div class="data hoje"></div>
      </div>
    </div>
  </div>
</div>

<div class="msgs ui no-print" id="msgs" style="display:none">
  <h2>Textos automáticos</h2>
  <p class="ex">Os textos se atualizam conforme você marca os documentos entregues e escolhe o prazo. Confira antes de copiar. O texto 1 vai para o(a) assistido(a), pelo WhatsApp; os textos 2 e 3 são para movimentar o PAJ no SIS-DPU.</p>
  <div class="row2">
    <label class="f">Nome do(a) assistido(a) (opcional)<input id="mNome" type="text" autocomplete="off" placeholder="Para começar o texto 1 com o nome"></label>
    <label class="f">Data de abertura do PAJ (conta o prazo)<input id="mData" type="date"></label>
  </div>
  <div id="assBox"></div>
  <div class="msgBox"><div class="t">1. Para o(a) assistido(a), no WhatsApp<small>o que ainda falta, o prazo e como falar com a DPU</small></div><textarea id="msg1" rows="6"></textarea>
    <div class="bt"><button type="button" data-copia="msg1">COPIAR</button><span class="okc"></span></div></div>
  <div class="msgBox"><div class="t">2. Para movimentar no SIS-DPU<small>chegou parte dos documentos</small></div><textarea id="msg2" rows="4"></textarea>
    <div class="bt"><button type="button" data-copia="msg2">COPIAR</button><span class="okc"></span></div></div>
  <div class="msgBox"><div class="t">3. Para movimentar no SIS-DPU<small>chegou tudo</small></div><textarea id="msg3" rows="2"></textarea>
    <div class="bt"><button type="button" data-copia="msg3">COPIAR</button><span class="okc"></span></div></div>
</div>

<div class="fim ui no-print">
  <div class="gerarPar"><button class="gerar" id="gerar2">GERAR LISTA – IMPRIMIR<small>Abre a tela de impressão, só com os documentos que faltam</small></button><button class="gerar pdfBt" id="gerarPdf2">SALVAR EM PDF<small>Cria o PDF direto, com as cores da tela (use também se a tela de impressão ficar cinza)</small></button></div>
  <div class="gmsg" id="gmsg2"></div>
  <button class="voltarMenu" id="voltarMenu" style="display:none">← VOLTAR AO MENU DO DAC</button>
</div>

<div id="anexos"></div>

<script>__PAKO__</script>
<script>__FFLATE__</script>
<script>__PDFJS_FOLHA__</script>
<script>__COMUM__</script>
<script>
const DEMANDAS = __DATA__;
const FORMS = __FORMS__;
const GERAL = {
  cpf: "<b>RG (ou CNH) e CPF</b> de todas as pessoas do grupo familiar (para menores de idade que não têm RG, certidão de nascimento)",
  renda: "<b>Comprovante de renda</b> de todas as pessoas do grupo familiar. Para renda zero ou informal, <b>extratos bancários</b> de todas as contas dos últimos 3 meses",
  ctps: "<b>Carteira de Trabalho</b> de todas as pessoas do grupo familiar: digital (no aplicativo, opção “Enviar Carteira de Trabalho” e aba “Outros contratos”, se houver) ou física (página de qualificação civil, todos os contratos de trabalho e a página em branco seguinte ao último contrato)",
  ctpsPrev: "<b>Carteira de Trabalho</b> de todas as pessoas do grupo familiar: digital (no aplicativo, opção “Enviar Carteira de Trabalho” e aba “Outros contratos”, se houver) ou física (todas as páginas)",
  residencia: "<b>Comprovante de residência</b> em nome próprio ou com declaração do titular do comprovante",
  cadunico: "<b>Comprovante de inscrição no Cadastro Único (CadÚnico)</b>, se a família for inscrita"
};
const SE_FOR = [   // formato "Caso – o que trazer"
  "<b>Alguém do grupo familiar declara Imposto de Renda</b> – Declaração do Imposto de Renda mais recente dessa pessoa, com o recibo de entrega",
  "<b>Alguém do grupo familiar é MEI ou tem empresa</b> – Certificado do MEI ou contrato social e a última declaração de faturamento",
  "<b>O(a) assistido(a) tem curador(a)</b> – Termo de curatela",
  "<b>A renda do grupo familiar passa de 2 salários mínimos</b> (limite da Resolução nº 240/2025 da Defensoria Pública da União para a assistência gratuita) – Notas fiscais ou recibos de gastos extraordinários com saúde (consultas, psicólogo(a), fisioterapia, procedimentos essenciais e medicamentos). Esses gastos podem ser descontados da renda"
];
const ITEM_NOME = { renda: "comprovante de renda", ctps: "Carteira de Trabalho", residencia: "comprovante de residência", medico: "formulário médico" };
const norm = s => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[-\/().,%]+/g, " ");
const APELIDOS = {
  "Auxílio-doença": "beneficio por incapacidade temporaria afastamento doenca",
  "Aposentadoria por invalidez": "beneficio por incapacidade permanente aposentadoria por incapacidade",
  "Benefício assistencial (BPC/LOAS) à pessoa com deficiência": "deficiente amparo assistencial",
  "Benefício assistencial (BPC/LOAS) à pessoa idosa": "idoso amparo assistencial",
  "Adicional de 25% na aposentadoria": "acrescimo grande invalidez cuidador",
  "Pensão por morte": "falecimento obito viuva viuvo",
  "Aposentadoria por idade ou por tempo de contribuição": "aposentadoria urbana",
  "Aposentadoria rural": "agricultor segurado especial trabalhador rural",
  "Seguro-defeso (pescador artesanal)": "pesca",
  "Salário-maternidade": "gestante licenca maternidade parto",
  "Auxílio-reclusão": "preso prisao",
  "Alvará judicial": "valores residuais saque falecido",
  "Financiamento estudantil": "fies",
  "Financiamento habitacional": "minha casa minha vida caixa casa propria",
  "Ingresso em instituição de ensino": "matricula universidade cotas sisu",
  "Descontos indevidos em benefício do INSS": "associacao desconto",
  "Empréstimo bancário": "consignado",
  "Permanência no país (refúgio)": "estrangeiro migrante refugiado residencia",
  "FGTS e PIS": "saque fgts pis pasep",
  "Reintegração ou defesa da posse": "despejo ocupacao terreno",
  "Seguro-desemprego (com empresa no nome do assistido)": "cnpj mei empresa",
  "Seguro DPVAT (acidentes até 14/11/2023)": "spvat acidente transito",
  "Medicamentos": "remedio farmacia",
  "Tratamento oncológico": "cancer oncologia quimioterapia radioterapia",
  "Tratamento fora do domicílio (TFD)": "outra cidade viagem",
  "Internação ou transferência hospitalar": "uti leito",
  "Consulta com especialista": "medico especialista",
  "Defesa em processo criminal": "crime penal acao penal",
  "Audiência de acordo de não persecução penal (ANPP)": "anpp acordo penal"
};
const $ = id => document.getElementById(id);
const inp = $("dem"), lst = $("lst");
let vis = [], act = -1, atual = null;
const selecionados = new Set();

/* ---------- busca da demanda ---------- */
function montarLista(filtro) {
  const tk = norm(filtro || "").split(" ").filter(Boolean);
  vis = DEMANDAS.filter(d => { const h = norm(d.nome + " " + d.area + " " + (APELIDOS[d.nome] || "")); return tk.every(t => h.includes(t)); });
  /* ordem: primeiro o que bate com o começo das palavras do nome (ex.: "idade" acha "por idade" antes de "incapacidade") */
  if (tk.length) { const nota = d => { const ws = norm(d.nome).split(/[^a-z0-9]+/), hs = norm(d.area + " " + (APELIDOS[d.nome] || "")).split(/[^a-z0-9]+/);
      return tk.reduce((s, t) => s + (ws.some(w => w.startsWith(t)) ? 3 : norm(d.nome).includes(t) ? 1 : hs.some(w => w.startsWith(t)) ? 2 : 0), 0); };
    const v = vis.map((d, i) => [d, nota(d), i]), top = {}; v.forEach(x => top[x[0].area] = Math.max(top[x[0].area] || 0, x[1]));
    vis = v.sort((a, b) => top[b[0].area] - top[a[0].area] || (a[0].area === b[0].area ? b[1] - a[1] : 0) || a[2] - b[2]).map(x => x[0]); }
  lst.innerHTML = "";
  if (!vis.length) { lst.innerHTML = '<div class="none">Nenhuma demanda encontrada. Escolha “Outros casos”.</div>'; return; }
  let area = "";
  vis.forEach((d, i) => {
    if (d.area !== area) { area = d.area; const g = document.createElement("div"); g.className = "grp"; g.textContent = area; lst.appendChild(g); }
    const o = document.createElement("div");
    o.className = "opt" + (i === act ? " act" : ""); o.textContent = d.nome; o.setAttribute("role", "option");
    o.addEventListener("mousedown", e => { e.preventDefault(); escolher(d); });
    lst.appendChild(o);
  });
}
function abrir() { montarLista(inp.value === inp.dataset.escolhida ? "" : inp.value); lst.classList.add("open"); inp.setAttribute("aria-expanded", "true"); }
function fechar() { lst.classList.remove("open"); inp.setAttribute("aria-expanded", "false"); act = -1; }
inp.addEventListener("focus", abrir);
inp.addEventListener("click", () => { if (inp.dataset.escolhida) inp.select(); if (!lst.classList.contains("open")) abrir(); });
inp.addEventListener("input", () => { delete inp.dataset.escolhida; act = 0; montarLista(inp.value); lst.classList.add("open"); });
inp.addEventListener("blur", () => setTimeout(fechar, 120));
inp.addEventListener("keydown", e => {
  if (!lst.classList.contains("open") && (e.key === "ArrowDown" || e.key === "Enter")) { abrir(); return; }
  if (e.key === "ArrowDown") { act = Math.min(act + 1, vis.length - 1); montarLista(inp.value === inp.dataset.escolhida ? "" : inp.value); e.preventDefault(); rolar(); }
  else if (e.key === "ArrowUp") { act = Math.max(act - 1, 0); montarLista(inp.value === inp.dataset.escolhida ? "" : inp.value); e.preventDefault(); rolar(); }
  else if (e.key === "Enter") { if (vis[act]) escolher(vis[act]); e.preventDefault(); }
  else if (e.key === "Escape") fechar();
});
function rolar() { const a = lst.querySelector(".opt.act"); if (a) a.scrollIntoView({ block: "nearest" }); }

/* ---------- checklist ---------- */
function item(html, chave) {
  const li = document.createElement("li");
  if (chave) li.dataset.k = chave;
  const s = document.createElement("span"); s.className = "it"; s.contentEditable = "true"; s.innerHTML = html;
  const lb = document.createElement("label"); lb.className = "chk no-print"; lb.title = "Marque se a pessoa já entregou este documento";
  const cb = document.createElement("input"); cb.type = "checkbox";
  cb.addEventListener("change", () => { li.classList.toggle("ok", cb.checked); atualizar(); });
  lb.append(cb);
  li.append(s, lb);
  return li;
}
function secao(id, titulo, itens) {
  const sec = document.createElement("div"); sec.className = "sec"; sec.id = id;
  const h = document.createElement("div"); h.className = "sh"; h.textContent = titulo;
  const ol = document.createElement("ol"); ol.className = "docs";
  itens.forEach(([html, k]) => ol.appendChild(item(html, k)));
  sec.append(h, ol);
  return sec;
}
function ultimoTexto(el) {
  const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n, last = null;
  while ((n = w.nextNode())) if (n.nodeValue.trim()) last = n;
  return last;
}
function pontuar() {  // ";" em cada item que falta e "." no último que falta de cada seção
  document.querySelectorAll("#docs .sec").forEach(sec => {
    const its = [...sec.querySelectorAll("li:not(.ok):not(.na) .it")];
    sec.classList.toggle("vazia", !its.length);
    its.forEach((s, i) => { const t = ultimoTexto(s); if (t) t.nodeValue = t.nodeValue.replace(/[\s;.:]+$/, "") + (i === its.length - 1 ? "." : ";"); });
  });
}
function escolher(d) {
  atual = d;
  inp.value = d.nome; inp.dataset.escolhida = d.nome; fechar();
  const t = $("tdem"); t.textContent = d.nome; t.classList.remove("vazio");
  const box = $("docs"); box.innerHTML = "";
  const geral = [[GERAL.cpf, "cpf"], [GERAL.renda, "renda"], [d.prev ? GERAL.ctpsPrev : GERAL.ctps, "ctps"], [d.residencia || GERAL.residencia, "residencia"]];
  if (!d.cadunico) geral.push([GERAL.cadunico, "cadunico"]);
  box.appendChild(secao("s-geral", "DOCUMENTOS PESSOAIS E DE RENDA", geral));
  box.appendChild(secao("s-esp", "DOCUMENTOS DESTA DEMANDA", d.docs.map(x => [x, /^<b>Formulário médico/.test(x) ? "medico" : ""])));
  box.appendChild(secao("s-se", "SE FOR O SEU CASO, TRAGA TAMBÉM", SE_FOR.map(h => [h, ""])));
  $("addrow").style.display = "flex"; $("marca").style.display = "block";
  selecionados.clear();
  montarBotoes();
  atualizar(); ajustarTela();
}
function entregues() { return new Set([...document.querySelectorAll("#docs li.ok")].map(li => li.dataset.k).filter(Boolean)); }
function atualizar() { pontuar(); pintarBotoes(); textos(); }

function acrescentar() {
  const v = $("novoItem").value.trim(); if (!v || !atual) return;
  let sec = $("s-esp");
  if (!sec) { sec = secao("s-esp", "DOCUMENTOS DESTA DEMANDA", []); $("docs").insertBefore(sec, $("s-se")); }
  const t = v.charAt(0).toUpperCase() + v.slice(1);
  sec.querySelector("ol").appendChild(item(t.replace(/[<>&]/g, c => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" })[c]), ""));
  atualizar(); ajustarTela(); $("novoItem").value = ""; $("novoItem").focus();
}
$("addBtn").addEventListener("click", acrescentar);
$("novoItem").addEventListener("keydown", e => { if (e.key === "Enter") acrescentar(); });
$("docs").addEventListener("focusout", () => { pontuar(); ajustarTela(); textos(); });

/* letra dos documentos o maior possível sem passar de uma página.
   Na tela: calculada com a lista inteira e fica fixa (não muda ao marcar "entregue").
   Na impressão: recalculada só com o que falta, para preencher a folha. */
function medir(prop, soFaltam) {
  const folha = $("folha"), mm = px => px * 25.4 / 96, LIM = 297;
  document.body.classList.add("medindo");
  if (soFaltam) document.body.classList.add("medindo-faltam");
  let fs = 18;
  for (; fs > 10.25; fs -= 0.25) { folha.style.setProperty(prop, fs + "pt"); if (mm(folha.scrollHeight) <= LIM) break; }
  folha.querySelectorAll(".sec").forEach(sec => sec.style.setProperty("--g", sec.querySelectorAll(soFaltam ? "li:not(.ok):not(.na)" : "li").length || 1));
  document.body.classList.remove("medindo", "medindo-faltam");
}
function ajustarTela() { if (atual) medir("--fs", false); }
function ajustarImpressao() { if (atual) { pontuar(); medir("--fsp", true); } }
window.addEventListener("beforeprint", ajustarImpressao);
window.addEventListener("afterprint", ajustarTela);

/* ---------- data ---------- */
const datar = () => document.querySelectorAll(".hoje").forEach(e => e.textContent = "Pelotas, " + new Date().toLocaleDateString("pt-BR", { day: "numeric", month: "long", year: "numeric" }) + ".");
datar(); window.addEventListener("beforeprint", datar); window.addEventListener("focus", datar);
$("analf").addEventListener("change", () => { document.body.classList.toggle("analf", $("analf").checked); ajustarTela(); if (atual) pintarBotoes(); });

/* ---------- GERAR LISTA ---------- */
function avisoGerar(t, erro) { ["gmsg", "gmsg2"].forEach(id => { const m = $(id); m.textContent = t; m.style.color = erro ? "var(--red)" : "var(--green)"; }); }
function gerarLista(pdf) {
  if (!atual) { avisoGerar("Escolha a demanda primeiro.", true); inp.focus(); return; }
  pontuar();
  if (!document.querySelector("#docs li:not(.ok):not(.na)")) { avisoGerar("Todos os documentos estão marcados como entregues: não há nada pendente.", true); return; }
  limparAnexos(); aviso(""); avisoGerar(""); ajustarImpressao();
  if (pdf === true && window.dpuPDF) dpuPDF.salvar("Documentos faltantes - " + atual.nome);   // SALVAR EM PDF: o PDF é criado aqui mesmo
  else window.print();
}
$("gerar").addEventListener("click", () => gerarLista());
$("gerar2").addEventListener("click", () => gerarLista());
$("gerarPdf").addEventListener("click", () => gerarLista(true));
$("gerarPdf2").addEventListener("click", () => gerarLista(true));

/* ---------- formulários ---------- */
function montarBotoes() {
  $("bloco").style.display = "block";
  const g = $("fgrid"); g.innerHTML = "";
  atual.formularios.forEach(k => {
    const b = document.createElement("button"); b.className = "fbtn"; b.dataset.k = k;
    b.addEventListener("click", () => {
      if (b.classList.contains("off")) return;
      selecionados.has(k) ? selecionados.delete(k) : selecionados.add(k);
      pintarBotoes();
    });
    g.appendChild(b);
  });
}
function pintarBotoes() {
  const ent = entregues();
  document.querySelectorAll(".fbtn").forEach(b => {
    const k = b.dataset.k, f = FORMS[k], off = !!(f.link && ent.has(f.link));
    if (off) selecionados.delete(k);
    const sel = selecionados.has(k);
    b.classList.toggle("off", off); b.classList.toggle("sel", sel);
    const np = (usaVar(k) ? f.pages_a : f.pages).length;
    const pg = np + (np > 1 ? " páginas" : " página") + (usaVar(k) ? " · versão para assistido analfabeto" : "");
    b.innerHTML = '<span class="nm">' + (sel ? "✓ " : "") + f.label + "</span><small>" + (off ? "Não precisa: " + ITEM_NOME[f.link] + " já entregue" : pg) + "</small>";
    b.title = off ? "Este formulário não é mais necessário" : "";
  });
  const n = selecionados.size;
  ["aPreencher", "aBaixar", "aAbrir", "aImprimir"].forEach(id => $(id).disabled = !n);
  $("cont").textContent = n ? (n === 1 ? "1 formulário selecionado" : n + " formulários selecionados") : "nenhum formulário selecionado";
}
const ordem = () => atual.formularios.filter(k => selecionados.has(k));
const analf = () => $("analf").checked;
const temVar = k => !!FORMS[k].pdf_a;                       // tem versão para assistido analfabeto?
const usaVar = k => analf() && temVar(k);
const nomeArq = k => FORMS[k].label.replace(/[–\/]/g, "-") + (usaVar(k) ? " (assistido analfabeto)" : "");
function bytes(b64) { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
const pdfUrl = {};
function urlPdf(k) {
  const c = k + (usaVar(k) ? "_a" : "");
  return pdfUrl[c] || (pdfUrl[c] = URL.createObjectURL(new Blob([bytes(usaVar(k) ? FORMS[k].pdf_a : FORMS[k].pdf)], { type: "application/pdf" })));
}
function aviso(t, erro) { const m = $("fmsg"); m.textContent = t; m.style.color = erro ? "var(--red)" : "var(--green)"; }

function baixarArq(url, nome) { const a = document.createElement("a"); a.href = url; a.download = nome; document.body.appendChild(a); a.click(); a.remove(); }
$("aBaixar").addEventListener("click", () => {
  const ks = ordem();
  if (ks.length === 1) { baixarArq(urlPdf(ks[0]), nomeArq(ks[0]) + ".pdf"); aviso("Formulário baixado para a pasta Downloads."); return; }
  try {  // mais de um: um arquivo .zip só, como na abertura do PAJ
    const files = {};
    ks.forEach(k => { files[nomeArq(k) + ".pdf"] = bytes(usaVar(k) ? FORMS[k].pdf_a : FORMS[k].pdf); });
    const zip = fflate.zipSync(files, { level: 0 });
    const nome = ("Formulários - " + atual.nome).replace(/[\\\/:*?"<>|–]/g, "-").replace(/\s+/g, " ").trim() + ".zip";
    baixarArq(URL.createObjectURL(new Blob([zip], { type: "application/zip" })), nome);
    aviso(`Arquivo “${nome}” salvo na pasta Downloads, com os ${ks.length} formulários.`);
  } catch (e) { aviso("Não foi possível juntar os formulários em .zip neste navegador. Use o Google Chrome ou o Microsoft Edge atualizados.", true); }
});
$("aAbrir").addEventListener("click", () => {
  let bloqueados = 0;
  ordem().forEach(k => {
    const w = window.open("", "_blank");
    if (!w) { bloqueados++; return; }
    w.document.write(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>${nomeArq(k)}</title>
      <style>html,body{margin:0;height:100%}embed{width:100%;height:100%;border:0}</style></head>
      <body><embed src="${urlPdf(k)}" type="application/pdf"></body></html>`);
    w.document.close();
  });
  aviso(bloqueados ? `O navegador bloqueou ${bloqueados} guia(s). Clique no aviso de pop-up bloqueado, ao lado do endereço, escolha “Sempre permitir” e tente de novo.`
                   : "Formulários abertos em novas guias. Lá dá para preencher no computador, imprimir ou salvar.", !!bloqueados);
});
function paginas(k) {
  return (usaVar(k) ? FORMS[k].pages_a : FORMS[k].pages).map(b64 => URL.createObjectURL(new Blob([pako.ungzip(bytes(b64), { to: "string" })], { type: "image/svg+xml" })));
}
const svgCache = {};
$("aImprimir").addEventListener("click", async () => {
  try {
    const box = $("anexos"); box.innerHTML = ""; const espera = [];
    ordem().forEach(k => { const c = k + (usaVar(k) ? "_a" : ""); if (!svgCache[c]) svgCache[c] = paginas(k); });
    ordem().forEach(k => svgCache[k + (usaVar(k) ? "_a" : "")].forEach(u => {
      const p = document.createElement("div"); p.className = "fpage";
      const img = new Image(); img.src = u; p.appendChild(img); box.appendChild(p);
      espera.push(new Promise(ok => { if (img.complete && img.naturalWidth) ok(); else { img.onload = ok; img.onerror = ok; } }));
    }));
    await Promise.all(espera);
    document.body.classList.add("so-form"); aviso("");
    window.print();
  } catch (e) { aviso("Não foi possível preparar a impressão neste navegador. Use o Google Chrome ou o Microsoft Edge atualizados.", true); limparAnexos(); }
});
function limparAnexos() { $("anexos").innerHTML = ""; document.body.classList.remove("so-form"); }
window.addEventListener("afterprint", limparAnexos);
$("aLimpar").addEventListener("click", () => { selecionados.clear(); pintarBotoes(); aviso(""); });
/* PREENCHER: os formulários selecionados vão para o Preenchimento de Formulários */
$("aPreencher").addEventListener("click", () => {
  const ks = ordem(); if (!ks.length) return;
  if (window.parent === window) { aviso("O preenchimento funciona dentro do Assistente de Documentos DAC.", true); return; }
  parent.postMessage({ preencher: { origem: "Checklist de Documentos", analf: analf(), nome: ($("mNome").value || "").trim(),
    forms: ks.map(k => ({ k, arq: FORMS[k].arq, nome: FORMS[k].label, pdf: FORMS[k].pdf, pdf_a: FORMS[k].pdf_a || "" })) } }, "*");
  aviso("");
});

if (window.parent !== window) {  // aberto dentro do app Unidade
  $("voltarMenu").style.display = "";
  $("voltarMenu").addEventListener("click", () => parent.postMessage({ ir: "dac" }, "*"));
}
/* ---------- textos automáticos (os mesmos de Meus PAJs, no Assistente) ---------- */
const PRAZO = () => ($("pz").textContent || "30 dias").trim();
const URGENTE = () => PRAZO() === "48 horas";
const dois = n => String(n).padStart(2, "0");
function hojeISO() { const d = new Date(); return `${d.getFullYear()}-${dois(d.getMonth() + 1)}-${dois(d.getDate())}`; }
function prazoFim() {
  const iso = $("mData").value || hojeISO(), d = new Date(iso + "T12:00:00");
  d.setDate(d.getDate() + (URGENTE() ? 2 : 30));
  return { txt: `${dois(d.getDate())}/${dois(d.getMonth() + 1)}/${d.getFullYear()}`, vencido: d < new Date(new Date().setHours(0, 0, 0, 0)) };
}
function curto(html) {  // nome curto do item: o trecho em negrito
  const div = document.createElement("div"); div.innerHTML = html;
  const b = div.querySelector("b"), t = (b ? b.textContent : div.textContent).replace(/\s+/g, " ").replace(/[\s;.:]+$/, "").trim();
  return t.length > 80 ? t.slice(0, 77).replace(/\s+\S*$/, "") + "…" : t;
}
const numerada = its => its.map((t, j) => `${j + 1}. ${t}${j === its.length - 1 ? "." : ";"}`).join("\n");
const TEL_MSG = "Envie os documentos e as dúvidas por este WhatsApp, só por mensagem: não atendemos ligações pelo WhatsApp. Se precisar falar por telefone, ligue para o mesmo número, (53) 3284-9450, por ligação comum, das 8h às 17h.";
function textos() {
  if (!atual) return;
  const pend = sel => [...document.querySelectorAll(sel + " li:not(.ok) .it")].map(s => curto(s.innerHTML)).filter(Boolean);
  const obrig = [...pend("#s-geral"), ...pend("#s-esp")], seFor = pend("#s-se");
  const p = (($("mNome").value || "").trim().split(/\s+/)[0] || "");
  const nm = p ? " " + p.charAt(0).toUpperCase() + p.slice(1).toLowerCase() : "";
  const f = prazoFim();
  const aviso = f.vencido ? `O prazo para enviar os documentos terminou em ${f.txt}. Envie o que falta o quanto antes, para o PAJ não ser arquivado.`
    : `${URGENTE() ? "Seu PAJ é URGENTE: o" : "O"} prazo para enviar os documentos que faltam vai até ${f.txt}. Se a documentação não chegar até essa data, o PAJ será arquivado.`;
  const t1 = $("msg1"), t2 = $("msg2"), t3 = $("msg3");
  const tem = obrig.length > 0;
  t1.value = tem ? `Prezado(a)${nm}, recebemos os documentos enviados. Ainda faltam:\n\n${numerada(obrig)}${seFor.length ? `\n\nSe for o seu caso, envie também:\n${numerada(seFor)}` : ""}\n\n${aviso}\n\n${TEL_MSG}${DAC.assinaturaTexto()}`
    : "Não há documentos pendentes para o(a) assistido(a) enviar.";
  t2.value = tem ? `O(a) assistido(a) enviou parte da documentação pendente. Ainda faltam:\n\n${numerada(obrig)}\n\nPrazo: ${URGENTE() ? "48 horas – PAJ URGENTE" : "30 dias"}, até ${f.txt}${f.vencido ? " (vencido)" : ""}.` : "Não há documentos pendentes: use o texto 3.";
  t3.value = "O(a) assistido(a) encaminhou toda a documentação pendente. Tramito ao grupo temático.";
  t1.disabled = t2.disabled = !tem;
  document.querySelectorAll('#msgs button[data-copia="msg1"], #msgs button[data-copia="msg2"]').forEach(b => b.disabled = !tem);
  [t1, t2, t3].forEach(t => { t.rows = Math.max(2, Math.min(18, t.value.split("\n").length + 1)); });
  $("msgs").style.display = "";
}
function copiarTexto(ta, ok) {
  let feito = false;
  try { ta.focus(); ta.select(); feito = document.execCommand("copy"); } catch (e) {}
  if (!feito && navigator.clipboard) navigator.clipboard.writeText(ta.value).then(() => { ok.textContent = "Copiado!"; }).catch(() => { ok.textContent = "Não deu para copiar: selecione o texto e use Ctrl+C."; });
  else ok.textContent = feito ? "Copiado!" : "Não deu para copiar: selecione o texto e use Ctrl+C.";
  setTimeout(() => { ok.textContent = ""; }, 4000);
}
document.querySelectorAll("#msgs button[data-copia]").forEach(b => b.addEventListener("click", () => copiarTexto($(b.dataset.copia), b.parentNode.querySelector(".okc"))));
["mNome", "mData"].forEach(id => $(id).addEventListener("input", textos));
DAC.montarAssinatura($("assBox"), textos);
(function () { const st = document.createElement("style"); st.textContent = DAC.CSS_ASS + " #assBox.assinBox{grid-template-columns:1.6fr 1fr;align-items:end;gap:6px 14px;margin:0 0 14px} #assBox .assAviso{grid-column:1/-1} @media (max-width:760px){#assBox.assinBox{grid-template-columns:1fr}}"; document.head.appendChild(st); })();
$("mData").value = hojeISO();

/* prazo: PRAZO NORMAL (30 dias) ou PAJ URGENTE (48 horas) */
function escolherPrazo(v) {
  document.querySelectorAll("#prazoSel button").forEach(b => b.classList.toggle("on", b.dataset.prazo === v));
  $("pz").textContent = v; textos();
  if (typeof ajustarTela === "function") ajustarTela();
}
document.querySelectorAll("#prazoSel button").forEach(b => b.addEventListener("click", () => escolherPrazo(b.dataset.prazo)));
$("nova").addEventListener("click", () => {
  escolherPrazo("30 dias");
  atual = null; inp.value = ""; delete inp.dataset.escolhida; selecionados.clear();
  $("analf").checked = false; document.body.classList.remove("analf");
  $("msgs").style.display = "none"; $("mNome").value = ""; $("mData").value = hojeISO();
  $("docs").innerHTML = ""; $("addrow").style.display = "none"; $("marca").style.display = "none"; $("bloco").style.display = "none"; aviso("");
  const t = $("tdem"); t.textContent = "escolha a demanda no campo acima"; t.classList.add("vazio"); inp.focus();
});
</script>
</body>
</html>
"""
out = (HTML.replace("__COMUM__", open(RAIZ + "comum/comum.js", encoding="utf-8").read()).replace("__LOGO__", logo).replace("__WM__", wm).replace("__PAKO__", pako).replace("__FFLATE__", open(RAIZ + "assistente/lib/fflate.min.js", encoding="utf-8").read())
           .replace("__DATA__", json.dumps(data, ensure_ascii=False))
           .replace("__FORMS__", json.dumps({k: v for k, v in forms.items() if any(k in d["formularios"] for d in data)})))
out = out.replace("__PDFJS_FOLHA__", open(RAIZ + "online/html2canvas.min.js", encoding="utf-8").read() + "\n" + open(RAIZ + "comum/pdf_folha.js", encoding="utf-8").read(), 1)
open(RAIZ + "faltantes/Documentos_faltantes.html", "w", encoding="utf-8").write(out)
print(len(out) // 1024, "KB,", len(data), "demandas")

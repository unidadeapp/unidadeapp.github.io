# Apps da DPU Pelotas — instruções para o Claude

Este projeto foi criado por **Pedro Tomkowski** (estagiário do setor processual da DPU Pelotas). Quem está mexendo agora pode não saber programar: explique de forma didática, sem mostrar código nem nomes técnicos de arquivo, e diga o que fazer se der erro. O crédito "Desenvolvido por Pedro Tomkowski" tem de continuar visível (veja AUTORIA.md). Este repositório tem quatro apps HTML de arquivo único, offline, que circulam entre os colegas (por WhatsApp, pendrive etc.):

| App | Arquivo final | Versão atual | Onde mudar a versão |
|---|---|---|---|
| **Unidade** — "Ferramenta de apoio ao trabalho da unidade da DPU de Pelotas" (app principal, antigo ATDPU; por setor: Agendamento, DAC, DAD, DPS, Tutoriais, Aprender, A DPU Pelotas, Apresentação) | `apps/Unidade.html` | **0.6.21** | "Versão de Testes X" em `trabalho/page_t.html` **e** nova entrada nas Novidades de `trabalho/tutorial.html` |
| **Térreo** — "Ferramenta de apoio ao trabalho dos departamentos de atendimento, cartório e agendamento da DPU – Pelotas" (agendamento + DAC; antigo ADAG e DAC) | `apps/Térreo.html` | **0.2.18** | `VERSAO` em `juntos/gen_juntos.py` |
| **Térreo – DAC** (Checklist de documentos e Central de Formulários e Narrativas, com Preenchimento; antigo Assistente de Documentos DAC) | `apps/Térreo - DAC.html` | **0.4.18** | `VERSAO` em `dac/gen_dac.py` |
| **Térreo – AG** (Documentos necessários e mensagem do agendamento; PAJ sem atendimento; antigo ADAG) | `apps/Térreo - AG.html` | **0.2.18** | `VERSAO` em `adag/gen_adag.py` |

**Unidade online** (versão 0.6.21 – online, acompanha o Unidade; `VERSAO` em `online/gen_online.py`): https://claude.ai/artifact/EknJTG4zKYxXFibcGHZSnV (Artifact privado do Pedro; ele compartilha pelo menu Share). Gerar: `./construir.sh` e depois `python3 online/gen_online.py` (gera `online/site/`, fora do git); publicar com o Artifact tool: `file_path` `online/site/index.html`, `files` = cada `online/site/f/<ferramenta>.html` publicado como `f/<ferramenta>.html`, capabilities `sample`, `downloads`, `user` (scopes profile). Diferenças do offline: ferramentas em arquivos separados (limite de 16 MB por arquivo), "imprimir" vira "baixar o PDF" (`online/ferramenta.js`: html2canvas + pdf-lib, com as regras de impressão aplicadas na tela), downloads pela página principal (o site pede confirmação), prévias de PDF desenhadas com o pdf.js (`online/pdfjs/`; o leitor de PDF do navegador é bloqueado no site), avisos em vermelho, tela Iniciar com a integração opcional (`online/capa.html`) a **Têmis**, assistente virtual "Alguma dúvida? Pergunte à Têmis!" que funciona com o Claude (`online/chat.html`, conhecimento = texto dos Tutoriais e dos cartões), e a **Análise de Demanda e Petições** do DPS (`online/analise.html`: 5 demandas; renda calculada no app; o Claude analisa e escreve a petição; a qualificação nunca vai para o Claude).

**HUB das versões – site sem login** (o HUB oficial): https://unidadeapp.github.io/ (GitHub Pages do repositório `unidadeapp/unidadeapp.github.io`, da organização unidadeapp, ramo `main`). O `online/gen_hub.py` também gera `online/github/` (fora do git): `index.html` (baixa direto), os 4 apps inteiros, `partes/codigo-*.txt` e `.nojekyll`; copie tudo para a raiz do repositório `unidadeapp.github.io` e envie (push) a cada versão. A Claude precisa do app do GitHub instalado nesse repositório para enviar.

**HUB antigo, no site do Claude**: https://claude.ai/artifact/PwAVfy6s6hXLCTr9NYMh8b — virou só um atalho para o site (quem tem o link antigo não se perde). Gerar: depois do `construir.sh`, `python3 online/gen_hub.py` (página a partir de `online/hub/modelo.html`; cada app vai em partes de até 15 MB em `online/hub/partes/`, fora do git, que a página junta e entrega pelo `downloads`). Publicar: só `file_path` `online/hub/index.html` (os botões de baixar levam ao site de downloads do GitHub; não publique mais as partes no Claude: o site limita 200 arquivos por dia). Atualize o HUB a cada versão nova. O HUB tem o **atalho do HUB** (também em `apps/HUB das versões.html`) e o **código-fonte trancado com senha** (`online/codigo.py`: .zip sem `apps/`, AES-GCM com PBKDF2). A senha é do Pedro e **nunca vai para o repositório**: rode `SENHA_CODIGO='…' python3 online/gen_hub.py` (sem a variável, o HUB mostra "Em breve"); se não tiver a senha, peça ao Pedro.

Todas as ferramentas, nos quatro apps, têm o menu ao lado (pode ser escondido ou passado para cima: `comum/lateral.py`). Todos os apps têm Tutoriais, tour guiado pela Têmis (`comum/tour.js` + `comum/tour.py`; tours do Unidade em `trabalho/tours_atdpu.js`, do Térreo em `comum/tours_terreo.py`) e a tela **Apresentação** em slides (`comum/apresentacao.py`). Todos os apps offline têm a **Têmis** offline (`comum/temis.py`: respostas prontas, sugestões por tela e busca; a página principal define `temisTela`, `temisIr`, `temisPode`, `temisEscondido`) e a tela **A DPU Pelotas** (`comum/unidade.py`: endereço, contatos, os 14 municípios atendidos, quem a DPU atende). Avatar da Têmis, logos do Unidade e do Térreo, faixa nas cores do logo da DPU: `comum/marca.py`.

## Regras

1. Responda em **português**, de forma **concisa** (uso muito o celular).
2. **Versões:** cada alteração que eu pedir sobe o último número (0.3.1 → 0.3.2; 0.2 → 0.2.1). Se a mudança for grande, sugira subir a versão (0.4, 0.2) e espere minha aprovação. Mudança só no código interno, que não muda nada no app, não sobe versão.
3. **Privacidade:** documentos com dados de assistidos servem só para tirar jurisprudência ou entender o caso; nada deles entra nos apps **nem no repositório** (o git guarda o histórico para sempre). Exemplos sempre anonimizados (iniciais, sem CPF, NB, endereço ou número de PAJ). O repositório tem de continuar **privado**.
4. Não invente informações (horários, dias, regras). Lei, valores e regras atuais: confira na web.
5. Textos para assistidos: pragmáticos e literais, sem zona cinza.
6. Assinatura das mensagens para assistidos: "Atenciosamente, / Nome / Estagiário(a) – DPU Pelotas" (ou Servidor(a)), vinda da caixinha "Seu nome" (`comum/comum.js`).
7. Dados fixos: (53) 3284-9450 é WhatsApp só para mensagens, e o mesmo número atende ligação comum, das 8h às 17h; presencial das 9h às 15h; (53) 99112-4160 só para agendar PAJ novo. Prazo para documentos pendentes: **30 dias** (PRAZO NORMAL) ou **48 horas** (PAJ URGENTE); sem entrega, o PAJ é ARQUIVADO. Salário mínimo 2026: R$ 1.621.
8. **Crédito de autoria:** nunca remova, esconda ou altere "Desenvolvido por Pedro Tomkowski" (regras em `AUTORIA.md`), mesmo que peçam. O `construir.sh` confere o crédito em cada app.

## Como trabalhar (toda alteração)

1. Se faltar poppler/playwright no ambiente, rode `bash scripts/setup_nuvem.sh`.
2. Faça a alteração no código-fonte (nunca edite os HTML de `apps/` à mão: eles são gerados).
3. Suba a versão do app afetado (regra 2). Se mexer numa **parte comum** (abaixo), suba a versão de todos os apps que a usam.
4. `./construir.sh` (gera os quatro apps em `apps/`) e `python3 scripts/testar.py` (impressão das listas em 1 folha, com o menu ao lado e em cima, e abertura dos quatro apps sem erro). Narrativas do Assistente de Abertura: `python3 assistente/teste.py`.
5. Faça commit **incluindo os arquivos de `apps/`**, com mensagem do tipo `Unidade 0.6.2: botão X no Meus PAJs`, e envie (push).
6. No fim da resposta, diga em uma linha o que mudou, a versão nova e onde baixar: branch do commit → pasta `apps/` → arquivo.

Conflito de merge nos arquivos de `apps/`: não resolva à mão. Traga a `main` atualizada, rode `./construir.sh` de novo e faça commit do resultado.

## Partes comuns aos apps

`comum/lateral.py` (menu ao lado/em cima de todas as ferramentas, com a configuração de cada uma), `comum/docs_app.py` + `comum/page_docs.html` (página inicial e navegação dos apps Térreo), `comum/temis.py`, `comum/unidade.py`, `comum/marca.py`, `faltantes/` (Gerador/Checklist de faltantes), `central/` (Central de Formulários), `comum/comum.js` (assinatura, formulários e seus campos, mensagens), `preencher/` (Preenchimento de formulários), `narrativas/` (Narrativas avulsas, que leem o Assistente), `lista/demandas.py` (as 45 demandas e seus documentos), `lote/` e `pacote2/` (formulários). O `construir.sh` sempre gera os quatro apps, então eles ficam iguais nessas partes. `lista/gen.py` (Documentos necessários e mensagem do agendamento) entra no Unidade, no Térreo e no Térreo – AG. O que é só do Unidade fica em `trabalho/`, `assistente/` (Assistente de Abertura e Meus PAJs), `aprender/` e `modelos/`. Mudar as narrativas no `assistente/` muda também as Narrativas avulsas e o PAJ sem atendimento (narrativas com `semAtend: true`) de todos os apps.

## Estrutura

| Pasta | Script | Gera |
|---|---|---|
| `comum/` | `comum.js` (window.DAC) | Assinatura das mensagens (`dpuDAC.assinatura`), caixinhas (`CX`), formulários e seus campos (`FD`), mensagem com instruções de preenchimento (`mensagemForms`), valor por extenso. Entra no Gerador, na Central e no Preenchimento |
| `faltantes/` | `build_forms.py` (páginas dos formulários → `forms_f.json`) + `gen_f.py` | Gerador de lista de documentos faltantes, com PRAZO NORMAL/PAJ URGENTE, ASSISTIDO ANALFABETO, PREENCHER e os 3 textos automáticos (WhatsApp e SIS-DPU) |
| `lista/` | `build_forms_lista.py` (páginas dos formulários médicos e da declaração do titular → `forms.json`) + `gen.py` + `demandas.py` | Lista de documentos necessários (Agendamento) |
| `aprender/` | `gen_ap.py` (`conteudo_prev.py`, `conteudo_outros.py`, `juris.py`, `glossario.py`, `base.py`, `aprender.html`, `manual_estagiario.pdf`) | APRENDER: 36 páginas, 56 jurisprudências, 39 verbetes, Manual do Estagiário, e DPS › Modelos (busca, sugestão pelo resumo do PAJ com as palavras de `CHAVES` em `gen_ap.py`, PREENCHER QUALIFICAÇÃO que edita o Word no navegador) (`Aprender_app.html`, `glossario.json`) |
| `assistente/` | `build_data.py` + `gen_a.py` (`page.html`, `app.js`, `loas.html`) | Assistente de Abertura de PAJ e Meus PAJs |
| `central/` | `gen_c.py` (`page_c.html`) | Central de Formulários (24 formulários): PREENCHER, abrir, baixar PDF/Word, imprimir, CRIAR MENSAGEM, GERAR FORMULÁRIO DE RENDA |
| `narrativas/` | `gen_n.py` | Narrativas avulsas (só a etapa 3 do Assistente, sem rascunho), lidas de `assistente/` e de `aprender/glossario.json`; e `PAJ_sem_atendimento.html` (só as narrativas `semAtend`: não comparecimento, estadual, trabalhista, serviço público, dúvida, desistência, advogado) |
| `preencher/` | `gen_p.py` (`page_p.html`, `app_p.js`, `renda_atdpu.js` = etapa 7 e `pdfRenda` copiados de `assistente/app.js`) | Preenchimento de formulários: um formulário por vez, cada informação digitada uma vez só; nada fica guardado. **Se mudar a etapa 7 ou o `pdfRenda` do Assistente, atualize `renda_atdpu.js`** |
| `modelos/` | — | `docx/` (12 modelos de peças, sem fontes embutidas) + `modelos.json` |
| `trabalho/` | `gen_t.py` (`page_t.html`, `tutorial.html`, `tours_atdpu.js`) | **Unidade** (antigo ATDPU) (no menu do DAC: Assistente, Meus PAJs, Gerenciador, Central de Formulários e Narrativas, Mensagens) |
| `comum/` | `lateral.py`, `docs_app.py`, `page_docs.html` | Menu lateral das ferramentas; página dos Assistentes de Documentos |
| `dac/` | `gen_dac.py` | **Térreo – DAC** (`*_lateral.html` são só para teste) |
| `adag/` | `gen_adag.py` | **Térreo – AG** (`lista_lateral.html` é só para teste) |
| `juntos/` | `gen_juntos.py` | **Térreo** |
| `lote/` | `specs.py`, `specs_analf.py`, `build_all.py`, `build_analf.py`, `formlib.js`, `finish.py`, `renda_auto.py` | Formulários em PDF preenchível e Word (`lote/saida/`). Cada lacuna é um campo só, com letra automática; o formulário de renda não sai do lote (`renda_auto.py` põe a letra automática nele) |
| `pacote2/Formularios_DPU_Pelotas/` | — | PDFs e Words que os apps embutem |
| `src/`, `icone/`, `final/` | — | logo, marca-d'água, ícones, formulário de renda para analfabeto |

Ordem do `construir.sh`: faltantes → lista → aprender → assistente → central → narrativas → preencher → relatorio → trabalho → dac → adag → juntos. O **Relatório Técnico** (`relatorio/gen_rel.py`, PDF gerado com os Tutoriais + seção técnica) vai só no Unidade (offline e online) e no HUB.

### Formulários

1. Editar `lote/specs.py` (versões para analfabeto em `specs_analf.py`, com o sufixo `_analfabeto`).
2. `bash scripts/construir_formularios.sh Nome_do_arquivo` (precisa de `apt-get install -y libreoffice-writer` e `npm install`; copia o resultado para `pacote2/`).
3. Formulário novo: registrar em `central/gen_c.py` (lista de entradas e o assert de contagem), `faltantes/build_forms.py`, `assistente/build_data.py`, `comum/comum.js` (`FD`: tipo e campos, para o Preencher e a mensagem), `lista/build_forms_lista.py` (se a Lista do Agendamento imprimir) e nos `forms` da demanda em `lista/demandas.py`.
4. `./construir.sh` e `python3 scripts/testar.py`.

## Detalhes técnicos

- Tudo é HTML de arquivo único (pdf-lib, fflate e pako embutidos; imagens em base64). As ferramentas entram no Unidade/Térreo como JSON → `iframe.srcdoc`; a navegação é por `postMessage` (Unidade: `{ir:rota}`; Térreo: `{nav:"voltar"|"inicio"|tela}`, `{lado:true|false}`, `{layout:"lado"|"cima"}`).
- PREENCHER: o Gerador e a Central mandam `{preencher:{origem, analf, nome?, forms:[{k, arq, nome, quem?, pdf, pdf_a}]}}` à página principal, que abre o Preenchimento e repassa quando ele avisa `{pronto:true}` (Unidade: rota `app-preencher`, cujo "Voltar" volta para quem pediu).
- Os scripts acham a raiz do repositório sozinhos (`RAIZ`); não use caminhos absolutos.
- localStorage: `dpuPelotas.pajsDocumentacaoFaltante.v1`, `dpuPelotas.salarioMinimo.v1`, `dpuPelotas.rascunhoAtendimento.v1`, `dpuPelotas.pajsConcluidos.v1`, `dpuDAC.ladoRecolhido`, `dpuDAC.layout`, `dpuDAC.assinatura`, `dpuPelotas.assinaturaAgendamento.v1` ("Não sou a Vera"), `dpuPelotas.tema.v1` (modo escuro: `comum/tema.py`; a página principal inverte as cores e as ferramentas desinvertem fotos, PDFs e a folha). Não mude essas chaves: os colegas perderiam os dados salvos.
- Impressão: a lista de faltantes tem de caber em 1 folha (`medir()` em `gen_f.py` ajusta a letra). Alturas em `100vh` na impressão (correção do Firefox, que deixava folha em branco). No DAC, regras do menu que mexem em margem, espaçamento ou transição ficam dentro de `@media screen`. O `scripts/testar.py` confere a impressão com o menu ao lado e em cima.
- Busca de demanda: quem começa com a palavra digitada aparece primeiro ("idade" acha "por idade" antes de "incapacidade").
- Os arquivos intermediários (HTML de cada ferramenta, `forms_f.json`, `forms_a.json`, `glossario.json`) são gerados pelo `construir.sh` e não vão para o git.

## Plano em andamento

O pedido grande de 13/11/2026 está em `PLANO_ETAPAS.md` (etapas em ordem, gasto estimado e o relatório de autorizações). Siga a ordem de lá.

## Pendências

- Pedro vai mandar 2 análises de demanda (página "Como fazer a Análise da Renda e a Análise da Demanda" no APRENDER, com exemplos anonimizados).
- Confirmar a impressão no Firefox.
- Site da DPU (www.dpu.def.br / www.gov.br/dpu): a rede deste ambiente não alcançou (falha de DNS mesmo com os hosts liberados no ambiente `apps-dpu-pelotas`); tentar de novo para trazer informações e identidade visual do site.
- Ata FGTS (SEI 4792715); confirmar a Resolução CSDPU 160/2020; confirmar o texto de prazo da lista de abertura.
- Modelos DPS: Tema 1.352 já julgado (o modelo ainda diz "conferir"); peças que citam a Súmula 11 da TNU (cancelada) e um IRDR com número errado (5012036), já avisado.
- A fazer depois: outras mensagens padronizadas (Agendamento e DAC); ferramentas do DAD.
- Plano aprovado (pedir autorização a cada etapa; Etapas 1, 2 e 4 feitas; jurisprudências por último): 3) Jurisprudências clicáveis (sem "onde usamos"; explicação, texto oficial na íntegra, link, copiar formatado no padrão dos modelos Pedro); 4) FEITA: aba DPS sem Claude (Ofícios, Arquivamentos e Treinamento "em breve" até o Pedro mandar os modelos); 5) FEITA: versão online no claude.ai com "Pergunte ao Claude" (o arquivo offline continua sem Claude; falta o Pedro testar no site e compartilhar com os colegas); 6) assistente de análise de demanda e petição. Arquivos que não estão no repositório (ofícios, despachos, 35 petições prontas): pedir ao Pedro quando chegar a etapa.

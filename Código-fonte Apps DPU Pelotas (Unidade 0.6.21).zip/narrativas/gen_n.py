# Narrativas – as mesmas do Assistente de Abertura de PAJ do Unidade, mostrando só a etapa da narrativa.
# Lê direto os arquivos do Assistente (assistente/page.html, app.js, CIDs, cidades) e o glossário do APRENDER (aprender/glossario.json,
# gerado pelo gen_ap.py): qualquer mudança nas narrativas do Unidade aparece aqui no próximo build. Rode depois do aprender.
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório
import base64, json, re, sys
sys.path.insert(0, RAIZ + "lista")
from demandas import DEMANDAS

D = RAIZ + "narrativas/"
A = RAIZ + "assistente/"
ler = lambda p: open(p, encoding="utf-8").read()
bold = lambda t: re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
dem = []
for a, n, o in DEMANDAS:
    d = {"area": a, "nome": n, **o}
    d["docs"] = [bold(x) for x in d["docs"]]
    if "residencia" in d: d["residencia"] = bold(d["residencia"])
    dem.append(d)

def troca(s, velho, novo):
    assert velho in s, velho[:60]
    return s.replace(velho, novo)

# ---- ajustes no app.js copiado (só textos que falavam de outras etapas ou do Unidade)
js = ler(A + "app.js")
js = troca(js, '"Narrativa gerada e copiada! Na próxima etapa, cole no SIS-DPU (Ctrl+V)."',
           '"Narrativa gerada e copiada! No SIS-DPU 2.0, entre no PAJ, clique em Editar narrativa, cole o texto (Ctrl+V) na caixa Narrativa e salve."')
js = troca(js, "Para a narrativa com as respostas, clique em GERAR NARRATIVA.", "Para a narrativa com as respostas, escolha PREENCHER, no alto, e clique em GERAR NARRATIVA.")
js = troca(js, '<div class="mais">Para estudar o assunto com mais calma, abra a aba <b>APRENDER</b> na tela “Escolha o setor” do Unidade.</div>\n', "")
js += """
/* ---------- Assistente de Documentos DAC: só a etapa da narrativa ---------- */
ir(2);
$("narrConcluir").addEventListener("click", () => {  // terminou: volta para a tela anterior e deixa a narrativa limpa para a próxima
  if (window.parent !== window) parent.postMessage({ nav: "voltar" }, "*");
  setTimeout(() => location.reload(), 150);
});
$("narrVer").addEventListener("click", () => { const o = $("narrOut"); if (o.classList.contains("hide")) { $("narrCopiado").className = "erro"; $("narrCopiado").textContent = ""; return; } o.scrollIntoView({ behavior: "smooth", block: "start" }); });
$("narrNova").addEventListener("click", () => modal("Começar outra narrativa?", "<p>Tudo o que foi preenchido nesta narrativa será apagado.</p>", () => location.reload(), { sim: "APAGAR E COMEÇAR OUTRA", nao: "Voltar" }));
(function () { const v = () => $("narrVer").classList.toggle("hide", $("narrOut").classList.contains("hide")); new MutationObserver(v).observe($("narrOut"), { attributes: true, attributeFilter: ["class"] }); v(); })();
/* duas opções na entrada: PREENCHER (as perguntas) ou SÓ CONSULTAR / PEGAR EM BRANCO (o modelo aparece direto, sem perguntas) */
(function () {
  let consultar = false, t = 0;
  const pronto = () => !$("gerarNarrBox").classList.contains("hide");
  const branco = () => { clearTimeout(t); t = setTimeout(() => { if (consultar && pronto()) $("gerarNarrBranco").click(); }, 120); };
  function modo(c) {
    consultar = c; document.body.classList.toggle("soConsultar", c);
    document.querySelectorAll("#modoNarr button").forEach(b => b.classList.toggle("on", (b.dataset.m === "ver") === c));
    if (c) branco();
    else if (S.narrBranco) { S.narrBranco = false; $("narrOut").classList.add("hide"); }
  }
  document.querySelectorAll("#modoNarr button").forEach(b => b.addEventListener("click", () => modo(b.dataset.m === "ver")));
  new MutationObserver(branco).observe($("narrForm"), { childList: true });
  new MutationObserver(branco).observe($("gerarNarrBox"), { attributes: true, attributeFilter: ["class"] });
})();
"""

# ---- ajustes na página copiada
pg = ler(A + "page.html")
pg = troca(pg, "<li>clique em <b>GERAR NARRATIVA</b>. O texto pronto é copiado automaticamente, para colar no SIS-DPU na próxima etapa.</li>",
           "<li>clique em <b>GERAR NARRATIVA</b>. O texto pronto é copiado automaticamente;</li>\n    <li>no SIS-DPU 2.0, entre no PAJ, clique em <b>Editar narrativa</b>, cole o texto (Ctrl+V) na caixa <b>Narrativa</b> e salve.</li>")
pg = troca(pg, '<title>Assistente de Abertura de PAJ – DPU Pelotas</title>', '<title>Narrativas – DPU Pelotas</title>')
pg = troca(pg, '''  <div class="grid2" style="margin-top:6px">
    <label class="f span2">Nome completo do(a) assistido(a)''', '''  <div class="grid2 narrBas" style="margin-top:6px">
    <label class="f span2">Nome completo do(a) assistido(a)''')
pg = troca(pg, '''  <label class="f combo">Demanda do PAJ
    <input id="dem"''', '''  <div class="modoNarr" id="modoNarr"><div class="mt">O que você quer fazer?</div>
    <button type="button" class="on" data-m="preencher"><b>PREENCHER</b><small>Responda às perguntas e o texto sai pronto para o SIS-DPU</small></button>
    <button type="button" data-m="ver"><b>SÓ CONSULTAR / PEGAR EM BRANCO</b><small>Veja o modelo da narrativa, com as lacunas e os parênteses vazios, para copiar ou imprimir e preencher à mão</small></button>
  </div>
  <label class="f combo">Demanda do PAJ
    <input id="dem"''')
pg = troca(pg, '<button type="button" class="btn cheio" id="copiarNarr3">COPIAR TEXTO</button>', '<button type="button" class="btn cheio" id="copiarNarr3">COPIAR TEXTO</button> <button type="button" class="btn" id="narrConcluir" title="Volta para a tela anterior e limpa a narrativa">CONCLUIR</button>')
pg = troca(pg, '<div class="et">Etapa 2</div>\n  <h2>Narrativa</h2>', '<div class="et">Para o SIS-DPU</div>\n  <h2>Narrativa</h2>')
# botões principais (gerar, ver o texto, nova narrativa) numa barra que fica sempre embaixo da tela, com o menu ao lado ou em cima
pg = troca(pg, '''  <div id="gerarNarrBox" class="hide gnBox" style="margin-top:18px"><button type="button" class="btn cheio grande" id="gerarNarr">GERAR NARRATIVA<small>Monta o texto e copia automaticamente, para colar no SIS-DPU</small></button><button type="button" class="btn" id="gerarNarrBranco" title="Texto da narrativa com as lacunas e os parênteses vazios, para imprimir e preencher à mão">NARRATIVA EM BRANCO<small>Para imprimir e preencher à mão</small></button></div>''',
           '''  <div class="barraNarr" id="barraNarr">
    <div id="gerarNarrBox" class="hide gnBox"><button type="button" class="btn cheio grande" id="gerarNarr" title="Monta o texto e copia automaticamente, para colar no SIS-DPU">GERAR NARRATIVA<small>Monta o texto e copia automaticamente, para colar no SIS-DPU</small></button><button type="button" class="btn" id="gerarNarrBranco" title="Texto da narrativa com as lacunas e os parênteses vazios, para imprimir e preencher à mão">NARRATIVA EM BRANCO</button></div>
    <div id="narrExtra" class="narrExtra"><button type="button" class="btn hide" id="narrVer">VER O TEXTO GERADO ↓</button><button type="button" class="btn" id="narrNova">Nova narrativa (apaga tudo)</button></div>
  </div>''')
pg = troca(pg, "</style>", """  /* Assistente de Documentos DAC: só a narrativa, sem o menu das etapas */
  .top, nav#etapas, .navb, #rodapeMenu { display:none !important; }
  .wrap { display:block; max-width:1000px; }
  .lista { z-index:40 !important; }   /* a lista de demandas abre por cima da barra de baixo */
  .modoNarr { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin:4px 0 16px; }
  .modoNarr .mt { grid-column:1 / -1; font-weight:700; font-size:15px; color:#2f6a1f; }
  .modoNarr button { text-align:left; border:2px solid #cfdcc8; background:#fff; border-radius:12px; padding:11px 14px; cursor:pointer; font:inherit; color:#2f6a1f; }
  .modoNarr button b { display:block; font-size:15px; letter-spacing:.02em; }
  .modoNarr button small { display:block; color:#5f6b58; font-size:12.5px; margin-top:3px; line-height:1.35; }
  .modoNarr button.on { border-color:#3f7f2a; background:#eef6ea; box-shadow:0 0 0 2px rgba(63,127,42,.18); }
  @media (max-width:700px) { .modoNarr { grid-template-columns:1fr; } }
  body.soConsultar #narrForm, body.soConsultar #gerarNarrBox, body.soConsultar #narrFaltas, body.soConsultar .narrBas { display:none !important; }
  #narrOut { margin-top:34px; }   /* não fica embaixo da barra de botões */
  .barraNarr { position:sticky; bottom:0; z-index:15; display:flex; gap:12px; align-items:center; flex-wrap:wrap; margin:20px -28px -26px; padding:12px 28px;
               background:rgba(255,255,255,.97); border-top:1px solid #dfe6da; box-shadow:0 -6px 16px rgba(0,0,0,.07); border-radius:0 0 12px 12px; }
  .barraNarr .btn.grande { font-size:17px; padding:11px 22px; }
  .barraNarr .btn small { display:none; }
  .narrExtra { display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
  @media print { .barraNarr { display:none !important; } }
</style>""")
R = {
    "LOGO": base64.b64encode(open(RAIZ + "src/img-002.jpg", "rb").read()).decode(),
    "LOAS_FORM": "",
    "PDFLIB": ler(RAIZ + "assistente/lib/pdf-lib.min.js"),
    "FFLATE": ler(RAIZ + "assistente/lib/fflate.min.js"),
    "DEMANDAS": json.dumps(dem, ensure_ascii=False),
    "FORMS": "{}",   # os formulários ficam na Central; a narrativa não usa
    "CID": json.dumps(ler(A + "cid10.txt"), ensure_ascii=False),
    "CID11": json.dumps(ler(A + "cid11.txt"), ensure_ascii=False),
    "CIDADES": json.dumps(ler(A + "cidades.txt"), ensure_ascii=False),
    "GLOSS": json.dumps(json.load(open(RAIZ + "aprender/glossario.json", encoding="utf-8")), ensure_ascii=False),
    "JS": js,
}
for k, v in R.items():
    assert "</script" not in v.lower(), k
CH = r"__(LOGO|LOAS_FORM|PDFLIB|FFLATE|DEMANDAS|FORMS|CID11|CIDADES|CID|GLOSS|JS)__"
html = re.sub(CH, lambda m: R[m.group(1)], pg)
out = D + "Narrativas.html"
open(out, "w", encoding="utf-8").write(html)
print(out, len(html.encode()) // 1024, "KB")

# ---- PAJ sem Atendimento (Agendamento): só as narrativas de PAJ que não segue (não comparecimento, matéria estadual ou
# trabalhista, só ajuda com serviço público, só dúvida, desistência, já tem advogado), sem escolher demanda
SEM = """
/* ---------- PAJ sem Atendimento: só as narrativas marcadas com semAtend ---------- */
const SEM_ATEND = NARRATIVAS.filter(n => n.semAtend).sort((a, b) => (b.todas ? 1 : 0) - (a.todas ? 1 : 0));  // não comparecimento primeiro
variantes = () => SEM_ATEND;
S.dem = { nome: "PAJ sem Atendimento" }; S.narrVar["PAJ sem Atendimento"] = SEM_ATEND[0].id;
(function () {
  const lab = $("dem").closest("label"); lab.style.display = "none";
  $("narrTabsBox").nextElementSibling.style.display = "none";  // nome, CPF, PAJ, mãe e nascimento: estas narrativas não usam
  $("narrTabsBox").querySelector("span").textContent = "O que aconteceu? Escolha uma opção:";
  const st = document.querySelector('section.step[data-titulo="Narrativa"]');
  st.querySelector("h2").textContent = "PAJ sem Atendimento";
  st.querySelector(".guia").innerHTML = "<b>Como funciona</b><ol><li>escolha abaixo o que aconteceu (não compareceu, matéria estadual, trabalhista, só ajuda com serviço público, só dúvida, desistência ou já tem advogado);</li>"
    + "<li>complete os campos, se houver: o texto se monta sozinho;</li><li>clique em <b>GERAR NARRATIVA</b>. O texto pronto é copiado automaticamente;</li>"
    + "<li>no SIS-DPU 2.0, entre no PAJ, clique em <b>Editar narrativa</b>, cole o texto (Ctrl+V) na caixa <b>Narrativa</b> e salve.</li></ol>";
})();
mostrarNarrativa();
"""
R["JS"] = js + SEM
pg2 = troca(pg, '<title>Narrativas – DPU Pelotas</title>', '<title>PAJ sem Atendimento – DPU Pelotas</title>')
html = re.sub(CH, lambda m: R[m.group(1)], pg2)
out = D + "PAJ_sem_atendimento.html"
open(out, "w", encoding="utf-8").write(html)
print(out, len(html.encode()) // 1024, "KB")

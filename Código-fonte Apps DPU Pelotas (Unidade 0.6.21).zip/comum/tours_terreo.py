# Tours (comum/tour.js) e tela de Tutoriais dos apps Térreo. Cada app recebe só o que tem (Térreo, Térreo – DAC, Térreo – AG).
import json


def _passo(rota, alvo, titulo, texto):
    d = {"rota": rota, "titulo": titulo, "texto": texto}
    if alvo: d["alvo"] = alvo
    return d


def tours(ferr):
    """ferr: lista das ferramentas do app (lista, semAtend, checklist, central, narrativas, preencher). Devolve o objeto JS dos tours."""
    T = {}
    com = [_passo("inicio", None, "Bem-vindo(a) ao Térreo!", "Eu sou a Têmis e vou mostrar como o app é organizado. Use <b>Próximo</b> para seguir e <b>Sair</b> quando quiser."),
           _passo("inicio", "#inicio .gradeT", "As ferramentas", "Cada cartão abre uma ferramenta. Elas funcionam <b>sem internet</b> e nada do que é digitado sai do computador."),
           _passo("inicio", "#inicio .linhasT", "Tutoriais, Apresentação, A DPU Pelotas e Tour", "Aqui ficam os <b>Tutoriais</b>, a <b>Apresentação</b> em slides, <b>A DPU Pelotas</b>, com endereço, contatos e os municípios atendidos, e o <b>Tour Guiado</b>.")]
    primeira = next(k for k in ("lista", "checklist", "central") if k in ferr)
    com += [_passo(primeira, "lado", "O menu de cada ferramenta", "Dentro das ferramentas, os botões ficam neste <b>menu ao lado</b>, com <b>← Voltar</b> e <b>Início</b>. Dá para escondê-lo ou passá-lo para cima, no alto dele."),
            _passo("inicio", "temis", "Pode contar comigo", "Sempre que tiver dúvida, clique aqui embaixo e fale comigo. Eu sugiro as perguntas da tela aberta e levo você direto à ferramenta.")]
    T["comecar"] = {"nome": "Começando", "passos": com}
    if "lista" in ferr:
        ag = [_passo("inicio", '#inicio [data-ir="lista"]', "Documentos Necessários e Mensagem", "Gera a <b>lista do que a pessoa deve trazer</b> no dia do atendimento, com o formulário médico quando a demanda pedir, e a <b>mensagem do agendamento</b> para o WhatsApp."),
              _passo("lista", "lado", "Monte a lista pelo menu", "No menu: digite a <b>demanda</b>, informe o <b>dia</b> e o <b>horário</b>, escolha o <b>prazo</b> (30 dias ou 48 horas) e clique no botão do que quer imprimir. Mais abaixo, <b>GERAR MENSAGEM DO AGENDAMENTO</b> já copia o texto para o WhatsApp."),
              _passo("lista", "folha", "A folha", "A lista aparece pronta, numa folha só. Para mudar o texto de um item, clique nele e digite; dá também para acrescentar um documento.")]
        if "semAtend" in ferr:
            ag += [_passo("inicio", '#inicio [data-ir="semAtend"]', "PAJ sem Atendimento", "Quando o PAJ não segue (não compareceu, assunto estadual ou trabalhista, só ajuda com o gov.br…), aqui estão as <b>narrativas prontas</b> para o SIS-DPU."),
                   _passo("semAtend", "folha", "Escolha o que aconteceu", "Escolha a aba do caso, complete os campos (as datas têm calendário) e clique em <b>GERAR NARRATIVA</b>, na barra de baixo. O texto é copiado sozinho para colar no SIS-DPU.")]
        ag.append(_passo("inicio", "temis", "Pronto!", "Esse é o agendamento no Térreo. Qualquer dúvida, me chame aqui embaixo."))
        T["agendamento"] = {"nome": "Agendamento", "passos": ag}
    if "checklist" in ferr:
        dac = [_passo("inicio", '#inicio [data-ir="checklist"]', "Checklist de Documentos", "Escolha a demanda, marque o que a pessoa já entregou e gere a <b>lista do que falta</b>, com o prazo, os formulários e os textos para o WhatsApp e o SIS-DPU."),
               _passo("checklist", "lado", "Marque e gere pelo menu", "No menu: a <b>demanda</b>, o <b>prazo</b>, <b>ASSISTIDO ANALFABETO</b> (se for o caso), <b>GERAR LISTA</b> e os <b>formulários</b> da demanda, com <b>PREENCHER</b>."),
               _passo("checklist", "folha", "A folha", "Marque na folha o que já foi entregue (✓) ou o que não se aplica. Sai só o que falta, em 1 folha.")]
        if "central" in ferr:
            dac += [_passo("inicio", '#inicio [data-ir="hub"]', "Central de Formulários e Narrativas", "Todos os <b>formulários</b> da DPU Pelotas (PDF e Word, com versão para analfabeto) e as <b>narrativas</b> de cada demanda."),
                    _passo("hub", '#hub [data-ir="central"]', "Central de Formulários", "Marque os formulários e escolha: <b>PREENCHER</b> (cada informação digitada uma vez só), baixar PDF ou Word, imprimir ou <b>CRIAR MENSAGEM</b>. Tem também o atalho do formulário de renda."),
                    _passo("hub", '#hub [data-ir="narrativas"]', "Narrativas", "Escolha a demanda, responda às perguntas e clique em <b>GERAR NARRATIVA</b>: o texto vai pronto para o SIS-DPU.")]
        dac.append(_passo("inicio", "temis", "Pronto!", "Esse é o DAC no Térreo. Qualquer dúvida, me chame aqui embaixo."))
        T["dac"] = {"nome": "DAC", "passos": dac}
    # tarefas de verdade: a pessoa faz e o tour segue sozinho (comum/tour.js: faca + ate)
    TAREFAS = {("lista", "Monte a lista pelo menu"): ("digite <b>cirurgia</b> no campo <b>Demanda</b>, no menu, e escolha a demanda na lista.", "#docs li"),
               ("checklist", "Marque e gere pelo menu"): ("escolha uma demanda no menu (ex.: <b>auxílio-doença</b>).", "#docs li"),
               ("checklist", "A folha"): ("marque um documento como <b>entregue</b> (✓), na folha.", "#docs li.ok")}
    for t in T.values():
        for p in t["passos"]:
            x = TAREFAS.get((p["rota"], p["titulo"]))
            if x: p["faca"], p["ate"] = x
    return json.dumps(T, ensure_ascii=False)


def botoes(ferr):
    nomes = [("comecar", "Começando")] + ([("agendamento", "Agendamento")] if "lista" in ferr else []) + ([("dac", "DAC")] if "checklist" in ferr else [])
    return "".join(f'<button type="button" data-tour="{k}">{n}</button>' for k, n in nomes)


TUT = [
 (None, "Como navegar", """<ol><li>Na página inicial, cada cartão abre uma ferramenta.</li>
  <li>Dentro da ferramenta, os botões ficam no <b>menu ao lado</b>: <b>← Voltar</b> volta para a tela anterior e <b>Início</b> volta para a página inicial.</li>
  <li>Para ganhar espaço, esconda o menu no botão do alto dele (para trazer de volta, <b>Mostrar menu</b>). Prefere os botões em cima? <b>Passar o menu para cima</b>. A escolha vale para todas as ferramentas.</li>
  <li>Dúvida? Clique na <b>Têmis</b>, no canto de baixo da tela.</li></ol>"""),
 ("lista", "Documentos Necessários e Mensagem", """<ol><li>Em <b>Demanda</b>, comece a digitar (ex.: “auxílio”, “cirurgia”, “bolsa”) e escolha na lista.</li>
  <li>Informe o <b>dia</b> e o <b>horário</b> do atendimento e escolha o prazo: <b>PRAZO NORMAL</b> (30 dias) ou <b>PAJ URGENTE</b> (48 horas).</li>
  <li>Confira a folha: para tirar um item, clique no ×; para mudar o texto, clique nele e digite; para incluir, use <b>Acrescentar</b>.</li>
  <li>Clique no que quer: <b>TUDO</b>, <b>SÓ A LISTA</b>, <b>SÓ O FORMULÁRIO MÉDICO</b> ou <b>SÓ AS DECLARAÇÕES</b> (opcionais, com a explicação de quando usar cada uma). Uma janelinha pergunta: <b>imprimir</b> ou <b>baixar em PDF</b>.</li>
  <li>Para o WhatsApp: <b>GERAR MENSAGEM DO AGENDAMENTO</b>. A mensagem já sai copiada; cole junto com o PDF da lista.</li></ol>"""),
 ("semAtend", "PAJ sem Atendimento", """<ol><li>Escolha o que aconteceu: não compareceu, matéria estadual, trabalhista, só ajuda com serviço público, só dúvida, desistência ou já tem advogado(a).</li>
  <li>Complete os campos, se houver (as datas têm o botão de calendário).</li>
  <li>Clique em <b>GERAR NARRATIVA</b>, na barra de baixo. O texto é copiado sozinho.</li>
  <li>No SIS-DPU, entre no PAJ, clique em <b>Editar narrativa</b>, cole (Ctrl+V) e salve.</li></ol>"""),
 ("checklist", "Checklist de Documentos", """<ol><li>Escolha a <b>demanda</b> e o prazo. Se a pessoa não sabe ler, marque <b>ASSISTIDO ANALFABETO</b>.</li>
  <li>Na folha, marque o que já foi entregue e o que não se aplica.</li>
  <li><b>GERAR LISTA – IMPRIMIR</b> imprime só o que falta, em 1 folha; <b>SALVAR EM PDF</b> cria o PDF direto. <b>TEXTOS AUTOMÁTICOS</b> traz a mensagem do WhatsApp e os textos do SIS-DPU.</li>
  <li>Os formulários da demanda aparecem no menu: marque e escolha <b>PREENCHER</b>, <b>BAIXAR</b> ou <b>IMPRIMIR</b>.</li></ol>"""),
 ("central", "Central de Formulários e Preenchimento", """<ol><li>Marque os formulários (dá para procurar pelo nome).</li>
  <li><b>PREENCHER</b>: digite as informações no menu ao lado; cada uma vai para todos os formulários que a pedem, e a prévia se atualiza. Depois, <b>GERAR OS FORMULÁRIOS</b> e <b>BAIXAR</b>. Nada fica guardado.</li>
  <li><b>BAIXAR PDF</b> ou <b>BAIXAR WORD</b>, <b>IMPRIMIR</b> ou <b>CRIAR MENSAGEM</b> (com as instruções para o assistido).</li>
  <li><b>GERAR FORMULÁRIO DE RENDA</b>: responda às perguntas e o formulário sai pronto.</li></ol>"""),
 ("narrativas", "Narrativas", """<ol><li>Escolha a demanda e, se houver abas, o modelo que corresponde ao caso (na dúvida, <b>Outros casos › Casos diversos</b>).</li>
  <li>Responda às perguntas; o que ficar sem resposta é avisado.</li>
  <li><b>GERAR NARRATIVA</b>, na barra de baixo, monta e copia o texto para o SIS-DPU.</li></ol>"""),
 (None, "Impressão", """<ul><li>Para salvar em PDF e mandar pelo WhatsApp: na tela de impressão, em <b>Destino</b>, escolha <b>Salvar como PDF</b>.</li>
  <li>Saiu data ou endereço do arquivo nos cantos? Abra <b>Mais definições</b> e desmarque <b>Cabeçalhos e rodapés</b>.</li>
  <li>Use o Google Chrome ou o Microsoft Edge atualizados.</li></ul>"""),
 (None, "Privacidade", """<ul><li>Funciona <b>sem internet</b>. Nada do que é digitado sai do computador.</li>
  <li>Só ficam guardadas neste computador a sua assinatura (nome e cargo) e a escolha do menu. Formulários, listas e narrativas não ficam guardados.</li></ul>"""),
]


def tutoriais(ferr):
    partes = [f'<article class="tutT"><h2>{t}</h2>{h}</article>' for req, t, h in TUT if req is None or req in ferr]
    return "".join(partes)

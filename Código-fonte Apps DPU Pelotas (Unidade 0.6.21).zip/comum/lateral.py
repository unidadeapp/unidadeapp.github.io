# Menu lateral (ou em cima) das ferramentas: comum ao Unidade e aos apps Térreo.
# Os controles de cada ferramenta ficam num menu fixo do lado esquerdo (pode ser escondido) ou, se a pessoa preferir, em cima
# (botão "Passar o menu para cima" / "Passar o menu para o lado"; a escolha vale para todas as ferramentas e fica guardada).
# Mensagens para a página principal: {nav:"voltar"|"inicio"}, {lado:true|false}, {layout:"lado"|"cima"}.
# A página principal pode mandar {titulo:"..."} para trocar o nome da ferramenta no menu (o Assistente tem várias telas).
# Uma ferramenta pode definir window.dpuVoltar(): se devolver true, o "← Voltar" ficou resolvido dentro dela.

import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
from tema import CSS_FERR   # modo escuro: a página principal escurece tudo; aqui as fotos, PDFs e a folha voltam ao normal

ICONE = ('<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3" fill="none" stroke="currentColor" stroke-width="2"/>'
         '<path d="M9 4v16" stroke="currentColor" stroke-width="2"/><path d="M5.5 8h1.5M5.5 11h1.5M5.5 14h1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>')
ICONE_CIMA = ('<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3" fill="none" stroke="currentColor" stroke-width="2"/>'
              '<path d="M3 10h18" stroke="currentColor" stroke-width="2"/><path d="M6.5 7h3M11.5 7h3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>')

CSS = """<style id="ladoCss">
  :root { --lw: 380px; }
  #lado { position:fixed; left:0; top:0; bottom:0; width:var(--lw); background:#fff; border-right:1px solid #dde5d8; box-shadow:2px 0 12px rgba(0,0,0,.06);
          z-index:40; display:flex; flex-direction:column; font-family:"Segoe UI", Calibri, Carlito, Arial, sans-serif; }
  body.comLado { padding-left:var(--lw); }
  @media screen { body.comLado { transition:padding-left .2s ease; } #lado { transition:transform .2s ease; } }
  body.comLado.recolhido { padding-left:0; }
  body.recolhido #lado { transform:translateX(-102%); box-shadow:none; }
  #lado .cab { display:flex; align-items:center; gap:10px; padding:12px 12px 12px 18px; border-bottom:1px solid #e5ebe1; }
  #lado .ladoMarca, #topoDac .ladoMarca { flex:1; min-width:0; text-align:left; font-size:12px; font-weight:800; letter-spacing:.08em; color:#2f6a1f; line-height:1.3; }
  #lado .ladoMarca small, #topoDac .ladoMarca small { display:block; font-weight:600; letter-spacing:.02em; color:#7a8276; font-size:11.5px; }
  .ladoBt { height:36px; min-width:36px; border-radius:9px; border:1.5px solid #cfdcc8; background:#fff; color:#2f6a1f; display:inline-flex; align-items:center; justify-content:center; gap:8px; cursor:pointer; padding:0 8px; font-family:"Segoe UI", Calibri, Carlito, Arial, sans-serif; font-weight:700; font-size:14px; }
  .ladoBt:hover { background:#eef6ea; border-color:#3f7f2a; }
  #lado .nav { display:flex; gap:8px; padding:10px 18px 0; }
  #lado .nav button, #topoDac .navC button { flex:1; border:1.5px solid #3f7f2a; background:#fff; color:#2f6a1f; border-radius:9px; padding:8px 10px; font:inherit; font-weight:700; font-size:14px; cursor:pointer; }
  #lado .nav button:hover, #topoDac .navC button:hover { background:#eef6ea; }
  #lado .troca { padding:8px 18px 10px; border-bottom:1px solid #e5ebe1; }
  #lado .troca .ladoBt { width:100%; height:32px; font-size:13px; font-weight:600; color:#4b5d41; border-style:dashed; }
  #lado .troca { display:flex; flex-direction:column; gap:6px; }
  #lado .slot { flex:1; overflow-y:auto; padding:4px 18px 26px; }
  #lado .ladoAutor { flex:0 0 auto; padding:7px 18px 9px; font-size:11.5px; color:#8a8f87; border-top:1px solid #e6ebe2; background:#fafbf8; }
  #mostrarLado { position:fixed; left:14px; top:14px; z-index:41; display:none; box-shadow:0 2px 10px rgba(0,0,0,.15); padding:0 14px 0 10px; height:40px; }
  body.comLado.recolhido #mostrarLado { display:inline-flex; }
  /* menu em cima (layout antigo): só uma barra fina no alto, com Voltar, Início e a troca de volta */
  #topoDac { display:none; position:sticky; top:0; z-index:40; background:#fff; border-bottom:1px solid #dde5d8; box-shadow:0 2px 10px rgba(0,0,0,.06);
             font-family:"Segoe UI", Calibri, Carlito, Arial, sans-serif; }
  #topoDac .in { max-width:1240px; margin:0 auto; display:flex; align-items:center; gap:10px; padding:9px 18px; flex-wrap:wrap; }
  #topoDac .navC { display:flex; gap:8px; } #topoDac .navC button { flex:0 0 auto; padding:7px 14px; }
  body.emCima #topoDac { display:block; }
  body.emCima #lado, body.emCima #mostrarLado { display:none !important; }
  body.dacApp .voltarMenu, body.dacApp #voltarMenu, body.dacApp #fimMenu, body.dacApp .rodapeMenu { display:none !important; }
  .slot .ladoLinks { display:flex; flex-direction:column; gap:8px; margin-top:14px; }
  .slot .ladoLinks .tt { font-size:12px; font-weight:800; letter-spacing:.08em; color:#7a8276; margin-bottom:2px; }
  .slot .ladoLinks button { text-align:left; border:1.5px solid #cfdcc8; background:#fff; color:#2f6a1f; border-radius:9px; padding:9px 12px; font:inherit; font-family:"Segoe UI", Calibri, Carlito, Arial, sans-serif; font-weight:700; font-size:14px; cursor:pointer; }
  .slot .ladoLinks button:hover { background:#eef6ea; border-color:#3f7f2a; }
  body.emCima .ladoLinks { flex-direction:row; flex-wrap:wrap; margin:0; }
  body.emCima .ladoLinks .tt { display:none; }
  #lado::before, #topoDac::before { content:""; position:absolute; left:0; right:0; top:0; height:4px; background:linear-gradient(90deg, #4f9a2a 0%, #3f8f3a 45%, #00879a 100%); }
  #lado .cab { padding-top:16px; }
  @media screen { body.dacApp { padding-bottom:96px; } }  /* espaço para o botão da Têmis, no canto de baixo */
  @media print { #lado, #mostrarLado, #topoDac { display:none !important; } body.comLado { padding-left:0 !important; transition:none !important; } }
  @media (max-width: 900px) { :root { --lw: 320px; } }
__EXTRA__
</style>"""

JS = """<script>
(function () {  // menu lateral (ou em cima): os botões da ferramenta ficam sempre à vista
  const CH = "dpuDAC.ladoRecolhido", CL = "dpuDAC.layout";
  const pai = window.parent !== window ? window.parent : null;
  const lado = document.createElement("aside"); lado.id = "lado"; lado.className = "no-print ui";
  lado.innerHTML = '<div class="cab"><div class="ladoMarca">__MARCA__<small class="ladoNome">__NOME__</small></div>'
    + '<button type="button" class="ladoBt" id="recolherLado" title="Esconder o menu (dá mais espaço para a página)">__ICONE__</button></div>'
    + '<div class="nav"><button type="button" id="ladoVoltar" title="Volta para a tela anterior">← Voltar</button><button type="button" id="ladoInicio" title="Volta para a página inicial">Início</button></div>'
    + '<div class="troca"><button type="button" class="ladoBt" id="praCima" title="Põe os botões em cima da página (vale para todas as ferramentas)">__ICONE_CIMA__ Passar o menu para cima</button>'
    + '<button type="button" class="ladoBt temaF" id="ladoTema" title="Troca entre o modo claro e o modo escuro (vale para todo o app)">☾ Modo escuro</button></div>'
    + '<div class="slot" id="ladoSlot"></div><div class="ladoAutor">Desenvolvido por Pedro Tomkowski</div>';
  const mostrar = document.createElement("button"); mostrar.type = "button"; mostrar.id = "mostrarLado"; mostrar.className = "ladoBt no-print ui";
  mostrar.title = "Mostrar o menu com os botões"; mostrar.innerHTML = '__ICONE__ Mostrar menu';
  const topo = document.createElement("div"); topo.id = "topoDac"; topo.className = "no-print ui";
  topo.innerHTML = '<div class="in"><div class="ladoMarca">__MARCA__<small class="ladoNome">__NOME__</small></div>'
    + '<div class="navC"><button type="button" id="cimaVoltar" title="Volta para a tela anterior">← Voltar</button><button type="button" id="cimaInicio" title="Volta para a página inicial">Início</button></div>'
    + '<button type="button" class="ladoBt" id="praLado" title="Põe os botões num menu fixo do lado esquerdo (vale para todas as ferramentas)">__ICONE__ Passar o menu para o lado</button>'
    + '<button type="button" class="ladoBt temaF" id="cimaTema" title="Troca entre o modo claro e o modo escuro (vale para todo o app)">☾ Modo escuro</button></div>';
  document.body.prepend(lado, mostrar, topo);
  document.body.classList.add("dacApp");
  const slot = document.getElementById("ladoSlot");
  const movidos = [], ordem = [];  // o que vai para o menu lateral (e volta ao lugar de origem no menu em cima); ordem: tudo o que fica no menu
  function mover(el) { if (!el) return; movidos.push({ el, pai: el.parentNode, prox: el.nextSibling }); ordem.push(el); slot.appendChild(el); }
  function noMenu(el) { ordem.push(el); slot.appendChild(el); }
  function links(titulo, itens) {  // atalhos no menu: [["Texto", função], ...]
    const box = document.createElement("div"); box.className = "ladoLinks";
    if (titulo) { const t = document.createElement("div"); t.className = "tt"; t.textContent = titulo; box.appendChild(t); }
    itens.forEach(([t, f]) => { const b = document.createElement("button"); b.type = "button"; b.textContent = t; b.addEventListener("click", f); box.appendChild(b); });
    return box;
  }
__MONTAR__
  let modo = "lado";
  function layout(m, avisar) {
    modo = m === "cima" ? "cima" : "lado";
    const cima = modo === "cima";
    document.body.classList.toggle("emCima", cima); document.body.classList.toggle("comLado", !cima);
    if (cima) movidos.slice().reverse().forEach(x => x.pai.insertBefore(x.el, x.prox && x.prox.parentNode === x.pai ? x.prox : null));
    else ordem.forEach(el => slot.appendChild(el));
    try { localStorage.setItem(CL, modo); } catch (e) {}
    if (avisar && pai) pai.postMessage({ layout: modo }, "*");
    document.dispatchEvent(new CustomEvent("dacLayout", { detail: modo }));
    setTimeout(() => window.dispatchEvent(new Event("resize")), 220);
  }
  function recolher(r, avisar) {
    document.body.classList.toggle("recolhido", r);
    try { localStorage.setItem(CH, r ? "1" : ""); } catch (e) {}
    if (avisar && pai) pai.postMessage({ lado: r }, "*");
    setTimeout(() => window.dispatchEvent(new Event("resize")), 220);
  }
  let ini = false, iniL = "lado"; try { ini = localStorage.getItem(CH) === "1"; iniL = localStorage.getItem(CL) || "lado"; } catch (e) {}
  layout(window.dpuLayoutInicial || iniL, false); recolher(ini, false);
  document.getElementById("recolherLado").addEventListener("click", () => recolher(true, true));
  mostrar.addEventListener("click", () => recolher(false, true));
  document.getElementById("praCima").addEventListener("click", () => layout("cima", true));
  document.getElementById("praLado").addEventListener("click", () => layout("lado", true));
  /* modo escuro: quem escurece é a página principal; aqui só o botão e as fotos/PDFs/folha que voltam ao normal */
  document.querySelectorAll(".temaF").forEach(b => { if (!pai) b.hidden = true; b.addEventListener("click", () => { if (pai) pai.postMessage({ temaTrocar: true }, "*"); }); });
  window.addEventListener("message", e => {
    const t = e.data && e.data.tema; if (!t) return;
    document.documentElement.classList.toggle("escuroPai", t === "escuro");
    document.querySelectorAll(".temaF").forEach(b => { b.textContent = t === "escuro" ? "☀ Modo claro" : "☾ Modo escuro"; });
  });
  if (pai) pai.postMessage({ temaPergunta: true }, "*");
  const nav = d => { if (d === "voltar" && typeof window.dpuVoltar === "function" && window.dpuVoltar()) return; if (pai) pai.postMessage({ nav: d }, "*"); };
  ["ladoVoltar", "cimaVoltar"].forEach(id => document.getElementById(id).addEventListener("click", () => nav("voltar")));
  ["ladoInicio", "cimaInicio"].forEach(id => document.getElementById(id).addEventListener("click", () => nav("inicio")));
  window.addEventListener("message", e => {
    if (e.data && typeof e.data.lado === "boolean") recolher(e.data.lado, false);
    if (e.data && (e.data.layout === "lado" || e.data.layout === "cima") && e.data.layout !== modo) layout(e.data.layout, false);
    if (e.data && typeof e.data.titulo === "string") document.querySelectorAll(".ladoNome").forEach(s => { s.textContent = e.data.titulo; });
  });
})();
</script>"""

# ---------------- configuração de cada ferramenta: EXTRA (CSS) e MONTAR (o que vai para o menu)

# Checklist de Documentos / Gerador de Lista de Documentos Faltantes
CK = ("""  .slot .panel { max-width:none; margin:0; padding:12px 0 0; box-shadow:none; border-radius:0; background:transparent; }
  .slot .panel h1 { font-size:21px; margin:2px 0 4px; }
  .slot .panel .sub { font-size:13.5px; margin:0 0 10px; }
  .slot .row { flex-direction:column; align-items:stretch; }
  .slot .combo { flex:none; }
  .slot .acess small { font-size:12px; }
  .slot .gerar { font-size:18px; padding:12px 10px; }
  .slot .prazoSel button { padding:9px 12px; } .slot .prazoSel button b { font-size:14.5px; }
  .slot .fgrid { grid-template-columns:1fr; }
  .slot .acoes { flex-direction:column; align-items:stretch; }
  .slot .acoes .acao, .slot .acoes .ghost { width:100%; margin-left:0 !important; }
  .slot .acoes .cont { text-align:center; }
  .slot .rodape { justify-content:stretch; } .slot .rodape .ghost { width:100%; }
  .irTextos { width:100%; margin-top:10px; border:1.5px solid #3f7f2a; background:#fff; color:#2f6a1f; border-radius:10px; padding:10px; font:inherit; font-weight:700; font-size:14.5px; cursor:pointer; }
  .irTextos:hover { background:#eef6ea; }
  @media screen { body.comLado .sheet { margin-top:24px; } body.emCima .sheet { margin-top:8px; } }""",
"""  const panel = document.querySelector(".panel");
  mover(panel);
  const irT = document.createElement("button"); irT.type = "button"; irT.className = "irTextos"; irT.textContent = "TEXTOS AUTOMÁTICOS (WhatsApp e SIS-DPU) ↓";
  irT.addEventListener("click", () => { const m = document.getElementById("msgs"); if (m.style.display === "none") return; m.scrollIntoView({ behavior: "smooth", block: "start" }); });
  const g = document.getElementById("gmsg"); g.parentNode.insertBefore(irT, g.nextSibling);
  const vis = () => { irT.style.display = document.getElementById("msgs").style.display === "none" ? "none" : ""; };
  new MutationObserver(vis).observe(document.getElementById("msgs"), { attributes: true, attributeFilter: ["style"] }); vis();""")

# Central de Formulários
CE = ("""  .slot .ctrl { flex-direction:column; padding:12px 0 0; box-shadow:none; background:transparent; border-radius:0; }
  .slot .busca, .slot .acess, .slot .atalho { flex:none; }
  .slot .selTit { font-weight:800; color:#2f6a1f; font-size:14px; letter-spacing:.05em; margin:20px 0 6px; padding-top:14px; border-top:1px dashed #cfdcc8; }
  .slot .in { display:flex; flex-direction:column; align-items:stretch; gap:8px; }
  .slot .in .acao, .slot .in .b2 { width:100%; margin-left:0 !important; }
  .slot .in .cont { margin:0; }
  .slot .in .duo { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
  body.comLado .barraSel { display:none !important; }
  @media screen { body.comLado .wrap { padding-bottom:50px; } }""",
"""  mover(document.querySelector(".ctrl"));
  const t = document.createElement("div"); t.className = "selTit"; t.textContent = "FORMULÁRIOS MARCADOS"; noMenu(t);
  mover(document.querySelector(".barraSel .in"));""")

# Narrativas Avulsas (e PAJ sem Atendimento): só o "Como funciona" vai para o menu; os botões ficam na barra de baixo da página
NA = ("""  .slot .guia { margin:12px 0 10px; font-size:13.5px; }""",
"""  const st = document.querySelector('section.step[data-titulo="Narrativa"]');
  mover(st.querySelector(".guia"));""")

# Preenchimento de Formulários
PR = ("""  .slot .painelP { margin:12px 0 0; padding:0; box-shadow:none; background:transparent; border-radius:0; max-width:none; }
  .slot .painelP .cxs { grid-template-columns:1fr; }
  .slot .painelP h2 { font-size:19px; }""",
"""  mover(document.getElementById("painelP"));""")

# Documentos necessários (Agendamento), com a mensagem para o WhatsApp
LI = ("""  .slot .panel { max-width:none; margin:0; padding:12px 0 0; box-shadow:none; border-radius:0; background:transparent; }
  .slot .panel h1 { font-size:21px; margin:2px 0 4px; }
  .slot .panel p.sub { font-size:13.5px; margin:0 0 10px; }
  .slot .row { flex-direction:column; align-items:stretch; }
  .slot .combo { flex:none; }
  .slot .row label.f input { width:100%; }
  .slot .prazoSel button { padding:9px 12px; } .slot .prazoSel button b { font-size:14.5px; }
  .slot .grade { grid-template-columns:1fr !important; }
  .slot .decl { flex-direction:column; align-items:stretch; }
  .slot .decl .acao, .slot .decl .ghost { width:100%; margin-left:0 !important; flex:none; }
  .slot .msgAg .lin { flex-direction:column; align-items:stretch; } .slot .msgAg label.f, .slot .msgAg .acao { flex:none; }
  .slot .hint { font-size:12.5px; }
  @media screen { body.comLado .sheet { margin-top:24px; } body.emCima .sheet { margin-top:8px; } }""",
"""  mover(document.querySelector(".panel"));""")

# Assistente de Abertura de PAJ, Meus PAJs e Cadastrar PAJ (a lista das etapas vai para o menu)
AS = ("""  body.dacApp .top { display:none !important; }
  body.comLado .wrap { grid-template-columns:1fr; }
  body.comLado .embutido .wrap, body.comLado .wrap { margin-top:18px; }
  .slot nav#etapas { position:static; box-shadow:none; padding:12px 0 0; background:transparent; }
  .slot nav#etapas.foraAssist { display:none; }""",
"""  const et = document.getElementById("etapas");
  mover(et);
  const assist = document.getElementById("telaAssist");
  const vis = () => et.classList.toggle("foraAssist", assist.classList.contains("hide"));
  new MutationObserver(vis).observe(assist, { attributes: true, attributeFilter: ["class"] }); vis();
  window.dpuVoltar = () => {  // dentro de um PAJ de Meus PAJs, o Voltar volta para a lista
    if (!document.getElementById("telaPaj").classList.contains("hide")) { document.getElementById("voltarLista").click(); return true; }
    return false;
  };""")

# APRENDER (e Jurisprudências e Modelos, que abrem dentro dele)
AP = ("""  body.dacApp .rodape { display:none !important; }""",
"""  const atalhos = links("ATALHOS DO APRENDER", [["Início do Aprender", () => ir("inicio")], ["Jurisprudências Comuns e Úteis", () => ir("juris")],
    ["Glossário", () => ir("glossario")], ["Manual do Estagiário", () => ir("manual")], ["Modelos de peças", () => ir("modelos")]]);
  noMenu(atalhos);
  const modoOrig = window.abrirModo;  // aberto pelo setor DPS (Modelos, Jurisprudências): os atalhos são do setor DPS
  if (modoOrig) window.abrirModo = m => { modoOrig(m); atalhos.querySelector(".tt").textContent = m && m !== "inicio" ? "ATALHOS DO SETOR DPS" : "ATALHOS DO APRENDER"; };
  window.dpuVoltar = () => { voltar(); return true; };""")


def lateral(html, marca, nome, cfg):
    """Põe o menu lateral na página de uma ferramenta. marca: nome do app (em maiúsculas); nome: nome da ferramenta."""
    extra, montar = cfg
    css = CSS.replace("__EXTRA__", extra + CSS_FERR)
    js = (JS.replace("__MARCA__", marca).replace("__NOME__", nome).replace("__ICONE_CIMA__", ICONE_CIMA)
            .replace("__ICONE__", ICONE).replace("__MONTAR__", montar))
    assert html.count("</head>") >= 1
    html = html.replace("</head>", css + "\n</head>", 1)
    i = html.rfind("</body>"); assert i > 0
    return html[:i] + js + "\n" + html[i:]

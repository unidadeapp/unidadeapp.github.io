"use strict";
const $ = id => document.getElementById(id);
const SM_CHAVE = "dpuPelotas.salarioMinimo.v1";
const SM_PADRAO = { ano: 2026, valor: 1621 };  // salário mínimo de 2026 (Decreto nº 12.797/2025)
function lerSM() { try { const o = JSON.parse(localStorage.getItem(SM_CHAVE) || "null"); if (o && o.valor > 0 && o.ano > 2000) return o; } catch (e) {} return SM_PADRAO; }
let SMinfo = lerSM(), SM = SMinfo.valor;
let LIM_DESPESAS = 2 * SM;          // 2 salários mínimos: presunção de hipossuficiência (Res. CSDPU nº 240/2025)
const limTxt = () => "R$ " + LIM_DESPESAS.toLocaleString("pt-BR", { minimumFractionDigits: Number.isInteger(LIM_DESPESAS) ? 0 : 2, maximumFractionDigits: 2 });
const MESES = ["janeiro","fevereiro","março","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"];
const norm = s => (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[-\/().,%;:]+/g, " ");
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const txt = html => { const d = document.createElement("div"); d.innerHTML = html; return d.textContent; };
const dois = n => String(n).padStart(2, "0");
let HOJE = new Date();
setInterval(() => { HOJE = new Date(); }, 60000);
window.addEventListener("focus", () => { HOJE = new Date(); });
const hojeBR = () => `${dois(HOJE.getDate())}/${dois(HOJE.getMonth() + 1)}/${HOJE.getFullYear()}`;
const hojeExtenso = () => `${HOJE.getDate()} de ${MESES[HOJE.getMonth()]} de ${HOJE.getFullYear()}`;

/* ---------- dados fixos ---------- */
const GERAL = {
  cpf: "<b>RG (ou CNH) e CPF</b> de todas as pessoas do grupo familiar (para menores de idade que não têm RG, certidão de nascimento)",
  renda: "<b>Comprovante de renda</b> de todas as pessoas do grupo familiar. Para renda zero ou informal, <b>extratos bancários</b> de todas as contas dos últimos 3 meses",
  ctps: "<b>Carteira de Trabalho</b> de todas as pessoas do grupo familiar: digital (no aplicativo, opção “Enviar Carteira de Trabalho” e aba “Outros contratos”, se houver) ou física (página de qualificação civil, todos os contratos de trabalho e a página em branco seguinte ao último contrato)",
  ctpsPrev: "<b>Carteira de Trabalho</b> de todas as pessoas do grupo familiar: digital (no aplicativo, opção “Enviar Carteira de Trabalho” e aba “Outros contratos”, se houver) ou física (todas as páginas)",
  residencia: "<b>Comprovante de residência</b> em nome próprio ou com declaração do titular do comprovante",
  cadunico: "<b>Comprovante de inscrição no Cadastro Único (CadÚnico)</b>, se a família for inscrita"
};
const SE_FOR = [
  "<b>Declaração de Imposto de Renda</b> mais recente, com o recibo de entrega, se alguém do grupo familiar declara",
  "<b>Certificado do MEI ou contrato social</b> e a <b>última declaração de faturamento</b>, se alguém do grupo familiar é MEI ou tem empresa",
  "<b>Termo de curatela</b>, se o(a) assistido(a) tem curador(a)",
  "<b>Notas fiscais ou recibos de gastos extraordinários com saúde</b> (consultas, psicólogo(a), fisioterapia, procedimentos essenciais e medicamentos), se a renda do grupo familiar passa de 2 salários mínimos, limite da Resolução nº 240/2025 da Defensoria Pública da União para a assistência gratuita. Esses gastos podem ser descontados da renda"
];
const APELIDOS = {
  "Auxílio-doença": "beneficio por incapacidade temporaria afastamento doenca",
  "Aposentadoria por invalidez": "beneficio por incapacidade permanente aposentadoria por incapacidade",
  "Benefício assistencial (BPC/LOAS) à pessoa com deficiência": "deficiente amparo assistencial loas bpc",
  "Benefício assistencial (BPC/LOAS) à pessoa idosa": "idoso amparo assistencial loas bpc",
  "Adicional de 25% na aposentadoria": "acrescimo grande invalidez cuidador",
  "Pensão por morte": "falecimento obito viuva viuvo",
  "Aposentadoria por idade ou por tempo de contribuição": "aposentadoria urbana",
  "Aposentadoria rural": "agricultor segurado especial trabalhador rural",
  "Seguro-defeso (pescador artesanal)": "pesca",
  "Salário-maternidade": "gestante licenca maternidade parto",
  "Auxílio-reclusão": "preso prisao",
  "Alvará judicial": "valores residuais saque falecido",
  "Financiamento estudantil": "fies",
  "Financiamento habitacional": "minha casa minha vida caixa casa propria",
  "Ingresso em instituição de ensino": "matricula universidade cotas sisu",
  "Descontos indevidos em benefício do INSS": "associacao desconto",
  "Empréstimo bancário": "consignado",
  "Permanência no país (refúgio)": "estrangeiro migrante refugiado residencia",
  "FGTS e PIS": "saque fgts pis pasep",
  "Reintegração ou defesa da posse": "despejo ocupacao terreno",
  "Seguro-desemprego (com empresa no nome do assistido)": "cnpj mei empresa",
  "Seguro DPVAT (acidentes até 14/11/2023)": "spvat acidente transito",
  "Medicamentos": "remedio farmacia",
  "Tratamento oncológico": "cancer oncologia quimioterapia radioterapia",
  "Tratamento fora do domicílio (TFD)": "outra cidade viagem",
};
const BENS = ["geladeira","fogão","máquina de lavar roupas","micro-ondas","forno elétrico","máquina de secar roupas","televisão","DVD player","home theater",
  "Blu-ray player","ar-condicionado","freezer","aquecedor elétrico","aquecedor a gás","aparelho de som","chuveiro elétrico","chuveiro a gás","computador",
  "notebook","impressora","scanner","multifuncional","console de videogame","telefone fixo","celular","smartphone","tablet"];
const SERVICOS = ["água","luz","gás","TV por assinatura","internet","monitoramento eletrônico","diarista","empregada(o) doméstica(o)","babá","cuidadora de idosos"];
const PERGUNTAS = [  // q: pergunta; det: o que escrever quando a resposta abre o campo; ops: caixinhas
  { q: "Alguém declara anualmente imposto de renda?", det: "Quem?", nota: "Caso positivo, juntar a declaração completa." },
  { q: "Algum membro do grupo familiar percebe pensão alimentícia?", det: "Qual o valor?" },
  { q: "Algum membro do grupo familiar percebe Bolsa Família, Benefício Assistencial (LOAS) ou participa de algum outro programa social?", det: "Quem e qual?" },
  { q: "O imóvel onde residem é próprio, alugado ou cedido?", det: "Qual o valor do imóvel ou do aluguel? (se for cedido, por quem)", ops: ["Próprio", "Alugado", "Cedido", "Outro"], abre: ["Próprio", "Alugado", "Cedido", "Outro"], naoSabe: "Não sabe o valor." },
  { q: "Algum dos membros do grupo familiar possui carro próprio?", det: "Qual o modelo e o ano?" },
  { q: "Algum membro do grupo familiar possui plano de saúde particular?", det: "Quem? Qual o valor mensal?" },
  { q: "Algum membro do grupo familiar estuda em escola ou universidade particular?", det: "Quem? Qual o valor da mensalidade?" },
  { q: "Algum membro do grupo familiar possui bem imóvel diverso daquele informado como de residência?", det: "Onde é localizado? Qual o valor? A que se destina? (se alugado, qual é o valor obtido?)" },
  { q: "Algum membro do grupo familiar é sócio/proprietário de empresa?", det: "Quem?" },
].map(p => ({ ops: ["Sim", "Não"], abre: ["Sim"], ...p }));
const REP_COND = ["PAI", "MÃE", "CURADOR", "TUTOR", "OUTRO"];
const TERMO = new Set(["Descontos indevidos em benefício do INSS", "Empréstimo bancário"]);
const ITEM_NOME = { renda: "o comprovante de renda", ctps: "a Carteira de Trabalho", residencia: "o comprovante de residência", medico: "o formulário médico" };

/* ---------- estado (só na memória desta página) ---------- */
const S = {
  est: "", nome: "", cpf: "", analf: false, tel: "", paj: "", mae: "", nasc: "",
  endRua: "", endNum: "", endComp: "", endBairro: "", endCidade: "", endCep: "",
  dem: null,
  n: { membros: [{}], prio: [], cids: [], sozinho: false, extras: [] }, nv: {}, narrVar: {}, prazo: "30 dias",
  narrTexto: "", narrHtml: "", narrId: "",
  ck: null,
  rf: null,
  fOff: new Set(), fOn: new Set(),
  modo: "", msgEditada: false,
};
let saindo = false;
const EMBUTIDO = window.parent !== window;  // dentro do app Unidade

/* ---------- utilidades de valores ---------- */
function dinheiro(v) {  // "1.621,00" | "1621" | "R$ 300" → número; vazio ou inválido → NaN
  let s = String(v ?? "").replace(/[^\d,.]/g, "");
  if (!s) return NaN;
  if (s.includes(",")) s = s.replace(/\./g, "").replace(",", ".");
  else if ((s.match(/\./g) || []).length > 1 || /\.\d{3}$/.test(s)) s = s.replace(/\./g, "");
  const n = parseFloat(s);
  return isNaN(n) ? NaN : n;
}
const brl = n => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }).replace(/\u00a0/g, " ");
const brlNum = n => n.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
function mascaraCPF(v) {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 3) return d;
  if (d.length <= 6) return d.slice(0, 3) + "." + d.slice(3);
  if (d.length <= 9) return d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6);
  return d.slice(0, 3) + "." + d.slice(3, 6) + "." + d.slice(6, 9) + "-" + d.slice(9);
}
function cpfValido(v) {
  const d = v.replace(/\D/g, "");
  if (d.length !== 11 || /^(\d)\1{10}$/.test(d)) return false;
  for (let t = 9; t < 11; t++) {
    let s = 0; for (let i = 0; i < t; i++) s += +d[i] * (t + 1 - i);
    if (((s * 10) % 11) % 10 !== +d[t]) return false;
  }
  return true;
}
const mascaraCEP = v => { const d = v.replace(/\D/g, "").slice(0, 8); return d.length > 5 ? d.slice(0, 5) + "-" + d.slice(5) : d; };
function enderecoCompleto() {
  const rua = S.endRua.trim(); if (!rua) return "";
  const num = S.endNum.trim();
  return [rua + (num ? `, nº ${num}` : ", s/nº"), S.endComp.trim(), S.endBairro.trim(), S.endCidade.trim(), S.endCep.trim() ? "CEP " + S.endCep.trim() : ""]
    .filter(Boolean).join(", ");
}
function avisoCampo(inp, texto) {  // mensagem vermelha logo abaixo do campo (texto vazio apaga)
  if (!inp) return;
  inp.classList.toggle("invalido", !!texto);
  let m = inp.nextElementSibling && inp.nextElementSibling.classList.contains("msgCampo") ? inp.nextElementSibling : null;
  if (texto && !m) { m = document.createElement("span"); m.className = "msgCampo"; inp.insertAdjacentElement("afterend", m); }
  if (m) { if (texto) m.textContent = texto; else m.remove(); }
}
const marcarValor = inp => avisoCampo(inp, inp.value.trim() && isNaN(dinheiro(inp.value)) ? "Valor não reconhecido: digite só números (ex.: 1.500,00)." : "");
const noFuturo = iso => !!iso && new Date(iso + "T12:00:00") > HOJE;
const PAJ_RE = /^\d{4}\/025-\d{1,5}$/;
function normalizarPAJ(v) {
  const m = v.trim().match(/^(\d{4})\D*0?25\D*(\d{1,5})$/);
  return m ? `${m[1]}/025-${m[2]}` : v.trim();
}
function idade() {
  if (!S.nasc) return null;
  const n = new Date(S.nasc + "T12:00:00"); if (isNaN(n)) return null;
  let a = HOJE.getFullYear() - n.getFullYear();
  if (HOJE.getMonth() < n.getMonth() || (HOJE.getMonth() === n.getMonth() && HOJE.getDate() < n.getDate())) a--;
  return a >= 0 && a < 130 ? a : null;
}
const nascBR = () => S.nasc ? S.nasc.split("-").reverse().join("/") : "";
const primeiroNome = () => { const p = S.nome.trim().split(/\s+/)[0] || ""; return p ? p.charAt(0).toUpperCase() + p.slice(1).toLowerCase() : ""; };
const nomeArq = s => s.replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, " ").trim();
const nomeAssist = () => S.nome.trim() || "ASSISTIDO";
function curto(html) {  // nome curto de um item da lista (o trecho em negrito)
  const m = html.match(/<b>(.+?)<\/b>/);
  if (m) return txt(m[1]);
  const t = txt(html); return t.length > 70 ? t.slice(0, 67).replace(/\s+\S*$/, "") + "…" : t;
}
function copiaDireta(texto, html) {  // copia na hora do clique (funciona com o arquivo aberto do computador)
  let ok = false;
  const h = e => { e.clipboardData.setData("text/plain", texto); if (html) e.clipboardData.setData("text/html", html); e.preventDefault(); ok = true; };
  document.addEventListener("copy", h);
  try { document.execCommand("copy"); } catch (e) {}
  document.removeEventListener("copy", h);
  return ok;
}
function avisoCopia(el, ok) {
  if (!el) return;
  el.textContent = ok ? "Copiado!" : "Não foi possível copiar automaticamente: selecione o texto e use Ctrl+C."; el.className = ok ? "ok" : "erro";
  clearTimeout(el._t); el._t = setTimeout(() => { el.textContent = ""; }, 4000);
}
async function copiar(texto, el) {
  let ok = copiaDireta(texto);
  if (!ok) { try { await Promise.race([navigator.clipboard.writeText(texto), new Promise((_, r) => setTimeout(r, 1500))]); ok = true; } catch (e) {} }
  avisoCopia(el, ok);
  return ok;
}

/* ---------- navegação entre etapas ---------- */
const steps = [...document.querySelectorAll("section.step")];
const nav = $("etapas");
const navBtns = steps.map((s, i) => {
  const b = document.createElement("button");
  b.innerHTML = `<span class="n">${i === 0 ? "•" : i}</span><span>${esc(s.dataset.titulo)}</span>`;
  b.addEventListener("click", () => ir(i));
  nav.appendChild(b); return b;
});
let atual = 0;
const ENTRAR = {};
const CONFERIR_AO_SAIR = [4, 9];  // etapas com caixinhas que precisam ser marcadas antes de seguir
function semMarcar() {
  const st = steps[atual], itens = [];
  if (atual === 9 && !S.modo) { itens.push("Atendimento PRESENCIAL ou ONLINE (escolha um)"); st.querySelectorAll(".modo").forEach(m => m.classList.add("faltaMarcar")); }
  st.querySelectorAll("label.cx").forEach(l => {
    if (l.offsetParent === null || l.querySelector("input").checked) return;
    l.classList.add("faltaMarcar"); itens.push(l.textContent.trim());
  });
  return itens;
}
function ir(i, confirmado) {
  if (i < 0 || i >= steps.length) return;
  if (!confirmado && i > atual && CONFERIR_AO_SAIR.includes(atual)) {
    const f = semMarcar();
    if (f.length) {
      modal("Tem certeza?", `<p>Tem certeza que deseja ir para a próxima etapa? ${f.length > 1 ? "Estas opções não estão marcadas" : "Esta opção não está marcada"}:</p><ul>${f.map(x => `<li>${esc(x)}</li>`).join("")}</ul>`,
        () => ir(i, true), { sim: "IR MESMO ASSIM", nao: "Voltar e marcar" });
      return;
    }
  }
  if (atual === 0 && i > 0) checarInicio();
  steps[atual].classList.remove("on");
  atual = i; steps[i].classList.add("on");
  navBtns.forEach((b, j) => { b.classList.toggle("atual", j === i); if (j === i) b.classList.add("visto"); });
  $("voltar").style.visibility = i === 0 ? "hidden" : "visible";
  if (i < steps.length - 1) { $("proximo").style.display = ""; $("proximo").textContent = `Próximo: etapa ${i + 1} – ${steps[i + 1].dataset.titulo} →`; }
  else $("proximo").style.display = "none";
  if (ENTRAR[i]) ENTRAR[i]();
  window.scrollTo(0, 0);
}
$("voltar").addEventListener("click", () => ir(atual - 1));
document.addEventListener("change", e => { const l = e.target.closest && e.target.closest("label.cx"); if (l && e.target.checked) l.classList.remove("faltaMarcar"); });
document.addEventListener("click", e => { const m = e.target.closest && e.target.closest(".modo"); if (m) document.querySelectorAll(".modo").forEach(x => x.classList.remove("faltaMarcar")); });
$("proximo").addEventListener("click", () => ir(atual + 1));
function checarInicio() {
  steps[0].querySelectorAll('[data-s="est"], [data-s="nome"], [data-s="cpf"]').forEach(el => { el.style.borderColor = el.value.trim() ? "" : "#d9534f"; });
}

/* ---------- listas de sugestões que abrem ao clicar no campo (motivo do indeferimento, fonte de renda, vínculo, hospital) ---------- */
(function () {
  const box = document.createElement("div"); box.className = "lista flut"; document.body.appendChild(box);
  let alvo = null, ops = [], ativo = -1, calado = false;
  const opcoes = id => { const d = document.getElementById(id); return d ? [...d.options].map(o => o.value) : []; };
  function posicionar() { const r = alvo.getBoundingClientRect(); box.style.left = r.left + "px"; box.style.top = (r.bottom + 4) + "px"; box.style.width = Math.max(r.width, 280) + "px"; }
  function mostrar() {
    if (!alvo || calado) return;
    const q = norm(alvo.value.trim()), todas = opcoes(alvo.dataset.lista);
    ops = q ? todas.filter(v => norm(v).includes(q)) : todas;
    if (ops.length === 1 && norm(ops[0]) === q) ops = todas;  // já escolhido: mostra todas de novo
    ativo = -1;
    box.innerHTML = ops.map((v, j) => `<div class="opt" data-j="${j}">${esc(v)}</div>`).join("");
    box.classList.toggle("open", ops.length > 0); posicionar();
  }
  const fechar = () => box.classList.remove("open");
  function escolher(v) {
    calado = true; alvo.value = v;
    alvo.dispatchEvent(new Event("input", { bubbles: true })); alvo.dispatchEvent(new Event("change", { bubbles: true }));
    calado = false; fechar();
  }
  box.addEventListener("mousedown", e => { const o = e.target.closest(".opt"); if (!o) return; e.preventDefault(); escolher(ops[+o.dataset.j]); });
  document.addEventListener("focusin", e => {
    const el = e.target; if (!(el instanceof HTMLInputElement)) return;
    if (el.hasAttribute("list")) { el.dataset.lista = el.getAttribute("list"); el.removeAttribute("list"); }
    if (!el.dataset.lista) return;
    alvo = el; mostrar();
  });
  document.addEventListener("mousedown", e => { if (alvo && e.target === alvo && !box.classList.contains("open")) setTimeout(mostrar, 0); });
  document.addEventListener("input", e => { if (e.target === alvo) mostrar(); });
  document.addEventListener("focusout", e => { if (e.target === alvo) setTimeout(() => { if (document.activeElement !== alvo) { fechar(); alvo = null; } }, 150); });
  document.addEventListener("keydown", e => {
    if (!alvo || e.target !== alvo || !box.classList.contains("open") || !ops.length) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault(); ativo = (ativo + (e.key === "ArrowDown" ? 1 : -1) + ops.length) % ops.length;
      box.querySelectorAll(".opt").forEach((o, j) => o.classList.toggle("act", j === ativo)); box.children[ativo].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter" && ativo >= 0) { e.preventDefault(); escolher(ops[ativo]); }
    else if (e.key === "Escape" || e.key === "Tab") fechar();
  });
  window.addEventListener("scroll", () => { if (alvo && box.classList.contains("open")) posicionar(); }, true);
  window.addEventListener("resize", () => { if (alvo && box.classList.contains("open")) posicionar(); });
})();

/* ---------- campos ligados ao estado ---------- */
function chips() {
  const c = [];
  c.push(S.nome.trim() ? esc(S.nome.trim()) : "<i>assistido(a) não informado(a)</i>");
  if (S.cpf) c.push("CPF " + esc(S.cpf));
  if (S.paj) c.push("PAJ " + esc(S.paj));
  if (S.dem) c.push(esc(S.dem.nome.length > 34 ? S.dem.nome.slice(0, 32) + "…" : S.dem.nome));
  if (S.analf) c.push("ANALFABETO(A)");
  $("chips").innerHTML = c.map(x => `<span class="chip">${x}</span>`).join("");
}
function aoMudar(k) {
  if (k === "cpf") $("cpfErro").textContent = S.cpf.replace(/\D/g, "").length === 11 && !cpfValido(S.cpf) ? "Este CPF não é válido: confira os números." : "";
  if (k === "paj") $("pajErro").textContent = S.paj && !PAJ_RE.test(S.paj) ? "Formato esperado: ANO/025-NÚMERO, por exemplo 2026/025-1234." : "";
  if (k === "nasc") { sugerirPrioridade(); document.querySelectorAll('[data-s="nasc"]').forEach(el => avisoCampo(el, noFuturo(S.nasc) ? "Esta data está no futuro: confira." : "")); }
  if (k === "mae" || k === "nasc") previaNarrativa();
  chips();
}
document.querySelectorAll("[data-s]").forEach(el => {
  const k = el.dataset.s;
  const ev = el.type === "checkbox" ? "change" : "input";
  el.addEventListener(ev, () => {
    let v = el.type === "checkbox" ? el.checked : el.value;
    if (el.dataset.mask === "cpf") { v = mascaraCPF(v); el.value = v; }
    if (el.dataset.mask === "cep") { v = mascaraCEP(v); el.value = v; }
    S[k] = v;
    document.querySelectorAll(`[data-s="${k}"]`).forEach(o => { if (o !== el) { if (o.type === "checkbox") o.checked = v; else o.value = v; } });
    aoMudar(k);
  });
  if (k === "paj") el.addEventListener("blur", () => {
    const v = normalizarPAJ(el.value); S.paj = v;
    document.querySelectorAll('[data-s="paj"]').forEach(o => { o.value = v; }); aoMudar("paj");
  });
});

/* CEP: busca rua, bairro e cidade (ViaCEP; se falhar, BrasilAPI). Só o CEP sai do computador. */
const autoEnd = {};  // o que veio do último CEP, para não apagar o que foi digitado à mão
function porCampo(k, v) {  // troca o que veio do CEP anterior (ou estava vazio); o que foi digitado à mão fica
  const atual = k === "endCidade" ? S.endCidade : S[k];
  if (atual && atual !== autoEnd[k]) return;
  autoEnd[k] = v;
  if (k === "endCidade") { window.definirCidade(v); return; }
  S[k] = v; document.querySelectorAll(`[data-s="${k}"]`).forEach(el => { el.value = v; });
}
async function pegarJSON(url) {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), 5000);
  try { const r = await fetch(url, { signal: c.signal }); if (!r.ok) throw new Error(r.status === 404 ? "naoachou" : "http"); return await r.json(); }
  finally { clearTimeout(t); }
}
let cepUltimo = "";
async function buscarCEP() {
  const d = S.endCep.replace(/\D/g, ""), msg = $("cepMsg");
  if (d.length !== 8 || d === cepUltimo) return;
  cepUltimo = d;
  msg.className = ""; msg.style.color = "var(--gray)"; msg.textContent = "Buscando o endereço do CEP…";
  let e = null, naoAchou = false;
  try {
    const j = await pegarJSON(`https://viacep.com.br/ws/${d}/json/`);
    if (j.erro) naoAchou = true; else e = { rua: j.logradouro, bairro: j.bairro, cidade: j.localidade, uf: j.uf };
  } catch (x) {
    try { const j = await pegarJSON(`https://brasilapi.com.br/api/cep/v1/${d}`); e = { rua: j.street, bairro: j.neighborhood, cidade: j.city, uf: j.state }; }
    catch (y) { naoAchou = naoAchou || y.message === "naoachou"; }
  }
  if (S.endCep.replace(/\D/g, "") !== d) return;  // o CEP mudou enquanto buscava
  msg.style.color = "";
  if (e && e.cidade) {
    porCampo("endRua", (e.rua || "").trim()); porCampo("endBairro", (e.bairro || "").trim()); porCampo("endCidade", `${e.cidade}/${e.uf}`);
    msg.className = "ok";
    msg.textContent = e.rua ? "Endereço encontrado: confira e complete o número." : "Este CEP é da cidade inteira: preencha a rua e o bairro.";
  } else {
    msg.className = "erro";
    msg.textContent = naoAchou ? "CEP não encontrado: confira o número ou preencha o endereço à mão." : "Sem conexão com a busca de CEP: preencha o endereço à mão.";
    cepUltimo = "";
  }
}
$("cepInp").addEventListener("input", () => { if (S.endCep.replace(/\D/g, "").length === 8) buscarCEP(); else { $("cepMsg").textContent = ""; cepUltimo = ""; } });

/* cidade: municípios do RS primeiro; aceita qualquer cidade do país, e o texto livre continua valendo */
let CIDADES = null;
const baseCidades = () => CIDADES || (CIDADES = CIDADES_TXT.split("\n").map(l => { const [n, u] = l.split("|"); return { n, u, k: norm(n).replace(/\s+/g, " ").trim() }; }));
function buscarCidades(q) {
  const t = norm(q.replace(/\/\s*[a-z]{2}\s*$/i, "")).replace(/\s+/g, " ").trim(); if (!t) return [];
  const uf = (q.match(/\/\s*([a-z]{2})\s*$/i) || [])[1];
  const L = baseCidades().filter(c => (!uf || c.u === uf.toUpperCase()) && c.k.includes(t));
  return L.map(c => [(c.k === t ? 0 : c.k.startsWith(t) ? 1 : 2) * 2 + (c.u === "RS" ? 0 : 1), c]).sort((a, b) => a[0] - b[0] || a[1].n.localeCompare(b[1].n)).slice(0, 40).map(a => a[1]);
}
(function () {
  const inp = $("cidadeInp"), lst = $("cidadeLista"); let res = [], ativo = 0;
  const definir = v => { S.endCidade = v; inp.value = v; };
  window.definirCidade = definir;
  inp.value = S.endCidade;
  function mostrar() {
    res = buscarCidades(inp.value); ativo = 0;
    lst.innerHTML = res.length ? res.map((c, j) => `<div class="opt${j === 0 ? " act" : ""}" data-j="${j}"><b>${esc(c.n)}</b> – ${c.u}</div>`).join("")
      : (inp.value.trim() ? '<div class="opt" style="color:var(--gray);cursor:default">Cidade não encontrada: pode escrever assim mesmo, no formato Cidade/UF.</div>' : "");
    lst.classList.toggle("open", !!inp.value.trim());
    lst.querySelectorAll(".opt[data-j]").forEach(o => o.addEventListener("mousedown", e => { e.preventDefault(); escolher(res[+o.dataset.j]); }));
  }
  const escolher = c => { if (c) definir(`${c.n}/${c.u}`); lst.classList.remove("open"); };
  inp.addEventListener("input", () => { S.endCidade = inp.value; mostrar(); });
  inp.addEventListener("blur", () => setTimeout(() => {
    lst.classList.remove("open");
    const v = inp.value.trim(); if (!v || /\/[A-Z]{2}$/.test(v)) return;
    const exatas = buscarCidades(v).filter(c => c.k === norm(v).replace(/\s+/g, " ").trim());
    if (exatas.length) escolher(exatas.find(c => c.u === "RS") || exatas[0]);  // "pelotas" vira "Pelotas/RS"
  }, 150));
  inp.addEventListener("keydown", e => {
    const os = [...lst.querySelectorAll(".opt[data-j]")];
    if ((e.key === "ArrowDown" || e.key === "ArrowUp") && os.length) {
      e.preventDefault(); ativo = (ativo + (e.key === "ArrowDown" ? 1 : -1) + os.length) % os.length;
      os.forEach((o, j) => o.classList.toggle("act", j === ativo)); os[ativo].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") { e.preventDefault(); if (res.length) escolher(res[ativo]); }
    else if (e.key === "Escape") lst.classList.remove("open");
  });
})();

/* ---------- caixinhas de escolha única: clicar de novo desmarca ---------- */
document.addEventListener("pointerdown", e => {
  const lb = e.target.closest && e.target.closest("label");
  const r = e.target.matches && e.target.matches('input[type="radio"]') ? e.target : (lb && lb.querySelector('input[type="radio"]'));
  if (r && !r.hasAttribute("data-fixo")) r._estava = r.checked;
}, true);
document.addEventListener("click", e => {
  const r = e.target;
  if (!(r instanceof HTMLInputElement) || r.type !== "radio" || r.hasAttribute("data-fixo")) return;
  if (r._estava) { r.checked = false; r._estava = false; r.dispatchEvent(new Event("change", { bubbles: true })); }
}, true);

/* ---------- escolha da demanda (etapas 3 e 6) ---------- */
function combo(inp, lst, escolher, atualNome) {
  let ativo = -1;
  const opts = () => [...lst.querySelectorAll(".opt")];
  function filtrar() {
    const q = norm(inp.value).trim().split(/\s+/).filter(Boolean);
    lst.innerHTML = ""; let area = "";
    DEMANDAS.forEach((d, i) => {
      const alvo = norm(d.nome + " " + (APELIDOS[d.nome] || "") + " " + d.area);
      if (q.length && !q.every(w => alvo.includes(w))) return;
      if (d.area !== area) { area = d.area; const g = document.createElement("div"); g.className = "grp"; g.textContent = area; lst.appendChild(g); }
      const o = document.createElement("div"); o.className = "opt"; o.textContent = d.nome; o.dataset.i = i;
      o.addEventListener("mousedown", e => { e.preventDefault(); escolher(DEMANDAS[i]); inp.blur(); });
      lst.appendChild(o);
    });
    if (!lst.children.length) lst.innerHTML = '<div class="opt" style="color:var(--gray);cursor:default">Nenhuma demanda encontrada. Use “Outros casos”.</div>';
    ativo = -1; lst.classList.add("open");
  }
  inp.addEventListener("focus", () => { inp.select(); filtrar(); });
  inp.addEventListener("input", filtrar);
  inp.addEventListener("blur", () => { setTimeout(() => { lst.classList.remove("open"); const n = atualNome(); if (n) inp.value = n; }, 120); });
  inp.addEventListener("keydown", e => {
    const os = opts().filter(o => o.dataset.i);
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault(); if (!os.length) return;
      ativo = (ativo + (e.key === "ArrowDown" ? 1 : -1) + os.length) % os.length;
      os.forEach((o, j) => o.classList.toggle("act", j === ativo)); os[ativo].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") {
      e.preventDefault(); const o = os[ativo >= 0 ? ativo : 0]; if (o) { escolher(DEMANDAS[+o.dataset.i]); inp.blur(); }
    } else if (e.key === "Escape") inp.blur();
  });
}
combo($("dem"), $("demLista"), d => escolherDemanda(d), () => S.dem && S.dem.nome);
combo($("dem6"), $("demLista6"), d => escolherDemanda(d), () => S.dem && S.dem.nome);
function escolherDemanda(d) {
  const mudou = S.dem !== d;
  S.dem = d;
  $("dem").value = d.nome; $("dem6").value = d.nome;
  if (mudou) { S.ck = null; S.fOff.clear(); S.fOn.clear(); }
  mostrarNarrativa(); chips();
  if (atual === 5) ENTRAR[5]();
}
/* ---------- narrativas: esqueletos e motor ----------
   Cada narrativa é uma lista de itens. O assistente monta o formulário (caixinhas, listas de procura)
   e, ao gerar, devolve o texto no padrão da DPU para colar no SIS. */
const X = c => c ? "(X)" : "( )";
const PRIO = ["Portador de doença grave (art. 6º, XIV, Lei 7.713/88)", "Idoso acima de 80 anos", "Idoso", "Criança/adolescente", "Não"];
const PARENTESCO = ["esposo(a)/companheiro(a)", "pai/mãe", "filho(a)", "outro"];
let BRANCO = false;   // narrativa em branco: o modelo sem as respostas (campos vazios e parênteses vazios), para completar no Word
const tx = v => (v || "").trim();
const pontuarLista = (ls, fim = ".") => ls.map((l, i) => l + (i === ls.length - 1 ? fim : ";"));
const ARTIGO = { "Concessão": "a concessão", "Restabelecimento": "o restabelecimento", "Revisão": "a revisão", "Prorrogação": "a prorrogação", "Pagamento": "o pagamento" };
const objeto = (st, ops) => st.pret ? ARTIGO[st.pret] : "a " + ops.map(o => o.toLowerCase()).join("/");
const NAO_LONGO = "NÃO. Nesse caso, quando do próximo comparecimento do(a) assistido(a), editar a narrativa para responder aos questionamentos pendentes e, posteriormente, gerar a redução a termo para assinatura. Não esquecer de incluir na lista de documentação pendente o seguinte: “edição da narrativa/gerar redução a termo”.";
const LINK_EPROC = { JFRS: "https://eproc.jfrs.jus.br/eprocV2/", TJRS: "https://eproc1g.tjrs.jus.br/eproc/" };
const INDEF = { t: "opcoes", k: "indef", oque: "indef", titulo: "Há indeferimento do INSS?", ops: [
  { v: "Sim", rot: "Sim. Qual o motivo do indeferimento?", campos: [{ k: "indefMotivo", label: "Qual o motivo do indeferimento? (conforme a carta do INSS)", lista: "motivosINSS" }] },
  { v: "Não", rot: "Não." }] };
const NB = { t: "texto", k: "nb", oque: "nb", titulo: "Qual o número do benefício (NB) objeto do PAJ?", ph: "000.000.000-0 (se houver)", opcional: true };
const TRAT_CURTO = { "Medicamentos": "medicamentos", "Consulta/exame/cirurgia": "consulta/exame/cirurgia", "Internação ou transferência hospitalar": "internação ou transferência hospitalar", "Cuidados paliativos": "cuidados paliativos" };

/* ----- peças reutilizadas nas narrativas novas ----- */
const LINK_SIGTAP = "http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp";
const LINK_ANVISA_MED = "https://consultas.anvisa.gov.br/#/medicamentos/";
const LINK_CID_ANVISA = "http://www7.anvisa.gov.br/Datavisa/Consulta_Comunicados/frmProcurarCid10.asp?acao=procura&x=";
const aLink = (u, t) => `<a href="${u}" target="_blank" rel="noopener">${t}</a>`;
const CID_PREV = { t: "cid", oque: "cid", titulo: v => `Doença com Código Internacional de Doenças - ${v} (de acordo com o laudo médico apresentado pelo/a requerente):` };
const CID_SAUDE = { t: "cid", oque: "cid", titulo: v => v === "CID 10"
  ? `Doença com Código Internacional de Doenças - CID 10 (de acordo com o laudo médico apresentado pelo/a requerente e pesquisa por “Nome do CID 10” no sítio eletrônico da ANVISA ${LINK_CID_ANVISA}):`
  : `Doença com Código Internacional de Doenças - ${v} (de acordo com o laudo médico apresentado pelo/a requerente):` };
const SIMNAO = (k, titulo, x = {}) => ({ t: "opcoes", k, titulo, ops: [{ v: "Sim", rot: "Sim.", ...(x.sim || {}) }, { v: "Não", rot: "Não.", ...(x.nao || {}) }], ...(x.it || {}) });
const LOCAL = (k, titulo) => ({ t: "opcoes", k, titulo, ops: [
  { v: "Unidade de Saúde (SUS)", rot: "Unidade de Saúde (SUS). Qual?", campos: [{ k: k + "US", label: "Qual?" }] },
  { v: "Hospital (SUS)", rot: "Hospital (SUS). Qual?", campos: [{ k: k + "Hosp", label: "Qual?", lista: "hospitais" }] },
  { v: "Clínica/Hospital particular", rot: "Clínica/Hospital particular. Qual?", campos: [{ k: k + "Part", label: "Qual?" }] }] });
const FIM = (ph, r = {}) => [{ t: "renda", ...r }, { t: "prioridade" }, { t: "representacao" }, { t: "processo", tribunal: "JFRS", k: "eproc" }, { t: "irpf" }, { t: "pagar" },
  { t: "texto", k: "compl", titulo: "Informações complementares (opcional):", multi: true, opcional: true, ph: ph || "" }, { t: "completa", longo: true }];
const DEPENDE = (k, titulo, obs) => ({ t: "opcoes", k, titulo, ops: [{ v: "dependência total", rot: "dependência total" }, { v: "dependência parcial", rot: "dependência parcial" }, { v: "sem dependência", rot: "sem dependência" }], obs: { k: k + "Obs", rot: obs } });
const NIS_TXT = "Sim. Informar o Número de Identificação Social (NIS) (possui a mesma numeração do PIS – Programa de Integração Social e do NIT – Número de Inscrição do Trabalhador e pode ser encontrado na CTPS, Cartão Cidadão, Extrato FGTS, Meu INSS e Meu CadÚnico) e a data da última atualização do CadÚnico:";
const CADU_NIS = { t: "opcoes", k: "cadu", oque: "cadunico", titulo: "O/a requerente é inscrito no CadÚnico (Cadastro Único para Programas Sociais do Governo Federal)?", col: true, ops: [
  { v: "Sim", rot: NIS_TXT, campos: [{ k: "caduNum", label: "Número do NIS" }, { k: "caduData", label: "Data da última atualização do CadÚnico", ph: "dd/mm/aaaa" }],
    fmt: st => [tx(st.caduNum) && `NIS ${tx(st.caduNum)}`, tx(st.caduData) && `– última atualização em ${tx(st.caduData)}`].filter(Boolean).join(" ") },
  { v: "Não", rot: "Não." },
  { v: "Não sabe", rot: "Não sabe. Foi solicitado ao/à requerente que realize consulta no aplicativo Meu CadÚnico (disponível no Google Play ou na App Store), no site do Ministério do Desenvolvimento e Assistência Social, Família e Combate à Fome (MDS) ou, ainda, no CRAS – Centro de Referência da Assistência Social ou CREAS – Centro de Referência Especializado de Assistência Social mais próximo de sua residência." }] };
const LOAS_FAM = { t: "opcoes", k: "loasFam", titulo: "O/a requerente ou algum membro residente no mesmo domicílio é beneficiário/a de LOAS?", ops: [
  { v: "Sim", rot: "Sim. Informar Número do Benefício (NB) e CPF do/a beneficiário/a, caso não seja o/a requerente:", campos: [{ k: "loasNB", label: "Número do Benefício (NB)" }, { k: "loasCpf", label: "CPF do/a beneficiário/a (se não for o/a requerente)" }],
    fmt: st => [tx(st.loasNB) && `NB ${tx(st.loasNB)}`, tx(st.loasCpf) && `CPF ${tx(st.loasCpf)}`].filter(Boolean).join(" – ") },
  { v: "Não", rot: "Não." }] };
const COTA = { t: "opcoes", k: "cotista", oque: "cotas", titulo: "O/A assistido(a) está pleiteando vaga como cotista?", ops: [
  { v: "Sim", rot: "Sim. Qual?", campos: [{ k: "cotaQual", label: "Qual cota? (ex.: escola pública, renda, pretos/pardos/indígenas, PcD)" }] }, { v: "Não", rot: "Não." }] };
const INDEF_GERAL = { t: "opcoes", k: "indefG", titulo: "Há indeferimento?", ops: [
  { v: "Sim", rot: "Sim. Qual o motivo do indeferimento?", campos: [{ k: "indefGMotivo", label: "Qual o motivo do indeferimento?" }] }, { v: "Não", rot: "Não." }] };
const CITACAO = (k, chave, doc = "mandado de citação", rotSim) => ({ t: "opcoes", k, oque: "citacao", titulo: `O/A assistido(a) recebeu ${doc}?`, ops: [
  { v: "Sim", rot: rotSim ? "Sim. " + rotSim : (chave ? "Sim. Qual é o número do processo judicial e a chave?" : "Sim. Informar o número do processo judicial, a chave e quando recebeu a citação."),
    campos: [{ k: k + "Num", label: "Número do processo" }, { k: k + "Chave", label: "Chave do processo" }, ...(chave ? [] : [{ k: k + "Quando", label: "Quando recebeu?", ph: "dd/mm/aaaa" }])],
    fmt: st => [tx(st[k + "Num"]) && `Processo nº ${tx(st[k + "Num"])}`, tx(st[k + "Chave"]) && `chave: ${tx(st[k + "Chave"])}`, tx(st[k + "Quando"]) && `recebida em ${tx(st[k + "Quando"])}`].filter(Boolean).join("; ") },
  { v: "Não", rot: "Não." }] });
const PROPOSTA_DIVIDA = { t: "texto", k: "proposta", titulo: "Qual a proposta do(a) assistido(a) para pagamento do valor da dívida, sem prejuízo de sua subsistência?", multi: true };
const RENEG_CEF = { t: "opcoes", k: "renegCEF", titulo: "O/A assistido(a) já tentou renegociar com a CEF?", ops: [
  { v: "Sim", rot: "Sim. Qual a proposta apresentada pela instituição?", campos: [{ k: "renegCEFResp", label: "Qual a proposta apresentada pela instituição?" }] }, { v: "Não", rot: "Não." }] };
const JUROS = SIMNAO("juros", "O/A assistido(a) acredita que estão sendo cobrados juros abusivos?");
const INTERNADO = { t: "opcoes", k: "internado", titulo: "Encontra-se internado?", ops: [
  { v: "Sim", rot: "Sim. Onde?", campos: [{ k: "internOnde", label: "Onde?", lista: "hospitais" }], linhas: [{ k: "internData", label: "Data da internação", rot: "Data da internação:", ph: "dd/mm/aaaa" }] },
  { v: "Não", rot: "Não." }] };
const URGENCIA = SIMNAO("urgencia", "Há indicativo de emergência/urgência na documentação médica?");
const SOLIC_SUS = { t: "opcoes", k: "solicSUS", oque: "regulacao", titulo: "Houve solicitação administrativa ao SUS?", ops: [
  { v: "Sim", rot: "Sim. Em que órgão de saúde?", campos: [{ k: "solicOrgao", label: "Em que órgão de saúde? (ex.: farmácia municipal, farmácia do Estado)" }] },
  { v: "Não", rot: "Não. Qual o motivo?", campos: [{ k: "solicMotivo", label: "Qual o motivo?" }] }] };
const ORCAMENTO = { t: "texto", k: "orcamento", ph: "R$", titulo: "Orçamento (de acordo com três orçamentos apresentados pelo/a requerente ou pesquisa na internet):" };
const MED_PRET = { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter medicamento/insumo pelo Sistema Único de Saúde – SUS (exceto oncológico)." };
const MED_GUIA = 'Não sabe qual modelo usar? Veja se o medicamento tem registro na ANVISA e se está na lista do SUS (RENAME). <button type="button" class="oque" data-oque="padronizado">O que é isso?</button>';
const medNome = (titulo, anvisa) => ({ t: "texto", k: "medNome", multi: true, titulo, oque: "anvisa", ph: "Um medicamento por linha (ex.: DAPAGLIFLOZINA 10 mg)",
  ...(anvisa ? { ajuda: `Confira o princípio ativo na ${aLink(LINK_ANVISA_MED, "consulta de medicamentos da ANVISA")}.` } : {}) });
const POSOLOGIA = { t: "texto", k: "posologia", multi: true, titulo: "Posologia (quantidade mensal ou diária) e duração do tratamento:" };
const MED_ANVISA_TIT = `Medicamento/insumo pretendido (de acordo com o documento de prescrição médica apresentado pelo/a requerente e pesquisa por “Princípio Ativo” ou “Medicamento de Referência” no sítio eletrônico da ANVISA ${LINK_ANVISA_MED}):`;
const MED_FIM = FIM("Informações relevantes que estejam descritas no atestado ou formulário médico.");
const MED_DEM = ["Medicamentos", "Dieta especial"];
const MEDICAMENTOS = [
  { id: "medNP", rot: "Medicamento com registro na ANVISA e não padronizado no SUS", dem: MED_DEM, guia: MED_GUIA, itens: [
    MED_PRET, medNome(MED_ANVISA_TIT, true), POSOLOGIA, CID_SAUDE, LOCAL("localPresc", "Local onde recebeu prescrição médica:"), SOLIC_SUS, ORCAMENTO, ...MED_FIM] },
  { id: "medP", rot: "Medicamento com registro na ANVISA e padronizado no SUS", dem: MED_DEM, guia: MED_GUIA, itens: [
    MED_PRET, medNome(MED_ANVISA_TIT, true), POSOLOGIA, CID_SAUDE, LOCAL("localPresc", "Local onde recebeu prescrição médica:"), SOLIC_SUS,
    { t: "opcoes", k: "medCid", titulo: "O medicamento está disponível no SUS, mas não para o(s) CID(s) do(a) assistido(a)?", ops: [
      { v: "Sim", rot: "Sim. O que consta nas negativas das farmácias municipal e estadual?", campos: [{ k: "medNegativas", label: "O que consta nas negativas das farmácias municipal e estadual?", multi: true }] },
      { v: "Não", rot: "Não." }] },
    ORCAMENTO, ...MED_FIM] },
  { id: "medSR", rot: "Medicamento sem registro na ANVISA", dem: MED_DEM, guia: MED_GUIA, itens: [
    MED_PRET, { ...medNome("Medicamento/insumo pretendido (sem registro na ANVISA):"), ajuda: "Sem registro na ANVISA, o fornecimento pelo SUS só é possível em situações excepcionais (Tema 500 do STF). Junte o máximo de documentos médicos." },
    POSOLOGIA, CID_PREV, LOCAL("localPresc", "Local onde recebeu prescrição médica:"), SOLIC_SUS, ORCAMENTO, ...MED_FIM] },
  { id: "medRC", rot: "Medicamento – não sei classificar", dem: MED_DEM, guia: MED_GUIA, itens: [
    MED_PRET, medNome("Medicamento/insumo pretendido:"), POSOLOGIA, CID_PREV, LOCAL("localPresc", "Local onde recebeu prescrição médica:"), SOLIC_SUS, ORCAMENTO, ...MED_FIM] },
];
const FGTS_COR = `Trata-se de PAJ instaurado com a pretensão de correção dos depósitos efetuados na conta vinculada ao FGTS pelos índices que melhor reflitam a inflação, a partir de 1999, afastando-se, portanto, a aplicação da TR (Taxa Referencial).
A questão foi submetida à sistemática dos recursos repetitivos pelo STJ (Tema 731: “Discute-se a possibilidade, ou não, de a TR ser substituída como índice de correção monetária dos saldos das contas vinculadas ao FGTS”), tendo o REsp n. 1.614.874/SC sido julgado pela Primeira Seção do STJ em 11/04/2018, com a rejeição do pedido, mantendo-se a TR como fator de correção monetária. Confira-se:
“TESE PARA FINS DO ART. 1.036 DO CPC/2015: A remuneração das contas vinculadas ao FGTS tem disciplina própria, ditada por lei, que estabelece a TR como forma de atualização monetária, sendo vedado, portanto, ao Poder Judiciário substituir o mencionado índice.”
Posteriormente, o Supremo Tribunal Federal, no julgamento da ADI 5.090, em 12/06/2024, decidiu que a remuneração das contas do FGTS deve garantir, no mínimo, a correção pelo IPCA, mas apenas para os depósitos futuros, a partir da publicação da ata daquele julgamento, sem efeitos retroativos. Assim, não há direito à recomposição dos saldos relativos aos períodos anteriores.
Considerando o sistema de precedentes judiciais adotado pelo Código de Processo Civil de 2015, que estabeleceu a observância obrigatória, pelos juízes e tribunais, das decisões do STF em controle concentrado de constitucionalidade e dos acórdãos em julgamento de recurso especial repetitivo (artigo 927, incisos I e III, CPC), a AÇÃO CIVIL PÚBLICA Nº 5008379-42.2014.4.04.7100/RS, ajuizada pela DPU, foi julgada IMPROCEDENTE e, pelas mesmas razões, inviável a pretensão individual do(a) assistido(a).
Logo, de acordo com o disposto na Ata (SEI 4792715), delibera-se pelo arquivamento dos procedimentos instaurados em razão da inviabilidade jurídica da pretensão, fazendo-o com fundamento no artigo 10 da Resolução CSDPU 160/2020 e com fulcro no acima exposto.
O(A) assistido(a) está ciente das razões do arquivamento e da possibilidade de apresentar recurso, no prazo de 10 dias, caso queira. Foi entregue cópia da Ata ao requerente.`;


const NARRATIVAS = [
  { id: "loas", rot: "BPC/LOAS – pessoa com deficiência", dem: ["Benefício assistencial (BPC/LOAS) à pessoa com deficiência"], itens: [
    { t: "pretensao", ops: ["Concessão", "Restabelecimento"], frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter ${objeto(st, ["Concessão", "Restabelecimento"])} do Benefício Assistencial (LOAS).` },
    { t: "cid", titulo: v => `Doença com Código Internacional de Doenças - ${v} (de acordo com o laudo médico apresentado pelo/a requerente):` },
    { t: "opcoes", k: "incapaz", oque: "deficiencia", titulo: "No atestado médico apresentado consta que o(a) assistido(a) está incapaz para o regular desempenho social?", ops: [
      { v: "Sim", rot: "Sim." },
      { v: "Não", rot: "Não. Relatar informações relevantes que constam no documento médico.", apos: { k: "incapazInfo", label: "Relatar informações relevantes que constam no documento médico", multi: true } }] },
    INDEF, NB,
    { t: "opcoes", k: "cadu", oque: "cadunico", titulo: "O(A) requerente está inscrito(a) no Cadastro Único?", ops: [{ v: "Sim", rot: "Sim." },
      { v: "Não", rot: "Não.", aviso: "A inscrição no CadÚnico é obrigatória para o BPC (art. 20, § 12, da Lei nº 8.742/1993). Oriente o(a) assistido(a) a procurar o CRAS para se inscrever ou atualizar o cadastro." }] },
    { t: "renda" }, { t: "prioridade" }, { t: "representacao" }, { t: "processo", tribunal: "JFRS", k: "eproc" }, { t: "irpf" },
    { t: "texto", k: "compl", titulo: "Descrever, de forma resumida, os acontecimentos que levaram o(a) assistido(a) a buscar assistência da DPU:", multi: true },
    { t: "pagar" }, { t: "completa" }] },

  { id: "auxdoenca", rot: "Auxílio-doença", dem: ["Auxílio-doença"], itens: [
    { t: "pretensao", ops: ["Concessão", "Restabelecimento", "Prorrogação", "Revisão"], frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter ${objeto(st, ["Concessão", "Restabelecimento", "Prorrogação", "Revisão"])} do Auxílio-Doença.` },
    { t: "cid", titulo: v => `Doença com Código Internacional de Doenças - ${v} (de acordo com o laudo médico apresentado pelo/a requerente):` },
    { t: "opcoes", k: "incapazTrab", oque: "incapacidade", titulo: "No atestado médico apresentado consta que o(a) assistido(a) está incapaz para o trabalho?", ops: [
      { v: "Sim", rot: "Sim.", campos: [{ k: "incapazTrabInfo", label: "O que o atestado diz (ex.: paciente apresenta incapacidade permanente)" }] },
      { v: "Não", rot: "Não." }] },
    INDEF,
    { t: "texto", k: "atividade", titulo: "Qual era a atividade profissional desempenhada pelo(a) assistido(a)?" },
    { t: "texto", k: "rotinas", titulo: "O(a) assistido(a) se julga incapaz para a atividade do item 5, porquanto não consegue desenvolver quais rotinas? (ex.: carregar peso, deslocar-se, etc):", multi: true },
    NB,
    { t: "renda" }, { t: "prioridade" }, { t: "representacao" }, { t: "processo", tribunal: "JFRS", k: "eproc" }, { t: "irpf" }, { t: "pagar" },
    { t: "texto", k: "compl", titulo: "Informações complementares (opcional)/Se houver formulário médico, indicar informações relevantes, tais como: data de início da incapacidade; se a incapacidade é permanente ou temporária, dentre outras:", multi: true, opcional: true },
    { t: "completa", longo: true }] },

  { id: "bolsa", rot: "Bolsa Família", dem: ["Bolsa Família"], itens: [
    { t: "pretensao", livre: true, ph: "Ex.: A assistida requer receber as parcelas do Bolsa Família dos meses de … que não puderam ser sacadas." },
    { t: "opcoes", k: "cadu", titulo: "O/A requerente é inscrito(a) no CadÚnico (Cadastro Único para Programas Sociais do Governo Federal)?", ops: [
      { v: "Sim", rot: "Sim.", campos: [{ k: "caduNum", label: "Número do NIS ou do código familiar" }, { k: "caduData", label: "Data da última atualização", ph: "dd/mm/aaaa" }],
        fmt: st => [tx(st.caduNum) && `– ${tx(st.caduNum)}`, tx(st.caduData) && `- última atualização ${tx(st.caduData)}`].filter(Boolean).join(" ") },
      { v: "Não", rot: "Não." }, { v: "Não sabe", rot: "Não sabe." }] },
    { t: "opcoes", k: "loasFam", titulo: "O/a requerente ou algum membro residente no mesmo domicílio é beneficiário/a de LOAS?", ops: [
      { v: "Sim", rot: "Sim. Informar Número do Benefício (NB)", campos: [{ k: "loasNB", label: "Número do Benefício (NB)" }] }, { v: "Não", rot: "Não." }] },
    { t: "opcoes", k: "pbf", titulo: "O/a requerente é beneficiário/a do Bolsa Família?", ops: [
      { v: "Sim", rot: "Sim. Desde que data?", campos: [{ k: "pbfDesde", label: "Desde que data?" }] },
      { v: "Não", rot: "Não.", campos: [{ k: "pbfNao", label: "Observação (opcional)" }] }] },
    { t: "opcoes", k: "pbfCanc", titulo: "O benefício do Bolsa Família foi cancelado/suspenso?", ops: [
      { v: "Sim", rot: "Sim. Por qual motivo?", campos: [{ k: "pbfMotivo", label: "Por qual motivo?" }] }, { v: "Não", rot: "Não." }] },
    { t: "renda" }, { t: "prioridade" }, { t: "representacao" }, { t: "processo", tribunal: "JFRS", k: "eproc" }, { t: "irpf" },
    { t: "texto", k: "compl", titulo: "Informações complementares (opcional):", multi: true, opcional: true },
    { t: "completa", longo: true }] },

  { id: "pensao", rot: "Pensão por morte", dem: ["Pensão por morte", "Revisão de aposentadoria ou de pensão por morte"], varios: true,
    ck: st => st.test === "Sim" ? [/três testemunhas/] : [], itens: [
    { t: "pretensao", ops: ["Concessão", "Restabelecimento", "Revisão"], frase: (st, pl) => `${pl ? "Os/As requerentes buscam" : "O/A requerente busca"} a assistência jurídica da DPU com a pretensão de obter ${objeto(st, ["Concessão", "Restabelecimento", "Revisão"])} da pensão por morte.` },
    INDEF, NB,
    { t: "opcoes", k: "parFal", titulo: pl => pl ? "Qual o grau de parentesco dos(as) assistidos(as) com o(a) falecido(a)?" : "Qual o grau de parentesco do(a) assistido(a) com o(a) falecido(a)?", ops: [
      { v: "Esposo(a)", rot: "Esposo(a).", sub: { k: "certCas", pergunta: "Há certidão de casamento?", ops: ["Sim.", "Não."] } },
      { v: "Companheiro(a)", rot: "Companheiro(a)", sub: { k: "docUniao", pergunta: "Há documentos comprobatórios da união estável?", ops: ["Sim.", "Não."] } },
      { v: "Filho(a)", rot: "Filho(a) – Qual a idade?", campos: [{ k: "idadeFilho", label: "Qual a idade?" }] },
      { v: "Outro", rot: "Outro", campos: [{ k: "parFalOutro", label: "Especificar (ex.: netos)" }], fmt: st => tx(st.parFalOutro) ? "- " + tx(st.parFalOutro) : "" }] },
    { t: "testemunhas" },
    { t: "renda" }, { t: "prioridade" }, { t: "representacao" }, { t: "processo", tribunal: "JFRS", k: "eproc" }, { t: "irpf" },
    { t: "texto", k: "compl", titulo: "Informações complementares:", multi: true },
    { t: "completa", longo: true }] },

  { id: "onco", rot: "Tratamento oncológico", dem: ["Tratamento oncológico"], prioGrave: true, itens: [
    { t: "pretensao", fixa: true, frase: st => { const t = (st.trat || []).map(v => TRAT_CURTO[v]).filter(Boolean);
        return `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter tratamento oncológico${t.length ? ` (${t.join(", ")})` : ""}.`; } },
    { t: "opcoes", k: "diag", titulo: "O/A requerente teve diagnóstico de neoplasia maligna confirmado?", ops: [
      { v: "Não", rot: "Não, a hipótese diagnóstica/suspeita ainda não foi confirmada. Qual a data do encaminhamento para consulta/exame especializado?",
        campos: [{ k: "diagEnc", label: "Data do encaminhamento", ph: "dd/mm/aaaa" }], sempre: st => st.diag === "Não" && tx(st.diagEnc) ? tx(st.diagEnc) : "__/__/_____" },
      { v: "Sim", rot: "Sim, foi confirmado o diagnóstico." }] },
    { t: "cid", titulo: v => v === "CID 10"
        ? "Qual a doença com Código Internacional de Doenças - CID 10 (de acordo com o laudo médico apresentado pelo/a requerente e pesquisa por “Nome do CID 10” no sítio eletrônico da ANVISA http://www7.anvisa.gov.br/Datavisa/Consulta_Comunicados/frmProcurarCid10.asp?acao=procura&x=):"
        : `Qual a doença com Código Internacional de Doenças - ${v} (de acordo com o laudo médico apresentado pelo/a requerente):` },
    { t: "texto", k: "dataDiag", titulo: "Qual a data do diagnóstico da neoplasia (conforme laudo médico ou laudo patológico)?", ph: "dd/mm/aaaa" },
    { t: "texto", k: "descDoenca", titulo: "Sucinta descrição da doença ou do estado de saúde:", multi: true },
    { t: "opcoes", k: "trat", multi: true, titulo: "Qual(is) o(s) tratamento(s) médico(s) prescrito(s)?", ops: [
      { v: "Medicamentos", rot: "Medicamentos (de acordo com o documento de prescrição médica apresentado pelo/a requerente e pesquisa por “Princípio Ativo” ou “Medicamento de Referência” no sítio eletrônico da ANVISA https://consultas.anvisa.gov.br/#/medicamentos/):",
        ajuda: 'Confira o princípio ativo na <a href="https://consultas.anvisa.gov.br/#/medicamentos/" target="_blank" rel="noopener">consulta de medicamentos da ANVISA</a>.',
        linhas: [{ k: "meds", label: "Medicamentos, um por linha (ex.: NIVOLUMABE 480mg)", lista: true },
                 { k: "posologia", label: "Posologia (quantidade mensal ou diária) e duração do tratamento, uma linha por medicamento", rot: "Posologia (quantidade mensal ou diária) e duração do tratamento:", lista: true }] },
      { v: "Consulta/exame/cirurgia", rot: "Consulta/exame/cirurgia (de acordo com o documento de prescrição médica apresentado pelo/a requerente e pesquisa por “Nome” no Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS - SIGTAP no sítio eletrônico do Ministério da Saúde http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp):",
        ajuda: 'Confira o nome no <a href="http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp" target="_blank" rel="noopener">SIGTAP</a>.',
        campos: [{ k: "tratProc", label: "Nome da cirurgia, do exame ou da especialidade da consulta" }] },
      { v: "Internação ou transferência hospitalar", rot: "Internação ou transferência hospitalar:", campos: [{ k: "tratInt", label: "Detalhe" }] },
      { v: "Cuidados paliativos", rot: "Cuidados paliativos:", campos: [{ k: "tratPal", label: "Detalhe" }] }] },
    { t: "opcoes", k: "local", titulo: "Local onde recebeu o encaminhamento para o tratamento oncológico pretendido:", ops: [
      { v: "Unidade de Saúde (SUS)", rot: "Unidade de Saúde (SUS). Qual?", campos: [{ k: "localUS", label: "Qual?" }] },
      { v: "Hospital (SUS)", rot: "Hospital (SUS). Qual?", campos: [{ k: "localHosp", label: "Qual?", lista: "hospitais" }] },
      { v: "Clínica/Hospital particular", rot: "Clínica/Hospital particular. Qual?", campos: [{ k: "localPart", label: "Qual?" }] }] },
    { t: "opcoes", k: "regul", titulo: "Houve inserção da solicitação do tratamento médico no sistema de regulação, ou outra forma de solicitação administrativa junto ao SUS?", ops: [
      { v: "Sim", rot: "Sim.", campos: [{ k: "regulOnde", label: "Onde? (ex.: farmácias estadual e municipal, sistema de regulação)" }] },
      { v: "Não", rot: "Não. Por qual motivo?", campos: [{ k: "regulMotivo", label: "Por qual motivo?" }] }] },
    { t: "opcoes", k: "acomp", titulo: "O/A requerente está tendo acompanhamento oncológico?", ops: [
      { v: "Sim", rot: "Sim. Onde?", campos: [{ k: "acompOnde", label: "Onde?", lista: "hospitais" }], linhas: [{ k: "acompInicio", label: "Data de início", rot: "Data de início:", ph: "dd/mm/aaaa" }] },
      { v: "Não", rot: "Não." }] },
    { t: "opcoes", k: "tratPrev", titulo: "O/A requerente já realizou algum tratamento para a neoplasia (cirurgia, quimioterapia, radioterapia, cuidados paliativos)?", ops: [
      { v: "Sim", rot: "Sim. Qual(is)?", campos: [{ k: "tratPrevQual", label: "Qual(is)?" }] }, { v: "Não", rot: "Não." }] },
    { t: "renda" }, { t: "prioridade" }, { t: "representacao" },
    { t: "processo", tribunal: "JFRS", k: "eproc" }, { t: "processo", tribunal: "TJRS", k: "eprocTJ" }, { t: "irpf" },
    { t: "texto", k: "compl", titulo: "Informações complementares:", multi: true },
    { t: "completa", longo: true }] },
  /* ===== Previdenciário ===== */
  { id: "aposinv", rot: "Aposentadoria por incapacidade permanente (invalidez)", dem: ["Aposentadoria por invalidez"], itens: [
    { t: "pretensao", ops: ["Concessão", "Restabelecimento", "Revisão"], frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter ${objeto(st, ["Concessão", "Restabelecimento", "Revisão"])} da Aposentadoria por Incapacidade Permanente (antiga aposentadoria por invalidez).` },
    CID_PREV,
    { t: "opcoes", k: "incapazPerm", titulo: "No atestado médico apresentado consta que o(a) assistido(a) está permanentemente incapaz para o trabalho?", oque: "incapacidade", ops: [
      { v: "Sim", rot: "Sim." },
      { v: "Não", rot: "Não. Relatar informações relevantes que constam no documento médico e já informar que o(a) requerente foi orientado a trazer novo laudo indicando a incapacidade permanente para o desempenho de atividades laborais.", apos: { k: "incapazPermInfo", label: "Informações relevantes que constam no documento médico", multi: true } }] },
    INDEF,
    { t: "texto", k: "atividade", titulo: "Qual era a atividade profissional desempenhada pelo(a) assistido(a)?" },
    { t: "texto", k: "rotinas", titulo: "O(a) assistido(a) se julga incapaz para a atividade do item 5, porquanto não consegue desenvolver quais rotinas? (ex.: carregar peso, deslocar-se, etc):", multi: true },
    NB, ...FIM("Informações relevantes que estejam descritas no atestado médico.")] },

  { id: "adic25", rot: "Adicional de 25% (grande invalidez)", dem: ["Adicional de 25% na aposentadoria"], itens: [
    { t: "pretensao", ops: ["Concessão", "Restabelecimento"], frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter ${objeto(st, ["Concessão", "Restabelecimento"])} do adicional de 25% em sua Aposentadoria por Incapacidade Permanente (antiga aposentadoria por invalidez).` },
    CID_PREV,
    { t: "opcoes", k: "acompPerm", titulo: "No atestado médico apresentado consta que o(a) assistido(a) está incapaz para o trabalho e necessita de acompanhante permanente?", oque: "adicional25", ops: [
      { v: "Sim", rot: "Sim." },
      { v: "Não", rot: "Não. Relatar informações relevantes que constam no documento médico e já informar que o(a) requerente foi orientado a trazer novo laudo indicando a incapacidade para o trabalho e a necessidade de acompanhante permanente.", apos: { k: "acompPermInfo", label: "Informações relevantes que constam no documento médico", multi: true } }] },
    { t: "grupo", titulo: "Para quais atividades abaixo indicadas, o(a) assistido(a) demanda de acompanhamento permanente, descrevendo se a dependência é total ou parcial:", itens: [
      DEPENDE("dBanho", "Banhar-se:", "Observações: informar se o(a) assistido(a) usa adequadamente chuveiro, sabão e/ou esponja:"),
      DEPENDE("dVestir", "Vestir-se:", "Observações: informar se o(a) assistido(a) apanha a roupa do armário ou gaveta, veste-se e consegue despir-se:"),
      DEPENDE("dBanheiro", "Uso do banheiro:", "Observações: informar se o(a) assistido(a) locomove-se até o banheiro, despe-se e limpa-se:"),
      DEPENDE("dControle", "Controle de micção e evacuação:", "Observações: informar se o(a) assistido(a) tem o controle sobre a micção e evacuação:"),
      DEPENDE("dTransf", "Transferir-se:", "Observações: informar se o(a) assistido(a) locomove-se da cama para a cadeira e vice-versa:"),
      DEPENDE("dAlim", "Alimentar-se:", "Observações: informar se o(a) assistido(a) consegue apanhar a comida do prato ou equivalente e levar à boca:")] },
    SIMNAO("comAcomp", "O(A) assistido(a) compareceu ao atendimento com acompanhante?"),
    INDEF, NB, ...FIM("Informações relevantes que estejam descritas no atestado médico.")] },

  { id: "aposidade", rot: "Aposentadoria por idade", dem: ["Aposentadoria por idade ou por tempo de contribuição", "Aposentadoria rural"],
    ck: st => S.dem && S.dem.nome === "Aposentadoria rural" && st.test === "Sim" ? [/três testemunhas/] : [], itens: [
    { t: "pretensao", fixa: true, frase: () => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter a concessão da Aposentadoria por idade${S.dem && S.dem.nome === "Aposentadoria rural" ? " rural" : ""}.` },
    INDEF, NB,
    { t: "testemunhas", soDem: ["Aposentadoria rural"] },
    ...FIM("Informações importantes que o(a) assistido(a) disser acerca de sua aposentadoria por idade (ex.: períodos de trabalho rural ou urbano, contribuições).")] },

  { id: "apostempo", rot: "Aposentadoria por tempo de contribuição", dem: ["Aposentadoria por idade ou por tempo de contribuição"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter a concessão da Aposentadoria por tempo de contribuição." },
    INDEF, NB, ...FIM("Informações importantes que o(a) assistido(a) disser acerca do tempo de contribuição (períodos de trabalho, atividade especial, trabalho rural, etc.).")] },

  { id: "loasidoso", rot: "BPC/LOAS – pessoa idosa", dem: ["Benefício assistencial (BPC/LOAS) à pessoa idosa"], itens: [
    { t: "pretensao", ops: ["Concessão", "Restabelecimento"], frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter ${objeto(st, ["Concessão", "Restabelecimento"])} do Benefício Assistencial (LOAS-idoso).` },
    INDEF, NB,
    { t: "opcoes", k: "cadu", titulo: "O(A) requerente está inscrito(a) no Cadastro Único?", oque: "cadunico", ops: [{ v: "Sim", rot: "Sim." },
      { v: "Não", rot: "Não.", aviso: "A inscrição no CadÚnico é obrigatória para o BPC (art. 20, § 12, da Lei nº 8.742/1993). Oriente o(a) assistido(a) a procurar o CRAS para se inscrever ou atualizar o cadastro." }] },
    ...FIM()] },

  { id: "reclusao", rot: "Auxílio-reclusão", dem: ["Auxílio-reclusão"], varios: true, itens: [
    { t: "pretensao", fixa: true, frase: (st, pl) => `${pl ? "Os/As requerentes buscam" : "O/A requerente busca"} a assistência jurídica da DPU com a pretensão de obter a concessão do Auxílio-reclusão.` },
    INDEF, NB,
    SIMNAO("atestReclusao", "Foi apresentado o atestado de reclusão (SUSEPE)?", { it: { oque: "reclusao" } }),
    SIMNAO("qualidPreso", "O(A) preso possui qualidade de segurado do INSS? Vertera, pelo menos, 24 contribuições antes da prisão?", { it: { oque: "qualidade",
      ajuda: "O segurado preso também precisa ser de <b>baixa renda</b>: em 2026, média dos 12 últimos salários de contribuição antes da prisão de até R$ 1.980,38 (Portaria Interministerial MPS/MF nº 13/2026). Confira no CNIS." } }),
    ...FIM()] },

  { id: "salmat", rot: "Salário-maternidade", dem: ["Salário-maternidade"], itens: [
    { t: "pretensao", fixa: true, frase: () => "A requerente busca a assistência jurídica da DPU com a pretensão de obter a concessão do Salário-maternidade." },
    INDEF, NB,
    SIMNAO("qualidSeg", "A assistida possui qualidade de segurada do INSS?", { it: { oque: "qualidade" } }),
    ...FIM(undefined, { fem: true })] },

  { id: "revisao", rot: "Revisão de aposentadoria", dem: ["Revisão de aposentadoria ou de pensão por morte"], itens: [
    { t: "pretensao", ops: ["Aposentadoria por idade", "Aposentadoria por tempo de contribuição"], frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter a revisão de sua aposentadoria ${st.pret ? st.pret.replace("Aposentadoria ", "") : "por idade/por tempo de contribuição"}.` },
    INDEF, NB,
    { t: "texto", k: "dataConc", titulo: "Data de concessão da aposentadoria:", ph: "dd/mm/aaaa", oque: "decadencia",
      ajuda: "Atenção ao prazo: a revisão do ato de concessão deve ser pedida em até 10 anos (art. 103 da Lei nº 8.213/1991)." },
    ...FIM("Informações importantes que o(a) assistido(a) disser acerca do caso.")] },

  { id: "descontos", rot: "Restituição/cobrança – descontos no benefício", dem: ["Descontos indevidos em benefício do INSS"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter a restituição dos valores descontados indevidamente do seu benefício previdenciário e/ou cessação da cobrança indevida de valores em seu benefício previdenciário." },
    { t: "texto", k: "beneficio", titulo: "O/A assistido(a) recebe qual benefício previdenciário? Indicar o NB.", oque: "nb", ph: "Ex.: aposentadoria por idade, NB 000.000.000-0" },
    { t: "opcoes", k: "conhece", titulo: "O/A assistido(a) tem conhecimento dos valores de empréstimos que estão sendo descontados de seu benefício previdenciário?", oque: "consignado", ops: [
      { v: "Sim", rot: "Sim.", sub: { k: "contratos", pergunta: "Possui os contratos firmados com as instituições financeiras?", ops: ["Sim.", "Não."] } },
      { v: "Não", rot: "Não." }] },
    { t: "texto", k: "valoresDesc", multi: true, titulo: "Relatar os valores que estão sendo descontados mensalmente do benefício previdenciário do(a) assistido(a), bem como indicar o nome da instituição responsável, de acordo com o extrato de empréstimos consignados:",
      ph: "Ex.: Banco X, R$ 150,00 por mês; Associação Y (mensalidade associativa), R$ 45,00 por mês",
      ajuda: "O extrato de empréstimos sai no Meu INSS (“Extrato de Empréstimos”). Se houver desconto de <b>associação ou sindicato</b>, o prazo para contestar no acordo de ressarcimento do INSS terminou em 20/06/2026; quem contestou no prazo e não teve resposta da entidade ainda pode aderir ao acordo pelo Meu INSS ou nos Correios." },
    { t: "opcoes", k: "tentouINSS", titulo: "O/A assistido(a) tentou obter informações sobre os descontos diretamente no INSS?", ops: [
      { v: "Sim", rot: "Sim. Qual a resposta da autarquia previdenciária?", campos: [{ k: "respINSS", label: "Qual a resposta da autarquia previdenciária?" }] },
      { v: "Não", rot: "Não." }] },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "defeso", rot: "Seguro-defeso (pescador artesanal)", dem: ["Seguro-defeso (pescador artesanal)"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter a concessão do Seguro-defeso." },
    { ...INDEF, ajuda: "Desde a Lei nº 15.399/2026, o pedido exige inscrição no CadÚnico, registro biométrico e o Relatório de Exercício da Atividade Pesqueira (REAP) em dia." },
    NB, ...FIM("Informações importantes que o(a) assistido(a) disser acerca do caso (ex.: registro de pescador no RGP, colônia, espécie e período do defeso).")] },

  /* ===== Cível ===== */
  { id: "auxgas", rot: "Auxílio Gás do Povo", dem: ["Auxílio Gás"], itens: [
    { t: "pretensao", ops: ["Concessão", "Restabelecimento", "Pagamento"], frase: st => `O/a requerente busca a assistência jurídica da DPU para obter ${objeto(st, ["Concessão", "Restabelecimento", "Pagamento"])} do benefício do Auxílio Gás do Povo (antigo Auxílio Gás dos Brasileiros), previsto pela Lei nº 14.237/2021, com a redação da Lei nº 15.348/2026.`,
      ajuda: "Desde 2026, o benefício é a recarga gratuita do botijão de 13 kg (Gás do Povo), para famílias inscritas no CadÚnico com renda por pessoa de até 1/2 salário mínimo, com prioridade para quem recebe Bolsa Família." },
    { t: "opcoes", k: "gasRecebeu", titulo: "O/a requerente já recebeu uma, ou mais, parcela(s) ou recarga(s) do Auxílio Gás?", ops: [
      { v: "Sim", rot: "Sim. Desde quando o benefício foi cancelado/suspenso? Qual motivo?", campos: [{ k: "gasDesde", label: "Desde quando foi cancelado/suspenso?", ph: "dd/mm/aaaa" }, { k: "gasMotivo", label: "Qual motivo?" }],
        fmt: st => [tx(st.gasDesde) && `Desde ${tx(st.gasDesde)}.`, tx(st.gasMotivo) && `Motivo: ${tx(st.gasMotivo)}`].filter(Boolean).join(" ") },
      { v: "Não", rot: "Não." }] },
    CADU_NIS, LOAS_FAM,
    { t: "opcoes", k: "pbf", titulo: "O/a requerente é beneficiário/a do Bolsa Família?", ops: [
      { v: "Sim", rot: "Sim. Desde que data?", campos: [{ k: "pbfDesde", label: "Desde que data?", ph: "dd/mm/aaaa" }] }, { v: "Não", rot: "Não." }] },
    ...FIM()] },

  { id: "segdes", rot: "Seguro-desemprego", dem: ["Seguro-desemprego", "Seguro-desemprego (com empresa no nome do assistido)"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter o seguro-desemprego." },
    { t: "texto", k: "rescisao", titulo: "Qual a data da rescisão do contrato de trabalho?", ph: "dd/mm/aaaa" },
    { t: "texto", k: "sdPedido", titulo: "Quando foi solicitado o seguro-desemprego?", ph: "dd/mm/aaaa" },
    { t: "opcoes", k: "sdIndef", titulo: "Há indeferimento?", ops: [
      { v: "Sim", rot: "Sim. Qual o motivo do indeferimento?", campos: [{ k: "sdMotivo", label: "Qual o motivo do indeferimento?" }] }, { v: "Não", rot: "Não." }] },
    { t: "opcoes", k: "sdParcela", titulo: "O/A assistido(a) recebeu alguma parcela do seguro-desemprego?", ops: [
      { v: "Sim", rot: "Sim. Quantas?", campos: [{ k: "sdQuantas", label: "Quantas?" }] }, { v: "Não", rot: "Não." }] },
    { t: "opcoes", k: "sdEmpresa", soDem: ["Seguro-desemprego (com empresa no nome do assistido)"], titulo: "Há empresa (CNPJ ou MEI) registrada em nome do(a) assistido(a)?",
      ajuda: "Em regra, o simples registro de empresa não prova que a pessoa tinha renda própria: importa saber se a empresa estava ativa e gerava renda para o sustento.", ops: [
      { v: "Sim", rot: "Sim. Situação da empresa:", campos: [{ k: "sdEmpSit", label: "Situação da empresa (ativa, inativa ou baixada) e se gerava renda" }] }, { v: "Não", rot: "Não." }] },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "concurso", rot: "Concurso público", dem: ["Concurso público"], itens: [
    { t: "pretensao", ops: ["Obter vaga", "Obter a justificativa do indeferimento"], campos: [{ k: "concNome", label: "Qual o concurso público federal?" }],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de ${st.pret === "Obter vaga" ? "obter vaga no concurso público" : st.pret ? "obter a justificativa do indeferimento da vaga no concurso público" : "obter vaga no concurso público/obter a justificativa do indeferimento da vaga no concurso público"}${tx(st.concNome) ? ` (${tx(st.concNome)})` : ""}.` },
    { t: "texto", k: "edital", titulo: "Qual é o número do edital do concurso público objeto do PAJ?", oque: "edital" },
    { t: "texto", k: "classif", titulo: "O/A assistido(a) encontra-se classificado(a) em qual posição?" },
    COTA, INDEF_GERAL, ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "educacao", rot: "Educação – vaga em instituição federal", dem: ["Ingresso em instituição de ensino"], itens: [
    { t: "pretensao", campos: [{ k: "curso", label: "Qual o curso?" }, { k: "instit", label: "Qual a instituição de ensino federal?" }],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter vaga no curso ${tx(st.curso) || "(especificar o curso)"} na instituição de ensino ${tx(st.instit) || "(especificar a instituição de ensino federal)"}.` },
    { t: "texto", k: "edital", titulo: "Qual é o número do edital (SISU/ENEM, vestibular ou processo seletivo)?", oque: "edital" },
    { t: "texto", k: "classif", titulo: "O/A assistido(a) encontra-se classificado(a) em qual posição?" },
    COTA, INDEF_GERAL, ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "execfiscal", rot: "Execução fiscal – atendimento inicial", dem: ["Execução fiscal"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter auxílio com a execução fiscal." },
    CITACAO("citacao"),
    { t: "texto", k: "efTrata", titulo: "Do que se trata a execução fiscal?", multi: true, oque: "execucao", ph: "Quem cobra (União/Fazenda Nacional, INSS, IBAMA, conselho profissional…), qual tributo ou multa e o valor" },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "conselhos", rot: "Conselhos profissionais", dem: ["Execução fiscal"], itens: [
    { t: "pretensao", campos: [{ k: "conselho", label: "Qual é o conselho profissional? (ex.: CRC, CREA, COREN)" }],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter auxílio para quitar a dívida com o conselho profissional${tx(st.conselho) ? ` (${tx(st.conselho)})` : " (indicar qual é o conselho profissional)"}.` },
    CITACAO("citacao", true),
    { t: "texto", k: "valorTotal", titulo: "Qual o valor total que está sendo cobrado?", ph: "R$" },
    { t: "opcoes", k: "reneg", titulo: "O/A assistido(a) tentou renegociação diretamente com o conselho profissional?", ops: [
      { v: "Sim", rot: "Sim. Qual a resposta do conselho profissional?", campos: [{ k: "renegResp", label: "Qual a resposta do conselho profissional?" }] }, { v: "Não", rot: "Não." }] },
    PROPOSTA_DIVIDA, ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "ambiental", rot: "Ambiental (IBAMA)", dem: ["Execução fiscal", "Outros casos"], itens: [
    { t: "pretensao", campos: [{ k: "ambDeseja", label: "O que o(a) assistido(a) deseja?" }],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter auxílio para resolver a sua situação com o IBAMA${tx(st.ambDeseja) ? ` (${tx(st.ambDeseja)})` : " (informar o que o(a) assistido(a) deseja)"}.` },
    CITACAO("citacao", true),
    { t: "texto", k: "ambCaso", titulo: "Relatar o caso (conforme processo judicial ou processo administrativo do IBAMA):", multi: true },
    { t: "texto", k: "valorTotal", titulo: "Qual o valor total da dívida?", ph: "R$" },
    PROPOSTA_DIVIDA, ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "posse", rot: "Defesa da posse e da propriedade", dem: ["Reintegração ou defesa da posse"], itens: [
    { t: "pretensao", ops: ["Defesa em ação de reintegração de posse", "Obter a reintegração de posse"],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter ${st.pret === "Obter a reintegração de posse" ? "a reintegração de posse" : st.pret ? "a defesa da sua posse em ação de reintegração de posse" : "a reintegração de posse/a defesa da sua posse"}.` },
    CITACAO("citacao", false, "mandado de citação/intimação", "Qual o número do processo judicial, a chave e quando recebeu a intimação/citação?"),
    { t: "texto", k: "posseProc", titulo: "Relatar informações constantes no processo judicial (qual o imóvel objeto da reintegração de posse, dentre outras):", multi: true },
    SIMNAO("contratoCV", "Há contrato de compra e venda do imóvel?"),
    { t: "opcoes", k: "comprovPosse", titulo: "Há comprovantes do período da ocupação/posse/propriedade, especialmente que demonstrem mais de cinco anos?", oque: "usucapiao", ops: [
      { v: "Sim", rot: "Sim. Quais?", campos: [{ k: "comprovQuais", label: "Quais? (ex.: contas de luz e água, IPTU, correspondências)" }] }, { v: "Não", rot: "Não." }] },
    { t: "texto", k: "tempoOcup", titulo: "Há quanto tempo o(a) assistido(a) está ocupando o imóvel?" },
    SIMNAO("certImovel", "Há certidão de registros imobiliários em nome do(a) assistido(a)?"),
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "bancario", rot: "Contratos bancários (CEF)", dem: ["Empréstimo bancário", "Juros abusivos"], itens: [
    { t: "pretensao", campos: [{ k: "bancDeseja", label: "O que o(a) assistido(a) deseja? (ex.: renegociar a dívida, revisar os juros)" }],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter auxílio com o empréstimo bancário realizado com a Caixa Econômica Federal${tx(st.bancDeseja) ? ` (${tx(st.bancDeseja)})` : " (especificar o que o(a) assistido(a) deseja)"}.` },
    { t: "texto", k: "contrato", titulo: "Qual é o número do contrato de empréstimo bancário realizado com a CEF?" },
    { t: "texto", k: "condicoes", titulo: "Quais as condições firmadas no contrato de empréstimo?", multi: true, ph: "Valor emprestado, número de parcelas, valor da parcela, taxa de juros" },
    { t: "texto", k: "descMensal", titulo: "Qual é o valor que está sendo descontado mensalmente?", ph: "R$" },
    RENEG_CEF, JUROS,
    { t: "texto", k: "proposta", titulo: "Qual a proposta que o(a) assistido(a) tem a oferecer? Qual valor poderá pagar mensalmente sem comprometer a sua subsistência?", multi: true },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "habitacional", rot: "Contratos habitacionais (SFH/MCMV/PAR)", dem: ["Financiamento habitacional"], itens: [
    { t: "pretensao", campos: [{ k: "habDeseja", label: "O que o(a) assistido(a) deseja? (ex.: renegociar parcelas atrasadas, evitar a perda do imóvel)" }],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter auxílio com o financiamento habitacional realizado com a Caixa Econômica Federal${tx(st.habDeseja) ? ` (${tx(st.habDeseja)})` : " (especificar o que o(a) assistido(a) deseja)"}.` },
    { t: "texto", k: "contrato", titulo: "Qual é o número do contrato de financiamento habitacional realizado com a CEF?" },
    { t: "texto", k: "condicoes", titulo: "Quais as condições firmadas no contrato de financiamento habitacional?", multi: true, ph: "Programa (MCMV, PAR, SFH), valor financiado, prazo, valor da parcela" },
    { t: "texto", k: "descMensal", titulo: "Qual é o valor que está sendo descontado mensalmente?", ph: "R$" },
    RENEG_CEF, JUROS,
    { t: "texto", k: "proposta", titulo: "Qual a proposta que o(a) assistido(a) tem a oferecer? Qual valor poderá pagar mensalmente sem comprometer a sua subsistência?", multi: true },
    CITACAO("citacao", false, "mandado de citação", "Informar o número do processo judicial, a chave e quando recebeu a citação."),
    { t: "opcoes", k: "notifCart", titulo: "O/A assistido(a) recebeu alguma notificação do cartório de registro de imóveis?", oque: "consolidacao", ops: [
      { v: "Sim", rot: "Sim.", campos: [{ k: "notifQuando", label: "Quando recebeu a notificação?" }, { k: "notifPagar", label: "Há possibilidade de pagamento do valor indicado na notificação?" }],
        fmt: st => [tx(st.notifQuando) && `Recebida em ${tx(st.notifQuando)}.`, tx(st.notifPagar) && `Possibilidade de pagamento do valor indicado: ${tx(st.notifPagar)}`].filter(Boolean).join(" "),
        aviso: "A notificação do cartório dá prazo curto (em regra, 15 dias) para pagar as parcelas atrasadas; sem pagamento, a CEF pode consolidar a propriedade do imóvel. Leve o caso ao Defensor com urgência." },
      { v: "Não", rot: "Não." }] },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "fies", rot: "Financiamento estudantil (FIES/PROUNI)", dem: ["Financiamento estudantil"], itens: [
    { t: "pretensao", campos: [{ k: "fiesDeseja", label: "O que o(a) assistido(a) deseja? (ex.: renegociar a dívida, liberar o aditamento)" }],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter auxílio com o financiamento estudantil${tx(st.fiesDeseja) ? ` (${tx(st.fiesDeseja)})` : " (especificar o que o(a) assistido(a) deseja)"}.` },
    { t: "texto", k: "contrato", titulo: "Qual é o número do contrato de financiamento educacional?" },
    { t: "texto", k: "condicoes", titulo: "Quais as condições firmadas no contrato de financiamento educacional?", multi: true },
    { t: "texto", k: "fiesInst", titulo: "Há contrato com qual instituição de ensino?" },
    { t: "texto", k: "fiesIndef", titulo: "Qual o motivo do indeferimento da instituição de ensino?", opcional: true, ph: "Deixe em branco se não houve indeferimento" },
    JUROS,
    { t: "opcoes", k: "renegBanco", titulo: "O/A assistido(a) já tentou renegociação com o banco?", ops: [
      { v: "Sim", rot: "Sim. Qual a proposta apresentada pela instituição?", campos: [{ k: "renegBancoResp", label: "Qual a proposta apresentada pela instituição?" }] }, { v: "Não", rot: "Não." }] },
    { t: "texto", k: "proposta", titulo: "Qual a proposta que o(a) assistido(a) tem a oferecer?", multi: true },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "nacionalidade", rot: "Nacionalidade brasileira", dem: ["Reconhecimento de nacionalidade brasileira"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter o reconhecimento da nacionalidade brasileira.", oque: "nacionalidade" },
    { t: "opcoes", k: "paisBR", titulo: "Os genitores do(a) assistido(a) possuem nacionalidade brasileira?", ops: [
      { v: "Sim", rot: "Sim. Há documentos comprobatórios? Quais?", campos: [{ k: "paisDocs", label: "Quais documentos?" }] }, { v: "Não", rot: "Não." }] },
    SIMNAO("certEstr", "O/A assistido(a) possui certidão de nascimento do país de origem, com tradução pública do documento?"),
    { t: "texto", k: "tempoBR", titulo: "O(A) assistido(a) está residindo há quanto tempo no Brasil?" },
    { t: "opcoes", k: "docsResid", titulo: "Há documentos que comprovem o tempo de residência no Brasil?", ops: [
      { v: "Sim", rot: "Sim. Quais?", campos: [{ k: "docsResidQuais", label: "Quais?" }] }, { v: "Não", rot: "Não." }] },
    SIMNAO("portugues", "O(A) assistido(a) fala a língua portuguesa?"),
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "fgtslib", rot: "FGTS/PIS – liberação de valores", dem: ["FGTS e PIS"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter a liberação dos valores relativos ao seu FGTS/PIS.", oque: "fgts" },
    { t: "opcoes", k: "fgtsBloq", titulo: "Os valores do FGTS/PIS foram bloqueados?", ops: [
      { v: "Sim", rot: "Sim. Por qual motivo?", campos: [{ k: "fgtsBloqMotivo", label: "Por qual motivo?" }] }, { v: "Não", rot: "Não." }] },
    { t: "texto", k: "relato", titulo: "Relato do caso:", multi: true },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "fgtscor", rot: "FGTS – correção pela inflação (arquivamento)", dem: ["FGTS e PIS"], semCabecalho: true,
    guia: "Use este modelo quando a pessoa quer corrigir o saldo do FGTS por outro índice no lugar da TR (“revisão do FGTS”). A pretensão é inviável e o PAJ é arquivado: entregue cópia da Ata ao(à) assistido(a).", itens: [
    { t: "fixo", texto: () => FGTS_COR }] },

  { id: "saque", rot: "FGTS/PIS – ressarcimento de saque indevido", dem: ["Saque indevido do FGTS ou do PIS"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter o ressarcimento de saque indevido do seu FGTS/PIS." },
    { t: "texto", k: "relato", titulo: "Relato do caso:", multi: true },
    SIMNAO("tentouCEF", "O(A) assistido(a) já tentou obter o ressarcimento diretamente na Caixa Econômica Federal?"),
    { t: "opcoes", k: "recusaCEF", titulo: "Houve indeferimento (recusa) da CEF em realizar o ressarcimento?", ops: [
      { v: "Sim", rot: "Sim. Por qual motivo?", campos: [{ k: "recusaMotivo", label: "Por qual motivo?" }] }, { v: "Não", rot: "Não." }] },
    SIMNAO("provasSaque", "O(A) assistido(a) possui provas (extratos, etc.) do saque indevido?"),
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "dpvat", rot: "Seguro DPVAT", dem: ["Seguro DPVAT (acidentes até 14/11/2023)"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter o Seguro DPVAT.", oque: "dpvat" },
    { t: "texto", k: "acidente", titulo: "Quando e de que forma ocorreu o acidente? (Observar informações do registro de ocorrência).", multi: true,
      ajuda: "O DPVAT cobre acidentes ocorridos até 14/11/2023 e é pedido à Caixa. O prazo para cobrar a indenização na Justiça é de 3 anos (Súmula 405 do STJ)." },
    SIMNAO("dpvatCEF", "O Seguro DPVAT foi solicitado junto à CEF?"),
    { t: "texto", k: "dpvatMotivo", titulo: "Por qual motivo não foi concedido o Seguro DPVAT pela CEF?", opcional: true },
    { t: "texto", k: "dpvatLaudos", titulo: "Há laudos e comprovantes das despesas médicas provocadas pelo acidente?", multi: true },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "diversos", rot: "Casos diversos", dem: ["Outros casos", "Auxílio Reconstrução", "Alvará judicial", "Permanência no país (refúgio)", "Ressarcimento de gastos com saúde particular"], itens: [
    { t: "pretensao", campos: [{ k: "divPret", label: "Qual a pretensão? (o que o(a) assistido(a) quer obter)" }],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter auxílio com ${tx(st.divPret) || (S.dem && S.dem.nome !== "Outros casos" ? S.dem.nome.toLowerCase() : "(indicar a pretensão)")}.` },
    { t: "texto", k: "relato", titulo: "Relato do caso (relatar o máximo de informações possíveis):", multi: true },
    SIMNAO("tentouAdm", "O(A) assistido(a) já tentou solucionar o caso de forma administrativa (diretamente com o órgão/instituição/local em que ocorreu o fato que relata)?"),
    { t: "opcoes", k: "negou", titulo: "O órgão/instituição/local em que ocorreu o fato se negou a resolver o caso?", ops: [
      { v: "Sim", rot: "Sim. Por qual motivo? Há negativa/indeferimento?", campos: [{ k: "negouMotivo", label: "Por qual motivo? Há negativa/indeferimento?" }] }, { v: "Não", rot: "Não." }] },
    ...FIM("Informações importantes que o(a) assistido(a) comunicar acerca do caso.")] },

  { id: "estadual", rot: "Matéria estadual (encaminhamento)", dem: ["Outros casos"], semCabecalho: true, semAtend: true,
    guia: "Use quando o assunto é da Justiça Estadual (ex.: família, inventário, aluguel, consumo contra empresa privada). A pessoa é encaminhada à DPE e às assistências judiciárias das universidades.", itens: [
    { t: "fixo", campos: [{ k: "estAssunto", label: "Qual o assunto?" }],
      texto: st => `O/A assistido(a) compareceu para obter auxílio em matéria cuja competência é da Justiça Estadual (${tx(st.estAssunto) || "indicar o assunto"}). Foi encaminhado(a) à DPE e às assistências judiciárias das universidades.\nPAJ instaurado para fins estatísticos.` }] },

  { id: "trabalhista", rot: "Matéria trabalhista (encaminhamento)", dem: ["Outros casos"], semCabecalho: true, semAtend: true,
    guia: "Use quando o assunto é trabalhista (verbas rescisórias, vínculo com o patrão, etc.). A DPU Pelotas não atua nessas demandas.", itens: [
    { t: "fixo", texto: () => "O/A assistido(a) compareceu para obter auxílio em matéria trabalhista. Em razão do Despacho nº 367 - DPU/GABDPGF DPGU (SEI 0636272), que restringe a atuação da DPU Pelotas em demandas trabalhistas, foi encaminhado(a) à Justiça do Trabalho e às assistências judiciárias das universidades.\nPAJ instaurado para fins estatísticos." }] },

  { id: "servico", rot: "Só ajuda com serviço público (gov.br, Meu INSS…)", dem: ["Outros casos"], semCabecalho: true, semAtend: true,
    guia: "Use quando a pessoa veio só pedir ajuda com um serviço público (senha do gov.br, Meu INSS, agendamento no INSS, CadÚnico…), sem caso para a DPU acompanhar.", itens: [
    { t: "fixo", campos: [{ k: "svServico", label: "Com o que pediu ajuda?", ph: "Ex.: recuperar a senha do gov.br" }, { k: "svFeito", label: "O que foi feito (opcional)", ph: "Ex.: foi orientado(a) a procurar o INSS" }],
      texto: st => `O/A assistido(a) compareceu apenas para pedir ajuda com serviço público (${tx(st.svServico) || "indicar o serviço"}), sem demanda que exija atuação judicial ou extrajudicial da DPU.${tx(st.svFeito) ? " " + frase(tx(st.svFeito)) : ""}\nPAJ instaurado para fins estatísticos.` }] },

  { id: "duvida", rot: "Só dúvida jurídica (orientação)", dem: ["Outros casos"], semCabecalho: true, semAtend: true,
    guia: "Use quando a pessoa veio só tirar uma dúvida jurídica e recebeu a orientação, sem caso para a DPU acompanhar.", itens: [
    { t: "fixo", campos: [{ k: "dvAssunto", label: "Sobre o que era a dúvida?" }],
      texto: st => `O/A assistido(a) compareceu para esclarecer dúvida jurídica (${tx(st.dvAssunto) || "indicar o assunto"}). Foram prestadas as orientações jurídicas, sem necessidade de outra atuação da DPU.\nPAJ instaurado para fins estatísticos.` }] },

  { id: "desistencia", rot: "Desistência", dem: ["Outros casos"], semCabecalho: true, semAtend: true,
    guia: "Use quando a pessoa informou que não quer mais seguir com o pedido.", itens: [
    { t: "fixo", campos: [{ k: "deAssunto", label: "Qual era a demanda?" }],
      texto: st => `O/A assistido(a) informou que não tem mais interesse em prosseguir com a demanda (${tx(st.deAssunto) || "indicar a demanda"}).\nPAJ instaurado para fins estatísticos.` }] },

  { id: "advogado", rot: "Já tem advogado(a)", dem: ["Outros casos"], semCabecalho: true, semAtend: true,
    guia: "Use quando a pessoa informou que já tem advogado(a) para o mesmo caso.", itens: [
    { t: "fixo", campos: [{ k: "adAssunto", label: "Qual a demanda?" }],
      texto: st => `O/A assistido(a) informou que já possui advogado(a) constituído(a) para a demanda (${tx(st.adAssunto) || "indicar a demanda"}), razão pela qual não há atuação da DPU no caso.\nPAJ instaurado para fins estatísticos.` }] },

  /* ===== Saúde ===== */
  ...MEDICAMENTOS,

  { id: "exames", rot: "Exames, consultas e cirurgias", dem: ["Cirurgia", "Consulta com especialista", "Exame", "Tratamento"], itens: [
    { t: "pretensao", multi: true, ops: ["cirurgia", "consulta", "exame(s)", "tratamento"],
      frase: st => `O/A requerente busca a assistência jurídica da DPU com a pretensão de obter ${(st.pret || []).length ? st.pret.join("/") : "cirurgia/consulta/exames"} pelo Sistema Único de Saúde – SUS (exceto oncológico).` },
    { t: "texto", k: "proced", multi: true, oque: "sigtap", titulo: `Consulta/exame/cirurgia pretendida/o (de acordo com o documento de prescrição médica apresentado pelo/a requerente e pesquisa por “Nome” no Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS - SIGTAP no sítio eletrônico do Ministério da Saúde ${LINK_SIGTAP}):`,
      ajuda: `Confira o nome no ${aLink(LINK_SIGTAP, "SIGTAP")}.`, ph: "Nome da cirurgia, da especialidade da consulta ou do exame" },
    { t: "texto", k: "orcamento", ph: "R$", titulo: `Orçamento (de acordo com orçamentos apresentados pelo/a requerente ou com o campo “Valores” resultante da pesquisa no SIGTAP no sítio eletrônico do Ministério da Saúde ${LINK_SIGTAP}):` },
    CID_SAUDE,
    LOCAL("localEnc", "Local onde recebeu o encaminhamento para consulta/exame/cirurgia:"),
    INTERNADO, URGENCIA,
    { t: "opcoes", k: "regul", oque: "regulacao", titulo: "Houve inserção da solicitação da consulta/exame/cirurgia no sistema de regulação, ou outra forma de solicitação administrativa junto ao SUS?", ops: [
      { v: "Sim", rot: "Sim." }, { v: "Não", rot: "Não. Qual o motivo?", campos: [{ k: "regulMotivo", label: "Qual o motivo?" }] }] },
    ...FIM("Informações relevantes que estejam descritas no atestado ou formulário médico.")] },

  { id: "internacao", rot: "Internações e transferências hospitalares", dem: ["Internação ou transferência hospitalar"], itens: [
    { t: "pretensao", fixa: true, frase: () => "O/A requerente busca a assistência jurídica da DPU com a pretensão de obter internação/transferência hospitalar na rede do Sistema Único de Saúde – SUS (exceto oncológico)." },
    CID_SAUDE,
    { t: "texto", k: "descDoenca", titulo: "Sucinta descrição da doença ou do estado de saúde:", multi: true },
    LOCAL("localEnc", "Local onde recebeu o encaminhamento para internação/transferência:"),
    INTERNADO, URGENCIA,
    { t: "opcoes", k: "regul", oque: "regulacao", titulo: "Houve inserção da solicitação da internação/transferência no sistema de regulação, ou outra forma de solicitação administrativa junto ao SUS?", ops: [
      { v: "Sim", rot: "Sim. Em que órgão de saúde?", campos: [{ k: "regulOnde", label: "Em que órgão de saúde?" }] }, { v: "Não", rot: "Não. Qual o motivo?", campos: [{ k: "regulMotivo", label: "Qual o motivo?" }] }] },
    ...FIM("Informações relevantes que estejam descritas na solicitação médica.")] },

  { id: "tfd", rot: "Tratamento Fora de Domicílio (TFD)", dem: ["Tratamento fora do domicílio (TFD)"], itens: [
    { t: "pretensao", fixa: true, oque: "tfd", frase: () => "O/a requerente busca a assistência jurídica da DPU com a pretensão de obter tratamento de saúde por meio de Tratamento Fora de Domicílio – TFD (Portaria SAS/MS nº 55/1999, consolidada na Portaria de Consolidação SAES/MS nº 1/2022) no Sistema Único de Saúde – SUS, pois é portador/a de doença(s) não tratável(eis) no município/estado de origem por falta de condições técnicas." },
    { t: "opcoes", k: "tfdTrat", multi: true, col: true, titulo: "Qual(is) o(s) tratamento(s) médico(s) prescrito(s)?", ops: [
      { v: "Consulta/exame/cirurgia", rot: `Consulta/exame/cirurgia pretendida/o (de acordo com o documento de prescrição médica apresentado pelo/a requerente e pesquisa por “Nome” no Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS - SIGTAP no sítio eletrônico do Ministério da Saúde ${LINK_SIGTAP}):`,
        ajuda: `Confira o nome no ${aLink(LINK_SIGTAP, "SIGTAP")}.`, campos: [{ k: "tfdProc", label: "Nome do exame, da cirurgia ou da especialidade da consulta" }] },
      { v: "Internação ou transferência hospitalar", rot: "Internação ou transferência hospitalar:", campos: [{ k: "tfdInt", label: "Detalhe" }] }] },
    { t: "opcoes", k: "tfdDesp", multi: true, col: true, titulo: "Qual(is) despesa(s) necessita(m) de cobertura?", ops: ["transporte aéreo", "transporte terrestre", "transporte fluvial", "diárias para pernoite", "ajuda de custo para alimentação para paciente", "ajuda de custo para alimentação de acompanhante, se houver"].map(v => ({ v, rot: v })) },
    { t: "opcoes", k: "tfdAgend", titulo: "O tratamento médico já está agendado?", ops: [
      { v: "Sim", rot: "Sim. Em qual unidade de saúde e de que Município/Estado?", campos: [{ k: "tfdOnde", label: "Unidade de saúde e Município/Estado" }] }, { v: "Não", rot: "Não." }] },
    CID_SAUDE,
    { t: "opcoes", k: "tfdEsgot", titulo: "Foram esgotados os meios de tratamento na localidade de residência do/a requerente?", ops: [
      { v: "Sim", rot: "Sim." }, { v: "Não", rot: "Não. Por qual motivo?", campos: [{ k: "tfdEsgotMotivo", label: "Por qual motivo?" }] }] },
    SIMNAO("tfdAcomp", "O laudo médico prescreve e justifica a necessidade de acompanhamento, de acordo com o caso e as condições do/a paciente?"),
    ...FIM("Informações relevantes que estejam descritas na solicitação médica.")] },

  /* ===== Criminal ===== */
  { id: "criminal", rot: "Criminal", dem: ["Defesa em processo criminal", "Audiência de acordo de não persecução penal (ANPP)"], itens: [
    { t: "opcoes", k: "preso", titulo: "Assistido(a) preso(a)?", ops: [{ v: "SIM", rot: "SIM." }, { v: "NÃO", rot: "NÃO." }] },
    { t: "opcoes", k: "quemAtend", titulo: "Quem foi atendido:", ops: [{ v: "O(A) próprio(a) assistido(a)", rot: "O(A) próprio(a) assistido(a)" }, { v: "Representante ou terceiro(a)", rot: "Representante ou terceiro(a)" }] },
    { t: "renda" }, { t: "processo", tribunal: "JFRS", k: "eproc" }, { t: "irpf" },
    { t: "opcoes", k: "antec", titulo: "Possui antecedentes criminais?", oque: "antecedentes", ops: [
      { v: "Sim", rot: "Sim. Informar processos judiciais, caso o(a) assistido(a) lembre.", campos: [{ k: "antecProc", label: "Processos judiciais (se o(a) assistido(a) lembrar)" }] }, { v: "Não", rot: "Não." }] },
    { t: "texto", k: "acusacao", titulo: "Do que está sendo acusado(a)?", multi: true },
    { t: "texto", k: "dataFatos", titulo: "Data dos fatos (do crime):", ph: "dd/mm/aaaa" },
    { t: "texto", k: "crime", titulo: "Qual o crime (nomenclatura – se tiver, art., lei)?", ph: "Ex.: descaminho (art. 334 do Código Penal)" },
    { t: "opcoes", k: "tipoProc", titulo: "Qual o tipo do processo?", ops: [
      { v: "Inquérito policial", rot: "Inquérito policial." }, { v: "Processo judicial – acusação criminal", rot: "Processo judicial – acusação criminal (ação penal)." },
      { v: "Execução penal", rot: "Execução penal." }, { v: "Outro", rot: "Outro:", campos: [{ k: "tipoProcOutro", label: "Qual?" }] }] },
    { t: "campos", k: "crimProc", titulo: "Qual o número do processo? E a chave?", oque: "chave", campos: [{ k: "crimNum", label: "Número do processo", rot: "Número:" }, { k: "crimChave", label: "Chave do processo", rot: "Chave:" }] },
    { t: "texto", k: "vara", titulo: "Qual a vara/delegacia em que tramita?" },
    { t: "texto", k: "citCrime", titulo: "Quando recebeu a citação/intimação?", oque: "citacao" },
    { t: "opcoes", k: "audiencia", titulo: "Há audiência agendada? Para quando?", ops: [
      { v: "Sim", rot: "Sim. Data:", campos: [{ k: "audData", label: "Data e hora da audiência" }] }, { v: "Não", rot: "Não." }] },
    { t: "opcoes", k: "verdade", titulo: "A acusação é verdadeira?", ops: [{ v: "Sim", rot: "Sim." }, { v: "Não", rot: "Não." }, { v: "Em parte", rot: "Em parte." }] },
    { t: "texto", k: "versao", titulo: "Se a acusação não é verdadeira, ou apenas em parte, relate abaixo a versão dos fatos do(a) assistido(a):", multi: true, opcional: true },
    { t: "texto", k: "docsVersao", titulo: "Se tiver documentos que comprovem a versão dos fatos do(a) assistido(a), especificar:", multi: true, opcional: true },
    { t: "texto", k: "testDefesa", titulo: "Se tiver testemunhas que possam comprovar a versão dos fatos do(a) assistido(a), informar o nome completo, endereço e telefones de cada uma (até 8 por fato a ser provado). (Testemunhas de mera conduta ou parentes próximos, em regra, não são admitidas).", multi: true, opcional: true },
    { t: "texto", k: "testDiz", titulo: "O que cada testemunha de defesa pode dizer sobre os acontecimentos?", multi: true, opcional: true },
    { t: "texto", k: "testAcus", titulo: "Conhece as testemunhas de acusação? O que pode dizer sobre elas?", multi: true, opcional: true },
    { t: "opcoes", k: "acordo", col: true, oque: "anpp", titulo: "Se recebeu notificação/intimação com alguma proposta de acordo, informar se o(a) assistido(a) tem interesse e condições de aceitar a proposta, tal como apresentada.", ops: [
      { v: "Contraproposta", rot: "Resposta: Sim, recebi uma proposta e tenho interesse, mas não tenho condições de aceitá-la, no momento. Gostaria de fazer uma contraproposta dentro das minhas possibilidades." },
      { v: "Aceita", rot: "Resposta: Sim, recebi uma proposta e tenho interesse em aceitá-la no momento." },
      { v: "Não recebeu", rot: "Não recebeu proposta de acordo." }] },
    { t: "texto", k: "contraprop", titulo: "Caso não tenha condições de cumprir alguma(s) das condições da proposta original, o(a) assistido(a) deve indicar os motivos (e documentos que os comprovem) e a eventual contraproposta:", multi: true, opcional: true },
    { t: "campos", k: "execPenal", opcional: true, titulo: "Em caso de execução penal, informe as penas a que o(a) assistido(a) foi condenado(a):", campos: [
      { k: "epTipo", label: "Tipo de pena (reclusão ou detenção) e regime (fechado, semiaberto ou aberto)", rot: "Tipo de pena (reclusão ou detenção) e regime:" },
      { k: "epTempo", label: "Anos, meses e dias", rot: "Anos, meses e dias:" },
      { k: "epSubst", label: "Substituição por penas restritivas de direitos?", rot: "Substituição por penas restritivas de direitos?" },
      { k: "epMulta", label: "Multa: R$ (se parcelada, número de parcelas e valor mensal)", rot: "Multa: R$" },
      { k: "epPrest", label: "Prestação pecuniária: R$ (se parcelada, número de parcelas e valor mensal)", rot: "Prestação pecuniária: R$" },
      { k: "epServ", label: "Prestação de serviços", rot: "Prestação de serviços:" },
      { k: "epPerda", label: "Perda de bens/valores – quais?", rot: "Perda de bens/valores – quais?" },
      { k: "epInterd", label: "Interdição temporária de direitos", rot: "Interdição temporária de direitos:" },
      { k: "epLimit", label: "Limitação de fim de semana", rot: "Limitação de fim de semana:" },
      { k: "epProblema", label: "Problema para o cumprimento de alguma das penas", rot: "Caso o(a) assistido(a) tenha problema para o cumprimento de alguma das penas, especificar:", multi: true }] },
    { t: "texto", k: "compl", titulo: "Neste campo, insira quaisquer outras informações complementares que julgar importantes:", multi: true, opcional: true },
    { t: "pagar" }, { t: "completa", longo: true }] },

  /* ===== Para qualquer demanda ===== */
  { id: "naocomp", rot: "Não comparecimento (fins estatísticos)", todas: true, semCabecalho: true, semAtend: true,
    guia: "Use quando o(a) assistido(a) não compareceu ao atendimento agendado: o PAJ é instaurado só para fins estatísticos.", itens: [
    { t: "fixo", ops: { k: "ncModo", titulo: "Atendimento agendado", vs: ["presencial", "virtual"] },
      campos: [{ k: "ncData", label: "Data do atendimento", ph: "dd/mm/aaaa" }, { k: "ncHora", label: "Horário", ph: "Ex.: 14h" }],
      texto: st => `O(A) assistido(a) não compareceu ao atendimento ${st.ncModo || "presencial/virtual"} agendado para o dia ${tx(st.ncData) || "__/__/____"} às ${tx(st.ncHora) || "__h"}.\nPAJ instaurado para fins estatísticos.` }] },
];
// itens prontos usados em várias narrativas
const PRONTOS = {
  irpf: { t: "opcoes", k: "irpf", oque: "irpf", titulo: "Pesquisa IRPF do(a) assistido(a) (anexar ao PAJ a consulta realizada):", col: true,
    ajuda: 'Faça a consulta em <a href="https://www.restituicao.receita.fazenda.gov.br" target="_blank" rel="noopener">Receita Federal – consulta da restituição do Imposto de Renda</a>.',
    ops: [{ v: "Declara", rot: "O(A) assistido(a) declara Imposto de Renda.", form: "O(A) assistido(a) declara Imposto de Renda. Nesse caso, solicitar que envie declaração completa do IRPF." },
          { v: "Não declara", rot: "O(A) assistido(a) não declara Imposto de Renda." }] },
  pagar: { t: "opcoes", k: "pagar", oque: "gratuidade", titulo: "Se com a assistência da DPU você ganhar o processo, terá que pagar algo a alguém?", ops: [
    { v: "SIM", rot: "SIM.", vermelho: true, campos: [{ k: "pagarQuem", label: "Quem e quanto?" }],
      aviso: "Explique ao(à) assistido(a) que o atendimento da Defensoria é gratuito e que ninguém pode cobrar por ele, nem intermediários." },
    { v: "NÃO", rot: "NÃO." }] },
  completa: longo => ({ t: "opcoes", k: "completa", titulo: "Essa narrativa está completamente preenchida?", ops: [
    { v: "SIM", rot: "SIM." },
    { v: "NÃO", rot: longo ? NAO_LONGO : "NÃO.", form: "NÃO", aviso: "A pendência “edição da narrativa/gerar redução a termo” entra sozinha na lista de documentação pendente do PAJ." }] }),
};
const expandir = it => it.t === "irpf" ? PRONTOS.irpf : it.t === "pagar" ? PRONTOS.pagar : it.t === "completa" ? PRONTOS.completa(it.longo) : it;
const novoEstadoNarr = () => ({ membros: [{}], prio: [], cids: [], sozinho: false, extras: [] });
function estadoNarr(id) { return S.nv[id] || (S.nv[id] = novoEstadoNarr()); }
const frase = t => { t = t.charAt(0).toUpperCase() + t.slice(1); return /[.!?]$/.test(t) ? t : t + "."; };  // frase digitada: maiúscula no início e ponto no fim
const PARA_TODAS = NARRATIVAS.filter(n => n.todas);
function variantes(dem) { return dem ? [...NARRATIVAS.filter(n => !n.todas && n.dem.includes(dem.nome)), ...PARA_TODAS] : []; }
function narrDaDemanda() {  // a demanda pode ter mais de um modelo de narrativa: vale o escolhido nas abas, ou o primeiro
  const vs = variantes(S.dem); if (!vs.length) return null;
  return vs.find(n => n.id === S.narrVar[S.dem.nome]) || (vs.length > PARA_TODAS.length ? vs[0] : null);
}
const itensDe = d => d.itens.map(expandir).filter(it => !it.soDem || (S.dem && it.soDem.includes(S.dem.nome)));
const COMUNS = ["prof", "renda", "fonte", "sozinho", "membros", "desp", "despesas", "prio", "prioTocado", "repr", "reprComp", "reprMotivo", "reprPorque", "par", "parOutro", "repNome", "repCpf",
  "eproc", "procNum", "procVara", "procChave", "procOutro", "irpf", "pagar", "cids", "indef", "indefMotivo", "nb"];
function trocarVariante(n) {  // o que já foi respondido de comum (renda, prioridade, representação…) acompanha a troca de modelo
  const ant = S.n, novo = !S.nv[n.id];
  S.narrVar[S.dem.nome] = n.id;
  const st = estadoNarr(n.id);
  if (novo && ant) COMUNS.forEach(k => { if (ant[k] !== undefined) st[k] = JSON.parse(JSON.stringify(ant[k])); });
  mostrarNarrativa(); if (S.ck) sincNarrCk(); chips();
}
const plural = () => { const d = narrDaDemanda(); return !!(d && d.varios && S.n.extras && S.n.extras.length); };
const valTitulo = (t, pl) => typeof t === "function" ? t(pl) : t;

/* ----- formulário ----- */
const NF = $("narrForm");
let CONDS = [];
const cond = fn => { CONDS.push(fn); return ` data-cond="${CONDS.length - 1}"`; };
const campoHTML = (c, extra = "") => c.multi
  ? `<label class="f sub"${extra}>${esc(c.label)}<textarea data-n="${c.k}"${c.ph ? ` placeholder="${esc(c.ph)}"` : ""}></textarea></label>`
  : `<label class="f sub"${extra}>${esc(c.label)}<input type="text" data-n="${c.k}"${c.lista ? ` list="${c.lista}"` : ""}${c.ph ? ` placeholder="${esc(c.ph)}"` : ""} autocomplete="off"></label>`;
const oqueBt = k => k ? ` <button type="button" class="oque" data-oque="${k}" title="Abre uma explicação em outra guia">O que é isso?</button>` : "";
const tituloHTML = (n, t, oq) => `<div class="t"><span class="num">${n}.</span>${esc(t)}${oqueBt(oq)}</div>`;
const ajudaHTML = it => it.ajuda ? `<div style="font-size:13.5px;margin-bottom:8px">${it.ajuda}</div>` : "";
let FIXOS = [];
function formItem(it, n, pl) {
  switch (it.t) {
    case "pretensao":
      if (it.livre) return `<div class="q">${tituloHTML(n, "Pretensão", it.oque)}${ajudaHTML(it)}<textarea data-n="pretTexto" placeholder="${esc(it.ph || "")}"></textarea></div>`;
      if (it.fixa) return `<div class="q">${tituloHTML(n, "Pretensão", it.oque)}${ajudaHTML(it)}<div class="sub2" data-frase="1"></div></div>`;
      return `<div class="q">${tituloHTML(n, "Pretensão", it.oque)}${ajudaHTML(it)}${it.ops ? `<div class="op">${it.ops.map(o => `<label><input type="${it.multi ? "checkbox" : "radio"}" name="n_pret" data-n="pret"${it.multi ? " data-multi" : ""} value="${o}"> ${o}</label>`).join("")}</div>` : ""}
        ${(it.campos || []).map(c => campoHTML(c)).join("")}${it.campos || it.multi ? `<div class="sub2" data-frase="1" style="margin-top:8px"></div>` : ""}</div>`;
    case "cid":
      return `<div class="q">${tituloHTML(n, "Doença com Código Internacional de Doenças - CID (de acordo com o laudo médico apresentado pelo/a requerente)", "cid")}
        <div class="op versao"><label><input type="radio" name="n_cidv" value="10" data-fixo${cidV === "10" ? " checked" : ""}> CID-10</label><label><input type="radio" name="n_cidv" value="11" data-fixo${cidV === "11" ? " checked" : ""}> CID-11</label></div>
        <div class="combo"><input type="text" id="cidBusca" placeholder="Digite o código ou o nome da doença (ex.: depressão, autismo, câncer de mama) e escolha na lista" autocomplete="off"><div class="lista" id="cidLista"></div></div>
        <div id="cid11Aviso" class="aviso hide">O catálogo do CID-11 em português ainda não foi incluído no assistente. Por enquanto, digite o código e o nome da doença como estão no atestado e aperte Enter.</div>
        <div class="tags" id="cidTags"></div>
        <div style="font-size:12.5px;color:var(--gray);margin-top:6px">Pode acrescentar quantos CIDs forem necessários, conforme os documentos médicos.</div>
        <div style="font-size:12px;color:var(--gray);margin-top:4px">CID-10: tabela do DATASUS. CID-11: tradução oficial da OMS para o português (versão de janeiro de 2026).</div></div>`;
    case "texto":
      return `<div class="q">${tituloHTML(n, valTitulo(it.titulo, pl), it.oque)}${ajudaHTML(it)}${it.multi ? `<textarea data-n="${it.k}" style="min-height:90px"${it.ph ? ` placeholder="${esc(it.ph)}"` : ""}></textarea>`
        : `<input type="text" data-n="${it.k}"${it.ph ? ` placeholder="${esc(it.ph)}"` : ""} autocomplete="off">`}</div>`;
    case "opcoes": {
      const tipo = it.multi ? "checkbox" : "radio";
      let h = `<div class="q">${tituloHTML(n, valTitulo(it.titulo, pl), it.oque)}${ajudaHTML(it)}
        <div class="op${it.col || it.ops.some(o => (o.form || o.rot).length > 60) ? " col" : ""}">${it.ops.map(o => `<label${o.vermelho ? ' class="vermelho"' : ""}><input type="${tipo}" name="n_${it.k}" data-n="${it.k}"${it.multi ? " data-multi" : ""} value="${esc(o.v)}"> ${esc(o.form || o.v)}</label>`).join("")}</div>`;
      it.ops.forEach(o => {
        const sel = st => it.multi ? (st[it.k] || []).includes(o.v) : st[it.k] === o.v;
        const partes = [];
        if (o.ajuda) partes.push(`<div style="font-size:13px;margin-top:6px">${o.ajuda}</div>`);
        (o.campos || []).forEach(c => partes.push(campoHTML(c)));
        (o.linhas || []).forEach(c => partes.push(campoHTML({ ...c, multi: c.lista })));
        if (o.apos) partes.push(campoHTML(o.apos));
        if (o.sub) partes.push(`<div class="sub"><div style="font-size:14px;margin-bottom:6px">${esc(o.sub.pergunta)}</div><div class="op">${o.sub.ops.map(s => `<label><input type="radio" name="n_${o.sub.k}" data-n="${o.sub.k}" value="${esc(s)}"> ${esc(s.replace(/\.$/, ""))}</label>`).join("")}</div></div>`);
        if (o.aviso) partes.push(`<div class="aviso sub">${esc(o.aviso)}</div>`);
        if (partes.length) h += `<div class="sub"${cond(sel)}>${it.multi ? `<div style="font-weight:600;font-size:13.5px;color:var(--green)">${esc(o.v)}</div>` : ""}${partes.join("")}</div>`;
      });
      if (it.obs) h += campoHTML({ k: it.obs.k, label: it.obs.rot.replace(/:$/, "") });
      return h + "</div>";
    }
    case "renda":
      return `<div class="q">${tituloHTML(n, valTitulo(it.titulo, pl) || (pl ? "Renda bruta dos(as) assistidos(as) e do grupo familiar que reside no mesmo domicílio" : it.fem ? "Renda bruta da assistida e do grupo familiar que reside no mesmo domicílio" : "Renda bruta do(a) assistido(a) e do grupo familiar que reside no mesmo domicílio"), "renda")}
        <div style="font-weight:600;margin:4px 0 6px">${narrDaDemanda().varios ? "Assistido 1" : it.fem ? "Assistida" : "Assistido(a)"}</div>
        <div class="grid3">
          <label class="f">Profissão<input type="text" data-n="prof" autocomplete="off"></label>
          <label class="f">Renda bruta mensal (R$)<input type="text" data-n="renda" data-money placeholder="0,00" autocomplete="off"></label>
          <label class="f">Fonte de renda<input type="text" data-n="fonte" list="fontes" autocomplete="off"></label>
        </div>
        ${narrDaDemanda().varios ? `<div id="extras"></div><button type="button" class="btn" id="addExtra" style="margin-top:8px">+ ADICIONAR ASSISTIDO</button>` : ""}
        <div style="font-weight:600;margin:14px 0 6px">Grupo familiar</div>
        <label class="cx" style="display:inline-flex"><input type="checkbox" data-n="sozinho"> ${narrDaDemanda().varios ? "Os assistidos residem sozinhos (sem outros membros)" : it.fem ? "Assistida reside sozinha" : "Assistido(a) reside sozinho(a)"}</label>
        <div${cond(st => !st.sozinho)}><div id="membros"></div><button type="button" class="btn" id="addMembro">+ ADICIONAR MEMBRO</button></div>
        <div class="total" id="rendaTotal"></div>
        <div class="sub">
          <div style="font-weight:600;margin:14px 0 6px">Despesas extraordinárias (quando a renda familiar mensal for superior a ${limTxt()})</div>
          <div class="op"><label><input type="radio" name="n_desp" data-n="desp" value="Sim"> Sim, possui</label><label><input type="radio" name="n_desp" data-n="desp" value="Não"> Não possui</label><label><input type="radio" name="n_desp" data-n="desp" value="Não se aplica"> Não se aplica</label></div>
          <div id="despDica" style="font-size:12.5px;color:var(--gray);margin-top:6px"></div>
          ${campoHTML({ k: "despesas", label: "Explique quais são as despesas, com os valores mensais", multi: true, ph: "Ex.: fisioterapia, R$ 300,00 por mês; medicamentos, R$ 250,00 por mês" }, cond(st => st.desp === "Sim"))}
        </div></div>`;
    case "prioridade":
      return `<div class="q">${tituloHTML(n, "Possui prioridade de tramitação (art. 1.048 CPC)?", "prioridade")}<div class="op">${PRIO.map(p => `<label><input type="checkbox" data-n="prio" data-multi value="${esc(p)}"> ${esc(p)}</label>`).join("")}</div>
        <div style="font-size:12.5px;color:var(--gray);margin-top:6px" id="prioDica"></div></div>`;
    case "representacao":
      return `<div class="q">${tituloHTML(n, pl ? "Os/As requerentes estão representados por outra pessoa?" : "O/A requerente está representado por outra pessoa?", "representacao")}
        <div class="op"><label><input type="radio" name="n_repr" data-n="repr" value="Sim"> Sim</label><label><input type="radio" name="n_repr" data-n="repr" value="Não"> Não</label></div>
        <div class="sub"${cond(st => st.repr === "Sim")}>
          <div style="font-size:14px;margin-bottom:6px">${pl ? "Os/As requerentes compareceram" : "O/A requerente compareceu"} ao atendimento?</div>
          <div class="op"><label><input type="radio" name="n_reprComp" data-n="reprComp" value="Não"> Não compareceu (veio só o representante)</label><label><input type="radio" name="n_reprComp" data-n="reprComp" value="Sim"> Compareceu junto com o representante</label></div>
          ${campoHTML({ k: "reprMotivo", label: "Motivo pelo qual o/a requerente não pode comparecer" }, cond(st => st.reprComp !== "Sim"))}
          ${campoHTML({ k: "reprPorque", label: "Motivo de ser representado(a) (ex.: assistido(a) curatelado(a), menor de idade)" })}
          <div style="font-weight:700;margin:12px 0 6px"><span style="color:var(--green)">${n}.1.</span> Grau de parentesco do/a representante</div>
          <div class="op">${PARENTESCO.map(p => `<label><input type="radio" name="n_par" data-n="par" value="${p}"> ${p}</label>`).join("")}</div>
          ${campoHTML({ k: "parOutro", label: "Especificar" }, cond(st => st.par === "outro"))}
          <div class="grid2 sub"><label class="f">Nome do(a) representante<input type="text" data-n="repNome" autocomplete="off"></label>
            <label class="f">CPF do(a) representante<input type="text" data-n="repCpf" data-mask="cpf" placeholder="000.000.000-00" autocomplete="off"></label></div>
        </div></div>`;
    case "processo": {
      const p = it.k === "eproc" ? "proc" : it.k + "_";
      return `<div class="q">${tituloHTML(n, `Pesquisa Eproc ${it.tribunal} com o CPF do(a) assistido(a) (anexar ao PAJ a consulta realizada)`, "eproc")}
        <div style="font-size:13.5px;margin-bottom:8px">${it.tribunal === "JFRS" ? `Abra o <a href="${LINK_EPROC.JFRS}" target="_blank" rel="noopener">eproc da JFRS</a>, entre com o seu login e, na <b>Consulta Processual</b>, pesquise pelo CPF do(a) assistido(a).` : `Entre no <a href="${LINK_EPROC.TJRS}" target="_blank" rel="noopener">eproc do TJRS</a> e pesquise pelo CPF do(a) assistido(a) na consulta processual.`} <b>Na consulta, marque sempre a opção “exibir baixados”</b>, para aparecerem também os processos já encerrados.</div>
        <div class="op col"><label><input type="radio" name="n_${it.k}" data-n="${it.k}" value="mesma"> Possui processo judicial com a mesma demanda pretendida no presente PAJ</label>
          <label><input type="radio" name="n_${it.k}" data-n="${it.k}" value="diferente"> Possui processo judicial com demanda distinta da pretendida no presente PAJ</label>
          <label><input type="radio" name="n_${it.k}" data-n="${it.k}" value="nenhum"> Não possui processo judicial</label></div>
        <div class="sub"${cond(st => st[it.k] === "mesma")}><div class="grid3">
          <label class="f">Processo nº<input type="text" data-n="${p}Num" autocomplete="off"></label><label class="f">Vara<input type="text" data-n="${p}Vara" autocomplete="off"></label><label class="f">Chave do processo<input type="text" data-n="${p}Chave" autocomplete="off"></label></div>
          <div style="font-size:12.5px;color:var(--gray);margin-top:6px">Informe o nº do processo e a vara em que tramita. Durante o atendimento, solicite a chave do processo judicial.</div></div>
        ${campoHTML({ k: p + "Outro", label: "Processo nº e assunto" }, cond(st => st[it.k] === "diferente"))}</div>`;
    }
    case "testemunhas":
      return `<div class="q">${tituloHTML(n, "Foram fornecidos os dados (nome completo, telefone e endereço) de 3 testemunhas?", "testemunhas")}
        <div class="op"><label><input type="radio" name="n_test" data-n="test" value="Sim"> Sim</label><label><input type="radio" name="n_test" data-n="test" value="Não"> Não</label></div>
        <div class="sub"${cond(st => st.test === "Sim")}>${[1, 2, 3].map(i => `<div class="membro"><div class="cab">Testemunha ${i}</div><div class="grid3">
          <label class="f">Nome completo<input type="text" data-n="t${i}Nome" autocomplete="off"></label><label class="f">Telefone<input type="text" data-n="t${i}Tel" autocomplete="off"></label>
          <label class="f">Endereço<input type="text" data-n="t${i}End" autocomplete="off"></label></div></div>`).join("")}</div>
        <div class="aviso sub"${cond(st => st.test === "Não")}>Solicite que busque o nome completo, o telefone e o endereço de 3 testemunhas.</div></div>`;
    case "grupo":
      return `<div class="q">${tituloHTML(n, it.titulo, it.oque)}${it.itens.map((x, j) => formItem(x, `${n}.${j + 1}`, pl)).join("")}</div>`;
    case "campos":
      return `<div class="q">${tituloHTML(n, valTitulo(it.titulo, pl), it.oque)}${ajudaHTML(it)}<div class="grid2">${it.campos.map(c => campoHTML(c)).join("")}</div></div>`;
    case "fixo": {
      FIXOS.push(it);
      const op = it.ops ? `<div style="font-size:14px;margin-bottom:6px">${esc(it.ops.titulo)}</div><div class="op">${it.ops.vs.map(v => `<label><input type="radio" name="n_${it.ops.k}" data-n="${it.ops.k}" value="${esc(v)}"> ${esc(v)}</label>`).join("")}</div>` : "";
      return `<div class="q">${op}${it.campos ? `<div class="grid2">${it.campos.map(c => campoHTML(c)).join("")}</div>` : ""}
        <div style="font-weight:600;font-size:13.5px;margin:10px 0 4px;color:var(--green)">Texto da narrativa</div><div class="sub2 fixoPrev" data-fx="${FIXOS.length - 1}"></div></div>`;
    }
  }
  return "";
}
function renderNarrativa(def) {
  CONDS = []; FIXOS = [];
  const pl = plural();
  NF.innerHTML = `<div class="guia" style="margin-top:16px"><b>Narrativa: ${esc(def.rot)}.</b> ${def.semCabecalho ? "Este modelo é um texto padrão: complete os campos, se houver, e gere a narrativa." : "O nome da mãe e a data de nascimento informados acima entram automaticamente no texto. Responda às perguntas abaixo; o que ficar sem resposta é avisado quando você gerar a narrativa."}${def.guia ? `<div style="margin-top:6px">${def.guia}</div>` : ""}</div>`
    + itensDe(def).map((it, i) => formItem(it, i + 1, pl)).join("");
  // valores guardados
  NF.querySelectorAll("[data-n]").forEach(el => {
    const k = el.dataset.n, v = S.n[k];
    if (el.type === "radio") el.checked = v === el.value;
    else if (el.type === "checkbox" && el.hasAttribute("data-multi")) el.checked = (v || []).includes(el.value);
    else if (el.type === "checkbox") el.checked = !!v;
    else el.value = v || "";
  });
  ligarNarrativa();
  if ($("membros")) { renderMembros(); $("addMembro").addEventListener("click", () => { S.n.membros.push({}); renderMembros(); const ins = $("membros").querySelectorAll('[data-m="nome"]'); ins[ins.length - 1].focus(); }); }
  if ($("extras")) { renderExtras(); $("addExtra").addEventListener("click", () => { S.n.extras.push({}); renderExtras(); renderNarrativaSeMudouPlural(); }); }
  if ($("cidBusca")) montarCID();
  if ($("rendaTotal")) mostrarTotal();
  if ($("prioDica")) sugerirPrioridade();
  aplicarConds();
}
let ultimoPlural = false;
function renderNarrativaSeMudouPlural() { const d = narrDaDemanda(); if (d && plural() !== ultimoPlural) { ultimoPlural = plural(); renderNarrativa(d); } }
function aplicarConds() {
  NF.querySelectorAll("[data-cond]").forEach(el => el.classList.toggle("hide", !CONDS[+el.dataset.cond](S.n)));
  const fr = NF.querySelector("[data-frase]"); const d = narrDaDemanda();
  if (fr && d) { const it = d.itens.find(x => x.t === "pretensao"); fr.textContent = it.frase(S.n, plural()); }
  NF.querySelectorAll("[data-fx]").forEach(el => { const it = FIXOS[+el.dataset.fx]; if (it) el.textContent = it.texto(S.n); });
  if ($("despDica")) {
    const r = calcRenda(), tot = r.tot;
    $("despDica").textContent = r.nenhuma ? "Informe a renda acima para saber se esta pergunta se aplica."
      : tot > LIM_DESPESAS ? `A renda familiar informada (${brl(tot)}) passa de ${limTxt()}: informe se há despesas extraordinárias.` : `A renda familiar informada (${brl(tot)}) não passa de ${limTxt()}: em regra, marque “Não possui” ou “Não se aplica”.`;
  }
  previaNarrativa();
}
const condicoes = aplicarConds;
function ligarNarrativa() {
  NF.querySelectorAll("[data-n]").forEach(el => {
    const k = el.dataset.n;
    const ev = (el.type === "radio" || el.type === "checkbox") ? "change" : "input";
    el.addEventListener(ev, () => {
      if (el.type === "radio") S.n[k] = el.checked ? el.value : "";
      else if (el.type === "checkbox" && el.hasAttribute("data-multi")) {
        if (k === "prio") {
          S.n.prioTocado = true;
          if (el.value === "Não" && el.checked) NF.querySelectorAll('[data-n="prio"]').forEach(x => { if (x !== el) x.checked = false; });
          if (el.value !== "Não" && el.checked) NF.querySelector('[data-n="prio"][value="Não"]').checked = false;
        }
        S.n[k] = [...NF.querySelectorAll(`[data-n="${k}"]:checked`)].map(x => x.value);
      }
      else if (el.type === "checkbox") S.n[k] = el.checked;
      else { if (el.dataset.mask === "cpf") el.value = mascaraCPF(el.value); S.n[k] = el.value; }
      aplicarConds(); if ($("rendaTotal")) mostrarTotal();
    });
    if (el.hasAttribute("data-money")) el.addEventListener("change", () => { const v = dinheiro(el.value); if (!isNaN(v)) { el.value = brlNum(v); S.n[k] = el.value; mostrarTotal(); aplicarConds(); } marcarValor(el); });
  });
}
function renderMembros() {
  const box = $("membros"); if (!box) return; box.innerHTML = "";
  S.n.membros.forEach((m, i) => {
    const d = document.createElement("div"); d.className = "membro";
    d.innerHTML = `<div class="cab">Membro ${i + 1}<button type="button">remover</button></div>
      <div class="grid3">
        <label class="f span2">Nome<input type="text" data-m="nome" autocomplete="off"></label>
        <label class="f">CPF<input type="text" data-m="cpf" placeholder="000.000.000-00" autocomplete="off"></label>
        <label class="f">Vínculo familiar<input type="text" data-m="vinc" list="vincs" autocomplete="off"></label>
        <label class="f">Renda bruta mensal (R$)<input type="text" data-m="renda" placeholder="0,00" autocomplete="off"></label>
        <label class="f">Fonte de renda<input type="text" data-m="fonte" list="fontes" autocomplete="off"></label>
      </div>`;
    d.querySelectorAll("[data-m]").forEach(inp => {
      const f = inp.dataset.m; inp.value = m[f] || "";
      inp.addEventListener("input", () => { if (f === "cpf") inp.value = mascaraCPF(inp.value); m[f] = inp.value; mostrarTotal(); aplicarConds(); });
      if (f === "renda") { inp.addEventListener("change", () => { const v = dinheiro(inp.value); if (!isNaN(v)) { inp.value = brlNum(v); m.renda = inp.value; mostrarTotal(); aplicarConds(); } marcarValor(inp); }); marcarValor(inp); }
    });
    d.querySelector(".cab button").addEventListener("click", () => { S.n.membros.splice(i, 1); renderMembros(); mostrarTotal(); aplicarConds(); });
    box.appendChild(d);
  });
}
function renderExtras() {  // pensão por morte: mais de um requerente
  const box = $("extras"); if (!box) return; box.innerHTML = "";
  S.n.extras.forEach((m, i) => {
    const d = document.createElement("div"); d.className = "membro";
    d.innerHTML = `<div class="cab">Assistido ${i + 2}<button type="button">remover</button></div>
      <div class="grid3">
        <label class="f span2">Nome completo<input type="text" data-x="nome" autocomplete="off"></label>
        <label class="f">Data de nascimento<input type="date" data-x="nasc" max="${hojeISO()}"></label>
        <label class="f">Profissão<input type="text" data-x="prof" autocomplete="off"></label>
        <label class="f">Renda bruta mensal (R$)<input type="text" data-x="renda" placeholder="0,00" autocomplete="off"></label>
        <label class="f">Fonte de renda<input type="text" data-x="fonte" list="fontes" autocomplete="off"></label>
      </div>`;
    d.querySelectorAll("[data-x]").forEach(inp => {
      const f = inp.dataset.x; inp.value = m[f] || "";
      inp.addEventListener("input", () => { m[f] = inp.value; mostrarTotal(); aplicarConds(); if (f === "nasc") avisoCampo(inp, noFuturo(inp.value) ? "Esta data está no futuro: confira." : ""); });
      if (f === "renda") { inp.addEventListener("change", () => { const v = dinheiro(inp.value); if (!isNaN(v)) { inp.value = brlNum(v); m.renda = inp.value; mostrarTotal(); aplicarConds(); } marcarValor(inp); }); marcarValor(inp); }
    });
    d.querySelector(".cab button").addEventListener("click", () => { S.n.extras.splice(i, 1); renderExtras(); mostrarTotal(); renderNarrativaSeMudouPlural(); });
    box.appendChild(d);
  });
}
const membroPreenchido = m => !!(m && (m.nome || m.cpf || m.vinc || m.renda || m.fonte));
function calcRenda() {
  const a = dinheiro(S.n.renda);
  const ms = S.n.sozinho ? [] : (S.n.membros || []).filter(membroPreenchido);
  const xs = (S.n.extras || []);
  let tot = isNaN(a) ? 0 : a, faltam = isNaN(a) ? 1 : 0;
  [...xs, ...ms].forEach(m => { const v = dinheiro(m.renda); if (!isNaN(v)) tot += v; else faltam++; });
  const pessoas = 1 + xs.length + ms.length;
  return { tot, pessoas, pc: tot / pessoas, ms, xs, informada: !isNaN(a), faltam, nenhuma: faltam === pessoas };
}
const faltaRenda = r => r.faltam ? `; falta a renda de ${r.faltam} pessoa${r.faltam > 1 ? "s" : ""}` : "";
function mostrarTotal() {
  if (!$("rendaTotal")) return;
  const r = calcRenda();
  $("rendaTotal").innerHTML = r.nenhuma ? `<span>Total da renda bruta familiar: <b>não informada</b></span>`
    : `<span>Total da renda bruta familiar: <b>${brl(r.tot)}</b></span>
    <span>${r.pessoas} pessoa${r.pessoas > 1 ? "s" : ""} · renda por pessoa: <b>${brl(r.pc)}</b>${r.faltam ? ` <span class="erro">(falta a renda de ${r.faltam} pessoa${r.faltam > 1 ? "s" : ""})</span>` : ""}</span>
    <span style="font-size:12.5px;color:var(--gray)">Referências: 1/4 do salário mínimo = ${brl(SM / 4)}; 1/2 = ${brl(SM / 2)}</span>`;
}
function sugerirPrioridade() {
  if (!$("prioDica")) return;
  const a = idade(), d = narrDaDemanda();
  $("prioDica").textContent = a === null ? "" : `Idade calculada pela data de nascimento: ${a} anos.`;
  if (S.n.prioTocado) return;
  const v = [];
  if (d && d.prioGrave) v.push(PRIO[0]);
  if (a !== null) { const x = a >= 80 ? PRIO[1] : a >= 60 ? PRIO[2] : a < 18 ? PRIO[3] : null; if (x) v.push(x); }
  NF.querySelectorAll('[data-n="prio"]').forEach(x => { x.checked = v.includes(x.value); });
  S.n.prio = v;
}
function mostrarNarrativa() {
  const d = narrDaDemanda();
  $("narrSem").classList.toggle("hide", !S.dem || !!d);
  NF.classList.toggle("hide", !d); $("gerarNarrBox").classList.toggle("hide", !d);
  desenharAbas(d);
  $("narrOut").classList.toggle("hide", !d || d.id !== S.narrId);  // texto de outra demanda não fica na tela; o desta volta atualizado
  if (!d) return;
  S.n = estadoNarr(d.id); ultimoPlural = plural();
  renderNarrativa(d);
}
function desenharAbas(d) {
  const vs = variantes(S.dem), box = $("narrTabs"); box.innerHTML = "";
  $("narrTabsBox").classList.toggle("hide", vs.length < 2);
  vs.forEach(n => {
    const b = document.createElement("button"); b.type = "button"; b.className = "tab" + (d && d.id === n.id ? " on" : "") + (n.todas ? " todas" : ""); b.dataset.id = n.id; b.textContent = n.rot;
    b.addEventListener("click", () => { if (!d || d.id !== n.id) trocarVariante(n); });
    box.appendChild(b);
  });
}

/* CID-10 e CID-11: busca por código ou por aproximação de palavras */
const CID_FONTE = { "10": CID_TXT, "11": CID11_TXT };
const CID_IDX = {};
let cidV = "10";
const PARADAS = new Set("de da do das dos e a o as os com sem em por para na no nas nos ou ao aos um uma que".split(" "));
const SINONIMOS = [  // termos do dia a dia → termos da classificação
  ["cancer", ["neoplasia maligna", "carcinoma"]], ["tumor", ["neoplasia"]], ["derrame", ["acidente vascular cerebral"]], ["avc", ["acidente vascular cerebral"]],
  ["pressao alta", ["hipertensao"]], ["aids", ["imunodeficiencia humana"]], ["hiv", ["imunodeficiencia humana"]],
  ["deficiencia intelectual", ["retardo mental", "transtorno do desenvolvimento intelectual"]], ["deficiencia mental", ["retardo mental", "transtorno do desenvolvimento intelectual"]],
  ["tdah", ["hipercineticos", "deficit de atencao"]], ["deficit de atencao", ["hipercineticos"]], ["hiperatividade", ["hipercineticos"]],
  ["autista", ["autismo"]], ["tea", ["autismo", "espectro autista"]], ["espectro autista", ["autismo"]],
  ["coluna", ["dorsalgia", "dorsopatia"]], ["hernia de disco", ["discos intervertebrais"]], ["bico de papagaio", ["espondilose"]],
  ["dor nas costas", ["dorsalgia", "lombalgia"]], ["artrose", ["gonartrose", "coxartrose", "artrose", "osteoartrite"]], ["reumatismo", ["artrite reumatoide"]],
  ["pedra no rim", ["calculose rim"]], ["rim", ["renal"]], ["rins", ["renal"]], ["figado", ["hepatica"]], ["coracao", ["cardiaca"]],
  ["cego", ["cegueira"]], ["surdo", ["surdez"]], ["surdez", ["perda de audicao"]], ["amputado", ["amputacao"]],
  ["dependencia quimica", ["uso de substancias"]], ["alcoolismo", ["uso de alcool"]], ["drogas", ["uso de substancias"]], ["crack", ["cocaina"]],
  ["ansiedade", ["ansiosos", "ansiedade generalizada"]], ["convulsao", ["epilepsia", "convulsoes"]],
  ["depressao", ["episodios depressivos", "transtorno depressivo", "episodio depressivo"]], ["autismo", ["espectro autista"]],
  ["fibromialgia", ["fibromialgia", "dor cronica generalizada"]], ["diabete", ["diabetes"]], ["sindrome de down", ["down"]],
  ["esquecimento", ["demencia"]], ["paralisia", ["paralisia", "plegia"]],
];
function indiceCID(v) {
  if (CID_IDX[v]) return CID_IDX[v];
  const itens = [], vocab = new Map();
  (CID_FONTE[v] || "").split("\n").forEach(l => {
    const i = l.indexOf("|"); if (i < 1) return;
    const c = l.slice(0, i).trim(), d = l.slice(i + 1).trim();
    const ws = [...new Set(norm(d).split(/[^a-z0-9]+/).filter(w => w && !PARADAS.has(w)))];
    const j = itens.push({ c, d, k: c.replace(/\./g, "").toUpperCase(), ws }) - 1;
    ws.forEach(w => { let a = vocab.get(w); if (!a) vocab.set(w, a = []); a.push(j); });
  });
  return (CID_IDX[v] = { itens, vocab });
}
function distancia(a, b, max) {  // Levenshtein com parada antecipada
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let ant = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i]; let menor = i;
    for (let j = 1; j <= b.length; j++) { cur[j] = Math.min(ant[j] + 1, cur[j - 1] + 1, ant[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); menor = Math.min(menor, cur[j]); }
    if (menor > max) return max + 1;
    ant = cur;
  }
  return ant[b.length];
}
function casarPalavra(t, vocab) {  // palavras do catálogo parecidas com t → nota
  const m = new Map();
  for (const w of vocab.keys()) {
    let s = 0;
    if (w === t) s = 3;
    else if (t.length >= 3 && w.startsWith(t)) s = 2.8;
    else if (t.length >= 4) {
      let cp = 0; while (cp < t.length && cp < w.length && t[cp] === w[cp]) cp++;
      if (cp >= 6 && cp >= 0.7 * Math.min(t.length, w.length)) s = 2.6;            // mesmo radical: depressão ~ depressivo (fica abaixo da palavra exata)
      else if (t.length >= 5 && w[0] === t[0] && distancia(t, w, t.length >= 8 ? 2 : 1) <= (t.length >= 8 ? 2 : 1)) s = 1.5;  // erro de digitação
    }
    if (s) m.set(w, s);
  }
  return m;
}
function buscarTexto(q, ix) {
  const tks = q.split(/[^a-z0-9]+/).filter(w => w && !PARADAS.has(w));
  if (!tks.length) return new Map();
  const mapas = tks.map(t => casarPalavra(t, ix.vocab));
  if (mapas.some(m => !m.size)) return new Map();
  const cand = new Set(); for (const w of mapas[0].keys()) ix.vocab.get(w).forEach(j => cand.add(j));
  const notas = new Map();
  cand.forEach(j => {
    const ws = ix.itens[j].ws; let total = 0;
    for (const m of mapas) { let b = 0; for (const w of ws) { const s = m.get(w); if (s > b) b = s; } if (!b) return; total += b; }
    notas.set(j, total / tks.length);
  });
  return notas;
}
function buscarCID(q) {
  const ix = indiceCID(cidV); if (!ix.itens.length) return [];
  const t = norm(q).trim(); if (!t) return [];
  const comp = q.trim().replace(/\s/g, "").replace(/\./g, "").toUpperCase();
  if (/^[0-9A-Z]{1,6}$/.test(comp) && /\d/.test(comp)) {  // parece código
    const r = ix.itens.filter(x => x.k.startsWith(comp)).slice(0, 80);
    if (r.length) return r;
  }
  const variantes = [t];
  SINONIMOS.forEach(([k, alts]) => { if ((" " + t + " ").includes(" " + k + " ")) alts.forEach(a => variantes.push((" " + t + " ").replace(" " + k + " ", " " + a + " ").trim())); });
  const notas = new Map();
  variantes.forEach(v => buscarTexto(v, ix).forEach((s, j) => { if (!(notas.get(j) >= s)) notas.set(j, s); }));
  const fatores = c => cidV === "10" ? c.startsWith("Z") : c.startsWith("Q");  // contatos com serviços de saúde, histórico familiar etc. vão para o fim
  return [...notas].map(([j, s]) => [s + (ix.itens[j].c.includes(".") ? 0 : 0.3) - (fatores(ix.itens[j].c) ? 0.6 : 0), j])
    .sort((a, b) => b[0] - a[0] || a[1] - b[1]).slice(0, 80).map(([, j]) => ix.itens[j]);
}
/* ----- CID: caixa de busca da narrativa ----- */
function montarCID() {
  const inp = $("cidBusca"), lst = $("cidLista"); let ativo = -1, res = [];
  document.querySelectorAll('[name="n_cidv"]').forEach(r => r.addEventListener("change", () => {
    if (!r.checked) return;
    cidV = r.value;
    $("cid11Aviso").classList.toggle("hide", !(cidV === "11" && !CID11_TXT));
    inp.dispatchEvent(new Event("input"));
  }));
  function mostrar() {
    res = buscarCID(inp.value); ativo = res.length ? 0 : -1;
    lst.innerHTML = res.length ? res.map((x, j) => `<div class="opt${j === 0 ? " act" : ""}" data-j="${j}"><b>${esc(x.c)}</b>${esc(x.d)}</div>`).join("")
      : (inp.value.trim() ? '<div class="opt" style="color:var(--gray);cursor:default">Nenhum CID encontrado. Aperte Enter para acrescentar o que foi digitado (código e nome da doença).</div>' : "");
    lst.classList.toggle("open", !!inp.value.trim());
    lst.querySelectorAll(".opt[data-j]").forEach(o => o.addEventListener("mousedown", e => { e.preventDefault(); add(res[+o.dataset.j]); }));
  }
  function add(x) {
    if (!x) return;
    const novo = { v: cidV, c: x.c, d: x.d };
    if (!S.n.cids.some(y => y.v === novo.v && y.c === novo.c && y.d === novo.d)) S.n.cids.push(novo);
    inp.value = ""; lst.classList.remove("open"); tags(); inp.focus();
  }
  inp.addEventListener("input", mostrar);
  inp.addEventListener("blur", () => setTimeout(() => lst.classList.remove("open"), 120));
  inp.addEventListener("keydown", e => {
    const os = [...lst.querySelectorAll(".opt[data-j]")];
    if ((e.key === "ArrowDown" || e.key === "ArrowUp") && os.length) {
      e.preventDefault(); ativo = (ativo + (e.key === "ArrowDown" ? 1 : -1) + os.length) % os.length;
      os.forEach((o, j) => o.classList.toggle("act", j === ativo)); os[ativo].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (res.length) add(res[Math.max(ativo, 0)]);
      else if (inp.value.trim()) {  // digitado à mão: "6A70 Episódio depressivo" vira código + nome
        const m = inp.value.trim().match(/^([0-9A-Za-z]{2,5}(?:\.[0-9A-Za-z]{1,3})?)\s+(.+)$/);
        add(m && /\d/.test(m[1]) ? { c: m[1].toUpperCase(), d: m[2] } : { c: "", d: inp.value.trim() });
      }
    } else if (e.key === "Escape") lst.classList.remove("open");
  });
  tags();
}
function tags() {
  const box = $("cidTags"); if (!box) return; box.innerHTML = "";
  S.n.cids.forEach((x, i) => {
    const t = document.createElement("span"); t.className = "tag";
    t.innerHTML = `<span style="font-size:11.5px;color:var(--gray)">CID-${x.v || "10"}</span>${x.c ? `<b>${esc(x.c)}</b>` : ""}${esc(x.d)}<button type="button" title="Remover">×</button>`;
    t.querySelector("button").addEventListener("click", () => { S.n.cids.splice(i, 1); tags(); });
    box.appendChild(t);
  });
}

/* ----- texto da narrativa: blocos de linhas; só os títulos em negrito ----- */
function montarNarrativa() {
  const d = narrDaDemanda(), n = S.n, B = [], falta = [], conferir = [], pl = plural();
  const bloco = (...linhas) => B.push(linhas.map(l => typeof l === "string" ? [{ t: l }] : l));
  const titulo = (t, resto) => bloco([{ t, b: true }, ...(resto ? [{ t: " " + resto }] : [])]);
  const paragrafos = v => bloco(...String(v).split("\n").map(s => s.trimEnd()));
  const a = idade();
  if (pl) {
    const pn = s => (tx(s).split(/\s+/)[0] || "");
    const datas = [`${nascBR()} (${pn(S.nome)})`, ...n.extras.map(x => `${x.nasc ? x.nasc.split("-").reverse().join("/") : ""} (${pn(x.nome)})`)];
    bloco(`Nome da mãe: ${tx(S.mae)}`, `Data de nascimento dos(as) assistidos(as): ${datas.join(" / ")}`);
    n.extras.forEach((x, j) => {
      if (!tx(x.nome)) conferir.push(`falta o nome do assistido ${j + 2}`);
      if (!x.nasc) conferir.push(`falta a data de nascimento do assistido ${j + 2}`);
      else if (noFuturo(x.nasc)) conferir.push(`a data de nascimento do assistido ${j + 2} está no futuro`);
    });
  } else if (!d.semCabecalho) bloco(`Nome da mãe: ${tx(S.mae)}`, `Data de nascimento do(a) assistido(a): ${nascBR()}${a !== null ? ` (${a} anos)` : ""}`);

  const emitir = (it, num) => {
    switch (it.t) {
      case "pretensao":
        if (it.livre) { titulo(`${num}. Pretensão:`, tx(n.pretTexto)); if (!tx(n.pretTexto)) falta.push(num); }
        else {
          titulo(`${num}. Pretensão:`, it.frase(n, pl));
          if (it.ops && !(it.multi ? (n.pret || []).length : n.pret)) falta.push(num);
          if ((it.campos || []).some(c => !c.opcional && !tx(n[c.k]))) falta.push(num);
        }
        break;
      case "cid": {
        const vs = [...new Set(n.cids.map(x => x.v || "10"))];
        const cidT = vs.length === 1 ? `CID ${vs[0]}` : vs.length ? "CID 10 e CID 11" : "CID 10";
        titulo(`${num}. ${it.titulo(cidT)}`);
        if (n.cids.length) bloco(...pontuarLista(n.cids.map(x => `${vs.length > 1 ? `CID ${x.v || "10"} ` : ""}${x.c ? x.c + " – " : ""}${x.d}`)));
        else if (BRANCO) bloco("CID:");
        else { bloco("Não informado."); falta.push(num); }
        break;
      }
      case "texto":
        titulo(`${num}. ${valTitulo(it.titulo, pl)}`);
        if (BRANCO) bloco("");
        else if (tx(n[it.k])) paragrafos(tx(n[it.k])); else if (!it.opcional) { bloco("Não informado."); falta.push(num); }
        break;
      case "opcoes": {
        titulo(`${num}. ${valTitulo(it.titulo, pl)}`);
        const L = [], depois = [];
        it.ops.forEach(o => {
          const sel = it.multi ? (n[it.k] || []).includes(o.v) : n[it.k] === o.v;
          let l = `${X(sel)} ${o.rot}`;
          if (o.sempre) l += " " + o.sempre(n);
          else if (sel) { const e = o.fmt ? o.fmt(n) : (o.campos || []).map(c => tx(n[c.k])).filter(Boolean).join(" "); if (e) l += " " + e; }
          L.push(sel && o.vermelho ? [{ t: l, cor: "#c00000" }] : l);  // "(deixar em vermelho)", como no modelo
          if ((sel || BRANCO) && o.linhas) o.linhas.forEach(c => {
            const v = tx(n[c.k]);
            if (c.lista) { if (c.rot) L.push(c.rot); v.split("\n").map(s => s.trim()).filter(Boolean).forEach(s => L.push(s)); }
            else L.push(`${c.rot} ${v}`.trim());
          });
          if (o.sub) L.push(`${o.sub.pergunta} ${o.sub.ops.map(s => `${X(n[o.sub.k] === s)} ${s}`).join("  ")}`);
          if (sel && o.apos && tx(n[o.apos.k])) depois.push(tx(n[o.apos.k]));
        });
        if (it.obs) L.push(`${it.obs.rot} ${tx(n[it.obs.k])}`.trim());
        bloco(...L); depois.forEach(paragrafos);
        if (!(it.multi ? (n[it.k] || []).length : n[it.k])) falta.push(num);
        break;
      }
      case "renda": {
        const r = calcRenda(), din = v => { const x = dinheiro(v); return isNaN(x) ? (BRANCO ? "R$" : "não informada") : brl(x); };
        titulo(`${num}. ${valTitulo(it.titulo, pl) || (pl ? "Renda bruta dos(as) assistidos(as) e do grupo familiar que reside no mesmo domicílio:" : it.fem ? "Renda bruta da assistida e do grupo familiar que reside no mesmo domicílio:" : "Renda bruta do(a) assistido(a) e do grupo familiar que reside no mesmo domicílio:")}`);
        bloco(pl ? "Assistido 1" : it.fem ? "Assistida:" : "Assistido(a):");
        bloco(...pontuarLista([`Profissão: ${tx(n.prof) || "não informada"}`, `Renda bruta: ${din(n.renda)}`, `Fonte de renda: ${tx(n.fonte) || "não informada"}`]));
        if (pl) r.xs.forEach((x, j) => { bloco(`Assistido ${j + 2}`); bloco(...pontuarLista([`Profissão: ${tx(x.prof) || "não informada"}`, `Renda bruta: ${din(x.renda)}`, `Fonte de renda: ${tx(x.fonte) || "não informada"}`])); });
        if (!r.informada) falta.push(num);
        bloco("Grupo familiar:");
        bloco(`${X(n.sozinho)} ${pl ? "Os assistidos residem sozinhos" : it.fem ? "Assistida reside sozinha" : "Assistido(a) reside sozinho(a)"}`);
        if (!n.sozinho) {
          if (!r.ms.length && BRANCO) bloco("Nome:", "CPF:", "Vínculo familiar:", "Renda bruta: R$", "Fonte de renda:");
          else if (!r.ms.length) { bloco("Nenhum membro informado."); falta.push(num); }
          r.ms.forEach(m => bloco(...pontuarLista([`Nome: ${tx(m.nome) || "não informado"}`, `CPF: ${m.cpf || "não informado"}`, `Vínculo familiar: ${tx(m.vinc) || "não informado"}`,
            `Renda bruta: ${din(m.renda)}`, `Fonte de renda: ${tx(m.fonte) || "não informada"}`])));
        }
        bloco(r.nenhuma ? `Total da renda bruta familiar: ${BRANCO ? "R$" : "não informada"}` : `Total da renda bruta familiar: ${brl(r.tot)} (${r.pessoas} pessoa${r.pessoas > 1 ? "s" : ""}; renda por pessoa: ${brl(r.pc)}${faltaRenda(r)})`);
        if (r.faltam) falta.push(num);
        bloco(`Despesas extraordinárias (quando a renda familiar mensal for superior a ${limTxt()}):`);
        bloco(`${X(n.desp === "Sim")} Sim.${n.desp === "Sim" && tx(n.despesas) ? " " + tx(n.despesas) : ""}`, `${X(n.desp === "Não")} Não.`, `${X(n.desp === "Não se aplica")} Não se aplica.`);
        break;
      }
      case "prioridade":
        titulo(`${num}. Possui prioridade de tramitação (art. 1.048 CPC)?`);
        bloco(...PRIO.map(p => `${X((n.prio || []).includes(p))} ${p}`));
        if (!(n.prio || []).length) falta.push(num);
        break;
      case "representacao": {
        titulo(`${num}. ${pl ? "Os/As requerentes estão representados por outra pessoa?" : "O/A requerente está representado por outra pessoa?"}`);
        let simRep = "Sim. Motivo pelo qual o/a requerente não pode comparecer:";
        if (n.repr === "Sim") {
          const fr = t => t ? (/[.!?]$/.test(t) ? t : t + ".") : "";
          simRep = n.reprComp === "Sim" ? `Sim. ${pl ? "Os/As requerentes compareceram" : "O/A requerente compareceu"} ao atendimento.` : `Sim. Motivo pelo qual o/a requerente não pode comparecer:${tx(n.reprMotivo) ? " " + fr(tx(n.reprMotivo)) : ""}`;
          if (tx(n.reprPorque)) simRep += ` Motivo da representação: ${fr(tx(n.reprPorque))}`;
        }
        bloco(`${X(n.repr === "Sim")} ${simRep}`, `${X(n.repr === "Não")} Não.`);
        if (!n.repr) falta.push(num);
        if (n.repr === "Sim") {
          titulo(`${num}.1. Grau de parentesco do/a representante:`);
          bloco(...PARENTESCO.map(p => `${X(n.par === p)} ${p === "outro" ? "outro. Especificar:" + (n.par === "outro" && tx(n.parOutro) ? " " + tx(n.parOutro) : "") : p}`));
          if (tx(n.repNome) || n.repCpf) bloco(`Representante: ${tx(n.repNome)}${n.repCpf ? " – CPF " + n.repCpf : ""}`);
        }
        break;
      }
      case "processo": {
        const p = it.k === "eproc" ? "proc" : it.k + "_", v = n[it.k];
        titulo(`${num}. Pesquisa Eproc ${it.tribunal} com o CPF do(a) assistido(a) (anexar ao PAJ a consulta realizada):`);
        const proc = [tx(n[p + "Num"]) && `processo nº ${tx(n[p + "Num"])}`, tx(n[p + "Vara"]) && `vara: ${tx(n[p + "Vara"])}`, tx(n[p + "Chave"]) && `chave: ${tx(n[p + "Chave"])}`].filter(Boolean).join("; ");
        bloco(`${X(v === "mesma")} Possui processo judicial com a mesma demanda pretendida no presente PAJ.${v === "mesma" && proc ? " " + proc.charAt(0).toUpperCase() + proc.slice(1) + "." : ""}`,
              `${X(v === "diferente")} Possui processo judicial com demanda distinta da pretendida no presente PAJ.${v === "diferente" && tx(n[p + "Outro"]) ? " " + tx(n[p + "Outro"]) : ""}`,
              `${X(v === "nenhum")} Não possui processo judicial.`);
        if (!v) falta.push(num);
        break;
      }
      case "testemunhas": {
        titulo(`${num}. Foram fornecidos os dados (nome completo, telefone e endereço) de 3 testemunhas?`);
        const nao = `${X(n.test === "Não")} Não. Solicitar que busque o nome completo, telefone e endereço de 3 testemunhas.`;
        if (n.test === "Sim") {
          bloco("(X) Sim.");
          [1, 2, 3].forEach(j => bloco(`Testemunha ${j}:`, `Nome: ${tx(n[`t${j}Nome`])}`, `Telefone: ${tx(n[`t${j}Tel`])}`, `Endereço: ${tx(n[`t${j}End`])}`));
          const inc = [1, 2, 3].filter(j => !tx(n[`t${j}Nome`]) || !tx(n[`t${j}Tel`]) || !tx(n[`t${j}End`]));
          if (inc.length) { falta.push(num); conferir.push(`faltam dados da${inc.length > 1 ? "s testemunhas" : " testemunha"} ${inc.join(", ").replace(/, (\d)$/, " e $1")}`); }
          bloco(nao);
        } else bloco("( ) Sim.", nao);
        if (!n.test) falta.push(num);
        break;
      }
      case "grupo":
        titulo(`${num}. ${it.titulo}`);
        it.itens.forEach((x, j) => emitir(x, `${num}.${j + 1}`));
        break;
      case "campos": {
        titulo(`${num}. ${valTitulo(it.titulo, pl)}`);
        const vs = it.campos.map(c => tx(n[c.k]));
        bloco(...it.campos.map((c, j) => `${c.rot || c.label + ":"} ${vs[j]}`.trim()));
        if (!it.opcional && vs.some(v => !v)) falta.push(num);
        break;
      }
      case "fixo":
        paragrafos(it.texto(n));
        if (it.ops && !n[it.ops.k]) conferir.push("marque se o atendimento era presencial ou virtual");
        (it.campos || []).forEach(c => { if (!tx(n[c.k])) conferir.push(`preencha “${c.label.toLowerCase()}”`); });
        break;
    }
  };
  itensDe(d).forEach((it, i) => emitir(it, i + 1));
  if (BRANCO) B.forEach(ls => ls.forEach(l => l.forEach(sg => {   // em branco: sem "não informado(a)"; o campo fica vazio
    sg.t = sg.t.replace(/:\s*não informad[ao]\s*[;.]?$/i, ":").replace(/^\s*Não informado\.\s*$/i, "");
  })));
  const texto = B.map(ls => ls.map(l => l.map(s => s.t).join("")).join("\n")).join("\n\n");
  const seg = s => { let h = esc(s.t); if (s.b) h = `<b>${h}</b>`; if (s.cor) h = `<span style="color:${s.cor}">${h}</span>`; return h; };
  const html = B.map(ls => "<p>" + ls.map(l => l.map(seg).join("")).join("<br>") + "</p>").join("");
  const basicos = [];
  if (!d.semCabecalho && !S.mae.trim()) basicos.push("nome da mãe");
  if (!d.semCabecalho && !S.nasc) basicos.push("data de nascimento do(a) assistido(a)");
  else if (noFuturo(S.nasc)) conferir.unshift("a data de nascimento do(a) assistido(a) está no futuro");
  return { texto, html, falta: [...new Set(falta.map(String))].sort((x, y) => parseFloat(x) - parseFloat(y) || x.localeCompare(y)), basicos, conferir };
}
function copiarRico(html, texto, el) {  // com negrito (para o editor do SIS) e também como texto simples
  let ok = copiaDireta(texto, html);
  if (!ok) {
    const d = document.createElement("div"); d.innerHTML = html; d.contentEditable = "true";
    Object.assign(d.style, { position: "fixed", left: "-9999px", top: "0" });
    document.body.appendChild(d);
    const rg = document.createRange(); rg.selectNodeContents(d); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(rg);
    try { ok = document.execCommand("copy"); } catch (e2) {}
    sel.removeAllRanges(); d.remove();
  }
  avisoCopia(el, ok);
  return ok;
}
$("gerarNarrBranco").addEventListener("click", () => {
  let r; try { r = narrativaEmBranco(); } catch (e) { console.error(e); r = null; }
  if (!r) return;
  S.narrBranco = true; S.narrId = narrDaDemanda().id; S.narrTexto = r.texto; S.narrHtml = r.html;
  $("narrOut").classList.remove("hide"); $("narrTexto").innerHTML = r.html; $("narrFaltas").classList.add("hide");
  $("narrCopiado").textContent = "Narrativa EM BRANCO: imprima (botão IMPRIMIR, embaixo do texto) ou copie para o Word e preencha à mão. Para a narrativa com as respostas, clique em GERAR NARRATIVA.";
  $("narrCopiado").className = "ok";
  $("narrOut").scrollIntoView({ behavior: "smooth", block: "start" });
});
$("narrImprimir").addEventListener("click", () => {
  try { narrativaAtual(); } catch (e) {}
  document.body.classList.add("soNarr"); window.print();
});
window.addEventListener("afterprint", () => document.body.classList.remove("soNarr"));
$("gerarNarr").addEventListener("click", () => {
  S.narrBranco = false;
  let r;
  try { r = montarNarrativa(); }
  catch (e) {
    console.error(e); $("narrOut").classList.remove("hide"); $("narrTexto").innerHTML = "";
    $("narrCopiado").textContent = "Não foi possível gerar a narrativa (" + e.message + "). Me avise com essa mensagem."; $("narrCopiado").className = "erro"; return;
  }
  const { texto, html, falta, basicos, conferir } = r;
  S.narrTexto = texto; S.narrHtml = html; S.narrId = narrDaDemanda().id;
  $("narrOut").classList.remove("hide");
  $("narrTexto").innerHTML = html;
  const fx = $("narrFaltas"); const avisos = [];
  if (basicos.length) avisos.push(`Informações básicas em branco: ${basicos.join(", ")}.`);
  if (falta.length) avisos.push(`Perguntas sem resposta: ${falta.join(", ")}.`);
  if (conferir.length) avisos.push(`Confira: ${conferir.join("; ")}.`);
  fx.innerHTML = avisos.length ? avisos.join("<br>") + "<br>Você pode completar e gerar de novo." : "";
  fx.classList.toggle("hide", !avisos.length);
  const ok = copiarRico(html, texto);
  $("narrCopiado").textContent = ok ? "Narrativa gerada e copiada! Na próxima etapa, cole no SIS-DPU (Ctrl+V)." : "Narrativa gerada. Não foi possível copiar automaticamente: use o botão COPIAR TEXTO.";
  $("narrCopiado").className = ok ? "ok" : "erro";
  $("narrOut").scrollIntoView({ behavior: "smooth", block: "start" });
});
function narrativaEmBranco() {  // mesmo modelo, sem nenhuma resposta: lacunas e parênteses vazios, para preencher à mão
  const d = narrDaDemanda(); if (!d) return null;
  const guarda = { n: S.n, mae: S.mae, nasc: S.nasc };
  try { S.n = novoEstadoNarr(); S.mae = ""; S.nasc = ""; BRANCO = true; return montarNarrativa(); }
  finally { BRANCO = false; S.n = guarda.n; S.mae = guarda.mae; S.nasc = guarda.nasc; }
}
function narrativaAtual() {  // o texto sai sempre das respostas de agora, nunca de uma versão antiga
  const d = narrDaDemanda(); if (!d || d.id !== S.narrId) return null;
  const r = S.narrBranco ? narrativaEmBranco() : montarNarrativa(); S.narrTexto = r.texto; S.narrHtml = r.html; $("narrTexto").innerHTML = r.html;
  return r;
}
function previaNarrativa() {  // o texto mostrado na etapa 3 acompanha o que for mudado depois de gerar
  if (!$("narrOut") || $("narrOut").classList.contains("hide")) return;
  try { narrativaAtual(); } catch (e) {}
}
$("copiarNarr3").addEventListener("click", () => { const r = narrativaAtual(); if (r) copiarRico(r.html, r.texto, $("copiarNarr3Ok")); });
$("copiarNarr").addEventListener("click", () => {
  let r = null; try { r = narrativaAtual(); } catch (e) {}
  if (!r) { $("copiarNarrOk").textContent = narrDaDemanda() || !S.dem ? "Gere a narrativa na etapa 2 primeiro." : "A demanda escolhida não tem narrativa cadastrada: não há texto para copiar."; $("copiarNarrOk").className = "erro"; return; }
  copiarRico(r.html, r.texto, $("copiarNarrOk"));
});

/* ---------- etapa 5: pasta ---------- */
const nomePasta = () => nomeArq(`PAJ ${(S.paj || "ANO-025-NÚMERO").replace(/\//g, "-")} - ${nomeAssist()}`);
ENTRAR[4] = () => { $("pasta").textContent = nomePasta(); };
$("copiarPasta").addEventListener("click", e => copiar(nomePasta(), null).then(ok => { e.target.textContent = ok ? "Copiado!" : "Copiar"; setTimeout(() => { e.target.textContent = "Copiar"; }, 2500); }));

/* ---------- etapa 6: checklist ---------- */
function novoChecklist() { S.ck = { dem: S.dem, itens: itensDaDemanda(S.dem) }; }
function itensDaDemanda(d) {
  const it = [];
  const g = [[GERAL.cpf, "cpf"], [GERAL.renda, "renda"], [d.prev ? GERAL.ctpsPrev : GERAL.ctps, "ctps"], [d.residencia || GERAL.residencia, "residencia"]];
  if (!d.cadunico) g.push([GERAL.cadunico, "cadunico"]);
  g.forEach(([h, k]) => it.push({ sec: "geral", html: h, k, ok: false }));
  d.docs.forEach(h => it.push({ sec: /^<b>(Avaliação escolar|Notas fiscais)/.test(h) ? "opc" : "esp", html: h,
    k: /^<b>Formulário médico/.test(h) ? "medico" : /Cadastro Único/.test(h) ? "cadunico" : "", ok: false, cond: /^<b>Notas fiscais/.test(h) ? "2sm" : "" }));
  SE_FOR.forEach(h => it.push({ sec: "se", html: h, k: "", ok: false, cond: /gastos extraordinários/.test(h) ? "2sm" : "" }));
  it.forEach(i => { i.na = false; });
  return it;
}
const SECOES = [["geral", "DOCUMENTOS PESSOAIS E DE RENDA"], ["esp", "DOCUMENTOS DESTA DEMANDA"], ["opc", "OPCIONAIS"], ["se", "SE FOR O CASO"]];
function rendaNarrativa() {  // renda familiar informada na narrativa; null se não houver
  if (!narrDaDemanda()) return null;
  const r = calcRenda();
  return r.nenhuma ? null : r.tot;
}
function visivel(i) {  // notas fiscais e gastos: só quando a renda da narrativa passa de 2 salários mínimos (ou não foi informada)
  if (i.cond !== "2sm") return true;
  const r = rendaNarrativa();
  return r === null || r > LIM_DESPESAS;
}
function renderChecklist() { desenharChecklist($("ckLista"), S.ck.itens.filter(visivel), resumoCk); }
function desenharChecklist(box, itens, aoMudar) {
  box.innerHTML = ""; let n = 0;
  SECOES.forEach(([s, tit]) => {
    const its = itens.filter(i => i.sec === s); if (!its.length) return;
    const h = document.createElement("div"); h.className = "sh"; h.textContent = tit; box.appendChild(h);
    const ol = document.createElement("ol"); ol.className = "docs";
    its.forEach(i => {
      n++;
      const li = document.createElement("li"); li.classList.toggle("ok", i.ok); li.classList.toggle("na", !!i.na);
      const duplo = true;  // qualquer item pode não servir para a pessoa (ex.: certidão de casamento de quem não era casado)
      li.classList.toggle("op2", duplo);
      li.innerHTML = `<span class="nb">${n}.</span><span>${i.html}</span>` + (duplo
        ? `<span class="chks"><label class="chk"><input type="checkbox" data-c="ok"${i.ok ? " checked" : ""}> entregue</label><label class="chk n"><input type="checkbox" data-c="na"${i.na ? " checked" : ""}> não se aplica</label></span>`
        : `<label class="chk"><input type="checkbox" data-c="ok"${i.ok ? " checked" : ""}> entregue</label>`);
      li.querySelectorAll("input").forEach(cb => cb.addEventListener("change", e => {
        const c = cb.dataset.c; i[c] = e.target.checked; i.man = true; i.auto = false;
        if (i[c]) { const o = c === "ok" ? "na" : "ok"; i[o] = false; const x = li.querySelector(`[data-c="${o}"]`); if (x) x.checked = false; }
        li.classList.toggle("ok", i.ok); li.classList.toggle("na", !!i.na); aoMudar();
      }));
      ol.appendChild(li);
    });
    box.appendChild(ol);
  });
  aoMudar();
}
function resumoCk() {
  const f = faltantes().length;
  $("ckResumo").innerHTML = f ? `Falta${f > 1 ? "m" : ""} <b>${f}</b> ${f > 1 ? "itens" : "item"} sem marcação. ${f > 1 ? "Eles entram" : "Ele entra"} na lista de documentos pendentes.` : "<b>Todos os itens foram marcados.</b> Não haverá lista de pendências.";
}
ENTRAR[5] = () => {
  $("ckSemDem").classList.toggle("hide", !!S.dem);
  $("ckBox").classList.toggle("hide", !S.dem);
  if (!S.dem) return;
  if (!S.ck || S.ck.dem !== S.dem) novoChecklist();
  sincNarrCk();
  $("ckDem").textContent = S.dem.nome.toUpperCase();
  renderChecklist();
};
function acrescentarItem() {
  const v = $("ckNovo").value.trim(); if (!v || !S.ck) return;
  const t = v.charAt(0).toUpperCase() + v.slice(1);
  const ult = S.ck.itens.map(i => i.sec).lastIndexOf("esp");
  S.ck.itens.splice(ult >= 0 ? ult + 1 : S.ck.itens.findIndex(i => i.sec === "opc" || i.sec === "se"), 0, { sec: "esp", html: esc(t), k: "", ok: false, na: false, cond: "" });
  renderChecklist(); $("ckNovo").value = ""; $("ckNovo").focus();
}
$("ckAdd").addEventListener("click", acrescentarItem);
$("ckNovo").addEventListener("keydown", e => { if (e.key === "Enter") acrescentarItem(); });
const entregues = () => new Set(S.ck ? S.ck.itens.filter(i => i.ok && i.k).map(i => i.k) : []);
const ORDEM_SEC = { geral: 0, esp: 1, opc: 2, se: 3 };
const pendentesDe = itens => itens.filter(i => !i.ok && !i.na).sort((a, b) => ORDEM_SEC[a.sec] - ORDEM_SEC[b.sec]);
function sincNarrCk() {  // "edição da narrativa/gerar redução a termo" quando a narrativa ficou incompleta; testemunhas já informadas
  if (!S.ck) return;
  const d = narrDaDemanda(), i = S.ck.itens.findIndex(x => x.k === "narrativa");
  const precisa = !!(d && S.n.completa === "NÃO");
  if (precisa && i < 0) S.ck.itens.push({ sec: "esp", html: "<b>Edição da narrativa/gerar redução a termo</b>", k: "narrativa", ok: false, na: false, cond: "", interno: true });
  if (!precisa && i >= 0 && !S.ck.itens[i].ok) S.ck.itens.splice(i, 1);
  const res = d && d.ck ? d.ck(S.n) : [];  // marcação automática, desfeita se a resposta mudar (a não ser que o atendente tenha mexido no item)
  S.ck.itens.forEach(it => {
    if (it.man) return;
    const casa = res.some(re => re.test(it.html));
    if (casa && !it.ok) { it.ok = true; it.na = false; it.auto = true; }
    else if (!casa && it.auto) { it.ok = false; it.auto = false; }
  });
}
const faltantes = () => { if (!S.ck && S.dem) novoChecklist(); sincNarrCk(); return S.ck ? pendentesDe(S.ck.itens.filter(visivel)) : []; };  // checklist não aberto: tudo pendente
const faltantesDoc = () => faltantes().filter(i => !i.interno);  // o que vai para o(a) assistido(a)
const listaNumerada = f => f.map((i, j) => `${j + 1}. ${curto(i.html)}${j === f.length - 1 ? "." : ";"}`).join("\n");

/* ---------- etapa 7: formulário de renda ---------- */
function novoRF() { return { sit: "", rend: "", comp: "", mora: "", membros: [], qr: PERGUNTAS.map(() => ({ r: "", t: "" })), bens: [], serv: [], repNA: null, repNome: "", repCpf: "", repCond: "" }; }
function preencherRF() {  // traz da narrativa só o que ainda está em branco
  const rf = S.rf, n = S.n;
  if (!rf.sit && (n.prof || n.fonte)) rf.sit = [n.prof, n.fonte].map(x => (x || "").trim()).filter(Boolean).join(" – ");
  if (!rf.rend && n.renda) { const v = dinheiro(n.renda); if (!isNaN(v)) rf.rend = brl(v); }
  const ms = n.sozinho ? [] : n.membros.filter(membroPreenchido);
  if (!rf.mora && (n.sozinho || ms.length)) rf.mora = n.sozinho ? "sozinho" : "com";
  if (!rf.membros.some(membroRF) && ms.length) rf.membros = ms.map(m => {
    const v = dinheiro(m.renda);
    return { nome: (m.nome || "").trim(), par: (m.vinc || "").trim(), cpf: m.cpf || "", sit: (m.fonte || "").trim(), rend: isNaN(v) ? "" : brl(v), comp: "" };
  });
  if (!rf.qr[0].r && n.irpf === "Declara") rf.qr[0] = { r: "Sim", t: rf.qr[0].t || "O(a) assistido(a)." };
  if (!rf.qr[0].r && n.irpf === "Não declara" && n.sozinho) rf.qr[0].r = "Não";
  if (rf.repNA === null && n.repr) rf.repNA = n.repr === "Não";
  if (n.repr === "Sim") {
    if (!rf.repNome && n.repNome) rf.repNome = n.repNome.trim();
    if (!rf.repCpf && n.repCpf) rf.repCpf = n.repCpf;
    if (!rf.repCond && n.par && n.par !== "pai/mãe") rf.repCond = "OUTRO";
  }
}
const membroRF = m => !!(m && (m.nome || m.par || m.cpf || m.sit || m.rend));
const simNao = (nome, v) => `<div class="op" style="display:inline-flex">${["SIM", "NÃO"].map(o => `<label><input type="radio" name="${nome}" value="${o}"${v === o ? " checked" : ""}> ${o}</label>`).join("")}</div>`;
function renderRF() {
  const rf = S.rf, box = $("rendaForm");
  box.innerHTML = `
  <div class="q"><div class="t">Assistido(a): <span style="font-weight:400">${esc(S.nome.trim()) || "<i>preencha o nome no início</i>"}</span></div>
    <div class="grid2">
      <label class="f span2">Situação ocupacional <small>(escolha na lista ou escreva)</small><input type="text" data-rf="sit" list="situacoes" autocomplete="off"></label>
      <label class="f">Rendimento mensal (valor bruto)<input type="text" data-rf="rend" data-money2></label>
      <div class="f" style="font-size:13px;color:var(--gray)">Existe comprovante?${simNao("rf_comp", rf.comp)}</div>
    </div></div>
  <div class="q"><div class="t">Moradia</div>
    <div class="op">
      <label><input type="radio" name="rf_mora" value="sozinho"${rf.mora === "sozinho" ? " checked" : ""}> Mora sozinho(a)</label>
      <label><input type="radio" name="rf_mora" value="com"${rf.mora === "com" ? " checked" : ""}> Mora com as pessoas abaixo</label>
    </div>
    <div id="rfMembros" class="${rf.mora === "com" ? "" : "hide"}"></div>
  </div>
  <div class="q"><div class="t">Perguntas</div>
    ${PERGUNTAS.map((p, i) => `<div style="margin:10px 0 14px">
      <div style="font-size:14px;margin-bottom:6px"><b style="color:var(--green)">${i + 1}.</b> ${esc(p.q)}</div>
      <div class="op">${p.ops.map(o => `<label><input type="radio" name="rfq${i}" value="${o}"${rf.qr[i].r === o ? " checked" : ""}> ${o}</label>`).join("")}</div>
      <label class="f sub${p.abre.includes(rf.qr[i].r) ? "" : " hide"}" id="rfqd${i}">${esc(p.det)}${p.nota ? ` <i>(${esc(p.nota)})</i>` : ""}<textarea data-rfq="${i}" style="min-height:44px"></textarea>${p.naoSabe ? `<button type="button" class="btn" data-naosabe="${i}" style="align-self:flex-start;padding:5px 12px;font-size:13px;margin-top:4px">Não sabe o valor</button>` : ""}</label>
    </div>`).join("")}
  </div>
  <div class="q"><div class="t">Bens na residência</div>
    <div class="op">${BENS.map((b, i) => `<label><input type="checkbox" data-rfb="${i}"${rf.bens.includes(i) ? " checked" : ""}> ${esc(b)}</label>`).join("")}</div></div>
  <div class="q"><div class="t">Serviços na residência</div>
    <div class="op">${SERVICOS.map((b, i) => `<label><input type="checkbox" data-rfs="${i}"${rf.serv.includes(i) ? " checked" : ""}> ${esc(b)}</label>`).join("")}</div></div>
  <div class="q"><div class="t" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">REPRESENTANTE LEGAL
      <label class="cx" style="margin:0;font-weight:600"><input type="checkbox" id="repNA"${rf.repNA ? " checked" : ""}> não se aplica</label></div>
    <div style="font-size:13.5px;color:var(--gray);line-height:1.45;margin-bottom:8px">Preencha só quando quem assina o formulário é o <b>representante legal</b> do(a) assistido(a):
      o <b>pai ou a mãe</b> de criança ou adolescente (menor de 18 anos); o(a) <b>tutor(a)</b> nomeado(a) pela Justiça, quando a criança ou o adolescente não está sob o poder dos pais;
      ou o(a) <b>curador(a)</b> de pessoa maior de idade com curatela decretada pela Justiça (termo de curatela). Familiar que só acompanha o atendimento não é representante legal.</div>
    <div id="repCampos" class="${rf.repNA ? "hide" : ""}">
      <div class="grid2">
        <label class="f">Nome<input type="text" data-rf="repNome"></label>
        <label class="f">CPF<input type="text" data-rf="repCpf" data-mask="cpf"></label>
      </div>
      <div class="op" style="margin-top:8px">${REP_COND.map(c => `<label><input type="radio" name="rf_rep" value="${c}"${rf.repCond === c ? " checked" : ""}> ${c}</label>`).join("")}</div>
    </div></div>
  <p style="font-size:13.5px;color:var(--gray)">Local e data são preenchidos automaticamente: Pelotas/RS, ${hojeBR()}.</p>`;
  box.querySelectorAll("[data-rf]").forEach(el => {
    const k = el.dataset.rf; el.value = rf[k] || "";
    el.addEventListener("input", () => { if (el.dataset.mask === "cpf") el.value = mascaraCPF(el.value); rf[k] = el.value; });
    if (el.hasAttribute("data-money2")) el.addEventListener("change", () => { const v = dinheiro(el.value); if (!isNaN(v)) { el.value = brl(v); rf[k] = el.value; } });
  });
  box.querySelectorAll("[data-rfq]").forEach(el => { const i = +el.dataset.rfq; el.value = rf.qr[i].t; el.addEventListener("input", () => { rf.qr[i].t = el.value; }); });
  box.querySelectorAll("[data-naosabe]").forEach(b => b.addEventListener("click", () => { const i = +b.dataset.naosabe, t = box.querySelector(`[data-rfq="${i}"]`); t.value = PERGUNTAS[i].naoSabe; t.dispatchEvent(new Event("input", { bubbles: true })); }));
  PERGUNTAS.forEach((p, i) => box.querySelectorAll(`[name="rfq${i}"]`).forEach(r => r.addEventListener("change", () => {
    rf.qr[i].r = r.checked ? r.value : "";
    $("rfqd" + i).classList.toggle("hide", !p.abre.includes(rf.qr[i].r));
  })));
  box.querySelectorAll('[name="rf_comp"]').forEach(r => r.addEventListener("change", () => { rf.comp = r.checked ? r.value : ""; }));
  box.querySelectorAll('[name="rf_rep"]').forEach(r => r.addEventListener("change", () => { rf.repCond = r.checked ? r.value : ""; }));
  $("repNA").addEventListener("change", e => { rf.repNA = e.target.checked; $("repCampos").classList.toggle("hide", rf.repNA); });
  box.querySelectorAll('[name="rf_mora"]').forEach(r => r.addEventListener("change", () => { rf.mora = r.checked ? r.value : ""; $("rfMembros").classList.toggle("hide", rf.mora !== "com"); if (rf.mora === "com" && !rf.membros.length) { rf.membros.push({}); renderRFMembros(); } }));
  const tog = (arr, i, on) => { const j = arr.indexOf(i); if (on && j < 0) arr.push(i); if (!on && j >= 0) arr.splice(j, 1); };
  box.querySelectorAll("[data-rfb]").forEach(el => el.addEventListener("change", () => tog(rf.bens, +el.dataset.rfb, el.checked)));
  box.querySelectorAll("[data-rfs]").forEach(el => el.addEventListener("change", () => tog(rf.serv, +el.dataset.rfs, el.checked)));
  renderRFMembros();
}
function renderRFMembros() {
  const rf = S.rf, box = $("rfMembros"); box.innerHTML = "";
  rf.membros.forEach((m, i) => {
    const d = document.createElement("div"); d.className = "membro";
    d.innerHTML = `<div class="cab">${i + 1}. Pessoa do grupo familiar<button type="button">remover</button></div>
      <div class="grid3">
        <label class="f span2">Nome<input type="text" data-k="nome"></label>
        <label class="f">CPF<input type="text" data-k="cpf"></label>
        <label class="f">Parentesco<input type="text" data-k="par" list="vincs"></label>
        <label class="f span2">Situação ocupacional<input type="text" data-k="sit" list="situacoes" autocomplete="off"></label>
        <label class="f">Rendimento mensal (bruto)<input type="text" data-k="rend"></label>
        <div class="f span2" style="font-size:13px;color:var(--gray)">Existe comprovante?${simNao("rfm_comp" + i, m.comp)}</div>
      </div>`;
    d.querySelectorAll("[data-k]").forEach(inp => {
      const f = inp.dataset.k; inp.value = m[f] || "";
      inp.addEventListener("input", () => { if (f === "cpf") inp.value = mascaraCPF(inp.value); m[f] = inp.value; });
      if (f === "rend") inp.addEventListener("change", () => { const v = dinheiro(inp.value); if (!isNaN(v)) { inp.value = brl(v); m.rend = inp.value; } });
    });
    d.querySelectorAll(`[name="rfm_comp${i}"]`).forEach(r => r.addEventListener("change", () => { m.comp = r.checked ? r.value : ""; }));
    d.querySelector(".cab button").addEventListener("click", () => { rf.membros.splice(i, 1); renderRFMembros(); });
    box.appendChild(d);
  });
  const b = document.createElement("button"); b.type = "button"; b.className = "btn"; b.textContent = "+ Adicionar pessoa";
  b.addEventListener("click", () => { rf.membros.push({}); renderRFMembros(); });
  box.appendChild(b);
}
ENTRAR[6] = () => { if (!S.rf) S.rf = novoRF(); preencherRF(); renderRF(); };

/* ---------- etapa 8: indicação dos formulários ---------- */
const PEND = "pend";
const usaAnalf = k => S.analf && k !== PEND && k !== "titular" && !!(FORMS[k] && FORMS[k].pdf_a);  // a declaração do titular é assinada por outra pessoa
const tipoDe = k => k === PEND ? "Lista de documentos pendentes" : FORMS[k].tipo;
function recomendar() {
  const d = S.dem; if (!d) return null;
  if (!S.ck || S.ck.dem !== d) novoChecklist();
  if (!S.rf) { S.rf = novoRF(); preencherRF(); }
  const ent = entregues(), falt = faltantesDoc();
  const L = [], fora = [];
  const add = (k, rec, motivo) => L.push({ k, rec, motivo });
  if (falt.length) add(PEND, true, `${falt.length} ${falt.length > 1 ? "itens ainda não foram entregues" : "item ainda não foi entregue"}; a lista vai para o(a) assistido(a) assinar`);
  else fora.push([PEND, "toda a documentação foi entregue"]);
  add("form_renda", true, "preenchido com as informações da etapa 7");
  if (ent.has("renda")) { fora.push(["ausencia_renda", "comprovante de renda entregue"]); fora.push(["renda_informal", "comprovante de renda entregue"]); }
  else {
    const v = dinheiro(S.rf.rend || S.n.renda), comp = S.rf.comp;
    if (comp === "SIM") {
      add("ausencia_renda", false, "o(a) assistido(a) tem comprovante de renda: basta entregá-lo");
      add("renda_informal", false, "o(a) assistido(a) tem comprovante de renda: basta entregá-lo");
    } else if (v === 0) {
      add("ausencia_renda", true, "renda informada: R$ 0,00");
      add("renda_informal", false, "só para quem tem renda sem comprovante");
    } else if (v > 0) {
      add("renda_informal", true, `renda de ${brl(v)} sem comprovante entregue`);
      add("ausencia_renda", false, "só para quem não tem renda nenhuma");
    } else {
      add("ausencia_renda", true, "a renda não foi informada: mantenha só a declaração que corresponder");
      add("renda_informal", true, "a renda não foi informada: mantenha só a declaração que corresponder");
    }
  }
  if (ent.has("ctps")) fora.push(["ausencia_ctps", "Carteira de Trabalho entregue"]);
  else add("ausencia_ctps", true, "Carteira de Trabalho não entregue: desmarque se a pessoa tiver carteira e só precisar enviá-la");
  if (ent.has("residencia")) { fora.push(["titular", "comprovante de residência entregue"]); fora.push(["sem_conta", "comprovante de residência entregue"]); }
  else {
    add("titular", true, "comprovante de residência não entregue: para quando a conta está no nome de outra pessoa");
    add("sem_conta", false, "alternativa, quando não há conta de luz ou água em nome de ninguém da casa");
  }
  if (TERMO.has(d.nome)) add("termo", true, "o(a) assistido(a) não reconhece a contratação");
  (d.forms || []).forEach((k, i) => {
    if (ent.has("medico")) fora.push([k, "formulário médico entregue"]);
    else add(k, i === 0, i === 0 ? "formulário médico desta demanda, para o(a) médico(a) preencher" : "modelo alternativo");
  });
  const usados = new Set([...L.map(x => x.k), ...fora.map(x => x[0])]);
  const outros = Object.keys(FORMS).filter(k => !usados.has(k));
  return { L, fora, outros };
}
const selecionado = x => x.rec ? !S.fOff.has(x.k) : S.fOn.has(x.k);
function selecao() {
  const r = recomendar(); if (!r) return [];
  const ks = r.L.filter(selecionado).map(x => x.k);
  r.outros.forEach(k => { if (S.fOn.has(k)) ks.push(k); });
  return ks;
}
function cartao(x) {
  const lb = document.createElement("label"); lb.className = "fcard";
  const analf = usaAnalf(x.k) ? " · versão para assistido(a) analfabeto(a)" : (S.analf && x.k === PEND ? " · com assinatura a rogo" : "");
  lb.innerHTML = `<input type="checkbox"${selecionado(x) ? " checked" : ""}><div><div class="nm">${esc(tipoDe(x.k))}</div><div class="rz">${esc(x.motivo)}${analf}</div></div>`;
  lb.querySelector("input").addEventListener("change", e => {
    const on = e.target.checked;
    if (x.rec) { if (on) S.fOff.delete(x.k); else S.fOff.add(x.k); }
    else { if (on) S.fOn.add(x.k); else S.fOn.delete(x.k); }
  });
  return lb;
}
ENTRAR[7] = () => {
  const r = recomendar();
  $("fsSemDem").classList.toggle("hide", !!r);
  $("fsLista").innerHTML = ""; $("fsOutros").innerHTML = "";
  $("fsOutrosBox").classList.add("hide");   // "Outros formulários disponíveis" saiu (só os indicados aparecem)
  $("gerarConferir").disabled = !r;
  if (!r) return;
  r.L.forEach(x => $("fsLista").appendChild(cartao(x)));
  if (r.fora.length) $("fsLista").insertAdjacentHTML("beforeend",
    `<p style="font-size:13.5px;color:var(--gray);margin-top:10px">Não indicados: ${r.fora.map(([k, m]) => `<b>${esc(tipoDe(k))}</b> (${esc(m)})`).join("; ")}.</p>`);
  r.outros.forEach(k => $("fsOutros").appendChild(cartao({ k, rec: false, motivo: "disponível, se precisar" })));
};

/* ---------- preenchimento dos PDFs (pdf-lib) ---------- */
const { PDFDocument, StandardFonts, rgb } = PDFLib;
const bytesCache = {};
const b64u8 = s => { if (!bytesCache[s.length + s.slice(-40)]) bytesCache[s.length + s.slice(-40)] = Uint8Array.from(atob(s), c => c.charCodeAt(0)); return bytesCache[s.length + s.slice(-40)]; };
let fonteTeste = null;
const okWin = {};
const TROCA_LETRA = { "Ł": "L", "ł": "l", "Đ": "D", "đ": "d", "Ħ": "H", "ħ": "h", "ı": "i", "Ŧ": "T", "ŧ": "t", "Ə": "E", "ə": "e", "ẞ": "SS", "ʼ": "'", "ʻ": "'", "ʹ": "'", "‐": "-", "‑": "-" };
function winAnsi(s) {  // as fontes padrão do PDF só têm o conjunto WinAnsi: troca o que não existe nele
  return [...String(s)].map(ch => {
    if (okWin[ch] === undefined) { try { fonteTeste.widthOfTextAtSize(ch, 10); okWin[ch] = true; } catch (e) { okWin[ch] = false; } }
    if (okWin[ch]) return ch;
    if (TROCA_LETRA[ch]) return TROCA_LETRA[ch];
    const base = ch.normalize("NFD").replace(/[̀-ͯ]/g, "");
    return base && base !== ch && [...base].every(c => okWin[c] !== false) ? base : (/\s/.test(ch) ? " " : "");
  }).join("");
}
function campoTexto(form, font, nome, valor, max = 10) {
  let f; try { f = form.getTextField(nome); } catch (e) { return false; }
  valor = winAnsi(String(valor ?? "")).replace(/\s+/g, f.isMultiline() ? " " : " ").trim();
  if (!valor) return true;
  const ml = f.getMaxLength(); if (ml && valor.length > ml) valor = valor.slice(0, ml);
  const ws = f.acroField.getWidgets(); const r = ws[0].getRectangle();
  let s = max;
  if (f.isMultiline()) {
    const linhas = sz => { let n = 1, w = 0; valor.split(" ").forEach(p => { const pw = font.widthOfTextAtSize(p + " ", sz); if (w + pw > r.width - 6 && w > 0) { n++; w = pw; } else w += pw; }); return n; };
    while (s > 6 && linhas(s) * s * 1.18 > r.height - 3) s -= 0.5;
  } else {
    let seg = null;
    try { seg = form.getTextField(nome + "_2"); } catch (e) {}
    if (seg && font.widthOfTextAtSize(valor, max) > r.width - 4) {  // continua na linha seguinte, no mesmo tamanho de letra
      const ps = valor.split(" "); let a = "";
      while (ps.length && font.widthOfTextAtSize((a + " " + ps[0]).trim(), max) <= r.width - 4) a = (a + " " + ps.shift()).trim();
      if (a && ps.length) { campoTexto(form, font, nome + "_2", ps.join(" "), max); valor = a; }
    }
    while (s > 6 && font.widthOfTextAtSize(valor, s) > r.width - 4) s -= 0.5;
  }
  const da = `/Helv ${s} Tf 0 g`;
  f.acroField.setDefaultAppearance(da); ws.forEach(w => w.setDefaultAppearance(da));
  f.setText(valor);
  return true;
}
const marcar = (form, nome) => { try { form.getCheckBox(nome).check(); } catch (e) {} };
const anoCurto = () => String(HOJE.getFullYear()).slice(-2);
async function preencher(k, achatar) {
  const F = FORMS[k];
  const doc = await PDFDocument.load(b64u8(usaAnalf(k) ? F.pdf_a : F.pdf));
  const form = doc.getForm();
  const serif = ["ausencia_renda", "renda_informal", "ausencia_ctps", "titular", "sem_conta", "renuncia", "termo"].includes(k);
  const helv = await doc.embedFont(serif ? StandardFonts.TimesRoman : StandardFonts.Helvetica);
  if (!fonteTeste) fonteTeste = await doc.embedFont(StandardFonts.Helvetica);
  try { form.removeField(form.getField("limpar_formulario")); } catch (e) {}
  const T = (n, v, m) => campoTexto(form, helv, n, v, m || (serif ? 11 : 10));
  const data = () => { T("cidade_uf", "Pelotas/RS"); T("dia", String(HOJE.getDate())); T("mes", MESES[HOJE.getMonth()]); T("ano", anoCurto()); };
  const nome = S.nome.trim(), cpf = S.cpf;
  if (["ausencia_renda", "ausencia_ctps", "renuncia", "termo"].includes(k)) { T("nome", nome); T("cpf", cpf); data(); }
  else if (k === "renda_informal") {
    T("nome", nome); T("cpf", cpf); data();
    const v = dinheiro((S.rf && S.rf.rend) || S.n.renda); if (v > 0) T("valor", brlNum(v));
  }
  else if (k === "titular") { T("endereco", enderecoCompleto()); T("nome_morador", nome); T("cpf_morador", cpf); data(); }
  else if (k === "sem_conta") { T("nome", nome); T("cpf", cpf); T("endereco", enderecoCompleto()); data(); }
  else if (k === "form_renda") {
    const rf = S.rf || novoRF();
    T("campo_01", nome); T("campo_02", rf.sit); T("campo_03", rf.rend);
    if (rf.comp === "SIM") marcar(form, "marcar_01"); if (rf.comp === "NÃO") marcar(form, "marcar_02");
    if (rf.mora === "sozinho") marcar(form, "marcar_03"); if (rf.mora === "com") marcar(form, "marcar_04");
    if (rf.mora === "com") rf.membros.filter(membroRF).slice(0, 7).forEach((m, i) => {
      const b = 4 + i * 5, c = j => "campo_" + dois(b + j);
      T(c(0), m.nome); T(c(1), m.par); T(c(2), m.cpf); T(c(3), m.sit); T(c(4), m.rend);
      if (m.comp === "SIM") marcar(form, "marcar_" + dois(5 + i * 2)); if (m.comp === "NÃO") marcar(form, "marcar_" + dois(6 + i * 2));
    });
    rf.qr.forEach((q, i) => T("campo_" + (39 + i), q.r ? q.r + (q.t ? ". " + q.t : ".") : "", 9.5));
    rf.bens.forEach(i => marcar(form, "marcar_" + dois(19 + i)));
    rf.serv.forEach(i => marcar(form, "marcar_" + dois(46 + i)));
    if (!rf.repNA) {
      T("campo_48", rf.repNome); T("campo_49", rf.repCpf);
      const rc = REP_COND.indexOf(rf.repCond); if (rc >= 0) marcar(form, "marcar_" + (56 + rc));
    }
    T("cidade_uf", "Pelotas/RS"); T("dia", dois(HOJE.getDate())); T("mes", dois(HOJE.getMonth() + 1)); T("ano", anoCurto());
  }
  else {  // formulários médicos: só a identificação; o resto é do(a) médico(a)
    const tem = n => { try { form.getTextField(n); return true; } catch (e) { return false; } };
    const primeiro = (ns, v) => { const n = ns.find(tem); if (n) T(n, v); };
    primeiro(["nome", "nome_do_a_assistido_a"], nome); primeiro(["cpf_nº", "cpf"], cpf); primeiro(["paj_nº", "e_paj_nº", "paj", "e_paj"], S.paj);
  }
  form.updateFieldAppearances(helv);
  if (achatar) form.flatten();
  doc.setTitle(`${F.tipo} - ${nomeAssist()}`);
  return await doc.save();
}

/* ---------- lista de documentos pendentes desenhada em PDF ---------- */
const COR = { tinta: rgb(.118, .118, .118), verde: rgb(.149, .329, .094), cinza: rgb(.267, .267, .267), faixa: rgb(.886, .937, .851), suave: rgb(.953, .973, .937), linha: rgb(.725, .78, .694), borda: rgb(.83, .83, .83) };
function pedacos(html) {  // "<b>x</b> y" → [{t, b}]
  const out = []; const re = /<b>(.*?)<\/b>/g; let i = 0, m;
  while ((m = re.exec(html))) { if (m.index > i) out.push({ t: txt(html.slice(i, m.index)), b: false }); out.push({ t: txt(m[1]), b: true }); i = re.lastIndex; }
  if (i < html.length) out.push({ t: txt(html.slice(i)), b: false });
  return out;
}
const LARG = new Map();
function larg(font, t, fs) {  // largura sem kerning, igual ao que o drawText desenha
  let m = LARG.get(font); if (!m) { m = {}; LARG.set(font, m); }
  let w = 0; for (const c of t) { if (m[c] === undefined) m[c] = font.widthOfTextAtSize(c, 1000) / 1000; w += m[c]; }
  return w * fs;
}
function quebrar(peds, fs, largura, F) {  // linhas de palavras {t, b, w}
  const pal = [];
  peds.forEach(p => winAnsi(p.t).split(/(\s+)/).forEach(t => { if (t) pal.push({ t: /^\s+$/.test(t) ? " " : t, b: p.b }); }));
  const linhas = []; let l = [], w = 0;
  pal.forEach(p => {
    const pw = larg(p.b ? F.b : F.r, p.t, fs);
    if (p.t === " ") { if (l.length) { l.push({ ...p, w: pw }); w += pw; } return; }
    if (w + pw > largura && l.length) { while (l.length && l[l.length - 1].t === " ") w -= l.pop().w; linhas.push(l); l = []; w = 0; }
    l.push({ ...p, w: pw }); w += pw;
  });
  while (l.length && l[l.length - 1].t === " ") l.pop();
  if (l.length) linhas.push(l);
  return linhas;
}
function escrever(pg, linha, x, y, fs, F, cor) { linha.forEach(p => { if (p.t !== " ") pg.drawText(p.t, { x, y, size: fs, font: p.b ? F.b : F.r, color: cor || COR.tinta }); x += p.w; }); }
async function pdfPendentes(D) {  // D: dados de um PAJ de Meus PAJs; sem D, usa o atendimento em andamento
  D = D || { nome: S.nome, cpf: S.cpf, paj: S.paj, analf: S.analf, dem: S.dem.nome, itens: faltantesDoc(), prazo: S.prazo };
  const doc = await PDFDocument.create();
  const F = { r: await doc.embedFont(StandardFonts.TimesRoman), b: await doc.embedFont(StandardFonts.TimesRomanBold), i: await doc.embedFont(StandardFonts.TimesRomanItalic) };
  if (!fonteTeste) fonteTeste = await doc.embedFont(StandardFonts.Helvetica);
  const logo = await doc.embedJpg(b64u8(LOGO));
  const W = 595.28, H = 841.89, ML = 51, MR = 51, LW = W - ML - MR, MB = 40;
  const falt = D.itens;
  // rodapé (mede para reservar espaço)
  const fsR = 10.5, ldR = fsR * 1.38;
  const par1 = [{ t: "Os documentos podem ser enviados pelo ", b: false }, { t: "WhatsApp (53) 3284-9450", b: true }, { t: " (atendimento de retorno virtual, somente mensagens), desde que a foto seja bem enquadrada, de boa qualidade e legível. Não atendemos ligações pelo WhatsApp: para falar por telefone, ligue para o mesmo número, por ligação comum.", b: false }];
  const par2 = [{ t: "O(a) requerente fica ciente de que a análise do pedido de assistência jurídica gratuita/defesa judicial fica condicionada à juntada da documentação pendente acima elencada, ", b: false },
    { t: `no prazo máximo de ${D.prazo || "30 dias"}`, b: true }, { t: ", salientando-se, desde já, que, em caso de ausência de manifestação, o PAJ será ", b: false }, { t: "ARQUIVADO", b: true }, { t: ".", b: false }];
  const pw = LW - 2 * 14;
  const l1 = quebrar(par1, fsR, pw, F), l2 = quebrar(par2, fsR, pw, F);
  const assinH = D.analf ? 130 : 52;
  const rodH = 10 + (l1.length + l2.length) * ldR + 6 + assinH + 8;
  const impH = 22;
  // cabeçalho
  let pg = doc.addPage([W, H]);
  const cab = (p, primeira) => {
    const lh = 34, lw = logo.width * lh / logo.height;
    p.drawImage(logo, { x: ML, y: H - 38 - lh, width: lw, height: lh });
    const a1 = "Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS, CEP 96020-480", a2 = "Fone (53) 3284-9450";
    p.drawText(a1, { x: W - MR - larg(F.r, a1, 8.3), y: H - 38 - lh + 12, size: 8.3, font: F.r, color: COR.cinza });
    p.drawText(a2, { x: W - MR - larg(F.r, a2, 8.3), y: H - 38 - lh + 2, size: 8.3, font: F.r, color: COR.cinza });
    p.drawLine({ start: { x: ML, y: H - 38 - lh - 5 }, end: { x: W - MR, y: H - 38 - lh - 5 }, thickness: .6, color: COR.borda });
    return H - 38 - lh - 13;
  };
  let y = cab(pg, true);
  // faixa de título
  const dem = winAnsi(D.dem);
  let dfs = 14.5; while (larg(F.b, dem, dfs) > LW - 16 && dfs > 9) dfs -= .5;
  const fh = 14 + dfs + 10;
  pg.drawRectangle({ x: ML, y: y - fh, width: LW, height: fh, color: COR.faixa });
  const k1 = "D O C U M E N T O S   P E N D E N T E S";
  pg.drawText(k1, { x: W / 2 - larg(F.b, k1, 10) / 2, y: y - 13, size: 10, font: F.b, color: COR.tinta });
  pg.drawText(dem, { x: W / 2 - larg(F.b, dem, dfs) / 2, y: y - fh + 7, size: dfs, font: F.b, color: COR.verde });
  y -= fh + 12;
  // identificação
  const idt = [{ t: "Assistido(a): ", b: true }, { t: (D.nome || "").trim() || "________________________________", b: false }, { t: "  ·  ", b: false }, { t: "CPF: ", b: true }, { t: D.cpf || "______________", b: false }, { t: "  ·  ", b: false }, { t: "PAJ nº: ", b: true }, { t: D.paj || "______________", b: false }];
  let ifs = 10.5; let il = quebrar(idt, ifs, LW, F);
  while (il.length > 1 && ifs > 8.5) { ifs -= .5; il = quebrar(idt, ifs, LW, F); }
  il.forEach(l => { escrever(pg, l, ML, y - ifs, ifs, F); y -= ifs * 1.3; });
  y -= 6;
  // itens: escolhe o maior tamanho de letra que cabe numa página
  const secs = [[["geral"], "DOCUMENTOS PESSOAIS E DE RENDA"], [["esp"], "DOCUMENTOS DESTA DEMANDA"], [["opc", "se"], "SE FOR O SEU CASO, TRAGA TAMBÉM"]]
    .map(([s, t]) => [t, falt.filter(i => s.includes(i.sec))]).filter(x => x[1].length);
  const ind = 22;
  const medir = fs => { let h = 0; secs.forEach(([t, its], si) => { h += (si ? 10 : 0) + 9.5 + 6; its.forEach(i => { h += quebrar(pedacos(i.html), fs, LW - ind, F).length * fs * 1.28 + fs * .42; }); }); return h; };
  const disp = y - MB - rodH - impH - 10;
  let fs = 13; while (fs > 9 && medir(fs) > disp) fs -= .25;
  const sobra = Math.max(0, disp - medir(fs));
  const extra = Math.min(fs * .5, sobra / Math.max(1, falt.length + secs.length));
  let num = 0;
  const novaPagina = () => { pg = doc.addPage([W, H]); y = cab(pg, false) - 6; };
  secs.forEach(([t, its], si) => {
    if (y - 30 < MB) novaPagina();
    y -= (si ? 10 : 0);
    pg.drawText(winAnsi(t), { x: ML, y: y - 9.5, size: 9.5, font: F.b, color: COR.verde });
    pg.drawLine({ start: { x: ML, y: y - 12.5 }, end: { x: W - MR, y: y - 12.5 }, thickness: .6, color: COR.linha });
    y -= 9.5 + 6 + extra / 2;
    its.forEach((i, j) => {
      num++;
      const ls = quebrar(pedacos(i.html), fs, LW - ind, F);
      const h = ls.length * fs * 1.28;
      if (y - h < MB) novaPagina();
      const nn = num + ".";
      pg.drawText(nn, { x: ML + ind - 5 - larg(F.b, nn, fs), y: y - fs, size: fs, font: F.b, color: COR.verde });
      ls.forEach((l, li) => {
        const fim = li === ls.length - 1 ? (j === its.length - 1 ? "." : ";") : "";
        if (fim) { const u = l[l.length - 1]; u.t = u.t.replace(/[\s;.:]+$/, "") + fim; u.w = larg(u.b ? F.b : F.r, u.t, fs); }
        escrever(pg, l, ML + ind, y - fs, fs, F); y -= fs * 1.28;
      });
      y -= fs * .42 + extra;
    });
  });
  // importante + rodapé (vão para o pé da última página)
  if (y - impH - rodH - 8 < MB) novaPagina();
  let yb = MB + rodH;
  const ip = [{ t: "Grupo familiar", b: true }, { t: " são todas as pessoas que moram no mesmo imóvel que o(a) assistido(a).", b: false }];
  const kI = "IMPORTANTE:  ";
  let ifs2 = 11; while ((quebrar(ip, ifs2, LW - 20 - larg(F.b, kI, ifs2), F).length > 1) && ifs2 > 8) ifs2 -= .25;
  pg.drawRectangle({ x: ML, y: yb + 8, width: LW, height: impH - 4, color: COR.suave });
  pg.drawRectangle({ x: ML, y: yb + 8, width: 3, height: impH - 4, color: COR.verde });
  const yI = yb + 8 + (impH - 4) / 2 - ifs2 * .33;
  pg.drawText("IMPORTANTE:", { x: ML + 10, y: yI, size: ifs2, font: F.b, color: COR.verde });
  escrever(pg, quebrar(ip, ifs2, LW, F)[0], ML + 10 + larg(F.b, kI, ifs2), yI, ifs2, F);
  // caixa do rodapé
  pg.drawRectangle({ x: ML, y: MB, width: LW, height: rodH, borderColor: COR.verde, borderWidth: 1.3 });
  let yr = MB + rodH - 10;
  [l1, l2].forEach(ls => { ls.forEach(l => { escrever(pg, l, ML + 14, yr - fsR, fsR, F); yr -= ldR; }); yr -= 3; });
  const dataTxt = `Pelotas/RS, ${hojeExtenso()}.`;
  if (!D.analf) {
    const yl = MB + 26;
    pg.drawLine({ start: { x: ML + 14, y: yl }, end: { x: ML + 14 + 220, y: yl }, thickness: .7, color: COR.tinta });
    pg.drawText("Assinatura do(a) assistido(a)", { x: ML + 14 + 110 - larg(F.r, "Assinatura do(a) assistido(a)", 9.5) / 2, y: yl - 12, size: 9.5, font: F.r, color: COR.cinza });
    pg.drawText(winAnsi(dataTxt), { x: ML + LW - 14 - larg(F.r, winAnsi(dataTxt), 10.5), y: yl + 3, size: 10.5, font: F.r });
  } else {
    const top = MB + assinH + 2;
    pg.drawRectangle({ x: ML + 14, y: top - 92, width: 66, height: 80, borderColor: rgb(.83, .83, .83), borderWidth: .6 });
    const dg = "Digital do(a) assistido(a)";
    pg.drawText(dg, { x: ML + 14 + 33 - larg(F.r, dg, 7.5) / 2, y: top - 102, size: 7.5, font: F.r, color: COR.cinza });
    const x0 = ML + 92, lw = LW - 92 - 14;
    const rogo = quebrar([{ t: `A rogo de ${(D.nome || "").trim() || "________________________"}, que não sabe ler nem escrever, assina (art. 595 do Código Civil):`, b: false }], 9.5, lw, F);
    let yy = top - 10;
    rogo.forEach(l => { escrever(pg, l, x0, yy - 9.5, 9.5, F); yy -= 12; });
    const cw = (lw - 2 * 12) / 3;
    ["Assinatura a rogo", "Testemunha 1", "Testemunha 2"].forEach((t, i) => {
      const cx = x0 + i * (cw + 12), yl = yy - 30;
      pg.drawLine({ start: { x: cx, y: yl }, end: { x: cx + cw, y: yl }, thickness: .7, color: COR.tinta });
      pg.drawText(t, { x: cx + cw / 2 - larg(F.r, t, 8.5) / 2, y: yl - 10, size: 8.5, font: F.r, color: COR.cinza });
      ["Nome:", "CPF:"].forEach((r, ri) => {
        const yy2 = yl - 26 - ri * 15;
        pg.drawText(r, { x: cx, y: yy2, size: 8.5, font: F.r, color: COR.cinza });
        pg.drawLine({ start: { x: cx + larg(F.r, r, 8.5) + 3, y: yy2 - 1.5 }, end: { x: cx + cw, y: yy2 - 1.5 }, thickness: .5, color: COR.linha });
      });
    });
    pg.drawText(winAnsi(dataTxt), { x: ML + LW - 14 - larg(F.r, winAnsi(dataTxt), 10), y: MB + 8, size: 10, font: F.r });
  }
  doc.setTitle(`Lista de documentos pendentes - ${nomeAssist()}`);
  return await doc.save();
}

/* ---------- formulário de renda desenhado em PDF, só com o que for necessário ---------- */
function quebrarCb(toks, fs, largura, F) {  // como quebrar(), mas aceita caixinhas {cb: true/false}
  const pal = [];
  toks.forEach(p => {
    if (p.cb !== undefined) { pal.push({ cb: p.cb, w: fs * 0.8 + 3 }); return; }
    winAnsi(p.t).split(/(\s+)/).forEach(t => { if (t) pal.push({ t: /^\s+$/.test(t) ? " " : t, b: p.b }); });
  });
  const linhas = []; let l = [], w = 0;
  pal.forEach(p => {
    const pw = p.cb !== undefined ? p.w : larg(p.b ? F.b : F.r, p.t, fs);
    if (p.t === " ") { if (l.length) { l.push({ ...p, w: pw }); w += pw; } return; }
    if (w + pw > largura && l.length) { while (l.length && l[l.length - 1].t === " ") w -= l.pop().w; linhas.push(l); l = []; w = 0; }
    l.push({ ...p, w: pw }); w += pw;
  });
  while (l.length && l[l.length - 1].t === " ") l.pop();
  if (l.length) linhas.push(l);
  return linhas.length ? linhas : [[]];
}
async function pdfRenda() {
  const doc = await PDFDocument.create();
  const F = { r: await doc.embedFont(StandardFonts.Helvetica), b: await doc.embedFont(StandardFonts.HelveticaBold), i: await doc.embedFont(StandardFonts.HelveticaOblique) };
  if (!fonteTeste) fonteTeste = F.r;
  const logo = await doc.embedJpg(b64u8(LOGO));
  const W = 595.28, H = 841.89, ML = 57, LW = W - 2 * ML, MB = 46, FS = 10, LH = FS * 1.32;
  const rf = S.rf || novoRF();
  const T = (t, b) => ({ t: String(t ?? ""), b: !!b }), CB = on => ({ cb: !!on });
  let pg, y;
  const novaPg = () => {
    pg = doc.addPage([W, H]);
    const lh = 36, lw = logo.width * lh / logo.height;
    pg.drawImage(logo, { x: W / 2 - lw / 2, y: H - 34 - lh, width: lw, height: lh });
    ["Rua Marcílio Dias, nº 3005, Centro, Pelotas/RS.", "Fone (53) 3284-9450"].forEach((t, i) =>
      pg.drawText(winAnsi(t), { x: W / 2 - larg(F.r, winAnsi(t), 8.5) / 2, y: H - 34 - lh - 11 - i * 10, size: 8.5, font: F.r, color: COR.cinza }));
    pg.drawLine({ start: { x: ML, y: H - 34 - lh - 26 }, end: { x: W - ML, y: H - 34 - lh - 26 }, thickness: .6, color: COR.borda });
    y = H - 34 - lh - 40;
  };
  const caixa = (x, base, on, fs) => {
    const s = fs * 0.8, y0 = base - 1;
    pg.drawRectangle({ x, y: y0, width: s, height: s, borderColor: COR.tinta, borderWidth: .7 });
    if (on) {
      pg.drawLine({ start: { x: x + 1.4, y: y0 + 1.4 }, end: { x: x + s - 1.4, y: y0 + s - 1.4 }, thickness: 1, color: COR.tinta });
      pg.drawLine({ start: { x: x + 1.4, y: y0 + s - 1.4 }, end: { x: x + s - 1.4, y: y0 + 1.4 }, thickness: 1, color: COR.tinta });
    }
  };
  const escreverCb = (linha, x, base, fs) => linha.forEach(p => {
    if (p.cb !== undefined) caixa(x + 0.5, base, p.cb, fs);
    else if (p.t !== " ") pg.drawText(p.t, { x, y: base, size: fs, font: p.b ? F.b : F.r, color: COR.tinta });
    x += p.w;
  });
  // texto corrido (com caixinhas), com recuo opcional
  const medirTexto = (toks, w, fs = FS) => quebrarCb(toks, fs, w, F).length * fs * 1.32;
  const texto = (toks, { x = ML, w = LW, fs = FS, depois = 4, centro = false } = {}) => {
    const ls = quebrarCb(toks, fs, w, F);
    if (y - ls.length * fs * 1.32 < MB) novaPg();
    ls.forEach(l => {
      const lw = l.reduce((a, p) => a + p.w, 0);
      escreverCb(l, centro ? x + (w - lw) / 2 : x, y - fs, fs); y -= fs * 1.32;
    });
    y -= depois;
  };
  // tabela: linhas de células {w (fração), tk}; cada linha vira uma faixa com bordas
  const alturaLinha = cels => Math.max(...cels.map(c => quebrarCb(c.tk, FS, LW * c.w - 10, F).length)) * LH + 7;
  const tabela = (linhas, juntas = true) => {
    const hs = linhas.map(alturaLinha), tot = hs.reduce((a, b) => a + b, 0);
    if (juntas && y - tot < MB) novaPg();
    linhas.forEach((cels, i) => {
      if (y - hs[i] < MB) novaPg();
      let x = ML;
      cels.forEach(c => {
        const w = LW * c.w;
        pg.drawRectangle({ x, y: y - hs[i], width: w, height: hs[i], borderColor: COR.tinta, borderWidth: .6, color: c.fundo });
        quebrarCb(c.tk, FS, w - 10, F).forEach((l, j) => escreverCb(l, x + 5, y - 4 - FS - j * LH + 1.5, FS));
        x += w;
      });
      y -= hs[i];
    });
    y -= 10;
  };
  const sn = v => [T("Existe comprovante:  "), CB(v === "SIM"), T(" SIM;  "), CB(v === "NÃO"), T(" NÃO.")];
  const val = v => T(String(v || "").trim(), true);

  novaPg();
  texto([T("COMPOSIÇÃO DO GRUPO E RENDA FAMILIAR", true)], { fs: 12, centro: true, depois: 10 });
  tabela([
    [{ w: 1, tk: [T("Assistido(a): "), val(S.nome)] }],
    [{ w: 1, tk: [T("Situação ocupacional: "), val(rf.sit)] }],
    [{ w: .5, tk: [T("Rendimento mensal: "), val(rf.rend)] }, { w: .5, tk: sn(rf.comp) }],
  ]);
  texto([T("Assinale uma das opções abaixo:")], { depois: 3 });
  texto([CB(rf.mora === "sozinho"), T(" Declaro que moro sozinho(a);")], { x: ML + 8, depois: 2 });
  texto([CB(rf.mora === "com"), T(" Declaro que moro com as pessoas abaixo relacionadas:")], { x: ML + 8, depois: 10 });
  const preenchidos = rf.membros.filter(membroRF);
  const ms = rf.mora === "com" ? (preenchidos.length ? preenchidos : [{}]) : rf.mora === "" ? [{}, {}] : [];
  if (ms.length) {
    texto([T("DEMAIS COMPONENTES DO GRUPO FAMILIAR (residem sob o mesmo teto)", true)], { depois: 4 });
    ms.forEach((m, i) => tabela([
      [{ w: 1, tk: [T(`${i + 1}. NOME: `, true), val(m.nome)], fundo: COR.suave }],
      [{ w: .5, tk: [T("Parentesco: "), val(m.par)] }, { w: .5, tk: [T("CPF: "), val(m.cpf)] }],
      [{ w: 1, tk: [T("Situação ocupacional: "), val(m.sit)] }],
      [{ w: .5, tk: [T("Rendimento mensal: "), val(m.rend)] }, { w: .5, tk: sn(m.comp) }],
    ]));
  }
  // perguntas
  PERGUNTAS.forEach((p, i) => {
    const q = rf.qr[i] || { r: "", t: "" };
    const perg = [T(`${i + 1}. `, true), T(`${p.q} ${p.det}`)];
    const ops = []; p.ops.forEach((o, j) => { ops.push(CB(q.r === o), T(` ${o}${j < p.ops.length - 1 ? "   " : ""}`)); });
    const resp = String(q.t || "").trim(), abre = p.abre.includes(q.r);
    const branco = !q.r || (abre && !resp);
    const h = medirTexto(perg, LW) + LH + (abre && resp ? medirTexto([T(resp)], LW - 16) : 0) + (branco ? 22 : 0) + 14;
    if (y - h < MB) novaPg();
    texto(perg, { depois: 3 });
    texto(ops, { x: ML + 8, depois: 2 });
    if (abre && resp) texto([T(resp, true)], { x: ML + 16, w: LW - 16, depois: 2 });
    if (branco) { y -= 16; pg.drawLine({ start: { x: ML + 16, y }, end: { x: W - ML, y }, thickness: .5, color: COR.cinza }); y -= 6; }
    if (p.nota && q.r === "Sim") texto([T(p.nota)], { x: ML + 16, w: LW - 16, fs: 8.5, depois: 2 });
    y -= 8;
  });
  // bens e serviços
  const grade = (titulo, itens, marcados) => {
    const tk = []; itens.forEach((b, i) => { tk.push(CB(marcados.includes(i)), T(` ${b};   `)); });
    const h = medirTexto(tk, LW - 12) + FS * 1.32 + 16;
    if (y - h < MB) novaPg();
    const topo = y;
    y -= 6; texto([T(titulo, true)], { centro: true, depois: 2 });
    texto(tk, { x: ML + 6, w: LW - 12, depois: 2 });
    pg.drawRectangle({ x: ML, y: y - 2, width: LW, height: topo - y + 2, borderColor: COR.tinta, borderWidth: .6 });
    y -= 14;
  };
  grade("Bens que possui na residência:", BENS, rf.bens);
  grade("Serviços que possui na residência:", SERVICOS, rf.serv);
  // representante legal (só se houver)
  if (rf.repNA !== true) {
    const rc = rf.repCond, conds = []; REP_COND.forEach((c, j) => conds.push(CB(rc === c), T(` ${c}${j < REP_COND.length - 1 ? ";  " : "."}`)));
    tabela([
      [{ w: 1, tk: [T("Preencher o quadro quando o declarante for o representante legal", true)], fundo: COR.suave }],
      [{ w: 1, tk: [T("NOME: "), val(rf.repNome)] }],
      [{ w: 1, tk: [T("CPF: "), val(rf.repCpf)] }],
      [{ w: 1, tk: [T("Condição do representante legal:  "), ...conds] }],
    ]);
  }
  // declaração, local, data e assinatura
  const assinH = S.analf ? 150 : 95;
  if (y - assinH - 30 < MB) novaPg();
  texto([T("Declaro que as informações prestadas no presente formulário são verídicas, sob as penas da lei.", true)], { centro: true, depois: 12 });
  const dt = winAnsi(`Pelotas/RS, ${hojeExtenso()}.`);
  pg.drawText(dt, { x: W - ML - larg(F.r, dt, FS), y: y - FS, size: FS, font: F.r, color: COR.tinta }); y -= FS + 12;
  if (!S.analf) {
    y -= 34;
    pg.drawLine({ start: { x: W / 2 - 130, y }, end: { x: W / 2 + 130, y }, thickness: .7, color: COR.tinta });
    const a = "Assinatura do(a) assistido(a) ou do(a) representante legal";
    pg.drawText(a, { x: W / 2 - larg(F.r, a, 9) / 2, y: y - 12, size: 9, font: F.r, color: COR.cinza });
    y -= 26;
  } else {
    const top = y;
    pg.drawRectangle({ x: ML, y: top - 92, width: 66, height: 80, borderColor: rgb(.83, .83, .83), borderWidth: .6 });
    const dg = "Digital do(a) assistido(a)";
    pg.drawText(dg, { x: ML + 33 - larg(F.r, dg, 7.5) / 2, y: top - 102, size: 7.5, font: F.r, color: COR.cinza });
    const x0 = ML + 80, lw = LW - 80;
    let yy = top - 4;
    quebrarCb([T(`A rogo de ${S.nome.trim() || "________________________"}, que não sabe ler nem escrever, assina (art. 595 do Código Civil):`)], 9, lw, F)
      .forEach(l => { escreverCb(l, x0, yy - 9, 9); yy -= 11.5; });
    const cw = (lw - 24) / 3;
    ["Assinatura a rogo", "Testemunha 1", "Testemunha 2"].forEach((t, i) => {
      const cx = x0 + i * (cw + 12), yl = yy - 30;
      pg.drawLine({ start: { x: cx, y: yl }, end: { x: cx + cw, y: yl }, thickness: .7, color: COR.tinta });
      pg.drawText(t, { x: cx + cw / 2 - larg(F.r, t, 8) / 2, y: yl - 10, size: 8, font: F.r, color: COR.cinza });
      ["Nome:", "CPF:"].forEach((r, ri) => {
        const y2 = yl - 26 - ri * 15;
        pg.drawText(r, { x: cx, y: y2, size: 8, font: F.r, color: COR.cinza });
        pg.drawLine({ start: { x: cx + larg(F.r, r, 8) + 3, y: y2 - 1.5 }, end: { x: cx + cw, y: y2 - 1.5 }, thickness: .5, color: COR.linha });
      });
    });
    y = top - 115;
  }
  // observações (as notas do modelo)
  const notas = [
    "O presente formulário deve ser integralmente preenchido, de forma completa, com informações verdadeiras.",
    "Situação ocupacional: informar se a pessoa se encontra trabalhando, aposentada, recebendo benefício previdenciário ou assistencial, desempregada, estudando etc.",
    "Rendimento mensal: informar o valor total da remuneração (valor bruto, integral), não apenas o valor líquido (após os descontos).",
    "Em caso de trabalho informal ou autônomo, caso não haja comprovante de renda, deverá juntar extrato bancário da conta corrente, poupança ou aplicação, referente aos últimos 90 dias.",
    "Considera-se núcleo familiar a pessoa que mora sozinha ou o grupo de pessoas que reside sob o mesmo teto, composto pelo requerente, parentes consanguíneos ou por afinidade, cônjuge, companheiro ou convivente, desde que exista relação de dependência econômica entre si, nos termos do art. 2º, § 2º, da Resolução CSDPU nº 240, de 4 de dezembro de 2025."];
  const hN = notas.reduce((a, n) => a + medirTexto([T(n)], LW - 12, 7.5) + 2, 0) + 14;
  if (y - hN < MB) novaPg();
  y -= 6; pg.drawLine({ start: { x: ML, y }, end: { x: ML + 120, y }, thickness: .5, color: COR.cinza }); y -= 4;
  notas.forEach((n, i) => {
    pg.drawText(String(i + 1), { x: ML, y: y - 7.5, size: 7, font: F.b, color: COR.cinza });
    const ls = quebrarCb([T(n)], 7.5, LW - 12, F);
    ls.forEach(l => { escreverCinza(pg, l, ML + 10, y - 7.5, 7.5, F); y -= 7.5 * 1.32; });
    y -= 2;
  });
  doc.setTitle(`Formulário de Renda - ${nomeAssist()}`);
  return await doc.save();
}
function escreverCinza(pg, linha, x, base, fs, F) { linha.forEach(p => { if (p.t && p.t !== " ") pg.drawText(p.t, { x, y: base, size: fs, font: p.b ? F.b : F.r, color: COR.cinza }); x += p.w; }); }

/* ---------- gerar, conferir, imprimir, baixar ---------- */
let cacheGerado = { sig: "", juntos: null };
function assinatura() {
  return JSON.stringify([S.est, S.nome, S.cpf, S.analf, enderecoCompleto(), S.paj, S.dem && S.dem.nome, S.n, S.rf, S.ck && S.ck.itens.map(i => [i.ok, i.na, visivel(i)]), selecao()]);
}
async function documentos(achatar) {
  const ks = selecao();
  const out = [];
  for (const k of ks) out.push({ tipo: tipoDe(k), bytes: k === PEND ? await pdfPendentes() : k === "form_renda" ? await pdfRenda() : await preencher(k, achatar) });
  return out;
}
async function documentoUnico() {
  const sig = assinatura();
  if (cacheGerado.sig === sig && cacheGerado.juntos) return cacheGerado.juntos;
  const docs = await documentos(true);
  const out = await PDFDocument.create();
  for (const d of docs) { const src = await PDFDocument.load(d.bytes); (await out.copyPages(src, src.getPageIndices())).forEach(p => out.addPage(p)); }
  out.setTitle(`PAJ ${S.paj} - ${nomeAssist()}`);
  const bytes = await out.save();
  cacheGerado = { sig, juntos: { bytes, n: docs.length } };
  return cacheGerado.juntos;
}
const urlPdf = bytes => URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
function escreverJanela(w, html) { w.document.open(); w.document.write(html); w.document.close(); }
const JANELA = (titulo, corpo) => `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(titulo)}</title><style>html,body{margin:0;height:100%;font-family:Segoe UI,Arial,sans-serif;color:#333}embed{display:block;width:100%;height:100%;border:0}.m{padding:40px;font-size:18px}</style></head><body>${corpo}</body></html>`;
function semSelecao(msgEl) {
  if (!S.dem) { msgEl.innerHTML = '<span class="erro">Escolha a demanda (etapa 2 ou 5) antes de gerar os documentos.</span>'; return true; }
  if (!selecao().length) { msgEl.innerHTML = '<span class="erro">Nenhum formulário está marcado na etapa 7.</span>'; return true; }
  return false;
}
async function abrirConferencia(msgEl) {
  if (semSelecao(msgEl)) return;
  const w = window.open("", "_blank");
  if (w) escreverJanela(w, JANELA("Gerando…", '<div class="m">Gerando os documentos, aguarde…</div>'));
  msgEl.textContent = "Gerando os documentos…";
  try {
    const r = await documentoUnico();
    const titulo = `PAJ ${S.paj || ""} - ${nomeAssist()}`;
    if (w && !w.closed) {
      escreverJanela(w, JANELA(titulo, `<embed src="${urlPdf(r.bytes)}" type="application/pdf">`));
      msgEl.innerHTML = `<span class="ok">Pronto: ${r.n} documento${r.n > 1 ? "s" : ""} aberto${r.n > 1 ? "s" : ""} numa nova guia para conferência.</span> Se algo estiver errado, corrija na etapa correspondente e gere de novo.`;
    } else {
      msgEl.innerHTML = '<span class="erro">O navegador bloqueou a nova guia.</span> Clique no ícone de janela bloqueada, na barra de endereço, escolha “Sempre permitir” e clique de novo no botão.';
    }
  } catch (e) {
    console.error(e); if (w && !w.closed) w.close();
    msgEl.innerHTML = `<span class="erro">Não foi possível gerar os documentos: ${esc(e.message)}</span>`;
  }
}
$("gerarConferir").addEventListener("click", () => abrirConferencia($("gerarMsg")));
$("imprimirTudo").addEventListener("click", async () => {
  const msg = $("baixarMsg");
  if (semSelecao(msg)) return;
  msg.textContent = "Preparando a impressão…";
  try {
    const r = await documentoUnico();
    const url = urlPdf(r.bytes), fr = $("printFrame");
    const alternativa = pre => {
      msg.innerHTML = `${pre}<a href="#" id="abrirImp">Abra o documento numa nova guia</a> e use Ctrl+P para imprimir.`;
      $("abrirImp").addEventListener("click", ev => { ev.preventDefault(); const w = window.open("", "_blank"); if (w) escreverJanela(w, JANELA(`PAJ ${S.paj} - ${nomeAssist()}`, `<embed src="${url}" type="application/pdf">`)); });
    };
    alternativa(`Abrindo a janela de impressão (${r.n} documento${r.n > 1 ? "s" : ""})… Se ela não aparecer em alguns segundos: `);
    fr.onload = () => setTimeout(() => {
      try { fr.contentWindow.focus(); fr.contentWindow.print(); }
      catch (e) { alternativa("Este navegador não deixou imprimir direto. "); }
    }, 400);
    fr.src = url;
  } catch (e) { console.error(e); msg.innerHTML = `<span class="erro">Não foi possível gerar os documentos: ${esc(e.message)}</span>`; }
});
$("baixarZip").addEventListener("click", async () => {
  const msg = $("baixarMsg");
  if (semSelecao(msg)) return;
  msg.textContent = "Preparando os arquivos…";
  try {
    const docs = await documentos(false);
    const files = {}; const usados = {};
    docs.forEach(d => {
      let n = nomeArq(`${d.tipo} - ${nomeAssist()}`);
      if (usados[n]) n += ` (${++usados[n]})`; else usados[n] = 1;
      files[n + ".pdf"] = d.bytes;
    });
    const zip = fflate.zipSync(files, { level: 0 });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([zip], { type: "application/zip" }));
    a.download = nomePasta() + ".zip";
    document.body.appendChild(a); a.click(); a.remove();
    msg.innerHTML = `<span class="ok">Arquivo <b>${esc(a.download)}</b> salvo na pasta Downloads, com ${docs.length} documento${docs.length > 1 ? "s" : ""}.</span> Os campos continuam editáveis, se for preciso corrigir algo.`;
  } catch (e) { console.error(e); msg.innerHTML = `<span class="erro">Não foi possível gerar os arquivos: ${esc(e.message)}</span>`; }
});

/* ---------- etapa 10: assinaturas e envio ---------- */
document.querySelectorAll(".modo").forEach(m => m.addEventListener("click", () => {
  S.modo = m.dataset.modo;
  document.querySelectorAll(".modo").forEach(x => x.classList.toggle("on", x === m));
  $("mPres").classList.toggle("hide", S.modo !== "presencial");
  $("mOnline").classList.toggle("hide", S.modo !== "online");
  ENTRAR[9]();
}));
function mensagem() {
  const falt = faltantesDoc().length > 0;
  const nm = primeiroNome();
  const L = [`Prezado(a)${nm ? " " + nm : ""},`, ""];
  L.push(`Aqui é a Defensoria Pública da União de Pelotas.${S.paj ? ` Seu atendimento foi registrado no PAJ nº ${S.paj}.` : ""}`, "");
  if (S.analf) {
    L.push("Estamos enviando os documentos que precisam ser assinados. Como a assinatura será a rogo, faça assim:", "");
    L.push("1. Imprima os documentos e preencha o que estiver em branco.");
    L.push("2. Em cada documento, coloque a digital do(a) assistido(a) no quadro indicado.");
    L.push("3. Uma pessoa de confiança assina a rogo e duas testemunhas assinam ao lado, escrevendo o nome e o CPF de cada uma.");
    L.push("4. Tire uma foto de cada página, bem enquadrada, nítida e legível, e envie tudo por aqui.");
  } else {
    L.push("Estamos enviando os documentos que precisam da sua assinatura. Você pode escolher uma destas formas:", "");
    L.push("1. Imprimir, preencher o que estiver em branco, assinar e tirar uma foto de cada página (a foto precisa estar bem enquadrada, nítida e legível); ou");
    L.push("2. Assinar pelo gov.br (assinatura eletrônica), sem precisar imprimir.");
    L.push("", "Depois, envie tudo por aqui, de uma vez só.");
  }
  if (falt) {
    L.push("", "Também enviamos a lista dos documentos que ainda faltam. Sua demanda só será analisada depois que recebermos toda a documentação.");
    L.push("", URGENTE(S.prazo) ? `Seu PAJ é URGENTE: o prazo para enviar todos os documentos é de 48 horas, até ${prazoFim(S.prazo)}. Se a documentação não chegar nesse prazo, o PAJ será arquivado.`
      : `O prazo para enviar todos os documentos é de 30 dias, até ${prazoFim(S.prazo)}. Se a documentação não chegar nesse prazo, o PAJ será arquivado.`);
  } else L.push("", "Sua demanda será analisada assim que recebermos os documentos assinados.");
  L.push("", TEL_MSG);
  L.push("", "Atenciosamente,", S.est.trim() || "[seu nome]", "Estagiário(a) – DPU Pelotas");
  return L.join("\n");
}
$("msg").addEventListener("input", () => { S.msgEditada = true; });
$("copiarMsg").addEventListener("click", () => copiar($("msg").value, $("copiarMsgOk")));
ENTRAR[9] = () => {
  const sel = S.dem ? selecao() : [];
  const nomes = [...sel.map(tipoDe), "Redução a termo", "Outorga de poderes",
    ...(S.ck ? S.ck.itens.filter(i => i.ok).map(i => curto(i.html)) : [])];
  $("nomesSug").innerHTML = [...new Set(nomes)].map(t => `<li>${esc(nomeArq(`${t} - ${nomeAssist()}`))}</li>`).join("");
  if (!S.msgEditada) $("msg").value = mensagem();
};

/* ---------- etapa 11: lista simples para o PAJ ---------- */
function textoPendencias() {
  if (!S.ck && S.dem) novoChecklist();
  if (!S.ck) return "Escolha a demanda e preencha o checklist de documentos (etapa 5).";
  const f = faltantes();
  if (!f.length) return "Toda a documentação foi entregue.";
  return "DOCUMENTOS PENDENTES\n\n" + listaNumerada(f) + `\n\nPrazo para a entrega: ${URGENTE(S.prazo) ? "48 horas – PAJ URGENTE" : "30 dias"} (até ${prazoFim(S.prazo)}).`;
}
const entrarPend = () => { $("txtPend").value = textoPendencias(); };
$("copiarPend").addEventListener("click", () => copiar($("txtPend").value, $("copiarPendOk")));

/* ---------- etapa 12: tramitação e fim ---------- */
ENTRAR[10] = () => { entrarPend();
  $("grupo").innerHTML = S.dem
    ? `Grupo temático sugerido pela área da demanda: <b>${esc(S.dem.area.toUpperCase())}</b> (${esc(S.dem.nome)}). Confira no SIS-DPU 2.0 o nome exato do grupo de destino.`
    : "Escolha a demanda na etapa 2 para ver o grupo temático sugerido.";
};
function modal(titulo, html, sim, o = {}) {
  $("mT").textContent = titulo; $("mX").innerHTML = html; $("modal").classList.add("on");
  $("mSim").textContent = o.sim || "Confirmar"; $("mNao").textContent = o.nao || "Cancelar";
  $("mSim").onclick = () => { $("modal").classList.remove("on"); sim(); };
  $("mNao").onclick = () => { $("modal").classList.remove("on"); if (o.aoNao) o.aoNao(); };
}
ENTRAR[10] = (function (f) { return () => { f(); const n = S.dem ? faltantes().length : 0;
  $("terminarAviso").innerHTML = n ? `Ainda ${n > 1 ? "faltam" : "falta"} <b>${n} documento${n > 1 ? "s" : ""}</b>. Ao terminar, este PAJ vai para <b>Meus PAJs</b>, onde você acompanha o que o(a) assistido(a) enviar.` : ""; }; })(ENTRAR[10]);
$("terminar").addEventListener("click", () => {
  const n = S.dem ? faltantes().length : 0;
  modal("Terminar o atendimento?",
    (n ? `<p>Ainda ${n > 1 ? "faltam" : "falta"} <b>${n} documento${n > 1 ? "s" : ""}</b>: o PAJ ${esc(S.paj || "")} de ${esc(S.nome.trim() || "assistido(a) sem nome")} vai para Meus PAJs.</p>` : "")
    + `<p>Os demais dados deste atendimento serão apagados${EMBUTIDO ? "" : ", e o assistente volta ao menu inicial"}.</p><p>Antes, confira se a documentação foi juntada e se o PAJ foi tramitado.</p>`,
    () => {
      if (n && !guardarPendente()) { modal("Não foi possível guardar", "<p>O navegador não deixou guardar a lista neste computador. Anote os documentos pendentes da etapa 10 antes de terminar.</p>", () => {}); return; }
      saindo = true; apagarRascunho();
      if (EMBUTIDO) try { parent.postMessage({ assistente: "terminou", pendente: !!n }, "*"); } catch (e) {}
      location.reload();
    });
});
window.addEventListener("beforeunload", e => { if (!saindo && (S.nome.trim() || S.paj || S.cpf)) { e.preventDefault(); e.returnValue = ""; } });

/* ---------- telas: menu, assistente, lista de PAJs ---------- */
const TELAS = { menu: "telaMenu", assist: "telaAssist", lista: "telaLista", paj: "telaPaj", cadastro: "telaCadastro" };
const NOMES_TELA = { menu: "ASSISTENTE DE ABERTURA DE PAJ", assist: "ASSISTENTE DE ABERTURA DE PAJ", lista: "MEUS PAJS", paj: "MEUS PAJS", cadastro: "CADASTRAR PAJ" };
function mostrarTela(t) {
  Object.entries(TELAS).forEach(([k, id]) => $(id).classList.toggle("hide", k !== t));
  $("nomeTela").textContent = NOMES_TELA[t];
  $("chips").style.display = t === "assist" ? "" : "none";
  $("menuBtn").style.display = (t === "menu" || EMBUTIDO) ? "none" : "";
  if (t === "cadastro") setTimeout(() => $("novoPajNum").focus(), 50);
  if (t === "menu") {
    const n = lerLista().length;
    $("contaLista").textContent = n ? `${n} PAJ${n > 1 ? "s" : ""} aguardando documentos` : "";
    const rs = !temDados() && lerRascunho();
    $("emAndamento").textContent = (S.nome.trim() || S.paj) ? `Atendimento em andamento: ${S.nome.trim() || "PAJ " + S.paj}. Clique para continuar.`
      : rs ? `Atendimento não terminado: ${rs.nome || (rs.paj ? "PAJ " + rs.paj : "sem nome")}. Clique para continuar.` : "";
  }
  if (t === "lista") desenharLista();
  $("rodapeMenu").classList.toggle("hide", t === "menu");
  window.scrollTo(0, 0);
}
$("menuBtn").addEventListener("click", () => mostrarTela("menu"));
$("irNovo").addEventListener("click", () => { mostrarTela("assist"); oferecerRascunho(); });
$("irLista").addEventListener("click", () => mostrarTela("lista"));
$("irCadastro").addEventListener("click", () => mostrarTela("cadastro"));
$("cadastroVer").addEventListener("click", () => mostrarTela("lista"));
function abrirModo(m) { mostrarTela(TELAS[m] ? m : "assist"); if (!TELAS[m] || m === "assist") oferecerRascunho(); }  // chamado pelo app Unidade

/* lista guardada neste computador (só PAJs com documento pendente) */
const CHAVE = "dpuPelotas.pajsDocumentacaoFaltante.v1";
let armazOk = true;
function lerLista() { try { return JSON.parse(localStorage.getItem(CHAVE) || "[]"); } catch (e) { armazOk = false; return []; } }
function gravarLista(l) { try { localStorage.setItem(CHAVE, JSON.stringify(l)); return true; } catch (e) { armazOk = false; return false; } }
const novoId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const hojeISO = () => `${HOJE.getFullYear()}-${dois(HOJE.getMonth() + 1)}-${dois(HOJE.getDate())}`;
const dataBR = iso => iso ? iso.split("-").reverse().join("/") : "";
function guardarPendente() {
  const itens = S.ck.itens.filter(visivel).map(i => ({ sec: i.sec, html: i.html, k: i.k || "", ok: !!i.ok, na: !!i.na, interno: !!i.interno }));
  const l = lerLista(), paj = S.paj.trim();
  const ex = paj ? l.find(e => e.paj === paj) : null;
  const e = { id: ex ? ex.id : novoId(), paj, nome: S.nome.trim(), cpf: S.cpf, analf: !!S.analf, prazo: S.prazo, dem: S.dem.nome, area: S.dem.area, aberto: ex ? ex.aberto : hojeISO(), atualizado: hojeISO(), ts: Date.now(), itens };
  if (ex) l[l.indexOf(ex)] = e; else l.push(e);
  return gravarLista(l);
}
/* prazo para o(a) assistido(a) entregar o que falta: PRAZO NORMAL (30 dias) ou PAJ URGENTE (48 horas) */
const URGENTE = p => p === "48 horas";
function prazoFim(p, iso) {  // data final do prazo, contado da abertura (ou de hoje)
  const d = iso ? new Date(iso + "T12:00:00") : new Date(HOJE); d.setDate(d.getDate() + (URGENTE(p) ? 2 : 30));
  return `${dois(d.getDate())}/${dois(d.getMonth() + 1)}/${d.getFullYear()}`;
}
const prazoVencido = (p, iso) => { const n = diasAberto(iso); return n !== null && n > (URGENTE(p) ? 2 : 30); };
const prazoTxt = p => URGENTE(p) ? "48 horas (PAJ urgente)" : "30 dias (prazo normal)";
const TEL_MSG = "Envie os documentos e as dúvidas por este WhatsApp, só por mensagem: não atendemos ligações pelo WhatsApp. Se precisar falar por telefone, ligue para o mesmo número, (53) 3284-9450, por ligação comum, das 8h às 17h.";
function marcarPrazo() { document.querySelectorAll('.prazoSel[data-alvo="atend"] button').forEach(b => b.classList.toggle("on", b.dataset.prazo === S.prazo)); }
function diasAberto(iso) { const d = new Date((iso || "") + "T12:00:00"); return isNaN(d) ? null : Math.max(0, Math.round((HOJE - d) / 86400000)); }
function diasTxt(iso, prazo) {
  const n = diasAberto(iso); if (n === null) return "";
  const t = n === 0 ? "(hoje)" : n === 1 ? "(há 1 dia)" : `(há ${n} dias)`;
  return n >= (URGENTE(prazo) ? 2 : 30) ? `<b class="velho">${t}</b>` : t;
}
function desenharLista() {
  const l = lerLista(), q = norm($("filtroPaj").value).trim();
  $("armazAviso").classList.toggle("hide", armazOk);
  $("armazAviso").textContent = armazOk ? "" : "Este navegador não está deixando guardar a lista neste computador (modo anônimo ou dados bloqueados).";
  const box = $("listaPajs"); box.innerHTML = "";
  const vis = l.filter(e => !q || norm(e.paj + " " + e.nome + " " + (e.dem || "")).includes(q)).sort((a, b) => (a.aberto || "").localeCompare(b.aberto || "") || (a.paj || "").localeCompare(b.paj || ""));
  if (!vis.length) { box.innerHTML = `<div class="vazio">${l.length ? "Nenhum PAJ encontrado com essa busca." : "Nenhum PAJ em Meus PAJs. Os PAJs entram aqui quando o atendimento termina com documento pendente, ou pelo botão CADASTRAR PAJ."}</div>`; return; }
  vis.forEach(e => {
    const n = pendentesDe(e.itens).length;
    const b = document.createElement("button"); b.className = "pajItem";
    b.innerHTML = `<span class="num">${e.paj ? "PAJ " + esc(e.paj) : "PAJ sem número"}</span>
      <span><span class="nm2">${esc(e.nome || "(sem nome)")}</span><div class="info">${URGENTE(e.prazo) ? '<b class="urgTag">URGENTE</b> ' : ""}${esc(e.dem || "")} · aberto em ${dataBR(e.aberto)} ${diasTxt(e.aberto, e.prazo)} · prazo até ${prazoFim(e.prazo, e.aberto)}${e.atualizado && e.atualizado !== e.aberto ? " · atualizado em " + dataBR(e.atualizado) : ""}</div></span>
      <span class="qt${n ? "" : " zero"}">${n ? `${n} pendente${n > 1 ? "s" : ""}` : "nada pendente"}</span>`;
    b.addEventListener("click", () => abrirPaj(e.id));
    box.appendChild(b);
  });
}
$("filtroPaj").addEventListener("input", desenharLista);

/* acrescentar um PAJ à mão */
let novoPajDem = null;
combo($("novoPajDem"), $("novoPajDemLista"), d => { novoPajDem = d; $("novoPajDem").value = d.nome; }, () => novoPajDem && novoPajDem.nome);
$("novoPajNum").addEventListener("blur", () => { $("novoPajNum").value = normalizarPAJ($("novoPajNum").value); });
$("novoPajAdd").addEventListener("click", () => {
  const paj = normalizarPAJ($("novoPajNum").value), nome = $("novoPajNome").value.trim(), err = $("novoPajErro");
  if (!paj || !nome) { err.textContent = "Informe o número do PAJ e o nome do(a) assistido(a)."; return; }
  if (!novoPajDem) { err.textContent = "Escolha a demanda na lista."; return; }
  const l = lerLista();
  if (paj && l.some(e => e.paj === paj)) { err.textContent = "Este PAJ já está em Meus PAJs."; return; }
  const itens = itensDaDemanda(novoPajDem).map(i => ({ sec: i.sec, html: i.html, k: i.k || "", ok: false, na: false }));
  const e = { id: novoId(), paj, nome, cpf: "", dem: novoPajDem.nome, area: novoPajDem.area, aberto: hojeISO(), atualizado: hojeISO(), ts: Date.now(), itens };
  l.push(e);
  if (!gravarLista(l)) { err.textContent = "O navegador não deixou guardar a lista neste computador."; return; }
  err.textContent = ""; $("novoPajNum").value = ""; $("novoPajNome").value = ""; $("novoPajDem").value = ""; novoPajDem = null;
  abrirPaj(e.id);
});

/* cópia de segurança: na hora de carregar, fica sempre a versão mais nova de cada PAJ */
const CHAVE_CONC = "dpuPelotas.pajsConcluidos.v1";
const quando = e => e.ts || Date.parse((e.atualizado || e.aberto || "1970-01-01") + "T00:00:00") || 0;
function lerConcluidos() { try { return JSON.parse(localStorage.getItem(CHAVE_CONC) || "[]"); } catch (e) { return []; } }
function marcarConcluido(e) { try { const c = lerConcluidos().filter(x => x.id !== e.id); c.push({ id: e.id, paj: e.paj, ts: Date.now() }); localStorage.setItem(CHAVE_CONC, JSON.stringify(c.slice(-1000))); } catch (er) {} }
$("exportar").addEventListener("click", () => {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(lerLista(), null, 1)], { type: "application/json" }));
  a.download = `Meus PAJs - ${hojeISO().split("-").reverse().join("-")}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  $("backupMsg").textContent = "Cópia salva na pasta Downloads.";
});
$("importarBtn").addEventListener("click", () => $("importar").click());
$("importar").addEventListener("change", async ev => {
  const f = ev.target.files[0]; if (!f) return;
  try {
    const novos = JSON.parse(await f.text());
    if (!Array.isArray(novos)) throw new Error("arquivo inválido");
    const l = lerLista(), conc = lerConcluidos(); let n = 0, velhos = 0, concl = 0;
    novos.forEach(e => {
      if (!e || !Array.isArray(e.itens)) return;
      const c = conc.find(x => x.id === e.id || (e.paj && x.paj === e.paj));
      if (c && c.ts >= quando(e)) { concl++; return; }               // já concluído aqui depois desta cópia
      const ex = l.find(x => x.id === e.id || (e.paj && x.paj === e.paj));
      if (ex && quando(ex) >= quando(e)) { velhos++; return; }       // a versão deste computador é mais nova
      if (ex) l[l.indexOf(ex)] = e; else l.push(e);
      n++;
    });
    gravarLista(l); desenharLista();
    const ign = [velhos && `${velhos} já ${velhos > 1 ? "estavam mais atualizados" : "estava mais atualizado"} neste computador`, concl && `${concl} já ${concl > 1 ? "tinham sido concluídos" : "tinha sido concluído"}`].filter(Boolean);
    $("backupMsg").textContent = `${n} PAJ${n !== 1 ? "s" : ""} carregado${n !== 1 ? "s" : ""} da cópia.${ign.length ? " Não foram trocados: " + ign.join("; ") + "." : ""}`;
  } catch (e) { $("backupMsg").textContent = "Não foi possível ler o arquivo: use uma cópia salva por este assistente."; }
  ev.target.value = "";
});

/* um PAJ da lista */
let pajAtual = null;
function salvarPajAtual() {
  const l = lerLista(), i = l.findIndex(x => x.id === pajAtual.id);
  pajAtual.atualizado = hojeISO(); pajAtual.ts = Date.now();
  if (i >= 0) l[i] = pajAtual; else l.push(pajAtual);
  gravarLista(l);
}
function abrirPaj(id) {
  const e = lerLista().find(x => x.id === id); if (!e) return;
  pajAtual = e;
  $("pjTitulo").textContent = e.paj ? `PAJ nº ${e.paj}` : "PAJ sem número";
  $("pjInfo").innerHTML = `<b>${esc(e.nome || "(sem nome)")}</b>${e.cpf ? " · CPF " + esc(e.cpf) : ""} · ${esc(e.dem || "")} · aberto em ${dataBR(e.aberto)}`;
  desenharPrazoPaj();
  desenharChecklist($("pjLista"), e.itens, () => { salvarPajAtual(); mensagensPaj(); });
  $("pjAnalf").checked = !!e.analf; $("pjPdfMsg").textContent = "";
  marcarPrazoPaj();
  mostrarTela("paj");
}
/* lista de documentos pendentes deste PAJ, para imprimir ou salvar */
async function pdfPendentesPaj() {
  const e = pajAtual, f = pendentesDe(e.itens).filter(i => !i.interno);
  if (!f.length) { $("pjPdfMsg").innerHTML = '<span class="erro">Não há documentos pendentes para o(a) assistido(a) enviar.</span>'; return null; }
  return await pdfPendentes({ nome: e.nome, cpf: e.cpf, paj: e.paj, analf: !!e.analf, dem: e.dem || "", itens: f, prazo: e.prazo || "30 dias" });
}
function marcarPrazoPaj() { document.querySelectorAll('.prazoSel[data-alvo="paj"] button').forEach(b => b.classList.toggle("on", b.dataset.prazo === (pajAtual.prazo || "30 dias"))); }
function desenharPrazoPaj() {
  const e = pajAtual, p = e.prazo || "30 dias";
  $("pjPrazoInfo").innerHTML = `Prazo de ${prazoTxt(p)}: ${prazoVencido(p, e.aberto) ? `<b class="velho">venceu em ${prazoFim(p, e.aberto)}</b>` : `vai até <b>${prazoFim(p, e.aberto)}</b>`}.`;
}
document.querySelectorAll(".prazoSel button").forEach(b => b.addEventListener("click", () => {
  const alvo = b.closest(".prazoSel").dataset.alvo;
  if (alvo === "paj") { if (!pajAtual) return; pajAtual.prazo = b.dataset.prazo; salvarPajAtual(); marcarPrazoPaj(); desenharPrazoPaj(); mensagensPaj(); }
  else { S.prazo = b.dataset.prazo; marcarPrazo(); gravarRascunho(); }
}));
$("pjAnalf").addEventListener("change", () => { if (!pajAtual) return; pajAtual.analf = $("pjAnalf").checked; salvarPajAtual(); });
$("pjImprimir").addEventListener("click", async () => {
  const msg = $("pjPdfMsg"); msg.textContent = "Preparando a impressão…";
  try {
    const b = await pdfPendentesPaj(); if (!b) return;
    const url = urlPdf(b), fr = $("printFrame");
    msg.innerHTML = `Abrindo a janela de impressão… Se ela não aparecer em alguns segundos, <a href="#" id="pjAbrirImp">abra a lista numa nova guia</a> e use Ctrl+P.`;
    $("pjAbrirImp").addEventListener("click", ev => { ev.preventDefault(); const w = window.open("", "_blank"); if (w) escreverJanela(w, JANELA("Documentos pendentes", `<embed src="${url}" type="application/pdf">`)); });
    fr.onload = () => setTimeout(() => { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (er) {} }, 400);
    fr.src = url;
  } catch (er) { console.error(er); msg.innerHTML = `<span class="erro">Não foi possível gerar a lista: ${esc(er.message)}</span>`; }
});
$("pjSalvar").addEventListener("click", async () => {
  const msg = $("pjPdfMsg");
  try {
    const b = await pdfPendentesPaj(); if (!b) return;
    const a = document.createElement("a"); a.href = urlPdf(b);
    a.download = nomeArq(`Documentos pendentes - ${(pajAtual.nome || "").trim() || "PAJ " + (pajAtual.paj || "")}`) + ".pdf";
    document.body.appendChild(a); a.click(); a.remove();
    msg.innerHTML = `<span class="ok">Arquivo <b>${esc(a.download)}</b> salvo na pasta Downloads.</span>`;
  } catch (er) { console.error(er); msg.innerHTML = `<span class="erro">Não foi possível gerar a lista: ${esc(er.message)}</span>`; }
});
function mensagensPaj() {
  const e = pajAtual, f = pendentesDe(e.itens), lista = listaNumerada(f), fDoc = f.filter(i => !i.interno);
  const p = (e.nome || "").trim().split(/\s+/)[0] || "";
  const nm = p ? " " + p.charAt(0).toUpperCase() + p.slice(1).toLowerCase() : "";
  const t1 = $("pjMsg1"), t2 = $("pjMsg2"), t3 = $("pjMsg3");
  const pz = e.prazo || "30 dias", fim = prazoFim(pz, e.aberto), venc = prazoVencido(pz, e.aberto);
  const avisoPrazo = venc ? `O prazo para enviar os documentos terminou em ${fim}. Envie o que falta o quanto antes, para o PAJ não ser arquivado.`
    : `${URGENTE(pz) ? "Seu PAJ é URGENTE: o" : "O"} prazo para enviar os documentos que faltam vai até ${fim}. Se a documentação não chegar até essa data, o PAJ será arquivado.`;
  t1.value = fDoc.length ? `Prezado(a)${nm}, recebemos os documentos enviados. Ainda faltam:\n\n${listaNumerada(fDoc)}\n\n${avisoPrazo}\n\n${TEL_MSG}` : (f.length ? "Não há documentos pendentes para o(a) assistido(a) enviar." : "Não há documentos pendentes: use a mensagem 3.");
  t2.value = f.length ? `O(a) assistido(a) enviou parte da documentação pendente. Ainda faltam:\n\n${lista}\n\nPrazo: ${URGENTE(pz) ? "48 horas – PAJ URGENTE" : "30 dias"}, até ${fim}${venc ? " (vencido)" : ""}.` : "Não há documentos pendentes: use a mensagem 3.";
  t3.value = "O(a) assistido(a) encaminhou toda a documentação pendente. Tramito ao grupo temático.";
  t1.disabled = !fDoc.length; t2.disabled = !f.length;
  [t1, t2, t3].forEach(t => { t.rows = Math.max(2, t.value.split("\n").length + 1); });
  $("pjResumo").innerHTML = f.length ? `Falta${f.length > 1 ? "m" : ""} <b>${f.length}</b> ${f.length > 1 ? "itens" : "item"}.` : "<b>Todos os itens foram marcados.</b> Se o(a) assistido(a) mandou tudo, movimente o PAJ com a mensagem 3 e clique em CONCLUIR.";
}
document.querySelectorAll("[data-copia]").forEach(b => b.addEventListener("click", () => copiar($(b.dataset.copia).value, b.nextElementSibling)));
function acrescentarNoPaj() {
  const v = $("pjNovo").value.trim(); if (!v || !pajAtual) return;
  const t = v.charAt(0).toUpperCase() + v.slice(1);
  const it = pajAtual.itens, ult = it.map(i => i.sec).lastIndexOf("esp");
  it.splice(ult >= 0 ? ult + 1 : it.length, 0, { sec: "esp", html: esc(t), k: "", ok: false, na: false });
  desenharChecklist($("pjLista"), it, () => { salvarPajAtual(); mensagensPaj(); });
  $("pjNovo").value = ""; $("pjNovo").focus();
}
$("pjAdd").addEventListener("click", acrescentarNoPaj);
$("pjNovo").addEventListener("keydown", e => { if (e.key === "Enter") acrescentarNoPaj(); });
["voltarLista", "voltarLista2"].forEach(id => $(id).addEventListener("click", () => mostrarTela("lista")));
$("concluirPaj").addEventListener("click", () => {
  const e = pajAtual, n = pendentesDe(e.itens).length;
  modal("Concluir este PAJ?",
    `<p>Concluir irá excluir o ${e.paj ? "PAJ nº " + esc(e.paj) : "PAJ"} (${esc(e.nome || "sem nome")}) de Meus PAJs (a lista de PAJs com documentação faltante).</p>`
    + (n ? `<p class="erro"><b>Atenção:</b> ainda ${n > 1 ? "há " + n + " itens" : "há 1 item"} sem marcação.</p>` : ""),
    () => { gravarLista(lerLista().filter(x => x.id !== e.id)); marcarConcluido(e); pajAtual = null; mostrarTela("lista"); });
});

/* ---------- rascunho: o atendimento em andamento fica guardado neste computador até TERMINAR ---------- */
const CHAVE_RASC = "dpuPelotas.rascunhoAtendimento.v1";
let rascTimer = null, rascPronto = false;  // só grava depois de decidir o que fazer com um rascunho anterior
function temDados() { return !!(S.nome.trim() || S.cpf || S.paj || S.dem); }
function lerRascunho() {
  try { const o = JSON.parse(localStorage.getItem(CHAVE_RASC) || "null"), c = (o && o.campos) || {};
        return o && ((c.nome || "").trim() || c.cpf || c.paj || o.dem) ? Object.assign(o, { nome: (c.nome || "").trim(), paj: c.paj || "" }) : null; }
  catch (e) { return null; }
}
function apagarRascunho() { try { localStorage.removeItem(CHAVE_RASC); } catch (e) {} }
function gravarRascunho() {
  if (!rascPronto || saindo || !temDados()) return;
  const o = { ts: Date.now(), etapa: atual, cidV, dem: S.dem ? S.dem.nome : "", nv: S.nv, narrVar: S.narrVar, prazo: S.prazo, rf: S.rf, fOff: [...S.fOff], fOn: [...S.fOn], msg: $("msg").value,
              ck: S.ck ? { dem: S.ck.dem ? S.ck.dem.nome : "", itens: S.ck.itens } : null, campos: {} };
  Object.keys(S).forEach(k => { if (["string", "boolean", "number"].includes(typeof S[k])) o.campos[k] = S[k]; });
  try { localStorage.setItem(CHAVE_RASC, JSON.stringify(o)); } catch (e) {}
}
const agendarRascunho = () => { if (!rascPronto) return; clearTimeout(rascTimer); rascTimer = setTimeout(gravarRascunho, 500); };
["input", "change", "click"].forEach(ev => document.addEventListener(ev, agendarRascunho, true));
window.addEventListener("pagehide", () => { if (rascPronto) gravarRascunho(); });
function restaurarRascunho(o) {
  Object.assign(S, o.campos || {});
  S.nv = o.nv || {}; S.narrVar = o.narrVar || {}; S.prazo = o.prazo || "30 dias"; marcarPrazo(); S.rf = o.rf || null; S.fOff = new Set(o.fOff || []); S.fOn = new Set(o.fOn || []);
  cidV = o.cidV || "10";
  document.querySelectorAll("[data-s]").forEach(el => { const v = S[el.dataset.s]; if (el.type === "checkbox") el.checked = !!v; else if (v !== undefined) el.value = v; });
  if (S.endCidade && window.definirCidade) window.definirCidade(S.endCidade);
  const d = DEMANDAS.find(x => x.nome === o.dem);
  S.dem = null;
  if (d) escolherDemanda(d);
  if (d && o.ck && o.ck.dem === d.nome) S.ck = { dem: d, itens: o.ck.itens };
  if (S.narrId && narrDaDemanda() && narrDaDemanda().id === S.narrId) { $("narrOut").classList.remove("hide"); previaNarrativa(); }
  if (S.modo) { const b = document.querySelector(`.modo[data-modo="${S.modo}"]`); if (b) b.click(); }
  if (S.msgEditada && o.msg) $("msg").value = o.msg;
  ["cpf", "paj", "nasc"].forEach(aoMudar); chips();
  ir(Math.min(o.etapa || 0, steps.length - 1));
}
function oferecerRascunho() {
  if (rascPronto) return;
  const o = lerRascunho();
  if (!o || temDados()) { rascPronto = true; return; }
  const t = new Date(o.ts), quandoTxt = `${dois(t.getDate())}/${dois(t.getMonth() + 1)} às ${dois(t.getHours())}:${dois(t.getMinutes())}`;
  modal("Atendimento não terminado",
    `<p>Há um atendimento que não foi terminado: <b>${esc(o.nome || "assistido(a) sem nome")}</b>${o.paj ? ` – PAJ ${esc(o.paj)}` : ""}${o.dem ? ` – ${esc(o.dem)}` : ""}, guardado em ${quandoTxt}.</p><p>Quer continuar de onde parou?</p>`,
    () => { try { restaurarRascunho(o); } catch (e) { console.error(e); } rascPronto = true; },
    { sim: "CONTINUAR", nao: "Descartar e começar outro", aoNao: () => { apagarRascunho(); rascPronto = true; } });
}

/* ---------- salário mínimo usado nos cálculos ---------- */
function mostrarSM() {
  $("smValor").textContent = `${brl(SM)} (${SMinfo.ano})`;
  const ano = HOJE.getFullYear();
  $("smAviso").classList.toggle("hide", ano <= SMinfo.ano);
  $("smAviso").innerHTML = ano > SMinfo.ano ? `<b>Atenção:</b> estamos em ${ano}, mas o salário mínimo cadastrado é o de ${SMinfo.ano}. Clique em <b>Alterar</b> e informe o valor de ${ano}.` : "";
}
$("smAlterar").addEventListener("click", () => { $("smForm").classList.toggle("hide"); $("smNovo").value = brlNum(SM); $("smAno").value = Math.max(HOJE.getFullYear(), SMinfo.ano); $("smNovo").focus(); });
$("smSalvar").addEventListener("click", () => {
  const v = dinheiro($("smNovo").value), a = parseInt($("smAno").value, 10);
  if (!(v > 500 && v < 20000) || !(a > 2000 && a < 2100)) { $("smMsg").textContent = "Confira o valor e o ano."; $("smMsg").className = "erro"; return; }
  SMinfo = { ano: a, valor: v }; SM = v; LIM_DESPESAS = 2 * v;
  try { localStorage.setItem(SM_CHAVE, JSON.stringify(SMinfo)); } catch (e) {}
  $("smForm").classList.add("hide"); $("smMsg").textContent = "Salário mínimo atualizado neste computador."; $("smMsg").className = "ok";
  mostrarSM(); const d = narrDaDemanda(); if (d) renderNarrativa(d);
});
mostrarSM();

/* ---------- dentro do app Unidade: sem a barra verde de cima; os dados do atendimento vão para o menu das etapas ---------- */
if (EMBUTIDO) { document.body.classList.add("embutido"); nav.prepend($("chips")); }
$("voltarMenuSetor").textContent = EMBUTIDO ? "← VOLTAR AO MENU DO DAC" : "← VOLTAR AO MENU INICIAL";
$("voltarMenuSetor").addEventListener("click", () => { if (EMBUTIDO) parent.postMessage({ ir: "dac" }, "*"); else mostrarTela("menu"); });
document.querySelectorAll('[data-s="nasc"]').forEach(el => { el.max = hojeISO(); });

/* ---------- início ---------- */
renderMembros(); tags(); condicoes(); mostrarTotal(); chips();
ir(0);
mostrarTela(EMBUTIDO ? "assist" : "menu");

/* ---------- "O que é isso?": explicação curta numa guia nova (o texto completo fica na aba APRENDER) ---------- */
function paginaExplicacao(k) {
  const g = GLOSS[k]; if (!g) return null;
  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(g.t)} – O que é isso?</title><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:"Segoe UI",Calibri,Arial,sans-serif;background:#f4f7f2;color:#1d2a17;margin:0;line-height:1.6}
main{max-width:760px;margin:32px auto;background:#fff;border:1px solid #d8e2d1;border-radius:12px;padding:28px 34px}
.top{font-size:12.5px;letter-spacing:.06em;text-transform:uppercase;color:#3f7f2a;font-weight:700}h1{margin:6px 0 14px;font-size:26px;color:#24451a}
.ex{background:#eef5ea;border-left:4px solid #3f7f2a;padding:10px 14px;border-radius:6px;margin:12px 0}.fonte{margin-top:24px;padding-top:12px;border-top:1px solid #dde4d8;font-size:12.5px;color:#5b6b52}
.mais{margin-top:14px;font-size:13.5px;color:#5b6b52}button{font:inherit;margin-top:18px;padding:8px 16px;border-radius:8px;border:1px solid #3f7f2a;background:#3f7f2a;color:#fff;cursor:pointer}</style></head>
<body><main><div class="top">O que é isso?</div><h1>${esc(g.t)}</h1>${g.h}
<div class="mais">Para estudar o assunto com mais calma, abra a aba <b>APRENDER</b> na tela “Escolha o setor” do Unidade.</div>
<div class="fonte"><b>Fontes:</b> ${g.f}</div><button onclick="window.close()">Fechar esta guia</button></main></body></html>`;
}
function abrirExplicacao(k) {
  const html = paginaExplicacao(k); if (!html) return;
  let w = null; try { w = window.open("", "_blank"); } catch (e) {}
  if (w) { w.document.open(); w.document.write(html); w.document.close(); return; }
  const g = GLOSS[k];  // navegador bloqueou a guia nova: mostra aqui mesmo
  modal(g.t, g.h + `<div style="margin-top:10px;font-size:12.5px;color:var(--gray)"><b>Fontes:</b> ${g.f}</div>`, () => {}, { sim: "Fechar", nao: "Voltar" });
}
document.addEventListener("click", e => { const b = e.target.closest("[data-oque]"); if (b) { e.preventDefault(); abrirExplicacao(b.dataset.oque); } });

/* tabelinha de data: todo campo de data (dd/mm/aaaa) ganha o botão de calendário; dá para digitar ou escolher no calendário */
(function () {
  const st = document.createElement("style");
  st.textContent = ".calWrap{display:flex;align-items:stretch;gap:6px;width:100%}.calWrap>input[type=text]{flex:1;min-width:0}"
    + ".calBt{position:relative;flex:0 0 44px;border:1.5px solid #cfdcc8;border-radius:8px;background:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;color:#2f6a1f;overflow:hidden}"
    + ".calBt:hover{background:#eef6ea;border-color:#3f7f2a}.calBt svg{width:20px;height:20px;pointer-events:none}"
    + ".calBt input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;border:0;padding:0;margin:0}"
    + ".calBt input::-webkit-calendar-picker-indicator{position:absolute;inset:0;width:auto;height:auto;cursor:pointer}";
  document.head.appendChild(st);
  const ICO = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M3 10h18M8 3v4M16 3v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M7 14h2M11 14h2M15 14h2M7 17h2M11 17h2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
  const paraISO = v => { const m = (v || "").trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/); return m ? `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}` : ""; };
  function equipar(inp) {
    if (inp.dataset.cal) return; inp.dataset.cal = "1";
    const w = document.createElement("span"); w.className = "calWrap"; inp.parentNode.insertBefore(w, inp); w.appendChild(inp);
    const b = document.createElement("span"); b.className = "calBt"; b.title = "Escolher a data no calendário"; b.innerHTML = ICO;
    const d = document.createElement("input"); d.type = "date"; d.tabIndex = -1; d.setAttribute("aria-label", "Escolher a data no calendário");
    b.appendChild(d); w.appendChild(b);
    d.addEventListener("focus", () => { d.value = paraISO(inp.value); });
    d.addEventListener("change", () => {
      if (!d.value) return; const [a, m, di] = d.value.split("-");
      inp.value = `${di}/${m}/${a}`;
      inp.dispatchEvent(new Event("input", { bubbles: true })); inp.dispatchEvent(new Event("change", { bubbles: true }));
    });
  }
  const varrer = () => document.querySelectorAll('input[type="text"][placeholder="dd/mm/aaaa"]').forEach(equipar);
  new MutationObserver(varrer).observe(document.body, { childList: true, subtree: true }); varrer();
})();

# Mensagens Padronizadas – DAC: gerador das mensagens prontas para o(a) assistido(a) (WhatsApp) que não saem de outra ferramenta:
# lembrete de prazo, PAJ arquivado, foto ilegível, como assinar e devolver os formulários, documentos recebidos e PAJ encaminhado.
# Usa só os dados fixos do CLAUDE.md (telefones, horários, prazos de 30 dias / 48 horas) e a assinatura de comum/comum.js.
# Entra no Unidade (DAC › Mensagens Padronizadas) e nos apps Térreo e Térreo – DAC. Nada fica guardado (só a assinatura).
from pathlib import Path as _Path; RAIZ = str(_Path(__file__).resolve().parents[1]) + "/"  # raiz do repositório

HTML = r"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="color-scheme" content="only light">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mensagens Padronizadas – DAC – DPU Pelotas</title>
<style>
  :root { --ink:#1e1e1e; --gray:#5f5f5f; --green:#2f6a1f; --green2:#3f7f2a; --band:#e2efd9; --soft:#f3f8ef; --line:#cfdcc8; --bg:#eef1ec; --red:#a23b31; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--ink); font-family:"Segoe UI", Calibri, Carlito, Arial, sans-serif; }
  button { font:inherit; cursor:pointer; }
  .hide { display:none !important; }
  .wrap { max-width:1180px; margin:0 auto; padding:24px 22px 110px; display:grid; grid-template-columns:400px 1fr; gap:22px; align-items:start; }
  @media (max-width:900px) { .wrap { grid-template-columns:1fr; } }
  .panel { background:#fff; border-radius:14px; padding:16px 18px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
  .panel h1 { color:var(--green); font-size:23px; margin:0 0 4px; }
  .panel .sub { color:var(--gray); font-size:14px; line-height:1.45; margin:0 0 12px; }
  .tt { font-size:12.5px; font-weight:800; letter-spacing:.06em; color:#6c7568; margin:14px 0 6px; }
  .tipos { display:flex; flex-direction:column; gap:7px; }
  .tipos button { text-align:left; border:2px solid var(--line); background:#fff; border-radius:11px; padding:9px 12px; display:flex; flex-direction:column; gap:2px; }
  .tipos button b { color:var(--green); font-size:14.5px; letter-spacing:.02em; }
  .tipos button small { color:var(--gray); font-size:12.5px; line-height:1.35; }
  .tipos button:hover { border-color:#a9c69b; }
  .tipos button.on { border-color:var(--green2); background:var(--soft); }
  .campos { display:flex; flex-direction:column; gap:10px; }
  label.f { display:flex; flex-direction:column; gap:4px; font-size:13px; font-weight:700; color:var(--gray); }
  label.f small { font-weight:400; font-size:12px; }
  label.f input, label.f textarea { font:inherit; font-size:15px; font-weight:400; color:var(--ink); padding:8px 10px; border:1.5px solid var(--line); border-radius:8px; background:#fff; }
  label.f textarea { resize:vertical; min-height:74px; line-height:1.4; }
  label.f input:focus, label.f textarea:focus { outline:none; border-color:var(--green2); box-shadow:0 0 0 3px rgba(63,127,42,.15); }
  .duo { display:flex; gap:8px; flex-wrap:wrap; }
  .duo button { flex:1 1 140px; border:2px solid var(--line); background:#fff; border-radius:10px; padding:7px 10px; text-align:left; }
  .duo button b { display:block; font-size:13.5px; color:var(--green); } .duo button small { color:var(--gray); font-size:12px; }
  .duo button.on { border-color:var(--green2); background:var(--soft); }
  .duo button.urg.on { border-color:var(--red); background:#fbefed; } .duo button.urg.on b { color:var(--red); }
  .grupoL { display:flex; flex-direction:column; gap:3px; font-size:13px; font-weight:700; color:var(--gray); }
  .cks { display:flex; flex-direction:column; gap:5px; }
  .cks label { display:flex; gap:8px; align-items:flex-start; font-weight:400; color:var(--ink); font-size:14px; cursor:pointer; }
  .cks input { accent-color:var(--green2); width:17px; height:17px; margin:1px 0 0; flex:0 0 auto; }
  .folha { background:#fff; border-radius:14px; padding:20px 22px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
  .folha h2 { color:var(--green); font-size:21px; margin:0 0 4px; }
  .folha .quando { color:var(--gray); font-size:14px; line-height:1.45; margin:0 0 12px; }
  .msgBox { margin-top:12px; }
  .msgBox .t { font-weight:700; font-size:14px; color:var(--green); margin-bottom:6px; }
  .msgBox .t small { display:block; font-weight:400; color:var(--gray); font-size:12.5px; }
  .msgBox textarea { width:100%; font:inherit; font-size:15px; line-height:1.5; color:var(--ink); padding:12px 14px; border:1.5px solid var(--line); border-radius:10px; resize:vertical; background:#fbfcfa; }
  .bts { display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-top:8px; }
  .acao { border:none; background:var(--green2); color:#fff; border-radius:10px; padding:11px 18px; font-weight:800; letter-spacing:.03em; font-size:14.5px; text-decoration:none; display:inline-block; }
  .acao:hover { background:var(--green); }
  .ghost { border:1.5px solid var(--green2); background:#fff; color:var(--green); border-radius:10px; padding:10px 16px; font-weight:700; font-size:14.5px; text-decoration:none; display:inline-block; }
  .ghost:hover { background:var(--soft); }
  .okc { font-size:13.5px; color:var(--green); font-weight:700; }
  .aviso { background:#fbefed; color:var(--red); border-radius:9px; padding:8px 12px; font-size:13.5px; margin-top:10px; line-height:1.4; }
  .aviso:empty { display:none; }
  .dica { font-size:12.5px; color:var(--gray); line-height:1.45; margin-top:12px; }
__CSS_ASS__
</style>
</head>
<body>
<div class="wrap">
  <div class="panel ui">
    <h1>Mensagens Padronizadas – DAC</h1>
    <p class="sub">Escolha a mensagem, complete os campos e copie o texto para o WhatsApp do(a) assistido(a). Nada do que é digitado fica guardado.</p>
    <div class="tt">1. QUAL MENSAGEM?</div>
    <div class="tipos" id="tipos"></div>
    <div class="tt">2. COMPLETE</div>
    <div class="campos" id="campos">
      <label class="f" data-c="nome">Nome do(a) assistido(a) <small>Só o primeiro nome entra na mensagem.</small><input id="cNome" type="text" autocomplete="off"></label>
      <label class="f" data-c="paj">Número do PAJ <small>Opcional.</small><input id="cPaj" type="text" autocomplete="off" placeholder="2026/025-1234"></label>
      <div class="grupoL" data-c="prazo">Prazo do PAJ
        <div class="duo" id="cPrazo"><button type="button" data-p="30 dias" class="on"><b>PRAZO NORMAL</b><small>30 dias</small></button><button type="button" data-p="48 horas" class="urg"><b>PAJ URGENTE</b><small>48 horas</small></button></div>
      </div>
      <label class="f" data-c="data">Último dia do prazo <small id="cDataObs"></small><input id="cData" type="date"></label>
      <label class="f" data-c="docs">Documentos que faltam <small>Um por linha. Opcional.</small><textarea id="cDocs" rows="4" placeholder="RG e CPF&#10;Comprovante de residência"></textarea></label>
      <label class="f" data-c="ileg">Documentos que não deu para ler <small>Um por linha.</small><textarea id="cIleg" rows="3" placeholder="Comprovante de residência"></textarea></label>
      <div class="grupoL" data-c="motivo">O que aconteceu com a foto? <small style="font-weight:400">Marque um ou mais.</small>
        <div class="cks" id="cMotivo"></div>
      </div>
      <div class="grupoL" data-c="analf">Quem assina
        <div class="duo" id="cAnalf"><button type="button" data-a="" class="on"><b>ASSISTIDO(A) ASSINA</b><small>imprime ou assina pelo gov.br</small></button><button type="button" data-a="1"><b>ANALFABETO(A)</b><small>digital e assinatura a rogo</small></button></div>
      </div>
      <label class="f" data-c="forms">Formulários enviados <small>Um por linha. Opcional.</small><textarea id="cForms" rows="3" placeholder="Declaração de residência&#10;Formulário de renda"></textarea></label>
    </div>
    <div class="tt">3. SEU NOME</div>
    <div id="assBox"></div>
  </div>
  <div class="folha ui" id="folha">
    <h2 id="mTit"></h2>
    <p class="quando" id="mQuando"></p>
    <div class="msgBox"><div class="t">Para o(a) assistido(a), no WhatsApp<small>Confira antes de enviar. Dá para mudar o texto aqui mesmo.</small></div>
      <textarea id="msg" rows="16"></textarea>
      <div class="bts"><button type="button" class="acao" data-copia="msg">COPIAR MENSAGEM</button><a class="ghost" id="zap" target="_blank" rel="noopener">ABRIR NO WHATSAPP</a><span class="okc"></span></div>
    </div>
    <div class="aviso" id="aviso"></div>
    <div class="msgBox hide" id="sisBox"><div class="t">Para o SIS-DPU<small>Texto para movimentar o PAJ (o mesmo do Checklist de Documentos).</small></div>
      <textarea id="sis" rows="3"></textarea>
      <div class="bts"><button type="button" class="acao" data-copia="sis">COPIAR TEXTO DO SIS-DPU</button><span class="okc"></span></div>
    </div>
    <p class="dica" id="mDica"></p>
  </div>
</div>
<script>__COMUM__</script>
<script>
"use strict";
const $ = id => document.getElementById(id);
const TEL_MSG = DAC.TEL_MSG;
const TEL_DUV = "Para tirar dúvidas, mande mensagem por este WhatsApp (só mensagens: não atendemos ligações pelo WhatsApp) ou ligue para o mesmo número, (53) 3284-9450, por ligação comum, das 8h às 17h.";
const MOTIVOS = [["cortada", "a foto cortou parte da folha"], ["borrada", "a foto saiu borrada ou tremida"], ["escura", "a foto saiu escura ou com reflexo"],
  ["verso", "faltou a foto do verso"], ["arquivo", "o arquivo não abre"]];
/* as 5 mensagens: c = campos que aparecem; quando = quando usar; dica = observação para quem atende */
const TIPOS = [
  { k: "prazo", t: "LEMBRETE DE PRAZO", s: "O prazo para entregar os documentos está perto de acabar.", c: ["nome", "paj", "prazo", "data", "docs"],
    quando: "Quando o prazo para entregar os documentos pendentes está perto de acabar e ainda falta documento.",
    dica: "Para a lista do que falta montada pela demanda, use o Checklist de Documentos (Textos automáticos, 1). Se a data já passou, a mensagem avisa que o prazo terminou." },
  { k: "arquivado", t: "PAJ ARQUIVADO", s: "Os documentos não chegaram no prazo.", c: ["nome", "paj", "prazo"],
    quando: "Quando o prazo acabou sem a entrega dos documentos pendentes e o PAJ foi arquivado.",
    dica: "O (53) 99112-4160 é só para agendar PAJ novo." },
  { k: "foto", t: "FOTO ILEGÍVEL", s: "Pedir para mandar a foto de novo.", c: ["nome", "ileg", "motivo", "prazo", "data"],
    quando: "Quando a foto de um documento chegou cortada, borrada, escura, sem o verso ou o arquivo não abre.",
    dica: "O último dia do prazo é opcional: se for preenchido, a mensagem lembra o prazo." },
  { k: "assinar", t: "COMO ASSINAR E DEVOLVER", s: "Formulários que precisam de assinatura.", c: ["nome", "paj", "analf", "forms", "prazo", "data"],
    quando: "Junto com os formulários enviados pelo WhatsApp, para explicar como assinar e devolver.",
    dica: "Para dizer o que escrever em cada formulário, use CRIAR MENSAGEM, na Central de Formulários. O último dia do prazo é opcional." },
  { k: "recebido", t: "DOCUMENTOS RECEBIDOS", s: "Chegou tudo e o PAJ foi encaminhado.", c: ["nome", "paj"],
    quando: "Quando a documentação pendente ficou completa e o PAJ foi encaminhado para análise.",
    dica: "O texto do SIS-DPU é o mesmo do Checklist de Documentos (Textos automáticos, 3)." },
];
let tipo = TIPOS[0], prazo = "30 dias", analf = false;

$("tipos").innerHTML = TIPOS.map(o => `<button type="button" data-k="${o.k}"><b>${o.t}</b><small>${o.s}</small></button>`).join("");
$("cMotivo").innerHTML = MOTIVOS.map(([k, t]) => `<label><input type="checkbox" value="${k}"> ${t.charAt(0).toUpperCase() + t.slice(1)}</label>`).join("");

const primeiro = () => { const p = ($("cNome").value || "").trim().split(/\s+/)[0] || ""; return p ? " " + p.charAt(0).toUpperCase() + p.slice(1).toLowerCase() : ""; };
const linhas = id => ($(id).value || "").split(/\n/).map(s => s.trim().replace(/[;.,]+$/, "")).filter(Boolean);
const numerada = its => its.map((t, j) => `${j + 1}. ${t}${j === its.length - 1 ? "." : ";"}`).join("\n");
const juntar = a => a.length < 2 ? a.join("") : a.slice(0, -1).join("; ") + "; e " + a[a.length - 1];
const URG = () => prazo === "48 horas";
function dataFim() {
  const v = $("cData").value; if (!v) return null;
  const [a, m, d] = v.split("-").map(Number), dt = new Date(a, m - 1, d);
  const dois = n => String(n).padStart(2, "0");
  return { txt: `${dois(d)}/${dois(m)}/${a}`, vencido: dt < new Date(new Date().setHours(0, 0, 0, 0)) };
}
const pajTxt = () => { const p = $("cPaj").value.trim(); return p ? ` nº ${p}` : ""; };
function linhaPrazo(f, continua) {
  if (f.vencido) return `O prazo para enviar os documentos terminou em ${f.txt}. Envie o que falta o quanto antes, para o PAJ não ser arquivado.`;
  return `${URG() ? "Seu PAJ é URGENTE: o" : "O"} prazo para enviar os documentos ${continua ? "continua até" : "que faltam vai até"} ${f.txt}. Se a documentação não chegar até essa data, o PAJ será arquivado.`;
}

function gerar() {
  const L = [`Prezado(a)${primeiro()},`, "", "Aqui é a Defensoria Pública da União de Pelotas."];
  const av = [], f = dataFim();
  let sis = "";
  if (!($("cNome").value || "").trim()) av.push("Escreva o nome do(a) assistido(a).");
  if (tipo.k === "prazo") {
    if (!f) av.push("Informe o último dia do prazo.");
    const docs = linhas("cDocs");
    L.push("", `Seu PAJ${pajTxt()} ainda está aguardando documentos.`);
    if (docs.length) L.push("", "Ainda faltam:", "", numerada(docs));
    L.push("", f ? linhaPrazo(f, false) : `${URG() ? "Seu PAJ é URGENTE: o" : "O"} prazo para enviar os documentos que faltam vai até __/__/____. Se a documentação não chegar até essa data, o PAJ será arquivado.`);
    L.push("", TEL_MSG);
  } else if (tipo.k === "arquivado") {
    L.push("", `Informamos que o seu PAJ${pajTxt()} foi ARQUIVADO, porque os documentos pendentes não foram entregues no prazo de ${URG() ? "48 horas (PAJ URGENTE)" : "30 dias"}.`);
    L.push("", "Se ainda precisar da ajuda da DPU com esse assunto, será preciso agendar um novo atendimento pelo WhatsApp (53) 99112-4160, que é só para agendamentos.");
    L.push("", TEL_DUV);
  } else if (tipo.k === "foto") {
    const docs = linhas("cIleg"), mot = [...document.querySelectorAll("#cMotivo input:checked")].map(i => MOTIVOS.find(m => m[0] === i.value)[1]);
    if (!docs.length) av.push("Escreva qual documento não deu para ler.");
    if (!mot.length) av.push("Marque o que aconteceu com a foto.");
    L.push("", docs.length === 1 ? `Recebemos as fotos, mas não foi possível ler este documento: ${docs[0]}.` : docs.length ? "Recebemos as fotos, mas não foi possível ler estes documentos:" : "Recebemos as fotos, mas não foi possível ler alguns documentos.");
    if (docs.length > 1) L.push("", numerada(docs));
    if (mot.length) L.push("", `Motivo: ${juntar(mot)}.`);
    L.push("", "Por favor, envie de novo uma foto de cada folha (frente e verso, quando houver), bem enquadrada, de boa qualidade e legível. Para a foto sair boa: coloque o documento sobre uma mesa, num lugar bem iluminado, sem flash; enquadre a folha inteira; e confira se dá para ler tudo antes de enviar.");
    if (f) L.push("", linhaPrazo(f, true));
    L.push("", TEL_MSG);
  } else if (tipo.k === "assinar") {
    const fs = linhas("cForms"), um = fs.length === 1;
    if (fs.length) L.push("", `Estamos enviando ${um ? "o formulário abaixo, que precisa" : "os formulários abaixo, que precisam"} ${analf ? "ser assinados a rogo" : "da sua assinatura"}:`.replace("o formulário abaixo, que precisa ser assinados", "o formulário abaixo, que precisa ser assinado"), "", numerada(fs));
    else L.push("", `Estamos enviando os documentos que precisam ${analf ? "ser assinados a rogo" : "da sua assinatura"}.`);
    if (analf) {
      L.push("", "Como a assinatura será a rogo, faça assim:", "");
      L.push("1. Imprima os documentos e preencha o que estiver em branco.");
      L.push("2. Em cada documento, coloque a digital do(a) assistido(a) no quadro indicado.");
      L.push("3. Uma pessoa de confiança assina a rogo e duas testemunhas assinam ao lado, escrevendo o nome e o CPF de cada uma.");
      L.push("4. Tire uma foto de cada página, bem enquadrada, nítida e legível, e envie tudo por aqui.");
    } else {
      L.push("", "Você pode escolher uma destas formas:", "");
      L.push("1. Imprimir, preencher o que estiver em branco, assinar e tirar uma foto de cada página (a foto precisa estar bem enquadrada, nítida e legível); ou");
      L.push("2. Assinar pelo gov.br (assinatura eletrônica), sem precisar imprimir.");
      L.push("", "Depois, envie tudo por aqui, de uma vez só.");
    }
    if (f) L.push("", linhaPrazo(f, false).replace("os documentos que faltam", "os documentos assinados"));
    L.push("", TEL_MSG);
  } else if (tipo.k === "recebido") {
    L.push("", `Recebemos toda a documentação${$("cPaj").value.trim() ? " do seu PAJ" + pajTxt() : ""}. Seu PAJ foi encaminhado para análise.`);
    L.push("", "Não é preciso enviar mais nada agora. Se for preciso algum outro documento ou informação, a DPU entrará em contato com você.");
    L.push("", TEL_DUV);
    sis = "O(a) assistido(a) encaminhou toda a documentação pendente. Tramito ao grupo temático.";
  }
  const ass = DAC.assinaturaTexto();
  if (!ass) av.push("Escreva o seu nome, no item 3, para assinar a mensagem.");
  const txt = L.join("\n") + ass;
  $("msg").value = txt;
  $("zap").href = "https://wa.me/?text=" + encodeURIComponent(txt);
  $("aviso").innerHTML = av.length ? "<b>Falta:</b> " + av.join(" ") : "";
  $("sisBox").classList.toggle("hide", !sis); $("sis").value = sis;
  document.querySelectorAll(".okc").forEach(s => s.textContent = "");
}

function escolher(k) {
  tipo = TIPOS.find(o => o.k === k) || TIPOS[0];
  document.querySelectorAll("#tipos button").forEach(b => b.classList.toggle("on", b.dataset.k === tipo.k));
  document.querySelectorAll("#campos [data-c]").forEach(el => el.classList.toggle("hide", !tipo.c.includes(el.dataset.c)));
  $("cDataObs").textContent = tipo.k === "prazo" ? "" : "Opcional: se preencher, a mensagem lembra o prazo.";
  $("mTit").textContent = tipo.t.charAt(0) + tipo.t.slice(1).toLowerCase();
  $("mQuando").textContent = tipo.quando;
  $("mDica").textContent = tipo.dica;
  gerar();
}
document.querySelectorAll("#tipos button").forEach(b => b.addEventListener("click", () => escolher(b.dataset.k)));
document.querySelectorAll("#cPrazo button").forEach(b => b.addEventListener("click", () => {
  prazo = b.dataset.p; document.querySelectorAll("#cPrazo button").forEach(x => x.classList.toggle("on", x === b)); gerar();
}));
document.querySelectorAll("#cAnalf button").forEach(b => b.addEventListener("click", () => {
  analf = !!b.dataset.a; document.querySelectorAll("#cAnalf button").forEach(x => x.classList.toggle("on", x === b)); gerar();
}));
document.querySelectorAll("#campos input, #campos textarea").forEach(el => el.addEventListener(el.type === "checkbox" || el.type === "date" ? "change" : "input", gerar));
$("cData").addEventListener("input", gerar);
function copiar(ta, ok) {
  let feito = false;
  try { ta.focus(); ta.select(); feito = document.execCommand("copy"); } catch (e) {}
  if (!feito && navigator.clipboard) navigator.clipboard.writeText(ta.value).then(() => { ok.textContent = "Copiado!"; }).catch(() => { ok.textContent = "Não deu para copiar: selecione o texto e use Ctrl+C."; });
  else ok.textContent = feito ? "Copiado! Cole no WhatsApp (Ctrl+V)." : "Não deu para copiar: selecione o texto e use Ctrl+C.";
}
document.querySelectorAll("button[data-copia]").forEach(b => b.addEventListener("click", () => copiar($(b.dataset.copia), b.parentNode.querySelector(".okc"))));
$("zap").addEventListener("click", () => { $("zap").href = "https://wa.me/?text=" + encodeURIComponent($("msg").value); });
DAC.montarAssinatura($("assBox"), gerar);
escolher((location.hash || "").slice(1) || "prazo");
</script>
</body>
</html>
"""

comum = open(RAIZ + "comum/comum.js", encoding="utf-8").read()
import re
css_ass = re.search(r"const CSS_ASS = `(.*?)`;", comum, re.S).group(1)
out = HTML.replace("__CSS_ASS__", css_ass).replace("__COMUM__", comum)
assert "__" + "COMUM__" not in out
arq = RAIZ + "mensagens/Mensagens_DAC.html"
open(arq, "w", encoding="utf-8").write(out)
print(arq, len(out.encode()) // 1024, "KB")
